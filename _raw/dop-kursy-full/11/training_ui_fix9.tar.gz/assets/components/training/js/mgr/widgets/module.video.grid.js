Training.grid.ModuleVideos = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;
    this.sm = new Ext.grid.CheckboxSelectionModel();

    Ext.applyIf(config, {
        id: 'training-grid-module-videos',
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/module/videos/getlist',
            module_id: this.moduleId
        },
        sm: this.sm,
        fields: [
            'id','module_id','quality','mime','file_path','width','height','bitrate','filesize','is_default','is_active'
        ],
        paging: true,
        remoteSort: true,
        sortBy: 'id',
        sortDir: 'ASC',
        autoHeight: true,
        anchor: '100%',
        multi_select: true,
        save_action: 'mgr/module/video/update',
        columns: [this.sm, {
            header: 'ID', dataIndex: 'id', width: 60
        }, {
            header: 'Качество', dataIndex: 'quality', width: 90
        }, {
            header: 'MIME', dataIndex: 'mime', width: 140
        }, {
            header: 'Файл', dataIndex: 'file_path', width: 360, renderer: Training.utils.renderFileLink
        }, {
            header: 'Размер', dataIndex: 'filesize', width: 100, renderer: Training.utils.renderBytes
        }, {
            header: 'Разрешение', dataIndex: 'width', width: 110,
            renderer: function(value, meta, rec) {
                return (rec.data.width || 0) + '×' + (rec.data.height || 0);
            }
        }, {
            header: 'Битрейт', dataIndex: 'bitrate', width: 80
        }, {
            header: 'По умолчанию', dataIndex: 'is_default', width: 110, renderer: Training.utils.renderBoolean
        }, {
            header: 'Активен', dataIndex: 'is_active', width: 90, renderer: Training.utils.renderBoolean
        }],
        tbar: [{
            text: 'Сгенерировать из исходника', handler: this.transcodeFromSource, scope: this
        }, '-', {
            text: 'Добавить видео', handler: this.createVideo, scope: this
        }, '-', {
            text: 'Изменить', handler: function(){ this.updateVideo(); }, scope: this
        }, {
            text: 'Удалить', handler: function(){ this.removeVideo(); }, scope: this
        }, '->', {
            text: 'Обновить', handler: function(){ this.refresh(); }, scope: this
        }],
        listeners: {
            rowdblclick: {
                fn: function(grid, rowIndex) {
                    var rec = grid.store.getAt(rowIndex);
                    if (rec) {
                        this.updateVideo(rec);
                    }
                },
                scope: this
            },
            rowcontextmenu: {
                fn: function(grid, rowIndex, e) {
                    var row = grid.store.getAt(rowIndex);
                    if (!row) {
                        return;
                    }
                    grid.getSelectionModel().selectRow(rowIndex);
                    this.menu.record = row.data || row;
                    this.getMenu(grid, rowIndex, e);
                    if (this.menu) {
                        this.menu.showAt(e.getXY());
                    }
                    e.stopEvent();
                },
                scope: this
            }
        }
    });

    Training.grid.ModuleVideos.superclass.constructor.call(this, config);
};

Ext.extend(Training.grid.ModuleVideos, MODx.grid.Grid, {
    getSelectedVideoIds: function() {
        var ids = [];
        var sm = this.getSelectionModel ? this.getSelectionModel() : this.sm;
        if (sm && sm.getSelections) {
            Ext.each(sm.getSelections(), function(rec) {
                var id = parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0;
                if (id) {
                    ids.push(id);
                }
            });
        }
        if (!ids.length && this.menu && this.menu.record) {
            var menuId = parseInt(Training.utils.getRecordValue(this.menu.record, 'id'), 10) || 0;
            if (menuId) {
                ids.push(menuId);
            }
        }
        return ids;
    },

    getSingleSelectedVideo: function() {
        var sm = this.getSelectionModel ? this.getSelectionModel() : this.sm;
        if (sm && sm.getSelected) {
            var selected = sm.getSelected();
            if (selected) {
                return selected;
            }
        }
        if (this.menu && this.menu.record) {
            return this.menu.record;
        }
        var ids = this.getSelectedVideoIds();
        if (!ids.length || !this.store) {
            return null;
        }
        var rec = null;
        if (this.store.each) {
            var wanted = parseInt(ids[0], 10) || 0;
            this.store.each(function(item) {
                if (!rec && parseInt(item.get('id'), 10) === wanted) {
                    rec = item;
                }
            });
        }
        return rec;
    },

    transcodeFromSource: function() {
        var form = Ext.getCmp('training-module-general-form');
        var values = form ? form.getForm().getValues() : {};
        this.getEl().mask('Генерируем видео...');
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/module/video/transcode',
                module_id: this.moduleId,
                source_video: values.source_video || ''
            },
            listeners: {
                success: {fn: function(){
                    this.getEl().unmask();
                    this.refresh();
                    var slidesGrid = Ext.getCmp('training-grid-module-slides');
                    if (slidesGrid) { slidesGrid.refresh(); }
                    var general = Ext.getCmp('training-module-general-form');
                    if (general && general.loadModule) { general.loadModule(); }
                    MODx.msg.alert('Готово', 'Варианты видео созданы');
                }, scope: this},
                failure: {fn: function(r){
                    this.getEl().unmask();
                    MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось обработать видео');
                }, scope: this}
            }
        });
    },

    createVideo: function() {
        var w = MODx.load({
            xtype: 'training-window-module-video',
            title: 'Добавить видео',
            baseParams: {action: 'mgr/module/video/create'},
            moduleId: this.moduleId,
            listeners: {success: {fn: function(){ this.refresh(); }, scope: this}}
        });
        w.setValues({module_id: this.moduleId, is_default: 0, is_active: 1, mime: 'video/mp4'});
        w.show();
    },

    updateVideo: function(rec) {
        rec = rec || this.getSingleSelectedVideo();
        if (!rec) {
            MODx.msg.alert('Внимание', 'Выбери одно видео для редактирования');
            return false;
        }
        var data = rec.data || rec;
        var w = MODx.load({
            xtype: 'training-window-module-video',
            title: 'Изменить видео',
            baseParams: {action: 'mgr/module/video/update'},
            moduleId: this.moduleId,
            listeners: {success: {fn: function(){ this.menu.record = null; this.refresh(); }, scope: this}}
        });
        w.show();
        w.setValues(data);
    },

    removeVideo: function(rec) {
        var ids = rec ? [Training.utils.getRecordValue(rec, 'id')] : this.getSelectedVideoIds();
        ids = Ext.filter(ids, function(item){ return !!parseInt(item, 10); });
        if (!ids.length) {
            MODx.msg.alert('Внимание', 'Выбери видео для удаления');
            return false;
        }
        MODx.msg.confirm({
            title: 'Удаление',
            text: ids.length > 1 ? 'Удалить выбранные видео?' : 'Удалить привязку видео?',
            url: Training.config.connector_url,
            params: {action: 'mgr/module/video/remove', ids: ids.join(',')},
            listeners: {success: {fn: function(){ this.menu.record = null; this.refresh(); }, scope: this}}
        });
    },

    getMenu: function(grid, rowIndex) {
        var rec = null;
        if (typeof rowIndex !== 'undefined' && grid && grid.getStore) {
            rec = grid.getStore().getAt(rowIndex);
        }
        rec = rec || this.getSingleSelectedVideo();
        if (!rec) {
            return false;
        }
        this.menu.record = rec.data || rec;
        this.addContextMenuItem([{
            text: 'Изменить', handler: function(){ this.updateVideo(rec); }, scope: this
        }, {
            text: 'Удалить', handler: function(){ this.removeVideo(rec); }, scope: this
        }, '-', {
            text: 'Открыть видео', handler: function(){
                var path = Training.utils.getRecordValue(rec, 'file_path');
                if (path) { window.open(Training.utils.normalizeLink(path), '_blank'); }
            }, scope: this
        }]);
        return true;
    }
});

Ext.reg('training-grid-module-videos', Training.grid.ModuleVideos);

/* window class сохранён из fix8 */
