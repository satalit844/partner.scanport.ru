Training.combo.CourseSlides = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;

    Ext.applyIf(config, {
        hiddenName: config.name || 'image_selector',
        name: config.name || 'image_selector',
        fieldLabel: config.fieldLabel || 'Слайд из папки курса',
        valueField: 'path',
        displayField: 'path',
        editable: false,
        forceSelection: true,
        minChars: 1,
        pageSize: 20,
        triggerAction: 'all',
        mode: 'remote',
        anchor: '100%',
        emptyText: 'Выбрать слайд из папки курса',
        store: new Ext.data.JsonStore({
            url: Training.config.connector_url,
            root: 'results',
            totalProperty: 'total',
            idProperty: 'path',
            fields: ['path', 'name', 'filename', 'slide_no', 'dir'],
            baseParams: { action: 'mgr/module/slide/available', module_id: this.moduleId }
        })
    });

    Training.combo.CourseSlides.superclass.constructor.call(this, config);
};
Ext.extend(Training.combo.CourseSlides, MODx.combo.ComboBox);
Ext.reg('training-combo-course-slides', Training.combo.CourseSlides);

Training.grid.ModuleSlides = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;
    this.sm = new Ext.grid.CheckboxSelectionModel();

    Ext.applyIf(config, {
        id: 'training-grid-module-slides',
        url: Training.config.connector_url,
        baseParams: { action: 'mgr/module/slides/getlist', module_id: this.moduleId },
        sm: this.sm,
        fields: ['id','module_id','slide_no','image','timecode_ms','timecode_human','is_active'],
        paging: true,
        remoteSort: true,
        sortBy: 'slide_no',
        sortDir: 'ASC',
        autoHeight: true,
        anchor: '100%',
        multi_select: true,
        columns: [this.sm, {header: 'ID', dataIndex: 'id', width: 60}, {header: '№ слайда', dataIndex: 'slide_no', width: 90}, {header: 'Превью', dataIndex: 'image', width: 110, renderer: Training.utils.renderSlidePreview}, {header: 'Изображение', dataIndex: 'image', width: 380, renderer: Training.utils.renderFileLink}, {header: 'Таймкод', dataIndex: 'timecode_human', width: 100}, {header: 'Активен', dataIndex: 'is_active', width: 90, renderer: Training.utils.renderBoolean}],
        tbar: [{text: 'Добавить слайд', handler: this.createSlide, scope: this}, '-', {text: 'Изменить', handler: function(){ this.updateSlide(); }, scope: this}, {text: 'Удалить', handler: function(){ this.removeSlide(); }, scope: this}, '-', {text: 'Импортировать из папки курса', handler: this.importSlides, scope: this}, {text: 'Авторасставить таймкоды', handler: this.autoTimecodes, scope: this}, '->', {text: 'Обновить', handler: function(){ this.refresh(); }, scope: this}],
        listeners: {
            rowdblclick: {fn: function(grid, rowIndex){ var rec = grid.store.getAt(rowIndex); if (rec) { this.updateSlide(rec); } }, scope: this},
            rowcontextmenu: {fn: function(grid, rowIndex, e){
                var row = grid.store.getAt(rowIndex);
                if (!row) { return; }
                grid.getSelectionModel().selectRow(rowIndex);
                this.menu.record = row.data || row;
                this.getMenu(grid, rowIndex, e);
                if (this.menu) { this.menu.showAt(e.getXY()); }
                e.stopEvent();
            }, scope: this}
        }
    });

    Training.grid.ModuleSlides.superclass.constructor.call(this, config);
};

Ext.extend(Training.grid.ModuleSlides, MODx.grid.Grid, {
    getSelectedSlideIds: function() {
        var ids = [];
        var sm = this.getSelectionModel ? this.getSelectionModel() : this.sm;
        if (sm && sm.getSelections) {
            Ext.each(sm.getSelections(), function(rec){
                var id = parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0;
                if (id) { ids.push(id); }
            });
        }
        if (!ids.length && this.menu && this.menu.record) {
            var menuId = parseInt(Training.utils.getRecordValue(this.menu.record, 'id'), 10) || 0;
            if (menuId) { ids.push(menuId); }
        }
        return ids;
    },

    getSingleSelectedSlide: function() {
        var sm = this.getSelectionModel ? this.getSelectionModel() : this.sm;
        if (sm && sm.getSelected) {
            var selected = sm.getSelected();
            if (selected) { return selected; }
        }
        if (this.menu && this.menu.record) { return this.menu.record; }
        var ids = this.getSelectedSlideIds();
        if (!ids.length || !this.store) { return null; }
        var rec = null;
        if (this.store.each) {
            var wanted = parseInt(ids[0], 10) || 0;
            this.store.each(function(item){ if (!rec && parseInt(item.get('id'), 10) === wanted) { rec = item; } });
        }
        return rec;
    },

    createSlide: function() {
        var w = MODx.load({ xtype: 'training-window-module-slide', title: 'Добавить слайд', baseParams: {action: 'mgr/module/slide/create'}, moduleId: this.moduleId, listeners: {success: {fn: function(){ this.refresh(); }, scope: this}} });
        w.setValues({ module_id: this.moduleId, slide_no: '', timecode_ms: 0, is_active: 1 });
        w.show();
    },

    updateSlide: function(rec) {
        rec = rec || this.getSingleSelectedSlide();
        if (!rec) {
            MODx.msg.alert('Внимание', 'Выбери один слайд для редактирования');
            return false;
        }
        var data = rec.data || rec;
        var w = MODx.load({ xtype: 'training-window-module-slide', title: 'Изменить слайд', baseParams: {action: 'mgr/module/slide/update'}, moduleId: this.moduleId, listeners: {success: {fn: function(){ this.menu.record = null; this.refresh(); }, scope: this}} });
        w.show();
        w.setValues(data);
    },

    removeSlide: function(rec) {
        var ids = rec ? [Training.utils.getRecordValue(rec, 'id')] : this.getSelectedSlideIds();
        ids = Ext.filter(ids, function(item){ return !!parseInt(item, 10); });
        if (!ids.length) {
            MODx.msg.alert('Внимание', 'Выбери слайды для удаления');
            return false;
        }
        MODx.msg.confirm({ title: 'Удаление', text: ids.length > 1 ? 'Удалить выбранные слайды?' : 'Удалить привязку слайда?', url: Training.config.connector_url, params: {action: 'mgr/module/slide/remove', ids: ids.join(',')}, listeners: {success: {fn: function(){ this.menu.record = null; this.refresh(); }, scope: this}} });
    },

    importSlides: function() {
        MODx.Ajax.request({ url: Training.config.connector_url, params: {action: 'mgr/module/slide/import', module_id: this.moduleId}, listeners: { success: {fn: function(r){ this.refresh(); var message = 'Импорт завершён'; if (r && r.object && typeof r.object.created !== 'undefined') { message += '. Добавлено: ' + r.object.created; } MODx.msg.alert('Готово', message); }, scope: this }, failure: {fn: function(r){ MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось импортировать слайды'); }, scope: this } } });
    },

    autoTimecodes: function() {
        this.getEl().mask('Расставляем таймкоды...');
        MODx.Ajax.request({ url: Training.config.connector_url, params: {action: 'mgr/module/slide/autotimecodes', module_id: this.moduleId}, listeners: { success: {fn: function(r){ this.getEl().unmask(); this.refresh(); var form = Ext.getCmp('training-module-general-form'); if (form && form.loadModule) { form.loadModule(); } var message = 'Таймкоды расставлены'; if (r && r.object && typeof r.object.updated !== 'undefined') { message += '. Обновлено слайдов: ' + r.object.updated; } MODx.msg.alert('Готово', message); }, scope: this }, failure: {fn: function(r){ this.getEl().unmask(); MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось расставить таймкоды'); }, scope: this } } });
    },

    getMenu: function(grid, rowIndex) {
        var rec = null;
        if (typeof rowIndex !== 'undefined' && grid && grid.getStore) {
            rec = grid.getStore().getAt(rowIndex);
        }
        rec = rec || this.getSingleSelectedSlide();
        if (!rec) { return false; }
        this.menu.record = rec.data || rec;
        this.addContextMenuItem([{ text: 'Изменить', handler: function(){ this.updateSlide(rec); }, scope: this }, { text: 'Удалить', handler: function(){ this.removeSlide(rec); }, scope: this }, '-', { text: 'Открыть слайд', handler: function(){ var image = Training.utils.getRecordValue(rec, 'image'); if (image) { window.open(Training.utils.normalizeLink(image), '_blank'); } }, scope: this }]);
        return true;
    }
});

Ext.reg('training-grid-module-slides', Training.grid.ModuleSlides);

/* window class сохранён из fix8 */
