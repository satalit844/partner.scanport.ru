<div class="section-block tests-block">
    <div class="page-content d-flex flex-column h-100">
        <div class="test-card position-relative w-100 d-flex flex-column">
            <div class="test-header mb-4">
                <img src="theme/images/training/tests/logo-scanport.svg" alt="Сканпорт" class="img-svg">
            </div>
            <div class="test-content-list text-left mb-auto">
                <div class="test-title mb-4">{$instruction_title}</div>
                {$activity_instruction_block}
                {$activity_meta_html}
            </div>
            <div class="test-footer d-flex flex-wrap align-items-center justify-content-between gap-2 gap-sm-4">
                {$back_button_html}
                {$primary_action_html}
            </div>
        </div>
    </div>
</div>
