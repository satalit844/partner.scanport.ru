/* Демо-данные для теста и практики */

UPDATE `modx_partnerstraining_test_links`
SET `usertest_test_id` = 1
WHERE `id` = 1 AND `link_type` = 'test';

UPDATE `modx_partnerstraining_test_links`
SET `usertest_test_id` = 2
WHERE `id` = 2 AND `link_type` = 'practice';

/* очищаем демо-тест */
DELETE FROM `modx_partnersusertest_test_question_link` WHERE `test_id` IN (1,2);
DELETE FROM `modx_partnersusertest_answers` WHERE `question_id` IN (1001,1002,1003,1004);
DELETE FROM `modx_partnersusertest_questions` WHERE `id` IN (1001,1002,1003,1004);

/* тест */
REPLACE INTO `modx_partnersusertest_tests`
(`id`,`name`,`description`,`count_questions`,`count_questions_on_page`,`count_test_answer`,`time_test`,`type`,`use_category`,`active`,`customer`,`appeal`,`instruction`,`use_block_q_number`,`pub_date`,`unpub_date`,`variant_set_id`,`test_type`,`ask_user_data`)
VALUES
(1,'Демо тест DataMobile','<p>Демо-тест по материалам курса внедрения DataMobile.</p>',4,1,1,600,1,0,1,'<p></p>','<p></p>','<p>Перед ответом внимательно прочитайте текст вопроса. Затем выберите правильный вариант ответа. В некоторых вопросах может быть несколько правильных ответов. Нажимайте «Ответить» для подтверждения ответа.</p>',1,0,0,NULL,1,0);

/* вопросы */
REPLACE INTO `modx_partnersusertest_questions`
(`id`,`menuindex`,`test_id`,`parent`,`category_id`,`question`,`type`,`type_file`,`file`,`extended`,`max_point`,`random_answer`,`validate`)
VALUES
(1001,0,1,0,NULL,'Какой функционал отсутствует в ПО DataMobile?',1,NULL,'','',10,0,0),
(1002,1,1,0,NULL,'Какого модуля ПО DataMobile не существует на текущий момент?',1,NULL,'','',10,0,0),
(1003,2,1,0,NULL,'С каким вариантом запуска 1С не сможем работать ПО DataMobile?',1,NULL,'','',10,0,0),
(1004,3,1,0,NULL,'Какого функционала нет в личном кабинете DM Cloud?',1,NULL,'','',10,0,0);

/* ответы */
REPLACE INTO `modx_partnersusertest_answers`
(`id`,`menuindex`,`question_id`,`answer`,`type_file`,`file`,`point`,`right`)
VALUES
(2001,0,1001,'Работа с маркировкой ЧЗ',NULL,'',0,0),
(2002,1,1001,'Работа с товарами ЕГАИС',NULL,'',0,0),
(2003,2,1001,'Работа с серийными товарами',NULL,'',0,0),
(2004,3,1001,'Работа с основными средствами',NULL,'',10,1),
(2005,4,1001,'Работа с упаковочными листами',NULL,'',0,0),
(2006,5,1001,'Работа с адресным хранением',NULL,'',0,0),

(2007,0,1002,'Маркировка',NULL,'',0,0),
(2008,1,1002,'ЕГАИС',NULL,'',0,0),
(2009,2,1002,'RFID',NULL,'',0,0),
(2010,3,1002,'Конструктор',NULL,'',10,1),

(2011,0,1003,'RDP',NULL,'',0,0),
(2012,1,1003,'VPN',NULL,'',0,0),
(2013,2,1003,'Толстый клиент',NULL,'',0,0),
(2014,3,1003,'Облачная база',NULL,'',0,0),
(2015,4,1003,'Сервис 1С фреш',NULL,'',0,0),
(2016,5,1003,'Все варианты возможны',NULL,'',10,1),

(2017,0,1004,'Настройка самого ЛК и уведомлений',NULL,'',0,0),
(2018,1,1004,'Активация сертификата на подписку',NULL,'',0,0),
(2019,2,1004,'Назначение лицензий на устройство',NULL,'',0,0),
(2020,3,1004,'Синхронизация настроек устройств',NULL,'',0,0),
(2021,4,1004,'Настройка шаблонов штрихкодов',NULL,'',10,1),
(2022,5,1004,'Выдача пробной триал лицензии',NULL,'',0,0);

/* связи тест-вопрос */
REPLACE INTO `modx_partnersusertest_test_question_link`
(`id`,`menuindex`,`test_id`,`question_id`)
VALUES
(3001,0,1,1001),
(3002,1,1,1002),
(3003,2,1,1003),
(3004,3,1,1004);

/* практика — отдельный источник, чтобы не конфликтовать со статусами теста */
REPLACE INTO `modx_partnersusertest_tests`
(`id`,`name`,`description`,`count_questions`,`count_questions_on_page`,`count_test_answer`,`time_test`,`type`,`use_category`,`active`,`customer`,`appeal`,`instruction`,`use_block_q_number`,`pub_date`,`unpub_date`,`variant_set_id`,`test_type`,`ask_user_data`)
VALUES
(2,'Практическое задание DataMobile','<p>Можно ли интегрировать ПО DataMobile в SAP, Navision или другие системы не 1С и если да, то как?</p>',0,1,1,0,1,0,1,'<p></p>','<p></p>','<p>Опишите вариант интеграции, укажите общую схему обмена и какие данные должны передаваться между системой и DataMobile.</p>',1,0,0,NULL,1,0);

/* если ранее уже были статусы практики на test_id=1, переносим их на test_id=2 только для not_started */
UPDATE `modx_partnerstraining_user_test_status`
SET `usertest_test_id` = 2
WHERE `module_id` = 1 AND `usertest_test_id` = 1 AND `status` = 'not_started' AND `user_id` NOT IN (
    SELECT `t`.`user_id`
    FROM (
        SELECT `user_id`
        FROM `modx_partnerstraining_user_test_status`
        WHERE `module_id` = 1 AND `usertest_test_id` = 2
    ) AS `t`
);