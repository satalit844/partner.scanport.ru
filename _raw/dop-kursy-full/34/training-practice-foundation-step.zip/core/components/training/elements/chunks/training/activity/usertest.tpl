{if $.get.activity is integer}
    {set $activityId = $.get.activity}
{else}
    {set $activityId = 0}
{/if}
{if $.get.back is integer}
    {set $backId = $.get.back}
{else}
    {set $backId = 0}
{/if}

{set $isPractice = false}
{if $_modx->resource.id == (('training.training_practice_resource_id' | config) ?: 176)}
    {set $isPractice = true}
{/if}

{set $backUrl = $backId ? $_modx->makeUrl($backId) : ''}
{set $restartUrl = $_modx->makeUrl($_modx->resource.id,'',['activity' => $activityId, 'back' => $backId, 'step' => 'start', 'reset' => 1])}
{set $formUrl = $_modx->makeUrl($_modx->resource.id,'',['activity' => $activityId, 'back' => $backId])}

{set $scorePercent = 0}
{if $max_point > 0}
    {set $scorePercent = (($test_point / $max_point) * 100) | round : 0}
{/if}

<div class="section-block tests-block{if $curStep == 'finish'} results-block{/if}">
    <div class="page-content d-flex flex-column h-100">
        <div class="test-card position-relative w-100 d-flex flex-column">
            <div class="test-header d-flex align-items-center justify-content-between mb-4">
                <img src="theme/images/training/tests/logo-scanport.svg" alt="Сканпорт" class="img-svg">
                {if $curStep != 'finish'}
                    <button type="button" class="btn btn-list-test mt-2 d-flex d-md-none">
                        <img src="theme/images/training/tests/list-ico.svg" class="img-svg">
                        <span>Список вопросов</span>
                    </button>
                {/if}
            </div>

            {if $curStep == 'finish'}
                <div class="test-content-list text-left mb-auto">
                    {if $result_status == 3}
                        <div class="test-question d-flex align-items-center gap-2 gap-lg-3 mb-4">
                            <img src="theme/images/training/tests/list-ico.svg" class="img-svg"><span>Результат отправлен на проверку</span>
                        </div>
                        <div class="test-result-list d-flex flex-column gap-3 mb-4">
                            <div class="test-result-item">
                                <div class="result-label">Статус:</div>
                                <div class="result-value">На проверке</div>
                            </div>
                            <div class="test-result-item">
                                <div class="result-label">Набрано:</div>
                                <div class="result-value">{$scorePercent}% ({$test_point} баллов)</div>
                            </div>
                        </div>
                    {elseif $isPractice}
                        <div class="test-question d-flex align-items-center gap-2 gap-lg-3 mb-4">
                            {if $var_passed}
                                <img src="theme/images/training/tests/circle-check-big.svg" class="img-svg"><span>Задание принято</span>
                            {else}
                                <img src="theme/images/training/tests/circle-x.svg" class="img-svg"><span>Задание не принято</span>
                            {/if}
                        </div>
                        <div class="test-result-list d-flex flex-column gap-3 mb-4">
                            <div class="test-result-item">
                                <div class="result-label">Набрано:</div>
                                <div class="result-value">{$scorePercent}% ({$test_point} баллов)</div>
                            </div>
                            {if $_modx->getPlaceholder('training_activity_min_pass_percent')}
                                <div class="test-result-item">
                                    <div class="result-label">Проходной балл:</div>
                                    <div class="result-value">{$_modx->getPlaceholder('training_activity_min_pass_percent')}%</div>
                                </div>
                            {/if}
                        </div>
                    {else}
                        <div class="test-question d-flex align-items-center gap-2 gap-lg-3 mb-4 ">
                            {if $var_passed}
                                <img src="theme/images/training/tests/circle-check-big.svg" class="img-svg"><span>Вы прошли тест</span>
                            {else}
                                <img src="theme/images/training/tests/circle-x.svg" class="img-svg"><span>Вы не прошли тест</span>
                            {/if}
                        </div>
                        <div class="test-result-list d-flex flex-column gap-3 mb-4">
                            <div class="test-result-item">
                                <div class="result-label">Набрано:</div>
                                <div class="result-value">{$scorePercent}% ({$test_point} баллов)</div>
                            </div>
                            {if $_modx->getPlaceholder('training_activity_min_pass_percent')}
                                <div class="test-result-item">
                                    <div class="result-label">Проходной балл:</div>
                                    <div class="result-value">{$_modx->getPlaceholder('training_activity_min_pass_percent')}%</div>
                                </div>
                            {/if}
                        </div>
                    {/if}
                </div>
                <div class="test-footer d-flex flex-wrap align-items-center justify-content-end gap-2 gap-sm-4">
                    {if !$isPractice || !$var_passed}
                        <a href="{$restartUrl}" class="btn btn-test btn-reload-test col-auto text-decoration-none">
                            <img src="theme/images/training/tests/rotate-ccw.svg" class="img-svg d-block d-sm-none">
                            <span>{if $isPractice}Выполнить задание заново{else}Пройти тест заново{/if}</span>
                            <img src="theme/images/training/tests/arrow-rotate-ico.svg" class="img-svg d-none d-sm-block">
                        </a>
                    {/if}
                    {if $backUrl}
                        <a href="{$backUrl}" class="btn btn-test col-auto text-decoration-none">
                            <span>Закрыть</span>
                            <img src="theme/images/training/tests/arrow-right-ico.svg" class="img-svg d-none d-sm-block">
                        </a>
                    {/if}
                </div>
            {else}
                <form id="UserTestForm" action="{$formUrl}" method="post">
                    <input type="hidden" name="test_id" value="{$test_id}">
                    <input type="hidden" name="step" id="next_step" value="{$nextStep}">
                    <input type="hidden" name="answer_step" id="answer_step" value="{$curStep}">

                    <div class="test-content-list text-left mb-4">
                        {foreach $questions as $q}
                            <div class="test-question mb-4">{$q.question}</div>
                            <div class="test-answer d-flex flex-column gap-3">
                                {if $q.type == 1 || $q.type == 12}
                                    {foreach $q.answers as $a}
                                        <div class="form-label">
                                            <label class="custom-radio-test">
                                                <input type="radio" name="question[{$q.id}]" value="{$a.id}"{if $q.answer_id == $a.id} checked{/if}>
                                                <span class="radio-mark"></span>
                                                <div class="text-answer">{$a.answer}</div>
                                            </label>
                                        </div>
                                    {/foreach}
                                {elseif $q.type == 2}
                                    {foreach $q.answers as $a}
                                        <div class="form-label">
                                            <label class="custom-checkbox-test">
                                                <input type="checkbox" name="question[{$q.id}][]" value="{$a.id}"{if $a.check} checked{/if}>
                                                <span class="checkbox-mark"></span>
                                                <div class="text-answer">{$a.answer}</div>
                                            </label>
                                        </div>
                                    {/foreach}
                                {elseif $q.type == 3 || $q.type == 4}
                                    <div class="form-label">
                                        <input type="text" class="form-control" name="question[{$q.id}]" value="{$q.answer|escape}">
                                    </div>
                                {else}
                                    <div class="form-label">
                                        <div class="text-answer">Для этого типа вопроса нужна отдельная вёрстка UserTest.</div>
                                    </div>
                                {/if}
                            </div>
                        {/foreach}
                    </div>

                    <div class="test-footer d-flex flex-wrap align-items-center justify-content-between ">
                        <button type="button" class="btn btn-list-test col mb-2 mb-sm-0">
                            <img src="theme/images/training/tests/list-ico.svg" class="img-svg">
                            <span>Список вопросов</span>
                        </button>
                        <div class="text-info-test ms-auto me-4 col-auto mb-2 mb-sm-0">
                            <span class="d-none d-lg-inline-block">Набрано баллов</span>
                            <span> {$test_point} из {$max_point}</span>
                            <span class="balls-text d-block d-lg-none">Баллы</span>
                        </div>
                        {if $nextStep == 'finish'}
                            <button type="submit" class="btn btn-test col-auto">
                                <span>Завершить</span>
                                <img src="theme/images/training/tests/arrow-right-ico.svg" class="img-svg d-none d-sm-block">
                            </button>
                        {else}
                            <button type="submit" class="btn btn-test col-auto">
                                <span>Продолжить</span>
                                <img src="theme/images/training/tests/arrow-right-ico.svg" class="img-svg d-none d-sm-block">
                            </button>
                        {/if}
                    </div>
                </form>

                <div class="modal fade testListModal" id="testListModal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog testListModal__dialog modal-dialog-centered">
                        <div class="modal-content testListModal__content">
                            <button type="button" class="testListModal__close" data-bs-dismiss="modal" aria-label="Закрыть">
                                <img src="theme/images/training/tests/close-modal.svg" alt="Закрыть" class="img-svg">
                            </button>
                            <div class="testListModal__head">
                                <div class="testListModal__grid testListModal__grid--head">
                                    <div>Вопрос</div>
                                    <div>Статус</div>
                                    <div>Шаг</div>
                                </div>
                            </div>
                            <div class="testListModal__body">
                                <div class="testListModal__list">
                                    {foreach $block_q_number as $q}
                                        <div class="testListModal__row js-test-step" data-step="{$q.step}">
                                            <div class="testListModal__number">{$q.numberQ}</div>
                                            <div class="testListModal__question">Вопрос {$q.numberQ}</div>
                                            <div class="testListModal__result">{if $q.ansCheck}Заполнен{elseif $q.curStepCheck}Текущий{else}Не заполнен{/if}</div>
                                            <div class="testListModal__score">{$q.step}</div>
                                        </div>
                                    {/foreach}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <script>
                    (function () {
                        document.querySelectorAll('.js-test-step').forEach(function (row) {
                            row.addEventListener('click', function () {
                                var form = document.getElementById('UserTestForm');
                                var next = document.getElementById('next_step');
                                if (!form || !next) return;
                                next.value = this.getAttribute('data-step');
                                form.submit();
                            });
                        });
                    })();
                </script>
            {/if}
        </div>
    </div>
</div>
