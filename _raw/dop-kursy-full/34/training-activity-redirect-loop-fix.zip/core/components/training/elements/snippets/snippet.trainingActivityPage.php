<?php
/** @var modX $modx */
/** @var array $scriptProperties */

$corePath = $modx->getOption(
    'training.core_path',
    null,
    $modx->getOption('core_path') . 'components/training/'
);

require_once $corePath . 'model/training/training.class.php';
require_once $corePath . 'model/training/services/trainingprogress.class.php';

if (!function_exists('trainingActivityRenderChunk')) {
    function trainingActivityRenderChunk(modX $modx, $corePath, $relativePath, array $placeholders = array())
    {
        $path = rtrim(str_replace('\\', '/', (string)$corePath), '/') . '/elements/chunks/' . ltrim($relativePath, '/');
        if (!is_file($path)) {
            return '';
        }

        $content = (string)file_get_contents($path);
        if ($content === '') {
            return '';
        }

        $replace = array();
        foreach ($placeholders as $key => $value) {
            if (is_array($value) || is_object($value)) {
                $value = '';
            }
            $replace['{$' . $key . '}'] = (string)$value;
        }

        return strtr($content, $replace);
    }
}

if (!function_exists('trainingActivityEsc')) {
    function trainingActivityEsc($value)
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('trainingActivityMakeUrl')) {
    function trainingActivityMakeUrl(modX $modx, $resourceId, array $params = array(), $forRedirect = false)
    {
        $resourceId = (int)$resourceId;
        if ($resourceId <= 0) {
            return '';
        }

        $url = (string)$modx->makeUrl($resourceId, '', $params);
        if ($forRedirect) {
            $url = html_entity_decode($url, ENT_QUOTES, 'UTF-8');
            $url = str_replace('&amp;', '&', $url);
        }

        return $url;
    }
}

if (!function_exists('trainingActivityCurrentRequestUrl')) {
    function trainingActivityCurrentRequestUrl()
    {
        $uri = isset($_SERVER['REQUEST_URI']) ? (string)$_SERVER['REQUEST_URI'] : '';
        $uri = html_entity_decode($uri, ENT_QUOTES, 'UTF-8');
        return str_replace('&amp;', '&', $uri);
    }
}

if (!function_exists('trainingActivityRedirectIfNeeded')) {
    function trainingActivityRedirectIfNeeded(modX $modx, $url)
    {
        $url = trim((string)$url);
        if ($url === '') {
            return false;
        }

        $url = html_entity_decode($url, ENT_QUOTES, 'UTF-8');
        $url = str_replace('&amp;', '&', $url);
        $current = trainingActivityCurrentRequestUrl();

        if ($current === $url) {
            return false;
        }

        $modx->sendRedirect($url);
        return true;
    }
}

if (!function_exists('trainingActivityNow')) {
    function trainingActivityNow()
    {
        return date('Y-m-d H:i:s');
    }
}

if (!function_exists('trainingActivityNormalizeHtml')) {
    function trainingActivityNormalizeHtml($value)
    {
        return trim((string)$value);
    }
}

if (!function_exists('trainingActivityTableExists')) {
    function trainingActivityTableExists(modX $modx, $tableName)
    {
        $tableName = trim((string)$tableName);
        if ($tableName === '') {
            return false;
        }

        $stmt = $modx->prepare('SHOW TABLES LIKE ?');
        if (!$stmt) {
            return false;
        }

        $stmt->execute(array($tableName));
        return (bool)$stmt->fetchColumn();
    }
}

if (!function_exists('trainingActivityFormatDate')) {
    function trainingActivityFormatDate($value)
    {
        $value = trim((string)$value);
        if ($value === '' || $value === '0000-00-00 00:00:00') {
            return '';
        }

        $time = strtotime($value);
        if (!$time) {
            return $value;
        }

        return date('d.m.Y H:i', $time);
    }
}

if (!function_exists('trainingActivityGetRequestParam')) {
    function trainingActivityGetRequestParam($name, $default = null)
    {
        $name = (string)$name;
        if ($name === '') {
            return $default;
        }

        if (array_key_exists($name, $_GET)) {
            return $_GET[$name];
        }

        $ampName = 'amp;' . $name;
        if (array_key_exists($ampName, $_GET)) {
            return $_GET[$ampName];
        }

        $queryString = isset($_SERVER['QUERY_STRING']) ? (string)$_SERVER['QUERY_STRING'] : '';
        if ($queryString !== '') {
            $decoded = html_entity_decode($queryString, ENT_QUOTES, 'UTF-8');
            $parsed = array();
            parse_str($decoded, $parsed);

            if (array_key_exists($name, $parsed)) {
                return $parsed[$name];
            }
            if (array_key_exists($ampName, $parsed)) {
                return $parsed[$ampName];
            }
        }

        return $default;
    }
}



if (!function_exists('trainingActivityCollectCanonicalParams')) {
    function trainingActivityCollectCanonicalParams()
    {
        $allowed = array('activity', 'back', 'screen', 'step', 'tab', 'result_id', 'reset');
        $queryString = isset($_SERVER['QUERY_STRING']) ? (string)$_SERVER['QUERY_STRING'] : '';
        if ($queryString === '') {
            return array(false, array());
        }

        $decoded = html_entity_decode($queryString, ENT_QUOTES, 'UTF-8');
        $parsed = array();
        parse_str($decoded, $parsed);

        $clean = array();
        foreach ($allowed as $name) {
            if (array_key_exists($name, $parsed) && $parsed[$name] !== '') {
                $clean[$name] = $parsed[$name];
                continue;
            }

            $ampName = 'amp;' . $name;
            if (array_key_exists($ampName, $parsed) && $parsed[$ampName] !== '') {
                $clean[$name] = $parsed[$ampName];
            }
        }

        $needsRedirect = strpos($queryString, 'amp;') !== false || $decoded !== $queryString;
        return array($needsRedirect, $clean);
    }
}

if (!function_exists('trainingActivityFindStatusObject')) {
    function trainingActivityFindStatusObject(modX $modx, $courseId, $moduleId, $testId, $userId)
    {
        return $modx->getObject('TrainingUserTestStatus', array(
            'course_id' => (int)$courseId,
            'module_id' => (int)$moduleId,
            'usertest_test_id' => (int)$testId,
            'user_id' => (int)$userId,
        ));
    }
}

if (!function_exists('trainingActivityUpsertStatus')) {
    function trainingActivityUpsertStatus(modX $modx, $courseId, $moduleId, $testId, $userId, array $data)
    {
        $status = trainingActivityFindStatusObject($modx, $courseId, $moduleId, $testId, $userId);
        if (!$status) {
            $status = $modx->newObject('TrainingUserTestStatus');
            if (!$status) {
                return null;
            }
            $status->set('course_id', (int)$courseId);
            $status->set('module_id', (int)$moduleId);
            $status->set('usertest_test_id', (int)$testId);
            $status->set('user_id', (int)$userId);
        }

        foreach ($data as $key => $value) {
            $status->set($key, $value);
        }
        $status->save();

        return $status;
    }
}

if (!function_exists('trainingActivityGetProfileName')) {
    function trainingActivityGetProfileName(modX $modx, $userId)
    {
        $userId = (int)$userId;
        if ($userId <= 0) {
            return 'Система';
        }

        $user = $modx->getObject('modUser', $userId);
        if (!$user) {
            return 'Пользователь #' . $userId;
        }

        $profile = $user->getOne('Profile');
        if ($profile) {
            $fullName = trim((string)$profile->get('fullname'));
            if ($fullName !== '') {
                return $fullName;
            }
        }

        $username = trim((string)$user->get('username'));
        if ($username !== '') {
            return $username;
        }

        return 'Пользователь #' . $userId;
    }
}

if (!function_exists('trainingActivityGetPracticeAttempt')) {
    function trainingActivityGetPracticeAttempt(modX $modx, $attemptTable, $attemptId, $testLinkId, $userId)
    {
        $sql = 'SELECT * FROM `' . $attemptTable . '` WHERE `id` = :id AND `test_link_id` = :test_link_id AND `user_id` = :user_id LIMIT 1';
        $stmt = $modx->prepare($sql);
        $stmt->bindValue(':id', (int)$attemptId, PDO::PARAM_INT);
        $stmt->bindValue(':test_link_id', (int)$testLinkId, PDO::PARAM_INT);
        $stmt->bindValue(':user_id', (int)$userId, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row ? $row : null;
    }
}

if (!function_exists('trainingActivityGetPracticeAttempts')) {
    function trainingActivityGetPracticeAttempts(modX $modx, $attemptTable, $testLinkId, $userId)
    {
        $sql = 'SELECT * FROM `' . $attemptTable . '` WHERE `test_link_id` = :test_link_id AND `user_id` = :user_id ORDER BY `attempt_no` DESC, `id` DESC';
        $stmt = $modx->prepare($sql);
        $stmt->bindValue(':test_link_id', (int)$testLinkId, PDO::PARAM_INT);
        $stmt->bindValue(':user_id', (int)$userId, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

if (!function_exists('trainingActivityCreatePracticeAttempt')) {
    function trainingActivityCreatePracticeAttempt(modX $modx, $attemptTable, $testLinkId, $courseId, $moduleId, $userId, $attemptNo, $title)
    {
        $sql = 'INSERT INTO `' . $attemptTable . '` (`test_link_id`,`course_id`,`module_id`,`user_id`,`attempt_no`,`status`,`title`,`createdon`,`updatedon`) VALUES (:test_link_id,:course_id,:module_id,:user_id,:attempt_no,:status,:title,:createdon,:updatedon)';
        $stmt = $modx->prepare($sql);
        $now = trainingActivityNow();
        $stmt->execute(array(
            ':test_link_id' => (int)$testLinkId,
            ':course_id' => (int)$courseId,
            ':module_id' => (int)$moduleId,
            ':user_id' => (int)$userId,
            ':attempt_no' => (int)$attemptNo,
            ':status' => 'draft',
            ':title' => (string)$title,
            ':createdon' => $now,
            ':updatedon' => $now,
        ));

        return (int)$modx->lastInsertId();
    }
}

if (!function_exists('trainingActivityInsertPracticeMessage')) {
    function trainingActivityInsertPracticeMessage(modX $modx, $messageTable, $attemptId, $userId, $senderRole, $message, $isSystem = 0)
    {
        $sql = 'INSERT INTO `' . $messageTable . '` (`attempt_id`,`user_id`,`sender_role`,`message`,`is_system`,`createdon`) VALUES (:attempt_id,:user_id,:sender_role,:message,:is_system,:createdon)';
        $stmt = $modx->prepare($sql);
        $stmt->execute(array(
            ':attempt_id' => (int)$attemptId,
            ':user_id' => (int)$userId,
            ':sender_role' => (string)$senderRole,
            ':message' => (string)$message,
            ':is_system' => (int)$isSystem,
            ':createdon' => trainingActivityNow(),
        ));
    }
}

if (!function_exists('trainingActivityGetPracticeMessages')) {
    function trainingActivityGetPracticeMessages(modX $modx, $messageTable, $attemptId)
    {
        $sql = 'SELECT * FROM `' . $messageTable . '` WHERE `attempt_id` = :attempt_id ORDER BY `id` ASC';
        $stmt = $modx->prepare($sql);
        $stmt->bindValue(':attempt_id', (int)$attemptId, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

if (!function_exists('trainingActivityUpdatePracticeAttemptStatus')) {
    function trainingActivityUpdatePracticeAttemptStatus(modX $modx, $attemptTable, $attemptId, $status)
    {
        $sql = 'UPDATE `' . $attemptTable . '` SET `status` = :status, `submittedon` = CASE WHEN :status_submitted = 1 AND (`submittedon` IS NULL OR `submittedon` = "0000-00-00 00:00:00") THEN :submittedon ELSE `submittedon` END, `updatedon` = :updatedon WHERE `id` = :id';
        $stmt = $modx->prepare($sql);
        $now = trainingActivityNow();
        $submitted = in_array($status, array('submitted', 'pending_review'), true) ? 1 : 0;
        $stmt->execute(array(
            ':status' => (string)$status,
            ':status_submitted' => $submitted,
            ':submittedon' => $now,
            ':updatedon' => $now,
            ':id' => (int)$attemptId,
        ));
    }
}

if (!function_exists('trainingActivityPracticeStatusMeta')) {
    function trainingActivityPracticeStatusMeta($status)
    {
        $status = trim((string)$status);
        switch ($status) {
            case 'accepted':
                return array('label' => 'Принято', 'class' => 'label-chip--green', 'key' => 'accepted');
            case 'rejected':
            case 'revision_requested':
                return array('label' => 'Не принято', 'class' => 'label-chip--red', 'key' => 'rejected');
            case 'submitted':
            case 'pending_review':
                return array('label' => 'На проверке', 'class' => 'label-chip--orange', 'key' => 'pending_review');
            case 'draft':
            case 'in_progress':
                return array('label' => 'В процессе', 'class' => 'label-chip--purple', 'key' => 'in_progress');
            default:
                return array('label' => 'Не начато', 'class' => 'label-chip--blue', 'key' => 'not_started');
        }
    }
}

$resourceId = (int)$modx->getOption('resource_id', $scriptProperties, $modx->resource ? $modx->resource->get('id') : 0);

list($needsCanonicalRedirect, $canonicalParams) = trainingActivityCollectCanonicalParams();
if ($resourceId > 0 && $needsCanonicalRedirect && !headers_sent()) {
    if (trainingActivityRedirectIfNeeded($modx, trainingActivityMakeUrl($modx, $resourceId, $canonicalParams, true))) {
        return '';
    }
}

$activityId = (int)trainingActivityGetRequestParam('activity', $modx->getOption('activity', $scriptProperties, 0));
$screen = trim((string)trainingActivityGetRequestParam('screen', $modx->getOption('screen', $scriptProperties, '')));
$backResourceId = (int)trainingActivityGetRequestParam('back', $modx->getOption('back', $scriptProperties, 0));
$tab = trim((string)trainingActivityGetRequestParam('tab', 'attempts'));
if (!in_array($tab, array('attempts', 'comments'), true)) {
    $tab = 'attempts';
}
$testPageId = (int)$modx->getOption('training.training_test_resource_id', null, 170);
$practicePageId = (int)$modx->getOption('training.training_practice_resource_id', null, 176);

if ($resourceId <= 0) {
    return '';
}

if (!$modx->user || !(int)$modx->user->get('id') || !$modx->user->isAuthenticated($modx->context->get('key'))) {
    return '';
}

$training = new Training($modx);
$service = new TrainingProgressService($modx, $training);
$userId = (int)$modx->user->get('id');

if ($activityId <= 0) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Активность не найдена',
        'message' => 'Не передан параметр активности.',
        'back_button_html' => '',
    ));
}

/** @var TrainingTestLink|null $activity */
$activity = $modx->getObject('TrainingTestLink', array('id' => $activityId));
if (!$activity) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Активность не найдена',
        'message' => 'Запрашиваемая активность не существует.',
        'back_button_html' => '',
    ));
}

$courseId = (int)$activity->get('course_id');
$moduleId = (int)$activity->get('module_id');
$testId = (int)$activity->get('usertest_test_id');
$linkType = $service->normalizeActivityLinkType($activity->get('link_type'));
$targetResourceId = $linkType === 'practice' ? $practicePageId : $testPageId;

if ($targetResourceId > 0 && $resourceId !== $targetResourceId) {
    $params = array('activity' => $activityId);
    if ($backResourceId > 0) {
        $params['back'] = $backResourceId;
    }
    if ($screen !== '') {
        $params['screen'] = $screen;
    }
    if ($tab !== 'attempts') {
        $params['tab'] = $tab;
    }
    $stepParam = trainingActivityGetRequestParam('step', null);
    if ($stepParam !== null && $stepParam !== '') {
        $params['step'] = trim((string)$stepParam);
    }
    $resultIdParam = trainingActivityGetRequestParam('result_id', null);
    if ($resultIdParam !== null && $resultIdParam !== '') {
        $params['result_id'] = (int)$resultIdParam;
    }
    $resetParam = trainingActivityGetRequestParam('reset', null);
    if ($resetParam !== null && $resetParam !== '') {
        $params['reset'] = 1;
    }
    if (trainingActivityRedirectIfNeeded($modx, trainingActivityMakeUrl($modx, $targetResourceId, $params, true))) {
        return '';
    }
}

/** @var TrainingCourse|null $course */
$course = $modx->getObject('TrainingCourse', array('id' => $courseId, 'is_active' => 1));
/** @var TrainingModule|null $module */
$module = $modx->getObject('TrainingModule', array('id' => $moduleId, 'course_id' => $courseId, 'is_active' => 1));
/** @var modResource|null $courseResource */
$courseResource = $course ? $modx->getObject('modResource', array('id' => (int)$course->get('resource_id'), 'deleted' => 0)) : null;

$backUrl = '';
if ($courseResource) {
    $backUrl = trainingActivityMakeUrl($modx, (int)$courseResource->get('id'));
}
if ($backResourceId > 0) {
    $backUrl = trainingActivityMakeUrl($modx, $backResourceId);
}
$backButtonHtml = $backUrl !== '' ? '<a href="' . trainingActivityEsc($backUrl) . '" class="btn btn-test col-auto text-decoration-none"><span>Назад к курсу</span><img src="theme/images/training/tests/arrow-rotate-ico.svg" class="img-svg d-none d-sm-block"></a>' : '';
$errorBackButtonHtml = $backUrl !== '' ? '<a href="' . trainingActivityEsc($backUrl) . '" class="btn btn-test col-auto text-decoration-none"><span>Вернуться</span><img src="theme/images/training/tests/arrow-right-ico.svg" class="img-svg d-none d-sm-block"></a>' : '';

if (!$course || !$module || !$courseResource) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Курс недоступен',
        'message' => 'Связанный курс или модуль не найдены.',
        'back_button_html' => $errorBackButtonHtml,
    ));
}

$service->syncUserCourseForUser($courseId, $userId);
if (!$service->hasCourseAccess($courseId, $userId)) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Нет доступа',
        'message' => 'У вас нет доступа к этой активности.',
        'back_button_html' => $errorBackButtonHtml,
    ));
}

if (!$service->canAccessModule($courseId, $moduleId, $userId)) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Активность заблокирована',
        'message' => 'Сначала завершите предыдущие обязательные модули курса.',
        'back_button_html' => $errorBackButtonHtml,
    ));
}

$moduleLessons = $service->getModuleLessons($moduleId, true, true);
$allLessonsCompleted = true;
foreach ($moduleLessons as $lesson) {
    $lessonProgress = $service->getLessonProgress($courseId, (int)$lesson->get('id'), $userId);
    if (!$lessonProgress || (int)$lessonProgress->get('completed') !== 1) {
        $allLessonsCompleted = false;
        break;
    }
}

$activityRows = $service->getModuleActivityRows($courseId, $moduleId, $userId);
$currentRow = null;
$previousRequiredActivitiesCompleted = true;
foreach ($activityRows as $row) {
    if ((int)$row['id'] === $activityId) {
        $currentRow = $row;
        break;
    }
    if (!empty($row['is_required']) && empty($row['completed'])) {
        $previousRequiredActivitiesCompleted = false;
    }
}

if (!$currentRow) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Активность не найдена',
        'message' => 'Эта активность не привязана к модулю.',
        'back_button_html' => $errorBackButtonHtml,
    ));
}

if (!$allLessonsCompleted || !$previousRequiredActivitiesCompleted) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Активность заблокирована',
        'message' => 'Сначала завершите все видеоуроки и обязательные активности этого модуля.',
        'back_button_html' => $errorBackButtonHtml,
    ));
}

if ($testId <= 0) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Активность не настроена',
        'message' => 'Для активности не выбран источник.',
        'back_button_html' => $errorBackButtonHtml,
    ));
}

$moduleTitle = '';
$moduleResource = $modx->getObject('modResource', array('id' => (int)$module->get('resource_id')));
if ($moduleResource) {
    $moduleTitle = trim((string)$moduleResource->get('pagetitle'));
}
if ($moduleTitle === '') {
    $moduleTitle = 'Модуль';
}

$title = trim((string)$currentRow['title']);
if ($title === '') {
    $title = trim((string)$moduleTitle);
}

$description = '';
$instructionHtml = '';
$testName = '';
$usertestCorePath = $modx->getOption('usertest_core_path', null, $modx->getOption('core_path') . 'components/usertest/');
$usertestModelPath = rtrim($usertestCorePath, '/\\') . '/model/';
if (is_dir($usertestModelPath)) {
    $modx->addPackage('usertest', $usertestModelPath);
    $test = $modx->getObject('UserTestTests', array('id' => $testId, 'active' => 1));
    if ($test) {
        $testName = trim((string)$test->get('name'));
        if ($title === '') {
            $title = $testName;
        }
        $description = trainingActivityNormalizeHtml($test->get('description'));
        $instructionHtml = trainingActivityNormalizeHtml($test->get('instruction'));
    }
}

$minPassPercent = (float)$activity->get('min_pass_percent');
$maxAttempts = (int)$activity->get('max_attempts');

$instructionUrl = trainingActivityMakeUrl($modx, $targetResourceId, array(
    'activity' => $activityId,
    'back' => $backResourceId,
    'screen' => 'instruction',
));
$runUrl = trainingActivityMakeUrl($modx, $targetResourceId, array(
    'activity' => $activityId,
    'back' => $backResourceId,
    'step' => 'start',
));
$restartUrl = trainingActivityMakeUrl($modx, $targetResourceId, array(
    'activity' => $activityId,
    'back' => $backResourceId,
    'step' => 'start',
    'reset' => 1,
));

$actionModeTitle = $linkType === 'practice' ? 'практическому заданию' : 'тесту';
$actionTypeLabel = $linkType === 'practice' ? 'Практическое задание' : 'Тест';
$actionStartButton = $linkType === 'practice' ? 'Начать задание' : 'Начать тест';
$actionContinueButton = $linkType === 'practice' ? 'Приступить к заданию' : 'Перейти к тесту';

$descriptionHtml = '';
if ($description !== '') {
    $descriptionHtml = '<p class="test-subtitle mt-2 mt-md-0">' . $description . '</p>';
} else {
    $descriptionHtml = '<p class="test-subtitle mt-2 mt-md-0">Нажмите «' . trainingActivityEsc($actionStartButton) . '», чтобы продолжить.</p>';
}

$attemptsText = '';
$attemptsHtml = '';
$instructionMetaHtml = '';
$primaryActionHtml = '<a href="' . trainingActivityEsc($instructionUrl) . '" class="btn btn-test col-auto text-decoration-none"><span>' . trainingActivityEsc($actionStartButton) . '</span><img src="theme/images/training/tests/arrow-right-ico.svg" class="img-svg d-none d-sm-block"></a>';

if ($linkType !== 'practice') {
    $status = $service->syncUserTestStatus($courseId, $moduleId, $testId, $userId);
    $currentStatus = $status ? trim((string)$status->get('status')) : 'not_started';
    $currentAttempts = $status ? (int)$status->get('attempts') : 0;
    $attemptsText = $maxAttempts > 0 ? ($currentAttempts . '/' . $maxAttempts) : '';
    if ($attemptsText !== '') {
        $attemptsHtml = '<div class="text-info-test mt-4 d-inline-flex gap-2 align-items-center"><span>Попытки</span><span>' . trainingActivityEsc($attemptsText) . '</span></div>';
    }
    if ($minPassPercent > 0) {
        $instructionMetaHtml .= '<div class="text-info-test mt-3">Проходной балл: ' . trainingActivityEsc(rtrim(rtrim(number_format($minPassPercent, 2, '.', ''), '0'), '.')) . '%</div>';
    }
    if ($attemptsText !== '') {
        $instructionMetaHtml .= '<div class="text-info-test mt-2">Попытки: ' . trainingActivityEsc($attemptsText) . '</div>';
    }

    $instructionTitle = 'Инструкция по прохождению теста';
    $instructionBlock = $instructionHtml !== ''
        ? '<div class="test-subtitle mb-4">' . $instructionHtml . '</div>'
        : '<ul class="test-list mb-5"><li>Перед ответом внимательно прочитайте текст вопроса</li><li>Затем выберите правильный вариант ответа. В некоторых вопросах может быть несколько правильных ответов</li><li>Нажмите кнопку <span>«Ответить»</span> для подтверждения ответа</li><li>Для просмотра и выбора вопросов используйте <span>список</span> вопросов</li></ul>';

    $commonPlaceholders = array(
        'instruction_title' => trainingActivityEsc($instructionTitle),
        'activity_type_title' => trainingActivityEsc($actionModeTitle),
        'module_title' => trainingActivityEsc($moduleTitle),
        'activity_description_html' => $descriptionHtml,
        'activity_attempts_html' => $attemptsHtml,
        'activity_instruction_block' => $instructionBlock,
        'activity_meta_html' => $instructionMetaHtml,
        'back_button_html' => $backButtonHtml,
        'primary_action_html' => $screen === 'instruction'
            ? '<a href="' . trainingActivityEsc($runUrl) . '" class="btn btn-test col-auto text-decoration-none"><span>' . trainingActivityEsc($actionContinueButton) . '</span><img src="theme/images/training/tests/arrow-right-ico.svg" class="img-svg d-none d-sm-block"></a>'
            : $primaryActionHtml,
    );

    if (trainingActivityGetRequestParam('step', null) !== null || trainingActivityGetRequestParam('result_id', null) !== null || trainingActivityGetRequestParam('reset', null) !== null) {
        $modx->setPlaceholder('training_activity_min_pass_percent', $minPassPercent > 0 ? rtrim(rtrim(number_format($minPassPercent, 2, '.', ''), '0'), '.') : '');
        return $modx->runSnippet('UserTest', array(
            'id' => $testId,
            'AjaxMode' => 0,
            'tpl' => '@FILE ' . rtrim($corePath, '/\\') . '/elements/chunks/training/activity/usertest.tpl',
            'tplError' => '@FILE ' . rtrim($corePath, '/\\') . '/elements/chunks/training/activity/usertest.error.tpl',
            'training_activity_id' => $activityId,
            'training_activity_type' => $linkType,
            'training_activity_title' => $title,
            'training_activity_back_id' => $backResourceId,
            'training_activity_min_pass_percent' => $minPassPercent,
            'training_activity_max_attempts' => $maxAttempts,
        ));
    }

    if ($screen === 'instruction') {
        return trainingActivityRenderChunk($modx, $corePath, 'training/activity/instruction.tpl', $commonPlaceholders);
    }

    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/start.tpl', $commonPlaceholders);
}

/* practice mode */

$attemptTable = $modx->getOption('table_prefix') . 'partnerstraining_practice_attempts';
$messageTable = $modx->getOption('table_prefix') . 'partnerstraining_practice_messages';

if (!trainingActivityTableExists($modx, $attemptTable) || !trainingActivityTableExists($modx, $messageTable)) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Практика не настроена',
        'message' => 'Не созданы таблицы для попыток и комментариев практических заданий.',
        'back_button_html' => $errorBackButtonHtml,
    ));
}

$status = $service->syncUserTestStatus($courseId, $moduleId, $testId, $userId);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postAction = isset($_POST['practice_action']) ? trim((string)$_POST['practice_action']) : '';
    $redirectTab = isset($_POST['tab']) ? trim((string)$_POST['tab']) : $tab;
    if (!in_array($redirectTab, array('attempts', 'comments'), true)) {
        $redirectTab = 'attempts';
    }

    $attempts = trainingActivityGetPracticeAttempts($modx, $attemptTable, $activityId, $userId);
    $latestAttempt = $attempts ? $attempts[0] : null;
    $attemptCount = count($attempts);

    if ($postAction === 'create_attempt') {
        $canCreate = true;
        if ($maxAttempts > 0 && $attemptCount >= $maxAttempts && (!$latestAttempt || !in_array($latestAttempt['status'], array('draft', 'revision_requested'), true))) {
            $canCreate = false;
        }

        if ($canCreate) {
            if ($latestAttempt && in_array($latestAttempt['status'], array('draft', 'revision_requested'), true)) {
                $attemptId = (int)$latestAttempt['id'];
            } else {
                $attemptNo = $attemptCount + 1;
                $attemptId = trainingActivityCreatePracticeAttempt(
                    $modx,
                    $attemptTable,
                    $activityId,
                    $courseId,
                    $moduleId,
                    $userId,
                    $attemptNo,
                    'Попытка #' . $attemptNo
                );
                trainingActivityInsertPracticeMessage($modx, $messageTable, $attemptId, $userId, 'system', 'Новая попытка создана.', 1);
            }

            trainingActivityUpsertStatus($modx, $courseId, $moduleId, $testId, $userId, array(
                'last_result_id' => (int)$attemptId,
                'attempts' => max($attemptCount, 1),
                'passed' => 0,
                'status' => 'in_progress',
                'last_score' => 0,
                'updatedon' => trainingActivityNow(),
            ));
        }
    } elseif ($latestAttempt && $postAction === 'post_message') {
        $message = trim((string)$_POST['practice_message']);
        if ($message !== '') {
            trainingActivityInsertPracticeMessage($modx, $messageTable, (int)$latestAttempt['id'], $userId, 'employee', $message, 0);
            trainingActivityUpsertStatus($modx, $courseId, $moduleId, $testId, $userId, array(
                'last_result_id' => (int)$latestAttempt['id'],
                'attempts' => max($attemptCount, 1),
                'passed' => 0,
                'status' => in_array($latestAttempt['status'], array('submitted', 'pending_review'), true) ? 'pending_review' : 'in_progress',
                'last_score' => 0,
                'updatedon' => trainingActivityNow(),
            ));
        }
    } elseif ($latestAttempt && $postAction === 'submit_attempt') {
        if (in_array($latestAttempt['status'], array('draft', 'revision_requested'), true)) {
            trainingActivityUpdatePracticeAttemptStatus($modx, $attemptTable, (int)$latestAttempt['id'], 'submitted');
            trainingActivityInsertPracticeMessage($modx, $messageTable, (int)$latestAttempt['id'], $userId, 'system', 'Попытка отправлена на проверку.', 1);
            trainingActivityUpsertStatus($modx, $courseId, $moduleId, $testId, $userId, array(
                'last_result_id' => (int)$latestAttempt['id'],
                'attempts' => max($attemptCount, 1),
                'passed' => 0,
                'status' => 'pending_review',
                'last_score' => 0,
                'updatedon' => trainingActivityNow(),
            ));
        }
    }

    $params = array(
        'activity' => $activityId,
        'back' => $backResourceId,
        'tab' => $redirectTab,
    );
    if (trainingActivityRedirectIfNeeded($modx, trainingActivityMakeUrl($modx, $targetResourceId, $params, true))) {
        return '';
    }
}

$attempts = trainingActivityGetPracticeAttempts($modx, $attemptTable, $activityId, $userId);
$latestAttempt = $attempts ? $attempts[0] : null;
$attemptCount = count($attempts);
$latestStatus = $latestAttempt ? trim((string)$latestAttempt['status']) : 'not_started';
$statusMeta = trainingActivityPracticeStatusMeta($latestStatus);

$attemptsText = $maxAttempts > 0 ? ($attemptCount . '/' . $maxAttempts) : (string)$attemptCount;
if ($attemptsText !== '') {
    $attemptsHtml = '<div class="text-info-test mt-4 d-inline-flex gap-2 align-items-center"><span>Попытки</span><span>' . trainingActivityEsc($attemptsText) . '</span></div>';
}
if ($minPassPercent > 0) {
    $instructionMetaHtml .= '<div class="text-info-test mt-3">Минимальный балл проверки: ' . trainingActivityEsc(rtrim(rtrim(number_format($minPassPercent, 2, '.', ''), '0'), '.')) . '%</div>';
}
if ($attemptsText !== '') {
    $instructionMetaHtml .= '<div class="text-info-test mt-2">Попытки: ' . trainingActivityEsc($attemptsText) . '</div>';
}

$instructionTitle = 'Инструкция по выполнению задания';
$instructionBlock = $instructionHtml !== ''
    ? '<div class="test-subtitle mb-4">' . $instructionHtml . '</div>'
    : '<ul class="test-list mb-5"><li>Ознакомьтесь с формулировкой задания и критериями проверки</li><li>Нажмите <span>«Приступить к заданию»</span>, чтобы открыть свою попытку</li><li>Опишите решение в комментариях и отправьте попытку на проверку</li><li>После проверки задание получит статус <span>«Принято»</span> или <span>«Не принято»</span></li></ul>';

if ($screen === 'instruction') {
    $actionHtml = '<form action="' . trainingActivityEsc(trainingActivityMakeUrl($modx, $targetResourceId, array('activity' => $activityId, 'back' => $backResourceId, 'tab' => 'comments'))) . '" method="post" class="m-0">'
        . '<input type="hidden" name="practice_action" value="create_attempt">'
        . '<input type="hidden" name="tab" value="comments">'
        . '<button type="submit" class="btn btn-test col-auto"><span>' . trainingActivityEsc($actionContinueButton) . '</span><img src="theme/images/training/tests/arrow-right-ico.svg" class="img-svg d-none d-sm-block"></button>'
        . '</form>';

    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/instruction.tpl', array(
        'instruction_title' => trainingActivityEsc($instructionTitle),
        'activity_instruction_block' => $instructionBlock,
        'activity_meta_html' => $instructionMetaHtml,
        'back_button_html' => $backButtonHtml,
        'primary_action_html' => $actionHtml,
    ));
}

if (!$latestAttempt) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/start.tpl', array(
        'activity_type_title' => trainingActivityEsc($actionModeTitle),
        'module_title' => trainingActivityEsc($moduleTitle),
        'activity_description_html' => $descriptionHtml,
        'activity_attempts_html' => $attemptsHtml,
        'back_button_html' => $backButtonHtml,
        'primary_action_html' => $primaryActionHtml,
    ));
}

$messages = trainingActivityGetPracticeMessages($modx, $messageTable, (int)$latestAttempt['id']);
$messagesHtml = '';
if (!$messages) {
    $messagesHtml = '<div class="text-center py-5"><div class="test-question mb-3">Нет истории сообщений</div><div class="test-subtitle">Напишите сообщение, чтобы начать обсуждение.</div></div>';
} else {
    foreach ($messages as $message) {
        $isOwn = (int)$message['user_id'] === $userId && (int)$message['is_system'] !== 1;
        $senderName = (int)$message['is_system'] === 1 ? 'Система' : trainingActivityGetProfileName($modx, (int)$message['user_id']);
        $alignClass = $isOwn ? 'justify-content-end' : 'justify-content-start';
        $cardClass = (int)$message['is_system'] === 1 ? 'label-chip--orange' : ($isOwn ? 'label-chip--purple' : 'label-chip--blue');
        $messagesHtml .= '<div class="d-flex ' . $alignClass . ' mb-3">'
            . '<div class="p-3 border rounded-4" style="max-width:720px;width:100%;background:#fff;">'
            . '<div class="d-flex align-items-center justify-content-between gap-3 mb-2"><strong>' . trainingActivityEsc($senderName) . '</strong><span class="text-muted small">' . trainingActivityEsc(trainingActivityFormatDate($message['createdon'])) . '</span></div>'
            . '<div class="small">' . nl2br(trainingActivityEsc($message['message'])) . '</div>'
            . '</div>'
            . '</div>';
    }
}

$attemptsRowsHtml = '';
foreach ($attempts as $attempt) {
    $meta = trainingActivityPracticeStatusMeta($attempt['status']);
    $attemptsRowsHtml .= '<div class="d-flex flex-wrap align-items-center justify-content-between gap-3 py-3 border-bottom">'
        . '<div><div class="fw-bold">' . trainingActivityEsc($attempt['title'] !== '' ? $attempt['title'] : ('Попытка #' . (int)$attempt['attempt_no'])) . '</div>'
        . '<div class="text-muted small">Создано: ' . trainingActivityEsc(trainingActivityFormatDate($attempt['createdon'])) . '</div></div>'
        . '<div class="d-flex align-items-center gap-3">'
        . '<span class="label-chip ' . trainingActivityEsc($meta['class']) . '"><span>' . trainingActivityEsc($meta['label']) . '</span></span>'
        . '<a href="' . trainingActivityEsc(trainingActivityMakeUrl($modx, $targetResourceId, array('activity' => $activityId, 'back' => $backResourceId, 'tab' => 'comments'))) . '" class="btn btn-list-test text-decoration-none"><span>Открыть</span></a>'
        . '</div></div>';
}

$composerHtml = '';
if (in_array($latestStatus, array('draft', 'revision_requested'), true)) {
    $composerHtml = '<form action="' . trainingActivityEsc(trainingActivityMakeUrl($modx, $targetResourceId, array('activity' => $activityId, 'back' => $backResourceId, 'tab' => 'comments'))) . '" method="post" class="mt-4">'
        . '<input type="hidden" name="practice_action" value="post_message">'
        . '<input type="hidden" name="tab" value="comments">'
        . '<div class="d-flex flex-column gap-3">'
        . '<textarea name="practice_message" class="form-control" rows="4" placeholder="Опишите решение, задайте вопрос или приложите текст ответа"></textarea>'
        . '<div class="d-flex flex-wrap align-items-center justify-content-between gap-2">'
        . '<button type="submit" class="btn btn-test btn-reload-test text-decoration-none"><span>Сохранить сообщение</span><img src="theme/images/training/tests/arrow-right-ico.svg" class="img-svg d-none d-sm-block"></button>'
        . '<button type="submit" formaction="' . trainingActivityEsc(trainingActivityMakeUrl($modx, $targetResourceId, array('activity' => $activityId, 'back' => $backResourceId, 'tab' => 'comments'))) . '" formmethod="post" name="practice_action" value="submit_attempt" class="btn btn-test"><span>Отправить на проверку</span><img src="theme/images/training/tests/arrow-right-ico.svg" class="img-svg d-none d-sm-block"></button>'
        . '</div></div></form>';
} elseif (in_array($latestStatus, array('submitted', 'pending_review'), true)) {
    $composerHtml = '<div class="alert alert-warning rounded-4 border-0 mt-4">Попытка отправлена на проверку. После проверки здесь появится комментарий и итоговый статус.</div>';
} elseif (in_array($latestStatus, array('accepted'), true)) {
    $composerHtml = '<div class="alert alert-success rounded-4 border-0 mt-4">Задание принято. Вы можете просматривать комментарии по попытке.</div>';
} else {
    $canRestart = $maxAttempts <= 0 || $attemptCount < $maxAttempts;
    if ($canRestart) {
        $composerHtml = '<form action="' . trainingActivityEsc(trainingActivityMakeUrl($modx, $targetResourceId, array('activity' => $activityId, 'back' => $backResourceId, 'tab' => 'comments'))) . '" method="post" class="mt-4">'
            . '<input type="hidden" name="practice_action" value="create_attempt">'
            . '<input type="hidden" name="tab" value="comments">'
            . '<button type="submit" class="btn btn-test"><span>Новая попытка</span><img src="theme/images/training/tests/arrow-right-ico.svg" class="img-svg d-none d-sm-block"></button>'
            . '</form>';
    } else {
        $composerHtml = '<div class="alert alert-danger rounded-4 border-0 mt-4">Доступные попытки исчерпаны.</div>';
    }
}

$practiceStatusChipHtml = '<span class="label-chip ' . trainingActivityEsc($statusMeta['class']) . '"><span>' . trainingActivityEsc($statusMeta['label']) . '</span></span>';
$practiceTitle = $title !== '' ? $title : 'Практическое задание';
$practiceImage = '';
if ($moduleResource) {
    $practiceImage = trim((string)$moduleResource->getTVValue('image_curse'));
}
if ($practiceImage === '') {
    $practiceImage = 'theme/images/training/curses/image_1.jpg';
}

return trainingActivityRenderChunk($modx, $corePath, 'training/activity/practice.tpl', array(
    'back_url' => trainingActivityEsc($backUrl),
    'module_title' => trainingActivityEsc($moduleTitle),
    'activity_title' => trainingActivityEsc($practiceTitle),
    'activity_type_label' => trainingActivityEsc($actionTypeLabel),
    'activity_description_html' => $description !== '' ? $description : '<p></p>',
    'activity_image' => trainingActivityEsc($practiceImage),
    'status_chip_html' => $practiceStatusChipHtml,
    'attempts_counter_html' => '<div class="text-info-test">Попытки: ' . trainingActivityEsc($attemptsText) . '</div>',
    'attempts_tab_class' => $tab === 'attempts' ? ' is-active' : '',
    'comments_tab_class' => $tab === 'comments' ? ' is-active' : '',
    'attempts_tab_url' => trainingActivityEsc(trainingActivityMakeUrl($modx, $targetResourceId, array('activity' => $activityId, 'back' => $backResourceId, 'tab' => 'attempts'))),
    'comments_tab_url' => trainingActivityEsc(trainingActivityMakeUrl($modx, $targetResourceId, array('activity' => $activityId, 'back' => $backResourceId, 'tab' => 'comments'))),
    'attempts_rows_html' => $attemptsRowsHtml,
    'messages_rows_html' => $messagesHtml,
    'composer_html' => $composerHtml,
    'active_tab' => $tab,
));
