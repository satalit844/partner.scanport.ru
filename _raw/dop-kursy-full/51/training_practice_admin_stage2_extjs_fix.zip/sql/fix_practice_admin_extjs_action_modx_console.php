<?php
$prefix = $modx->getOption('table_prefix');
$actionId = 6;
$actionsTable = $prefix . 'actions';
$menusTable = $prefix . 'menus';

$modx->exec("UPDATE `{$actionsTable}` SET `controller` = 'controllers/practices', `namespace` = 'training', `haslayout` = 1, `lang_topics` = 'training:default' WHERE `id` = {$actionId}");
$modx->exec("UPDATE `{$menusTable}` SET `action` = {$actionId}, `params` = '', `namespace` = 'training' WHERE `action` = {$actionId} OR `text` = 'Практические задания'");

$cachePath = MODX_CORE_PATH . 'cache/';
$paths = array(
    $cachePath . 'mgr/',
    $cachePath . 'includes/',
    $cachePath . 'scripts/',
    $cachePath . 'system_settings/',
    $cachePath . 'lexicon_topics/',
);

foreach ($paths as $path) {
    if (is_dir($path)) {
        $modx->cacheManager->deleteTree($path, array(
            'deleteTop' => false,
            'skipDirs' => false,
            'extensions' => array(),
        ));
    }
}

$modx->cacheManager->refresh(array(
    'db' => array(),
    'system_settings' => array(),
    'scripts' => array(),
));

echo '<pre>';
echo "OK: ExtJS action fixed\n\n";
$stmt = $modx->query("SELECT `id`, `namespace`, `controller`, `haslayout`, `lang_topics` FROM `{$actionsTable}` WHERE `id` = {$actionId}");
print_r($stmt ? $stmt->fetch(PDO::FETCH_ASSOC) : array());

echo "\nFILES:\n";
$files = array(
    MODX_CORE_PATH . 'components/training/controllers/practices.php',
    MODX_ASSETS_PATH . 'components/training/js/mgr/practices/practices.panel.js',
    MODX_ASSETS_PATH . 'components/training/css/mgr/practices.css',
    MODX_ASSETS_PATH . 'components/training/connector.php',
    MODX_CORE_PATH . 'components/training/processors/mgr/practice/_helper.php',
    MODX_CORE_PATH . 'components/training/processors/mgr/practice/practices/getlist.php',
    MODX_CORE_PATH . 'components/training/processors/mgr/practice/attempts/getlist.php',
    MODX_CORE_PATH . 'components/training/processors/mgr/practice/messages/getlist.php',
);
foreach ($files as $file) {
    echo (is_file($file) ? 'OK   ' : 'FAIL ') . $file . "\n";
}

echo "\nOPEN:\n";
echo "/manager/?a={$actionId}&namespace=training&tp_debug=1\n";
echo "/manager/?a={$actionId}&namespace=training\n";
echo '</pre>';
