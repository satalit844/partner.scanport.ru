<?php
/**
 * Compatibility wrapper for MODX manager controller path controllers/default/practices.php.
 * @var modX $modx
 */
$corePath = $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/');
return include $corePath . 'controllers/practices.php';
