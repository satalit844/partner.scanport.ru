<?php
/**
 * Old-style MODX Manager action controller.
 * MODX 2.8 looks for controllers/practices.php when modAction.controller = practices.
 * Do not remove this wrapper even if practices.class.php exists.
 *
 * @var modX $modx
 */
$corePath = $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/');
$assetsUrl = $modx->getOption('training.assets_url', null, $modx->getOption('assets_url') . 'components/training/');
$connectorUrl = $assetsUrl . 'connector.php';

$modx->regClientCSS($assetsUrl . 'css/mgr/practices.css');
$modx->regClientStartupScript($assetsUrl . 'js/mgr/practices/practices.panel.js');
$modx->regClientStartupHTMLBlock('<script type="text/javascript">
Ext.onReady(function() {
    Training.config = Training.config || {};
    Training.config.connector_url = "' . $connectorUrl . '";
    MODx.add({xtype: "training-panel-practices"});
});
</script>');

return '<div id="training-panel-practices-wrap"></div>';
