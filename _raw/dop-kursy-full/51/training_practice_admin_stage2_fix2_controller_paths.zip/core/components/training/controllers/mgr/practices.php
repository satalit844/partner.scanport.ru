<?php
/**
 * Compatibility wrapper for installations where manager controllers are resolved from controllers/mgr/.
 * @var modX $modx
 */
$corePath = $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/');
return include $corePath . 'controllers/practices.php';
