<?php
require_once dirname(dirname(__FILE__)) . '/_helper.php';

class TrainingPracticeMgrMessagesCreateProcessor extends modProcessor
{
    public function process()
    {
        $attemptId = trainingPracticeMgrGetInt($this, 'attempt_id');
        $message = trim((string)$this->getProperty('message', ''));

        if ($attemptId <= 0) {
            return $this->failure('Выберите попытку');
        }
        if ($message === '') {
            return $this->failure('Напишите сообщение');
        }

        $attemptsTable = trainingPracticeMgrTable($this->modx, 'training_practice_attempts');
        $messagesTable = trainingPracticeMgrTable($this->modx, 'training_practice_messages');

        $stmt = $this->modx->prepare("SELECT * FROM {$attemptsTable} WHERE `id` = :id LIMIT 1");
        $stmt->execute(array(':id' => $attemptId));
        $attempt = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$attempt) {
            return $this->failure('Попытка не найдена');
        }

        $stmt = $this->modx->prepare("
            INSERT INTO {$messagesTable}
            (`attempt_id`, `practice_id`, `author_id`, `author_type`, `message`, `is_system`, `createdon`)
            VALUES
            (:attempt_id, :practice_id, :author_id, 'mentor', :message, 0, NOW())
        ");
        $stmt->execute(array(
            ':attempt_id' => $attemptId,
            ':practice_id' => (int)$attempt['practice_id'],
            ':author_id' => (int)$this->modx->user->get('id'),
            ':message' => $message,
        ));

        if ((string)$attempt['status'] === 'submitted') {
            $stmt = $this->modx->prepare("UPDATE {$attemptsTable} SET `status` = 'in_review', `reviewedon` = NOW(), `reviewedby` = :reviewedby WHERE `id` = :id");
            $stmt->execute(array(
                ':reviewedby' => (int)$this->modx->user->get('id'),
                ':id' => $attemptId,
            ));
        }

        return $this->success('Сообщение отправлено');
    }
}

return 'TrainingPracticeMgrMessagesCreateProcessor';
