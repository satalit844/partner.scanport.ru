<?php
if (!function_exists('trainingPracticeMgrTable')) {
    function trainingPracticeMgrTable(modX $modx, $name)
    {
        $prefix = (string)$modx->getOption('table_prefix');
        $candidates = array(
            $prefix . $name,
            $prefix . '_' . $name,
            'modx_' . $name,
        );

        foreach ($candidates as $table) {
            $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
            if ($table === '') {
                continue;
            }

            $stmt = $modx->query("SHOW TABLES LIKE " . $modx->quote($table));
            if ($stmt && $stmt->fetchColumn()) {
                return '`' . $table . '`';
            }
        }

        return '`' . preg_replace('/[^a-zA-Z0-9_]/', '', $prefix . $name) . '`';
    }
}

if (!function_exists('trainingPracticeMgrPlainTable')) {
    function trainingPracticeMgrPlainTable(modX $modx, $name)
    {
        return str_replace('`', '', trainingPracticeMgrTable($modx, $name));
    }
}

if (!function_exists('trainingPracticeMgrEsc')) {
    function trainingPracticeMgrEsc($value)
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('trainingPracticeMgrDate')) {
    function trainingPracticeMgrDate($value)
    {
        $value = trim((string)$value);
        if ($value === '' || $value === '0000-00-00 00:00:00') {
            return '';
        }
        $time = strtotime($value);
        return $time ? date('d.m.Y H:i', $time) : $value;
    }
}

if (!function_exists('trainingPracticeMgrStatusText')) {
    function trainingPracticeMgrStatusText($status)
    {
        $map = array(
            'not_started' => 'Не начато',
            'new' => 'Не начато',
            'draft' => 'Черновик',
            'submitted' => 'Отправлено',
            'in_review' => 'На проверке',
            'revision' => 'На доработке',
            'approved' => 'Принято',
            'rejected' => 'Отклонено',
            'overdue' => 'Просрочено',
        );
        return isset($map[$status]) ? $map[$status] : $status;
    }
}

if (!function_exists('trainingPracticeMgrJsonSuccess')) {
    function trainingPracticeMgrJsonSuccess(array $data)
    {
        return array_merge(array('success' => true), $data);
    }
}

if (!function_exists('trainingPracticeMgrGetInt')) {
    function trainingPracticeMgrGetInt(modProcessor $processor, $key, $default = 0)
    {
        return (int)$processor->getProperty($key, $default);
    }
}

if (!function_exists('trainingPracticeMgrGetString')) {
    function trainingPracticeMgrGetString(modProcessor $processor, $key, $default = '')
    {
        return trim((string)$processor->getProperty($key, $default));
    }
}

if (!function_exists('trainingPracticeMgrNormalizeDate')) {
    function trainingPracticeMgrNormalizeDate($value)
    {
        $value = trim((string)$value);
        if ($value === '') {
            return null;
        }

        $value = str_replace('T', ' ', $value);
        $time = strtotime($value);
        if (!$time) {
            return null;
        }

        return date('Y-m-d H:i:s', $time);
    }
}
