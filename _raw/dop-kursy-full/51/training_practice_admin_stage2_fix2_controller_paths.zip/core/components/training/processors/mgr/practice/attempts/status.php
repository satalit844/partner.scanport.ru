<?php
require_once dirname(dirname(__FILE__)) . '/_helper.php';

class TrainingPracticeMgrAttemptsStatusProcessor extends modProcessor
{
    public function process()
    {
        $id = trainingPracticeMgrGetInt($this, 'id');
        $status = trainingPracticeMgrGetString($this, 'status');
        $comment = trim((string)$this->getProperty('comment', ''));

        if ($id <= 0) {
            return $this->failure('Не передан ID попытки');
        }

        $allowed = array('submitted', 'in_review', 'revision', 'approved', 'rejected');
        if (!in_array($status, $allowed, true)) {
            return $this->failure('Недопустимый статус');
        }

        $attemptsTable = trainingPracticeMgrTable($this->modx, 'training_practice_attempts');
        $messagesTable = trainingPracticeMgrTable($this->modx, 'training_practice_messages');

        $stmt = $this->modx->prepare("SELECT * FROM {$attemptsTable} WHERE `id` = :id LIMIT 1");
        $stmt->execute(array(':id' => $id));
        $attempt = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$attempt) {
            return $this->failure('Попытка не найдена');
        }

        $stmt = $this->modx->prepare("
            UPDATE {$attemptsTable}
            SET `status` = :status, `reviewedon` = NOW(), `reviewedby` = :reviewedby
            WHERE `id` = :id
        ");
        $stmt->execute(array(
            ':id' => $id,
            ':status' => $status,
            ':reviewedby' => (int)$this->modx->user->get('id'),
        ));

        $systemMessage = 'Статус изменен: ' . trainingPracticeMgrStatusText($status);
        if ($comment !== '') {
            $systemMessage .= "\n\n" . $comment;
        }

        $stmt = $this->modx->prepare("
            INSERT INTO {$messagesTable}
            (`attempt_id`, `practice_id`, `author_id`, `author_type`, `message`, `is_system`, `createdon`)
            VALUES
            (:attempt_id, :practice_id, :author_id, 'mentor', :message, 1, NOW())
        ");
        $stmt->execute(array(
            ':attempt_id' => $id,
            ':practice_id' => (int)$attempt['practice_id'],
            ':author_id' => (int)$this->modx->user->get('id'),
            ':message' => $systemMessage,
        ));

        return $this->success('Статус изменен');
    }
}

return 'TrainingPracticeMgrAttemptsStatusProcessor';
