<?php
require_once dirname(dirname(__FILE__)) . '/_helper.php';

class TrainingPracticeMgrPracticeGetListProcessor extends modProcessor
{
    public function process()
    {
        $table = trainingPracticeMgrTable($this->modx, 'training_practices');
        $contentTable = trainingPracticeMgrTable($this->modx, 'site_content');

        $start = max(0, (int)$this->getProperty('start', 0));
        $limit = max(0, (int)$this->getProperty('limit', 20));
        $query = trim((string)$this->getProperty('query', ''));
        $courseId = (int)$this->getProperty('course_id', 0);
        $moduleId = (int)$this->getProperty('module_id', 0);
        $active = trim((string)$this->getProperty('active', ''));

        $where = array('1=1');
        $params = array();

        if ($query !== '') {
            $where[] = '(p.`title` LIKE :query OR p.`description` LIKE :query)';
            $params[':query'] = '%' . $query . '%';
        }
        if ($courseId > 0) {
            $where[] = 'p.`course_id` = :course_id';
            $params[':course_id'] = $courseId;
        }
        if ($moduleId > 0) {
            $where[] = 'p.`module_id` = :module_id';
            $params[':module_id'] = $moduleId;
        }
        if ($active !== '') {
            $where[] = 'p.`active` = :active';
            $params[':active'] = (int)$active;
        }

        $whereSql = implode(' AND ', $where);

        $countStmt = $this->modx->prepare("SELECT COUNT(*) FROM {$table} p WHERE {$whereSql}");
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        $sort = preg_replace('/[^a-zA-Z0-9_]/', '', (string)$this->getProperty('sort', 'rank'));
        if ($sort === '') {
            $sort = 'rank';
        }
        $dir = strtoupper((string)$this->getProperty('dir', 'ASC')) === 'DESC' ? 'DESC' : 'ASC';

        $sql = "
            SELECT
                p.*,
                cr.`pagetitle` AS `course_title`,
                mr.`pagetitle` AS `module_title`
            FROM {$table} p
            LEFT JOIN {$contentTable} cr ON cr.`id` = p.`course_id`
            LEFT JOIN {$contentTable} mr ON mr.`id` = p.`module_id`
            WHERE {$whereSql}
            ORDER BY p.`{$sort}` {$dir}, p.`id` ASC
        ";

        if ($limit > 0) {
            $sql .= " LIMIT {$start}, {$limit}";
        }

        $stmt = $this->modx->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $results = array();

        foreach ($rows as $row) {
            $row['active_text'] = !empty($row['active']) ? 'Да' : 'Нет';
            $row['createdon_formatted'] = trainingPracticeMgrDate($row['createdon']);
            $row['editedon_formatted'] = trainingPracticeMgrDate($row['editedon']);
            $row['deadline_at_formatted'] = trainingPracticeMgrDate($row['deadline_at']);
            $row['course_display'] = trim((string)$row['course_title']) !== '' ? $row['course_title'] : $row['course_id'];
            $row['module_display'] = trim((string)$row['module_title']) !== '' ? $row['module_title'] : $row['module_id'];
            $results[] = $row;
        }

        return $this->outputArray($results, $total);
    }
}

return 'TrainingPracticeMgrPracticeGetListProcessor';
