<?php
require_once dirname(dirname(__FILE__)) . '/_helper.php';

class TrainingPracticeMgrAttemptsGetListProcessor extends modProcessor
{
    public function process()
    {
        $attemptsTable = trainingPracticeMgrTable($this->modx, 'training_practice_attempts');
        $practicesTable = trainingPracticeMgrTable($this->modx, 'training_practices');
        $usersTable = trainingPracticeMgrTable($this->modx, 'users');
        $attributesTable = trainingPracticeMgrTable($this->modx, 'user_attributes');
        $contentTable = trainingPracticeMgrTable($this->modx, 'site_content');

        $start = max(0, (int)$this->getProperty('start', 0));
        $limit = max(0, (int)$this->getProperty('limit', 20));
        $query = trim((string)$this->getProperty('query', ''));
        $practiceId = (int)$this->getProperty('practice_id', 0);
        $status = trim((string)$this->getProperty('status', ''));

        $where = array('1=1');
        $params = array();

        if ($practiceId > 0) {
            $where[] = 'a.`practice_id` = :practice_id';
            $params[':practice_id'] = $practiceId;
        }
        if ($status !== '') {
            $where[] = 'a.`status` = :status';
            $params[':status'] = $status;
        }
        if ($query !== '') {
            $where[] = '(p.`title` LIKE :query OR ua.`fullname` LIKE :query OR u.`username` LIKE :query OR u.`email` LIKE :query)';
            $params[':query'] = '%' . $query . '%';
        }

        $whereSql = implode(' AND ', $where);

        $countStmt = $this->modx->prepare("
            SELECT COUNT(*)
            FROM {$attemptsTable} a
            LEFT JOIN {$practicesTable} p ON p.`id` = a.`practice_id`
            LEFT JOIN {$usersTable} u ON u.`id` = a.`user_id`
            LEFT JOIN {$attributesTable} ua ON ua.`internalKey` = u.`id`
            WHERE {$whereSql}
        ");
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        $sort = preg_replace('/[^a-zA-Z0-9_]/', '', (string)$this->getProperty('sort', 'id'));
        if ($sort === '') {
            $sort = 'id';
        }
        $dir = strtoupper((string)$this->getProperty('dir', 'DESC')) === 'ASC' ? 'ASC' : 'DESC';

        $sql = "
            SELECT
                a.*,
                p.`title` AS `practice_title`,
                cr.`pagetitle` AS `course_title`,
                mr.`pagetitle` AS `module_title`,
                u.`username`,
                u.`email`,
                ua.`fullname`
            FROM {$attemptsTable} a
            LEFT JOIN {$practicesTable} p ON p.`id` = a.`practice_id`
            LEFT JOIN {$contentTable} cr ON cr.`id` = a.`course_id`
            LEFT JOIN {$contentTable} mr ON mr.`id` = a.`module_id`
            LEFT JOIN {$usersTable} u ON u.`id` = a.`user_id`
            LEFT JOIN {$attributesTable} ua ON ua.`internalKey` = u.`id`
            WHERE {$whereSql}
            ORDER BY a.`{$sort}` {$dir}
        ";

        if ($limit > 0) {
            $sql .= " LIMIT {$start}, {$limit}";
        }

        $stmt = $this->modx->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $results = array();

        foreach ($rows as $row) {
            $fullname = trim((string)$row['fullname']);
            if ($fullname === '') {
                $fullname = trim((string)$row['username']);
            }
            if ($fullname === '') {
                $fullname = 'Пользователь #' . (int)$row['user_id'];
            }

            $row['user_display'] = $fullname;
            $row['status_text'] = trainingPracticeMgrStatusText($row['status']);
            $row['createdon_formatted'] = trainingPracticeMgrDate($row['createdon']);
            $row['submittedon_formatted'] = trainingPracticeMgrDate($row['submittedon']);
            $row['reviewedon_formatted'] = trainingPracticeMgrDate($row['reviewedon']);
            $row['deadline_at_formatted'] = trainingPracticeMgrDate($row['deadline_at']);
            $row['course_display'] = trim((string)$row['course_title']) !== '' ? $row['course_title'] : $row['course_id'];
            $row['module_display'] = trim((string)$row['module_title']) !== '' ? $row['module_title'] : $row['module_id'];
            $results[] = $row;
        }

        return $this->outputArray($results, $total);
    }
}

return 'TrainingPracticeMgrAttemptsGetListProcessor';
