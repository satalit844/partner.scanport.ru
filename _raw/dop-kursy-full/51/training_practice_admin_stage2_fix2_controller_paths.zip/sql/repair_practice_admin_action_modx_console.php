<?php
/**
 * Repair manager action for Training practices in MODX 2.8.
 * Paste into MODX Console or run: include MODX_BASE_PATH . 'sql/repair_practice_admin_action_modx_console.php';
 */
$prefix = $modx->getOption('table_prefix');

function tp_fix_replace_placeholders(modX $modx, $value) {
    $value = (string)$value;
    $value = str_replace(array('{core_path}', '[[++core_path]]'), $modx->getOption('core_path'), $value);
    $value = str_replace(array('{assets_path}', '[[++assets_path]]'), $modx->getOption('assets_path'), $value);
    $value = str_replace('\\', '/', $value);
    return rtrim($value, '/') . '/';
}

function tp_fix_column_exists(modX $modx, $table, $column) {
    $stmt = $modx->query("SHOW COLUMNS FROM `{$table}` LIKE " . $modx->quote($column));
    return $stmt && $stmt->fetchColumn();
}

function tp_fix_insert_dynamic(modX $modx, $table, array $data) {
    $columns = array();
    $params = array();
    $placeholders = array();

    foreach ($data as $key => $value) {
        if (!tp_fix_column_exists($modx, $table, $key)) {
            continue;
        }
        $columns[] = '`' . $key . '`';
        $ph = ':' . $key;
        $placeholders[] = $ph;
        $params[$ph] = $value;
    }

    if (!$columns) {
        return false;
    }

    $stmt = $modx->prepare("INSERT INTO `{$table}` (" . implode(',', $columns) . ") VALUES (" . implode(',', $placeholders) . ")");
    return $stmt && $stmt->execute($params);
}

function tp_fix_update_dynamic(modX $modx, $table, array $data, $where, array $whereParams) {
    $sets = array();
    $params = $whereParams;

    foreach ($data as $key => $value) {
        if (!tp_fix_column_exists($modx, $table, $key)) {
            continue;
        }
        $ph = ':set_' . $key;
        $sets[] = '`' . $key . '` = ' . $ph;
        $params[$ph] = $value;
    }

    if (!$sets) {
        return false;
    }

    $stmt = $modx->prepare("UPDATE `{$table}` SET " . implode(',', $sets) . " WHERE " . $where);
    return $stmt && $stmt->execute($params);
}

function tp_fix_write_file($path, $content) {
    $dir = dirname($path);
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    return @file_put_contents($path, $content) !== false;
}

$corePath = '';
$namespace = $modx->getObject('modNamespace', array('name' => 'training'));
if ($namespace) {
    $nsPath = trim((string)$namespace->get('path'));
    if ($nsPath !== '') {
        $corePath = tp_fix_replace_placeholders($modx, $nsPath);
    }
}

if ($corePath === '') {
    $corePath = tp_fix_replace_placeholders($modx, $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/'));
}

$assetsUrl = $modx->getOption('training.assets_url', null, $modx->getOption('assets_url') . 'components/training/');
$connectorUrl = rtrim($assetsUrl, '/') . '/connector.php';

$controllerRootContent = <<<'PHPROOT'
<?php
/**
 * Old-style MODX Manager action controller.
 * Required when modAction.controller = practices.
 * @var modX $modx
 */
$corePath = $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/');
$assetsUrl = $modx->getOption('training.assets_url', null, $modx->getOption('assets_url') . 'components/training/');
$connectorUrl = rtrim($assetsUrl, '/') . '/connector.php';

$modx->regClientCSS(rtrim($assetsUrl, '/') . '/css/mgr/practices.css');
$modx->regClientStartupScript(rtrim($assetsUrl, '/') . '/js/mgr/practices/practices.panel.js');
$modx->regClientStartupHTMLBlock('<script type="text/javascript">
Ext.onReady(function() {
    window.Training = window.Training || {};
    Training.config = Training.config || {};
    Training.config.connector_url = "' . $connectorUrl . '";
    MODx.add({xtype: "training-panel-practices"});
});
</script>');

return '<div id="training-panel-practices-wrap"></div>';
PHPROOT;

$controllerWrapperContent = <<<'PHPWRAP'
<?php
/**
 * Compatibility wrapper.
 * @var modX $modx
 */
$corePath = $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/');
return include rtrim($corePath, '/') . '/controllers/practices.php';
PHPWRAP;

$controllerClassContent = <<<'PHPCLASS'
<?php
class TrainingPracticesManagerController extends modExtraManagerController
{
    public function getPageTitle()
    {
        return 'Практические задания';
    }

    public function loadCustomCssJs()
    {
        $assetsUrl = $this->modx->getOption('training.assets_url', null, $this->modx->getOption('assets_url') . 'components/training/');
        $assetsUrl = rtrim($assetsUrl, '/') . '/';

        $this->addCss($assetsUrl . 'css/mgr/practices.css');
        $this->addJavascript($assetsUrl . 'js/mgr/practices/practices.panel.js');

        $connectorUrl = $assetsUrl . 'connector.php';
        $this->addHtml('<script type="text/javascript">Ext.onReady(function(){window.Training = window.Training || {}; Training.config = Training.config || {}; Training.config.connector_url = "' . $connectorUrl . '"; MODx.add({xtype: "training-panel-practices"});});</script>');
    }

    public function getTemplateFile()
    {
        return $this->modx->getOption('training.core_path', null, $this->modx->getOption('core_path') . 'components/training/') . 'templates/mgr/practices.tpl';
    }
}
PHPCLASS;

$controllerClassWrapperContent = <<<'PHPCLASSWRAP'
<?php
$corePath = dirname(dirname(dirname(__FILE__))) . '/';
$classFile = $corePath . 'controllers/mgr/practices.class.php';
if (is_file($classFile)) {
    require_once $classFile;
}
PHPCLASSWRAP;

$files = array(
    $corePath . 'controllers/practices.php' => $controllerRootContent,
    $corePath . 'controllers/index.php' => $controllerWrapperContent,
    $corePath . 'controllers/mgr/practices.php' => $controllerWrapperContent,
    $corePath . 'controllers/mgr/index.php' => $controllerWrapperContent,
    $corePath . 'controllers/default/practices.php' => $controllerWrapperContent,
    $corePath . 'controllers/mgr/practices.class.php' => $controllerClassContent,
    $corePath . 'controllers/default/practices.class.php' => $controllerClassWrapperContent,
);

$writeLog = array();
foreach ($files as $path => $content) {
    $ok = tp_fix_write_file($path, $content);
    clearstatcache(true, $path);
    $writeLog[] = ($ok && is_file($path) ? 'OK  ' : 'FAIL') . ' ' . $path;
}

$actionsTable = $prefix . 'actions';
$menusTable = $prefix . 'menus';
$actionId = 0;

$actionsExists = $modx->query("SHOW TABLES LIKE " . $modx->quote($actionsTable));
if ($actionsExists && $actionsExists->fetchColumn()) {
    $stmt = $modx->prepare("SELECT `id` FROM `{$actionsTable}` WHERE `namespace` = 'training' AND `controller` = 'practices' LIMIT 1");
    $stmt->execute();
    $actionId = (int)$stmt->fetchColumn();

    if ($actionId <= 0) {
        tp_fix_insert_dynamic($modx, $actionsTable, array(
            'namespace' => 'training',
            'controller' => 'practices',
            'haslayout' => 1,
            'lang_topics' => 'training:default',
            'assets' => '',
        ));
        $actionId = (int)$modx->lastInsertId();
    } else {
        tp_fix_update_dynamic($modx, $actionsTable, array(
            'namespace' => 'training',
            'controller' => 'practices',
            'haslayout' => 1,
            'lang_topics' => 'training:default',
            'assets' => '',
        ), '`id` = :id', array(':id' => $actionId));
    }
}

$menusExists = $modx->query("SHOW TABLES LIKE " . $modx->quote($menusTable));
if ($actionId > 0 && $menusExists && $menusExists->fetchColumn()) {
    $menuKey = 'Практические задания';
    $menuData = array(
        'text' => $menuKey,
        'parent' => 'components',
        'action' => $actionId,
        'description' => 'Практические задания',
        'icon' => 'icon-tasks',
        'menuindex' => 99,
        'params' => '',
        'handler' => '',
        'permissions' => '',
        'namespace' => 'training',
    );

    $stmt = $modx->prepare("SELECT `text` FROM `{$menusTable}` WHERE `text` = :text LIMIT 1");
    $stmt->execute(array(':text' => $menuKey));
    $exists = (string)$stmt->fetchColumn();

    if ($exists !== '') {
        tp_fix_update_dynamic($modx, $menusTable, $menuData, '`text` = :text', array(':text' => $menuKey));
    } else {
        tp_fix_insert_dynamic($modx, $menusTable, $menuData);
    }
}

$modx->cacheManager->refresh(array(
    'system_settings' => array(),
    'menu' => array(),
    'manager' => array(),
));

echo '<pre>';
echo "Training practices repair\n";
echo "corePath: {$corePath}\n";
echo "connectorUrl: {$connectorUrl}\n\n";
echo implode("\n", $writeLog);
echo "\n\nactionId: {$actionId}\n";
echo "URL: /manager/?a={$actionId}&namespace=training\n";
echo "\nЕсли сверху все файлы OK, обнови админку через Ctrl+F5.\n";
echo '</pre>';
