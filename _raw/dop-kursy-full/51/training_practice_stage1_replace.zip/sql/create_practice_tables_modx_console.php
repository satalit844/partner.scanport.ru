<?php
$prefix = (string)$modx->getOption('table_prefix');
$charset = 'utf8mb4';
$collation = 'utf8mb4_unicode_ci';

$tables = array(
    'practices' => $prefix . 'training_practices',
    'attempts' => $prefix . 'training_practice_attempts',
    'messages' => $prefix . 'training_practice_messages',
    'files' => $prefix . 'training_practice_files',
);

$sql = array();

$sql[] = "
CREATE TABLE IF NOT EXISTS `{$tables['practices']}` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `module_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `title` VARCHAR(255) NOT NULL DEFAULT '',
  `description` MEDIUMTEXT NULL,
  `template_file` VARCHAR(500) NOT NULL DEFAULT '',
  `template_file_name` VARCHAR(255) NOT NULL DEFAULT '',
  `image` VARCHAR(500) NOT NULL DEFAULT '',
  `deadline_at` DATETIME NULL,
  `deadline_days` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `allowed_extensions` VARCHAR(255) NOT NULL DEFAULT 'pdf,doc,docx,xls,xlsx,png,jpg,jpeg,zip',
  `max_file_size` INT(10) UNSIGNED NOT NULL DEFAULT 52428800,
  `active` TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
  `rank` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `createdon` DATETIME NULL,
  `editedon` DATETIME NULL,
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`),
  KEY `module_id` (`module_id`),
  KEY `active` (`active`),
  KEY `rank` (`rank`)
) ENGINE=InnoDB DEFAULT CHARSET={$charset} COLLATE={$collation};
";

$sql[] = "
CREATE TABLE IF NOT EXISTS `{$tables['attempts']}` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `practice_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `course_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `module_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `attempt_num` INT(10) UNSIGNED NOT NULL DEFAULT 1,
  `status` VARCHAR(50) NOT NULL DEFAULT 'submitted',
  `deadline_at` DATETIME NULL,
  `createdon` DATETIME NULL,
  `submittedon` DATETIME NULL,
  `reviewedon` DATETIME NULL,
  `reviewedby` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_latest` TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `practice_user` (`practice_id`, `user_id`),
  KEY `course_id` (`course_id`),
  KEY `module_id` (`module_id`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  KEY `is_latest` (`is_latest`)
) ENGINE=InnoDB DEFAULT CHARSET={$charset} COLLATE={$collation};
";

$sql[] = "
CREATE TABLE IF NOT EXISTS `{$tables['messages']}` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `attempt_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `practice_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `author_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `author_type` VARCHAR(50) NOT NULL DEFAULT 'user',
  `message` MEDIUMTEXT NULL,
  `is_system` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
  `createdon` DATETIME NULL,
  PRIMARY KEY (`id`),
  KEY `attempt_id` (`attempt_id`),
  KEY `practice_id` (`practice_id`),
  KEY `author_id` (`author_id`),
  KEY `author_type` (`author_type`)
) ENGINE=InnoDB DEFAULT CHARSET={$charset} COLLATE={$collation};
";

$sql[] = "
CREATE TABLE IF NOT EXISTS `{$tables['files']}` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `attempt_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `message_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `practice_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `path` VARCHAR(500) NOT NULL DEFAULT '',
  `url` VARCHAR(500) NOT NULL DEFAULT '',
  `name` VARCHAR(255) NOT NULL DEFAULT '',
  `original_name` VARCHAR(255) NOT NULL DEFAULT '',
  `mime` VARCHAR(255) NOT NULL DEFAULT '',
  `extension` VARCHAR(50) NOT NULL DEFAULT '',
  `size` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `hash` VARCHAR(64) NOT NULL DEFAULT '',
  `createdon` DATETIME NULL,
  PRIMARY KEY (`id`),
  KEY `attempt_id` (`attempt_id`),
  KEY `message_id` (`message_id`),
  KEY `practice_id` (`practice_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET={$charset} COLLATE={$collation};
";

foreach ($sql as $query) {
    $modx->exec($query);
}

if (!$modx->getObject('modSystemSetting', array('key' => 'training.training_practice_resource_id'))) {
    $setting = $modx->newObject('modSystemSetting');
    $setting->fromArray(array(
        'key' => 'training.training_practice_resource_id',
        'value' => '176',
        'xtype' => 'numberfield',
        'namespace' => 'training',
        'area' => 'training',
        'editedon' => date('Y-m-d H:i:s'),
    ));
    $setting->save();
}

$modx->cacheManager->refresh(array(
    'system_settings' => array(),
));

echo 'OK: practice tables created';
