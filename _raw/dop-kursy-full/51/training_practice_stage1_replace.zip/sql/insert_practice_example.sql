INSERT INTO `modx_partnerstraining_practices`
(`course_id`, `module_id`, `title`, `description`, `active`, `rank`, `createdon`)
VALUES
(1, 1, 'Практическое задание 1 к Модулю 1', 'Загрузите выполненное задание PDF, DOCX или XLSX и отправьте сообщение ментору.', 1, 0, NOW());
