(function () {
    'use strict';

    var Admin = {
        root: null,
        connectorUrl: '',
        practices: [],
        attempts: [],
        selectedAttemptId: 0,
        selectedAttempt: null,

        init: function () {
            this.root = document.getElementById('training-practice-admin');
            if (!this.root) {
                return;
            }

            this.connectorUrl = this.root.getAttribute('data-connector') ||
                (window.TrainingPracticeAdminConfig && window.TrainingPracticeAdminConfig.connectorUrl) ||
                '/assets/components/training/connector.php';

            this.renderShell();
            this.bindEvents();
            this.loadPractices();
            this.loadAttempts();
        },

        esc: function (value) {
            value = value == null ? '' : String(value);
            return value
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        },

        request: function (action, data) {
            var body = new URLSearchParams();
            body.append('action', action);

            data = data || {};
            Object.keys(data).forEach(function (key) {
                body.append(key, data[key] == null ? '' : data[key]);
            });

            return fetch(this.connectorUrl, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: body.toString()
            }).then(function (response) {
                return response.text().then(function (text) {
                    var json;
                    try {
                        json = JSON.parse(text);
                    } catch (e) {
                        throw new Error('Некорректный ответ сервера: ' + text.substring(0, 500));
                    }

                    if (json && json.success === false) {
                        throw new Error(json.message || 'Ошибка запроса');
                    }

                    return json;
                });
            });
        },

        getResults: function (response) {
            if (!response) {
                return [];
            }
            if (Array.isArray(response.results)) {
                return response.results;
            }
            if (response.object && Array.isArray(response.object.results)) {
                return response.object.results;
            }
            if (Array.isArray(response.object)) {
                return response.object;
            }
            return [];
        },

        notify: function (message, type) {
            var box = this.root.querySelector('[data-tpa-notice]');
            if (!box) {
                return;
            }
            box.className = 'tpa-notice ' + (type === 'error' ? 'is-error' : 'is-success');
            box.textContent = message || '';
            box.hidden = !message;

            if (message && type !== 'error') {
                window.setTimeout(function () {
                    box.hidden = true;
                }, 2500);
            }
        },

        renderShell: function () {
            this.root.innerHTML = '' +
                '<div class="tpa-page">' +
                    '<div class="tpa-head">' +
                        '<div>' +
                            '<h1 class="tpa-title">Практические задания</h1>' +
                            '<div class="tpa-subtitle">Задания, попытки, файлы и переписка</div>' +
                        '</div>' +
                        '<button type="button" class="tpa-btn" data-tpa-refresh>Обновить</button>' +
                    '</div>' +
                    '<div class="tpa-notice" data-tpa-notice hidden></div>' +
                    '<div class="tpa-tabs">' +
                        '<button type="button" class="tpa-tab is-active" data-tpa-tab="practices">Задания</button>' +
                        '<button type="button" class="tpa-tab" data-tpa-tab="attempts">Попытки и переписка</button>' +
                    '</div>' +
                    '<div class="tpa-panel is-active" data-tpa-panel="practices">' +
                        this.renderPracticePanel() +
                    '</div>' +
                    '<div class="tpa-panel" data-tpa-panel="attempts">' +
                        this.renderAttemptsPanel() +
                    '</div>' +
                '</div>';
        },

        renderPracticePanel: function () {
            return '' +
                '<div class="tpa-layout">' +
                    '<div class="tpa-card">' +
                        '<div class="tpa-card-head">' +
                            '<div class="tpa-card-title">Список заданий</div>' +
                            '<button type="button" class="tpa-btn tpa-btn--primary" data-tpa-new-practice>Создать</button>' +
                        '</div>' +
                        '<div class="tpa-toolbar">' +
                            '<input class="tpa-input" type="text" data-tpa-practice-query placeholder="Поиск по названию">' +
                            '<button type="button" class="tpa-btn" data-tpa-search-practices>Найти</button>' +
                            '<button type="button" class="tpa-btn" data-tpa-reset-practices>Сбросить</button>' +
                        '</div>' +
                        '<div class="tpa-table-wrap" data-tpa-practices-table>Загрузка...</div>' +
                    '</div>' +
                    '<div class="tpa-card">' +
                        '<div class="tpa-card-title" data-tpa-practice-form-title>Новое задание</div>' +
                        this.renderPracticeForm() +
                    '</div>' +
                '</div>';
        },

        renderPracticeForm: function () {
            return '' +
                '<form class="tpa-form" data-tpa-practice-form>' +
                    '<input type="hidden" name="id">' +
                    '<div class="tpa-form-row tpa-form-row--2">' +
                        '<label>Курс / ресурс курса<input class="tpa-input" type="number" name="course_id" required></label>' +
                        '<label>Модуль / ресурс модуля<input class="tpa-input" type="number" name="module_id" required></label>' +
                    '</div>' +
                    '<label>Название<input class="tpa-input" type="text" name="title" required></label>' +
                    '<label>Описание / инструкция<textarea class="tpa-textarea" name="description" rows="5"></textarea></label>' +
                    '<div class="tpa-form-row tpa-form-row--2">' +
                        '<label>Файл задания<input class="tpa-input" type="text" name="template_file" placeholder="assets/.../file.docx"></label>' +
                        '<label>Название файла<input class="tpa-input" type="text" name="template_file_name"></label>' +
                    '</div>' +
                    '<label>Картинка<input class="tpa-input" type="text" name="image" placeholder="theme/images/training/tests/logo-scanport.svg"></label>' +
                    '<div class="tpa-form-row tpa-form-row--4">' +
                        '<label>Срок до даты<input class="tpa-input" type="text" name="deadline_at" placeholder="2026-05-30 18:00:00"></label>' +
                        '<label>Срок дней<input class="tpa-input" type="number" name="deadline_days" value="0"></label>' +
                        '<label>Ранг<input class="tpa-input" type="number" name="rank" value="0"></label>' +
                        '<label>Активно<select class="tpa-input" name="active"><option value="1">Да</option><option value="0">Нет</option></select></label>' +
                    '</div>' +
                    '<div class="tpa-form-row tpa-form-row--2">' +
                        '<label>Расширения<input class="tpa-input" type="text" name="allowed_extensions" value="pdf,doc,docx,xls,xlsx,png,jpg,jpeg,zip"></label>' +
                        '<label>Макс. размер, байт<input class="tpa-input" type="number" name="max_file_size" value="52428800"></label>' +
                    '</div>' +
                    '<div class="tpa-actions">' +
                        '<button type="submit" class="tpa-btn tpa-btn--primary">Сохранить</button>' +
                        '<button type="button" class="tpa-btn" data-tpa-clear-practice-form>Очистить</button>' +
                    '</div>' +
                '</form>';
        },

        renderAttemptsPanel: function () {
            return '' +
                '<div class="tpa-layout tpa-layout--attempts">' +
                    '<div class="tpa-card">' +
                        '<div class="tpa-card-title">Попытки пользователей</div>' +
                        '<div class="tpa-toolbar">' +
                            '<input class="tpa-input" type="text" data-tpa-attempt-query placeholder="Пользователь или задание">' +
                            '<select class="tpa-input" data-tpa-attempt-status>' +
                                '<option value="">Все статусы</option>' +
                                '<option value="submitted">Отправлено</option>' +
                                '<option value="in_review">На проверке</option>' +
                                '<option value="revision">На доработке</option>' +
                                '<option value="approved">Принято</option>' +
                                '<option value="rejected">Отклонено</option>' +
                            '</select>' +
                            '<button type="button" class="tpa-btn" data-tpa-search-attempts>Найти</button>' +
                            '<button type="button" class="tpa-btn" data-tpa-reset-attempts>Сбросить</button>' +
                        '</div>' +
                        '<div class="tpa-table-wrap" data-tpa-attempts-table>Загрузка...</div>' +
                    '</div>' +
                    '<div class="tpa-card">' +
                        '<div class="tpa-card-title">Переписка</div>' +
                        '<div class="tpa-selected" data-tpa-selected-attempt>Выберите попытку слева</div>' +
                        '<div class="tpa-status-actions">' +
                            '<button type="button" class="tpa-btn" data-tpa-status="in_review">На проверке</button>' +
                            '<button type="button" class="tpa-btn tpa-btn--success" data-tpa-status="approved">Принять</button>' +
                            '<button type="button" class="tpa-btn tpa-btn--warning" data-tpa-status="revision">На доработку</button>' +
                            '<button type="button" class="tpa-btn tpa-btn--danger" data-tpa-status="rejected">Отклонить</button>' +
                        '</div>' +
                        '<div class="tpa-messages" data-tpa-messages>Сообщения появятся после выбора попытки.</div>' +
                        '<form class="tpa-reply" data-tpa-reply-form>' +
                            '<textarea class="tpa-textarea" name="message" rows="4" placeholder="Ответ пользователю"></textarea>' +
                            '<button type="submit" class="tpa-btn tpa-btn--primary">Отправить ответ</button>' +
                        '</form>' +
                    '</div>' +
                '</div>';
        },

        bindEvents: function () {
            var self = this;

            this.root.addEventListener('click', function (e) {
                var tab = e.target.closest('[data-tpa-tab]');
                if (tab) {
                    self.switchTab(tab.getAttribute('data-tpa-tab'));
                    return;
                }

                if (e.target.closest('[data-tpa-refresh]')) {
                    self.loadPractices();
                    self.loadAttempts();
                    return;
                }

                if (e.target.closest('[data-tpa-new-practice]')) {
                    self.clearPracticeForm();
                    return;
                }

                if (e.target.closest('[data-tpa-clear-practice-form]')) {
                    self.clearPracticeForm();
                    return;
                }

                if (e.target.closest('[data-tpa-search-practices]')) {
                    self.loadPractices();
                    return;
                }

                if (e.target.closest('[data-tpa-reset-practices]')) {
                    var pq = self.root.querySelector('[data-tpa-practice-query]');
                    if (pq) pq.value = '';
                    self.loadPractices();
                    return;
                }

                if (e.target.closest('[data-tpa-search-attempts]')) {
                    self.loadAttempts();
                    return;
                }

                if (e.target.closest('[data-tpa-reset-attempts]')) {
                    var aq = self.root.querySelector('[data-tpa-attempt-query]');
                    var as = self.root.querySelector('[data-tpa-attempt-status]');
                    if (aq) aq.value = '';
                    if (as) as.value = '';
                    self.loadAttempts();
                    return;
                }

                var editBtn = e.target.closest('[data-tpa-edit-practice]');
                if (editBtn) {
                    self.editPractice(parseInt(editBtn.getAttribute('data-tpa-edit-practice'), 10) || 0);
                    return;
                }

                var removeBtn = e.target.closest('[data-tpa-remove-practice]');
                if (removeBtn) {
                    self.removePractice(parseInt(removeBtn.getAttribute('data-tpa-remove-practice'), 10) || 0);
                    return;
                }

                var attemptRow = e.target.closest('[data-tpa-attempt-id]');
                if (attemptRow) {
                    self.selectAttempt(parseInt(attemptRow.getAttribute('data-tpa-attempt-id'), 10) || 0);
                    return;
                }

                var statusBtn = e.target.closest('[data-tpa-status]');
                if (statusBtn) {
                    self.setAttemptStatus(statusBtn.getAttribute('data-tpa-status'));
                }
            });

            this.root.addEventListener('submit', function (e) {
                var practiceForm = e.target.closest('[data-tpa-practice-form]');
                if (practiceForm) {
                    e.preventDefault();
                    self.savePractice(practiceForm);
                    return;
                }

                var replyForm = e.target.closest('[data-tpa-reply-form]');
                if (replyForm) {
                    e.preventDefault();
                    self.sendReply(replyForm);
                }
            });

            this.root.addEventListener('keydown', function (e) {
                if (e.key !== 'Enter') return;
                if (e.target.matches('[data-tpa-practice-query]')) {
                    e.preventDefault();
                    self.loadPractices();
                }
                if (e.target.matches('[data-tpa-attempt-query]')) {
                    e.preventDefault();
                    self.loadAttempts();
                }
            });
        },

        switchTab: function (name) {
            this.root.querySelectorAll('[data-tpa-tab]').forEach(function (tab) {
                tab.classList.toggle('is-active', tab.getAttribute('data-tpa-tab') === name);
            });
            this.root.querySelectorAll('[data-tpa-panel]').forEach(function (panel) {
                panel.classList.toggle('is-active', panel.getAttribute('data-tpa-panel') === name);
            });
        },

        loadPractices: function () {
            var self = this;
            var queryEl = this.root.querySelector('[data-tpa-practice-query]');
            var query = queryEl ? queryEl.value : '';
            var wrap = this.root.querySelector('[data-tpa-practices-table]');
            if (wrap) wrap.innerHTML = 'Загрузка...';

            this.request('mgr/practice/practices/getlist', {
                start: 0,
                limit: 200,
                query: query
            }).then(function (res) {
                self.practices = self.getResults(res);
                self.renderPracticesTable();
            }).catch(function (err) {
                if (wrap) wrap.innerHTML = '<div class="tpa-error">' + self.esc(err.message) + '</div>';
                self.notify(err.message, 'error');
            });
        },

        renderPracticesTable: function () {
            var wrap = this.root.querySelector('[data-tpa-practices-table]');
            if (!wrap) return;

            if (!this.practices.length) {
                wrap.innerHTML = '<div class="tpa-empty">Практические задания не найдены</div>';
                return;
            }

            var html = '' +
                '<table class="tpa-table">' +
                    '<thead><tr>' +
                        '<th>ID</th><th>Курс</th><th>Модуль</th><th>Название</th><th>Активно</th><th>Срок</th><th></th>' +
                    '</tr></thead><tbody>';

            this.practices.forEach(function (row) {
                html += '<tr>' +
                    '<td>' + Admin.esc(row.id) + '</td>' +
                    '<td>' + Admin.esc(row.course_display || row.course_id) + '</td>' +
                    '<td>' + Admin.esc(row.module_display || row.module_id) + '</td>' +
                    '<td>' + Admin.esc(row.title) + '</td>' +
                    '<td>' + Admin.esc(row.active_text) + '</td>' +
                    '<td>' + Admin.esc(row.deadline_at_formatted || '') + '</td>' +
                    '<td class="tpa-row-actions">' +
                        '<button type="button" class="tpa-link" data-tpa-edit-practice="' + Admin.esc(row.id) + '">Изменить</button>' +
                        '<button type="button" class="tpa-link is-danger" data-tpa-remove-practice="' + Admin.esc(row.id) + '">Удалить</button>' +
                    '</td>' +
                '</tr>';
            });

            html += '</tbody></table>';
            wrap.innerHTML = html;
        },

        clearPracticeForm: function () {
            var form = this.root.querySelector('[data-tpa-practice-form]');
            if (!form) return;
            form.reset();
            form.elements.id.value = '';
            form.elements.allowed_extensions.value = 'pdf,doc,docx,xls,xlsx,png,jpg,jpeg,zip';
            form.elements.max_file_size.value = '52428800';
            form.elements.deadline_days.value = '0';
            form.elements.rank.value = '0';
            form.elements.active.value = '1';
            var title = this.root.querySelector('[data-tpa-practice-form-title]');
            if (title) title.textContent = 'Новое задание';
        },

        editPractice: function (id) {
            var row = null;
            this.practices.forEach(function (item) {
                if ((parseInt(item.id, 10) || 0) === id) row = item;
            });
            if (!row) return;

            var form = this.root.querySelector('[data-tpa-practice-form]');
            if (!form) return;

            Object.keys(row).forEach(function (key) {
                if (form.elements[key]) {
                    form.elements[key].value = row[key] == null ? '' : row[key];
                }
            });

            var title = this.root.querySelector('[data-tpa-practice-form-title]');
            if (title) title.textContent = 'Изменить задание #' + id;

            form.scrollIntoView({block: 'start', behavior: 'smooth'});
        },

        savePractice: function (form) {
            var self = this;
            var data = {};
            Array.prototype.forEach.call(form.elements, function (el) {
                if (!el.name) return;
                data[el.name] = el.value;
            });

            var action = data.id ? 'mgr/practice/practices/update' : 'mgr/practice/practices/create';
            this.request(action, data).then(function () {
                self.notify('Практическое задание сохранено');
                self.clearPracticeForm();
                self.loadPractices();
            }).catch(function (err) {
                self.notify(err.message, 'error');
            });
        },

        removePractice: function (id) {
            var self = this;
            if (!id) return;
            if (!window.confirm('Удалить или отключить практическое задание?')) return;

            this.request('mgr/practice/practices/remove', {id: id}).then(function () {
                self.notify('Задание удалено или отключено');
                self.loadPractices();
            }).catch(function (err) {
                self.notify(err.message, 'error');
            });
        },

        loadAttempts: function () {
            var self = this;
            var queryEl = this.root.querySelector('[data-tpa-attempt-query]');
            var statusEl = this.root.querySelector('[data-tpa-attempt-status]');
            var wrap = this.root.querySelector('[data-tpa-attempts-table]');
            if (wrap) wrap.innerHTML = 'Загрузка...';

            this.request('mgr/practice/attempts/getlist', {
                start: 0,
                limit: 200,
                query: queryEl ? queryEl.value : '',
                status: statusEl ? statusEl.value : ''
            }).then(function (res) {
                self.attempts = self.getResults(res);
                self.renderAttemptsTable();
            }).catch(function (err) {
                if (wrap) wrap.innerHTML = '<div class="tpa-error">' + self.esc(err.message) + '</div>';
                self.notify(err.message, 'error');
            });
        },

        renderAttemptsTable: function () {
            var wrap = this.root.querySelector('[data-tpa-attempts-table]');
            if (!wrap) return;

            if (!this.attempts.length) {
                wrap.innerHTML = '<div class="tpa-empty">Попыток пока нет</div>';
                return;
            }

            var html = '' +
                '<table class="tpa-table tpa-table--clickable">' +
                    '<thead><tr>' +
                        '<th>ID</th><th>Задание</th><th>Пользователь</th><th>Статус</th><th>Попытка</th><th>Отправлено</th>' +
                    '</tr></thead><tbody>';

            this.attempts.forEach(function (row) {
                var active = (parseInt(row.id, 10) || 0) === Admin.selectedAttemptId ? ' class="is-active"' : '';
                html += '<tr data-tpa-attempt-id="' + Admin.esc(row.id) + '"' + active + '>' +
                    '<td>' + Admin.esc(row.id) + '</td>' +
                    '<td>' + Admin.esc(row.practice_title) + '</td>' +
                    '<td>' + Admin.esc(row.user_display || row.email || row.user_id) + '</td>' +
                    '<td><span class="tpa-status tpa-status--' + Admin.esc(row.status) + '">' + Admin.esc(row.status_text || row.status) + '</span></td>' +
                    '<td>' + Admin.esc(row.attempt_num) + '</td>' +
                    '<td>' + Admin.esc(row.submittedon_formatted || '') + '</td>' +
                '</tr>';
            });

            html += '</tbody></table>';
            wrap.innerHTML = html;
        },

        selectAttempt: function (id) {
            var self = this;
            this.selectedAttemptId = id;
            this.selectedAttempt = null;
            this.attempts.forEach(function (row) {
                if ((parseInt(row.id, 10) || 0) === id) self.selectedAttempt = row;
            });

            var selected = this.root.querySelector('[data-tpa-selected-attempt]');
            if (selected && this.selectedAttempt) {
                selected.textContent = 'Попытка #' + id + ' — ' + (this.selectedAttempt.user_display || '') + ' / ' + (this.selectedAttempt.practice_title || '');
            }

            this.renderAttemptsTable();
            this.loadMessages();
        },

        loadMessages: function () {
            var self = this;
            var wrap = this.root.querySelector('[data-tpa-messages]');
            if (!wrap) return;
            if (!this.selectedAttemptId) {
                wrap.innerHTML = 'Выберите попытку слева';
                return;
            }
            wrap.innerHTML = 'Загрузка сообщений...';

            this.request('mgr/practice/messages/getlist', {
                attempt_id: this.selectedAttemptId,
                start: 0,
                limit: 200
            }).then(function (res) {
                self.renderMessages(self.getResults(res));
            }).catch(function (err) {
                wrap.innerHTML = '<div class="tpa-error">' + self.esc(err.message) + '</div>';
                self.notify(err.message, 'error');
            });
        },

        renderMessages: function (rows) {
            var wrap = this.root.querySelector('[data-tpa-messages]');
            if (!wrap) return;
            if (!rows.length) {
                wrap.innerHTML = '<div class="tpa-empty">Сообщений пока нет</div>';
                return;
            }

            var html = '';
            rows.forEach(function (row) {
                html += '<div class="tpa-message tpa-message--' + Admin.esc(row.author_type) + '">' +
                    '<div class="tpa-message__meta">' + Admin.esc(row.createdon_formatted || '') + ' · ' + Admin.esc(row.author_display || row.author_type) + '</div>' +
                    '<div class="tpa-message__text">' + (row.message_html || Admin.esc(row.message || '').replace(/\n/g, '<br>')) + '</div>' +
                    '<div class="tpa-message__files">' + (row.files_html || '') + '</div>' +
                '</div>';
            });
            wrap.innerHTML = html;
        },

        sendReply: function (form) {
            var self = this;
            if (!this.selectedAttemptId) {
                this.notify('Сначала выберите попытку', 'error');
                return;
            }
            var text = form.elements.message ? form.elements.message.value.trim() : '';
            if (!text) {
                this.notify('Напишите сообщение', 'error');
                return;
            }

            this.request('mgr/practice/messages/create', {
                attempt_id: this.selectedAttemptId,
                message: text
            }).then(function () {
                form.reset();
                self.notify('Ответ отправлен');
                self.loadMessages();
                self.loadAttempts();
            }).catch(function (err) {
                self.notify(err.message, 'error');
            });
        },

        setAttemptStatus: function (status) {
            var self = this;
            if (!this.selectedAttemptId) {
                this.notify('Сначала выберите попытку', 'error');
                return;
            }
            var comment = window.prompt('Комментарий к смене статуса. Можно оставить пустым:', '') || '';

            this.request('mgr/practice/attempts/status', {
                id: this.selectedAttemptId,
                status: status,
                comment: comment
            }).then(function () {
                self.notify('Статус изменен');
                self.loadAttempts();
                self.loadMessages();
            }).catch(function (err) {
                self.notify(err.message, 'error');
            });
        }
    };

    window.TrainingPracticeAdmin = Admin;

    function boot() {
        try {
            Admin.init();
        } catch (e) {
            var root = document.getElementById('training-practice-admin');
            if (root) {
                root.innerHTML = '<pre class="tpa-error">Ошибка JS: ' + Admin.esc(e.message) + '</pre>';
            }
            if (window.console && console.error) console.error(e);
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
