<?php
$prefix = $modx->getOption('table_prefix');
$actionId = 6;
$actionsTable = $prefix . 'actions';
$menusTable = $prefix . 'menus';

$modx->exec("UPDATE `{$actionsTable}` SET `controller` = 'controllers/practices', `namespace` = 'training', `haslayout` = 1, `lang_topics` = 'training:default' WHERE `id` = {$actionId}");
$modx->exec("UPDATE `{$menusTable}` SET `action` = {$actionId}, `params` = '', `namespace` = 'training' WHERE `action` = {$actionId} OR `text` = 'Практические задания'");

$cachePath = MODX_CORE_PATH . 'cache/';
foreach (array('mgr/', 'includes/', 'scripts/') as $dir) {
    $path = $cachePath . $dir;
    if (is_dir($path)) {
        $modx->cacheManager->deleteTree($path, array('deleteTop' => false, 'skipDirs' => false));
    }
}
$modx->cacheManager->refresh(array('db' => array(), 'system_settings' => array(), 'scripts' => array()));

echo '<pre>';
echo "OK: no Ext admin action installed\n\n";
$stmt = $modx->query("SELECT `id`, `namespace`, `controller`, `haslayout`, `lang_topics` FROM `{$actionsTable}` WHERE `id` = {$actionId}");
print_r($stmt->fetch(PDO::FETCH_ASSOC));
echo "\nOpen:\n/manager/?a={$actionId}&namespace=training\n";
echo '</pre>';
