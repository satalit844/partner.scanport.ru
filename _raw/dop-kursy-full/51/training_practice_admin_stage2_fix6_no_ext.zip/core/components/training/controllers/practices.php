<?php
/**
 * Training practices manager action controller.
 * MODX 2.8 deprecated manager action. No Ext dependency.
 */
@ini_set('display_errors', '1');
@ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

if (!isset($modx) || !is_object($modx)) {
    if (isset($this) && is_object($this) && isset($this->modx) && is_object($this->modx)) {
        $modx = $this->modx;
    }
}

if (!isset($modx) || !is_object($modx)) {
    print '<pre>Training practices error: MODX object is not available</pre>';
    return;
}

$corePath = $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/');
$corePath = rtrim(str_replace('\\', '/', $corePath), '/') . '/';

$assetsUrl = $modx->getOption('training.assets_url', null, $modx->getOption('assets_url') . 'components/training/');
$assetsUrl = rtrim($assetsUrl, '/') . '/';

$assetsPath = $modx->getOption('training.assets_path', null, $modx->getOption('assets_path') . 'components/training/');
$assetsPath = rtrim(str_replace('\\', '/', $assetsPath), '/') . '/';

$connectorUrl = $assetsUrl . 'connector.php';
$cssUrl = $assetsUrl . 'css/mgr/practices.css?v=' . time();
$jsUrl = $assetsUrl . 'js/mgr/practices/practices.panel.js?v=' . time();

if (!empty($_GET['tp_debug'])) {
    $checks = array(
        'controller' => __FILE__,
        'corePath' => $corePath,
        'assetsPath' => $assetsPath,
        'assetsUrl' => $assetsUrl,
        'connectorUrl' => $connectorUrl,
        'jsFile' => $assetsPath . 'js/mgr/practices/practices.panel.js',
        'cssFile' => $assetsPath . 'css/mgr/practices.css',
        'connectorFile' => $assetsPath . 'connector.php',
        'processorHelper' => $corePath . 'processors/mgr/practice/_helper.php',
        'practicesGetList' => $corePath . 'processors/mgr/practice/practices/getlist.php',
        'attemptsGetList' => $corePath . 'processors/mgr/practice/attempts/getlist.php',
        'messagesGetList' => $corePath . 'processors/mgr/practice/messages/getlist.php',
    );

    print '<pre style="font:13px/1.4 monospace; padding:16px;">';
    print "Training practices controller debug\n";
    print "PHP: " . htmlspecialchars(PHP_VERSION, ENT_QUOTES, 'UTF-8') . "\n";
    foreach ($checks as $label => $path) {
        $ok = (stripos($label, 'url') !== false || $label === 'assetsUrl') ? '' : ((is_file($path) || is_dir($path)) ? ' OK' : ' FAIL');
        print htmlspecialchars($label . ': ' . $path . $ok, ENT_QUOTES, 'UTF-8') . "\n";
    }
    print '</pre>';
    return;
}

print '<link rel="stylesheet" type="text/css" href="' . htmlspecialchars($cssUrl, ENT_QUOTES, 'UTF-8') . '" />';
print '<div id="training-practice-admin" class="training-practice-admin" data-connector="' . htmlspecialchars($connectorUrl, ENT_QUOTES, 'UTF-8') . '">';
print '  <div class="tpa-loading">Загрузка практических заданий...</div>';
print '</div>';
print '<script type="text/javascript">window.TrainingPracticeAdminConfig={connectorUrl:' . json_encode($connectorUrl) . '};</script>';
print '<script type="text/javascript" src="' . htmlspecialchars($jsUrl, ENT_QUOTES, 'UTF-8') . '"></script>';
