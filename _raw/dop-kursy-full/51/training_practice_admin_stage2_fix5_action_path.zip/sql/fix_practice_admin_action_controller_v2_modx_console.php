<?php
@ini_set('display_errors', 1);
error_reporting(E_ALL);

$prefix = $modx->getOption('table_prefix');
$corePath = $modx->getOption('training.core_path', null, MODX_CORE_PATH . 'components/training/');
$corePath = rtrim(str_replace('\\', '/', $corePath), '/') . '/';
$assetsPath = MODX_ASSETS_PATH . 'components/training/';

$actionTable = $prefix . 'actions';
$menuTable = $prefix . 'menus';
$namespaceTable = $prefix . 'namespaces';

print "Training practices action controller fix v2\n";
print str_repeat('=', 64) . "\n";
print "corePath: {$corePath}\n";
print "assetsPath: {$assetsPath}\n";

$stmt = $modx->prepare("SELECT COUNT(*) FROM `{$namespaceTable}` WHERE `name` = 'training'");
$stmt->execute();
$namespaceExists = (int)$stmt->fetchColumn();

if ($namespaceExists) {
    $stmt = $modx->prepare("UPDATE `{$namespaceTable}` SET `path` = :path, `assets_path` = :assets_path WHERE `name` = 'training'");
    $stmt->execute(array(
        ':path' => $corePath,
        ':assets_path' => $assetsPath,
    ));
    print "updated namespace training\n";
} else {
    $stmt = $modx->prepare("INSERT INTO `{$namespaceTable}` (`name`, `path`, `assets_path`) VALUES ('training', :path, :assets_path)");
    $stmt->execute(array(
        ':path' => $corePath,
        ':assets_path' => $assetsPath,
    ));
    print "created namespace training\n";
}

$controller = 'controllers/practices.php';
$actionId = 0;

$stmt = $modx->prepare("SELECT `action` FROM `{$menuTable}` WHERE `text` = 'Практические задания' AND `namespace` = 'training' LIMIT 1");
$stmt->execute();
$menuActionId = (int)$stmt->fetchColumn();

if ($menuActionId > 0) {
    $actionId = $menuActionId;
} else {
    $stmt = $modx->prepare("SELECT `id` FROM `{$actionTable}` WHERE `namespace` = 'training' AND (`controller` LIKE '%practices%') ORDER BY `id` DESC LIMIT 1");
    $stmt->execute();
    $actionId = (int)$stmt->fetchColumn();
}

if ($actionId > 0) {
    $stmt = $modx->prepare("UPDATE `{$actionTable}` SET `controller` = :controller, `namespace` = 'training', `haslayout` = 1, `lang_topics` = 'training:default', `assets` = '' WHERE `id` = :id");
    $stmt->execute(array(
        ':controller' => $controller,
        ':id' => $actionId,
    ));
    print "updated action: {$actionId}\n";
} else {
    $stmt = $modx->prepare("INSERT INTO `{$actionTable}` (`namespace`, `controller`, `haslayout`, `lang_topics`, `assets`) VALUES ('training', :controller, 1, 'training:default', '')");
    $stmt->execute(array(':controller' => $controller));
    $actionId = (int)$modx->lastInsertId();
    print "created action: {$actionId}\n";
}

$menuText = 'Практические задания';
$stmt = $modx->prepare("SELECT COUNT(*) FROM `{$menuTable}` WHERE `text` = :text AND `namespace` = 'training'");
$stmt->execute(array(':text' => $menuText));
$exists = (int)$stmt->fetchColumn();

if ($exists > 0) {
    $stmt = $modx->prepare("UPDATE `{$menuTable}` SET `parent`='components', `action`=:action, `description`=:description, `icon`='icon-tasks', `menuindex`=99, `params`='', `handler`='', `permissions`='', `namespace`='training' WHERE `text`=:text AND `namespace`='training'");
    $stmt->execute(array(':action' => $actionId, ':description' => $menuText, ':text' => $menuText));
    print "updated menu\n";
} else {
    $stmt = $modx->prepare("INSERT INTO `{$menuTable}` (`text`, `parent`, `action`, `description`, `icon`, `menuindex`, `params`, `handler`, `permissions`, `namespace`) VALUES (:text, 'components', :action, :description, 'icon-tasks', 99, '', '', '', 'training')");
    $stmt->execute(array(':text' => $menuText, ':action' => $actionId, ':description' => $menuText));
    print "created menu\n";
}

$paths = array(
    $corePath . 'controllers/practices.php',
    $corePath . 'controllers/mgr/practices.class.php',
    $corePath . 'templates/mgr/practices.tpl',
    $corePath . 'processors/mgr/practice/_helper.php',
    $assetsPath . 'js/mgr/practices/practices.panel.js',
    $assetsPath . 'css/mgr/practices.css',
    $assetsPath . 'connector.php',
);

foreach ($paths as $path) {
    print (is_file($path) ? 'OK   ' : 'FAIL ') . $path . "\n";
}

$stmt = $modx->prepare("SELECT `id`, `namespace`, `controller`, `haslayout`, `lang_topics`, `assets` FROM `{$actionTable}` WHERE `id` = :id");
$stmt->execute(array(':id' => $actionId));
print "\naction row:\n";
print_r($stmt->fetch(PDO::FETCH_ASSOC));

$modx->cacheManager->refresh(array(
    'menu' => array(),
    'actions' => array(),
    'system_settings' => array(),
    'db' => array(),
));

print "\nURL: /manager/?a={$actionId}&namespace=training\n";
print "Debug: /manager/?a={$actionId}&namespace=training&tp_debug=1\n";
