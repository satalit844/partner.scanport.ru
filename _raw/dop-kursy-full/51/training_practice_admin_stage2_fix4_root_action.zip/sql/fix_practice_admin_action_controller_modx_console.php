<?php
@ini_set('display_errors', 1);
error_reporting(E_ALL);

$prefix = $modx->getOption('table_prefix');
$corePath = $modx->getOption('training.core_path', null, MODX_CORE_PATH . 'components/training/');
$corePath = rtrim(str_replace('\\', '/', $corePath), '/') . '/';

$actionTable = $prefix . 'actions';
$menuTable = $prefix . 'menus';
$namespaceTable = $prefix . 'namespaces';

print "Training practices action controller fix\n";
print str_repeat('=', 64) . "\n";
print "corePath: {$corePath}\n";

$stmt = $modx->prepare("SELECT id, namespace, controller FROM `{$actionTable}` WHERE `namespace` = 'training' AND (`controller` = 'practices' OR `controller` = 'practices.php' OR `controller` = 'controllers/practices.php') ORDER BY id DESC LIMIT 1");
$stmt->execute();
$action = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$action) {
    $stmt = $modx->prepare("INSERT INTO `{$actionTable}` (`namespace`, `controller`, `haslayout`, `lang_topics`) VALUES ('training', 'practices', 1, 'training:default')");
    $stmt->execute();
    $actionId = (int)$modx->lastInsertId();
    print "created action: {$actionId}\n";
} else {
    $actionId = (int)$action['id'];
    $stmt = $modx->prepare("UPDATE `{$actionTable}` SET `controller` = 'practices', `namespace` = 'training', `haslayout` = 1, `lang_topics` = 'training:default' WHERE `id` = :id");
    $stmt->execute(array(':id' => $actionId));
    print "updated action: {$actionId}\n";
}

$menuText = 'Практические задания';
$stmt = $modx->prepare("SELECT COUNT(*) FROM `{$menuTable}` WHERE `text` = :text AND `namespace` = 'training'");
$stmt->execute(array(':text' => $menuText));
$exists = (int)$stmt->fetchColumn();

if ($exists > 0) {
    $stmt = $modx->prepare("UPDATE `{$menuTable}` SET `parent`='components', `action`=:action, `description`=:description, `icon`='icon-tasks', `menuindex`=99, `params`='', `handler`='', `permissions`='', `namespace`='training' WHERE `text`=:text AND `namespace`='training'");
    $stmt->execute(array(':action' => $actionId, ':description' => $menuText, ':text' => $menuText));
    print "updated menu\n";
} else {
    $stmt = $modx->prepare("INSERT INTO `{$menuTable}` (`text`, `parent`, `action`, `description`, `icon`, `menuindex`, `params`, `handler`, `permissions`, `namespace`) VALUES (:text, 'components', :action, :description, 'icon-tasks', 99, '', '', '', 'training')");
    $stmt->execute(array(':text' => $menuText, ':action' => $actionId, ':description' => $menuText));
    print "created menu\n";
}

$paths = array(
    $corePath . 'practices',
    $corePath . 'practices.php',
    $corePath . 'controllers/practices.php',
    $corePath . 'controllers/mgr/practices.php',
    $corePath . 'controllers/default/practices.php',
    $corePath . 'controllers/mgr/practices.class.php',
    $corePath . 'templates/mgr/practices.tpl',
    MODX_ASSETS_PATH . 'components/training/js/mgr/practices/practices.panel.js',
    MODX_ASSETS_PATH . 'components/training/css/mgr/practices.css',
    MODX_ASSETS_PATH . 'components/training/connector.php',
);

foreach ($paths as $path) {
    print (is_file($path) ? 'OK   ' : 'FAIL ') . $path . "\n";
}

$modx->cacheManager->refresh(array(
    'menu' => array(),
    'actions' => array(),
    'system_settings' => array(),
));

print "\nURL: /manager/?a={$actionId}&namespace=training\n";
print "Debug: /manager/?a={$actionId}&namespace=training&tp_debug=1\n";
