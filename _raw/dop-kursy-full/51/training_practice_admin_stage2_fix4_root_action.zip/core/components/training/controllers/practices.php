<?php
/**
 * Training practices manager action controller.
 * Compatible with deprecated MODX 2 manager action include.
 * Debug URL: /manager/?a=6&namespace=training&tp_debug=1
 */
@ini_set('display_errors', '1');
@ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

$tpDebug = !empty($_GET['tp_debug']);

if (!function_exists('tp_practices_print_line')) {
    function tp_practices_print_line($label, $value = '')
    {
        print htmlspecialchars((string)$label, ENT_QUOTES, 'UTF-8');
        if ($value !== '') {
            print ': ' . htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
        }
        print "\n";
    }
}

try {
    if (!isset($modx) || !is_object($modx)) {
        if (isset($this) && is_object($this) && isset($this->modx) && is_object($this->modx)) {
            $modx = $this->modx;
        }
    }

    if (!isset($modx) || !is_object($modx)) {
        print '<pre>';
        tp_practices_print_line('ERROR', 'MODX object is not available');
        tp_practices_print_line('FILE', __FILE__);
        tp_practices_print_line('PHP', PHP_VERSION);
        print '</pre>';
        exit;
    }

    $corePath = $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/');
    $corePath = rtrim(str_replace('\\', '/', $corePath), '/') . '/';

    $assetsUrl = $modx->getOption('training.assets_url', null, $modx->getOption('assets_url') . 'components/training/');
    $assetsUrl = rtrim($assetsUrl, '/') . '/';

    $assetsPath = $modx->getOption('training.assets_path', null, $modx->getOption('assets_path') . 'components/training/');
    $assetsPath = rtrim(str_replace('\\', '/', $assetsPath), '/') . '/';

    $connectorUrl = $assetsUrl . 'connector.php';
    $cssUrl = $assetsUrl . 'css/mgr/practices.css?v=' . time();
    $jsUrl = $assetsUrl . 'js/mgr/practices/practices.panel.js?v=' . time();

    $checks = array(
        'controller' => __FILE__,
        'rootActionNoExt' => $corePath . 'practices',
        'rootActionPhp' => $corePath . 'practices.php',
        'corePath' => $corePath,
        'assetsPath' => $assetsPath,
        'assetsUrl' => $assetsUrl,
        'connectorUrl' => $connectorUrl,
        'classFile' => $corePath . 'controllers/mgr/practices.class.php',
        'templateFile' => $corePath . 'templates/mgr/practices.tpl',
        'jsFile' => $assetsPath . 'js/mgr/practices/practices.panel.js',
        'cssFile' => $assetsPath . 'css/mgr/practices.css',
        'connectorFile' => $assetsPath . 'connector.php',
        'processorHelper' => $corePath . 'processors/mgr/practice/_helper.php',
    );

    if ($tpDebug) {
        print '<pre>';
        tp_practices_print_line('Training practices controller debug');
        tp_practices_print_line('PHP', PHP_VERSION);
        foreach ($checks as $label => $path) {
            if (stripos($label, 'url') !== false) {
                tp_practices_print_line($label, $path);
                continue;
            }
            if ($label === 'corePath' || $label === 'assetsPath') {
                tp_practices_print_line($label, $path . ' | ' . (is_dir($path) ? 'OK' : 'FAIL'));
                continue;
            }
            tp_practices_print_line($label, $path . ' | ' . (is_file($path) ? 'OK' : 'FAIL'));
        }
        print '</pre>';
        exit;
    }

    $html = '';
    $html .= '<div id="training-practices-debug" style="display:none">training practices action loaded</div>';
    $html .= '<div id="training-panel-practices-wrap"></div>';
    $html .= '<script type="text/javascript" src="' . htmlspecialchars($jsUrl, ENT_QUOTES, 'UTF-8') . '"></script>';
    $html .= '<link rel="stylesheet" type="text/css" href="' . htmlspecialchars($cssUrl, ENT_QUOTES, 'UTF-8') . '" />';
    $html .= '<script type="text/javascript">';
    $html .= 'window.Training=window.Training||{};';
    $html .= 'Training.config=Training.config||{};';
    $html .= 'Training.config.connector_url=' . json_encode($connectorUrl) . ';';
    $html .= 'Ext.onReady(function(){';
    $html .= 'if(!Ext.ComponentMgr.types["training-panel-practices"]){Ext.Msg.alert("Ошибка","JS панель training-panel-practices не загружена. Проверь файл assets/components/training/js/mgr/practices/practices.panel.js");return;}';
    $html .= 'MODx.add({xtype:"training-panel-practices"});';
    $html .= '});';
    $html .= '</script>';

    return $html;
} catch (Exception $e) {
    print '<pre>';
    tp_practices_print_line('Training practices fatal');
    tp_practices_print_line('Message', $e->getMessage());
    tp_practices_print_line('File', $e->getFile());
    tp_practices_print_line('Line', $e->getLine());
    tp_practices_print_line('Trace', $e->getTraceAsString());
    print '</pre>';
    exit;
} catch (Throwable $e) {
    print '<pre>';
    tp_practices_print_line('Training practices fatal');
    tp_practices_print_line('Message', $e->getMessage());
    tp_practices_print_line('File', $e->getFile());
    tp_practices_print_line('Line', $e->getLine());
    tp_practices_print_line('Trace', $e->getTraceAsString());
    print '</pre>';
    exit;
}
