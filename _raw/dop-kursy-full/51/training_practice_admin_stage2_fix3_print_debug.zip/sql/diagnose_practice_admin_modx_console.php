<?php
@ini_set('display_errors', '1');
error_reporting(E_ALL);

print "Training practices diagnose\n";
print "================================================================\n";

$prefix = $modx->getOption('table_prefix');
$corePath = $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/');
$corePath = rtrim(str_replace('\\', '/', $corePath), '/') . '/';
$assetsPath = $modx->getOption('training.assets_path', null, $modx->getOption('assets_path') . 'components/training/');
$assetsPath = rtrim(str_replace('\\', '/', $assetsPath), '/') . '/';
$assetsUrl = $modx->getOption('training.assets_url', null, $modx->getOption('assets_url') . 'components/training/');
$assetsUrl = rtrim($assetsUrl, '/') . '/';

print "corePath: {$corePath}\n";
print "assetsPath: {$assetsPath}\n";
print "assetsUrl: {$assetsUrl}\n";
print "PHP: " . PHP_VERSION . "\n";
print "----------------------------------------------------------------\n";

$files = array(
    'controllers/practices.php' => $corePath . 'controllers/practices.php',
    'controllers/mgr/practices.php' => $corePath . 'controllers/mgr/practices.php',
    'controllers/default/practices.php' => $corePath . 'controllers/default/practices.php',
    'controllers/mgr/practices.class.php' => $corePath . 'controllers/mgr/practices.class.php',
    'templates/mgr/practices.tpl' => $corePath . 'templates/mgr/practices.tpl',
    'processors/mgr/practice/_helper.php' => $corePath . 'processors/mgr/practice/_helper.php',
    'assets js panel' => $assetsPath . 'js/mgr/practices/practices.panel.js',
    'assets css' => $assetsPath . 'css/mgr/practices.css',
    'assets connector' => $assetsPath . 'connector.php',
);

foreach ($files as $name => $path) {
    print str_pad($name, 42) . ' ' . (is_file($path) ? 'OK   ' : 'FAIL ') . $path . "\n";
}

print "----------------------------------------------------------------\n";

$actionsTable = $prefix . 'actions';
$menusTable = $prefix . 'menus';

$stmt = $modx->prepare("SELECT * FROM `{$actionsTable}` WHERE `namespace` = 'training' AND `controller` = 'practices' LIMIT 5");
$stmt->execute();
$actions = $stmt->fetchAll(PDO::FETCH_ASSOC);
print "actions:\n";
print_r($actions);

$stmt = $modx->prepare("SELECT * FROM `{$menusTable}` WHERE `namespace` = 'training' OR `text` LIKE '%Практи%' LIMIT 10");
$stmt->execute();
$menus = $stmt->fetchAll(PDO::FETCH_ASSOC);
print "menus:\n";
print_r($menus);

print "----------------------------------------------------------------\n";
$errorLog = $modx->getOption('core_path') . 'cache/logs/error.log';
print "MODX error log: {$errorLog}\n";
if (is_file($errorLog)) {
    $lines = file($errorLog);
    $tail = array_slice($lines, -80);
    print implode('', $tail);
} else {
    print "error.log not found\n";
}
