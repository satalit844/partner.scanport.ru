<?php
/** @var modX $modx */
if (!isset($modx) || !is_object($modx)) {
    if (isset($this) && is_object($this) && isset($this->modx) && is_object($this->modx)) {
        $modx = $this->modx;
    }
}
$corePath = $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/');
return include rtrim($corePath, '/') . '/controllers/practices.php';
