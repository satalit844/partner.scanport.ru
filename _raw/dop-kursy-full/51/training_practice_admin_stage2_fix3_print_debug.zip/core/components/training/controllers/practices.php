<?php
/**
 * Training practices manager action controller.
 * Safe MODX 2.8 old-action controller with print diagnostics.
 *
 * Debug URL: /manager/?a=6&namespace=training&tp_debug=1
 */
@ini_set('display_errors', '1');
@ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

$tpDebug = !empty($_GET['tp_debug']);

function tp_practices_print_line($label, $value = '')
{
    print htmlspecialchars((string)$label, ENT_QUOTES, 'UTF-8');
    if ($value !== '') {
        print ': ' . htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
    print "\n";
}

try {
    if (!isset($modx) || !is_object($modx)) {
        if (isset($this) && is_object($this) && isset($this->modx) && is_object($this->modx)) {
            $modx = $this->modx;
        }
    }

    if (!isset($modx) || !is_object($modx)) {
        print '<pre>';
        tp_practices_print_line('ERROR', 'MODX object is not available in practices.php');
        tp_practices_print_line('FILE', __FILE__);
        tp_practices_print_line('PHP', PHP_VERSION);
        print '</pre>';
        exit;
    }

    $corePath = $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/');
    $corePath = rtrim(str_replace('\\', '/', $corePath), '/') . '/';

    $assetsUrl = $modx->getOption('training.assets_url', null, $modx->getOption('assets_url') . 'components/training/');
    $assetsUrl = rtrim($assetsUrl, '/') . '/';

    $connectorUrl = $assetsUrl . 'connector.php';
    $cssUrl = $assetsUrl . 'css/mgr/practices.css';
    $jsUrl = $assetsUrl . 'js/mgr/practices/practices.panel.js';

    $assetsPath = $modx->getOption('training.assets_path', null, $modx->getOption('assets_path') . 'components/training/');
    $assetsPath = rtrim(str_replace('\\', '/', $assetsPath), '/') . '/';

    $checks = array(
        'controller' => __FILE__,
        'corePath' => $corePath,
        'assetsUrl' => $assetsUrl,
        'connectorUrl' => $connectorUrl,
        'classFile' => $corePath . 'controllers/mgr/practices.class.php',
        'templateFile' => $corePath . 'templates/mgr/practices.tpl',
        'jsFile' => $assetsPath . 'js/mgr/practices/practices.panel.js',
        'cssFile' => $assetsPath . 'css/mgr/practices.css',
        'connectorFile' => $assetsPath . 'connector.php',
        'processorHelper' => $corePath . 'processors/mgr/practice/_helper.php',
    );

    if ($tpDebug) {
        print '<pre>';
        tp_practices_print_line('Training practices controller debug');
        tp_practices_print_line('PHP', PHP_VERSION);
        tp_practices_print_line('MODX', method_exists($modx, 'getVersionData') ? print_r($modx->getVersionData(), true) : 'unknown');
        foreach ($checks as $label => $path) {
            if (strpos($label, 'Url') !== false) {
                tp_practices_print_line($label, $path);
                continue;
            }
            tp_practices_print_line($label, $path . ' | ' . (is_file($path) ? 'OK' : 'FAIL'));
        }
        print '</pre>';
        exit;
    }

    if (method_exists($modx, 'regClientCSS')) {
        $modx->regClientCSS($cssUrl);
    }

    if (method_exists($modx, 'regClientStartupScript')) {
        $modx->regClientStartupScript($jsUrl);
    }

    $html = '<div id="training-panel-practices-wrap"></div>';
    $html .= '<script type="text/javascript">\n';
    $html .= 'window.Training = window.Training || {};\n';
    $html .= 'Training.config = Training.config || {};\n';
    $html .= 'Training.config.connector_url = ' . json_encode($connectorUrl) . ';\n';
    $html .= 'Ext.onReady(function(){\n';
    $html .= '    if (!Ext.ComponentMgr.types["training-panel-practices"]) {\n';
    $html .= '        Ext.Msg.alert("Ошибка", "JS панель training-panel-practices не загружена. Проверь assets/components/training/js/mgr/practices/practices.panel.js");\n';
    $html .= '        return;\n';
    $html .= '    }\n';
    $html .= '    MODx.add({xtype: "training-panel-practices"});\n';
    $html .= '});\n';
    $html .= '</script>';

    return $html;
} catch (Throwable $e) {
    print '<pre>';
    tp_practices_print_line('Training practices fatal');
    tp_practices_print_line('Message', $e->getMessage());
    tp_practices_print_line('File', $e->getFile());
    tp_practices_print_line('Line', $e->getLine());
    tp_practices_print_line('Trace', $e->getTraceAsString());
    print '</pre>';
    exit;
}
