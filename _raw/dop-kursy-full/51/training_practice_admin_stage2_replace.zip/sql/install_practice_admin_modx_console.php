<?php
$prefix = $modx->getOption('table_prefix');

function tp_column_exists(modX $modx, $table, $column) {
    $stmt = $modx->query("SHOW COLUMNS FROM `{$table}` LIKE " . $modx->quote($column));
    return $stmt && $stmt->fetchColumn();
}

function tp_insert_dynamic(modX $modx, $table, array $data) {
    $columns = array();
    $params = array();
    $placeholders = array();

    foreach ($data as $key => $value) {
        if (!tp_column_exists($modx, $table, $key)) {
            continue;
        }
        $columns[] = '`' . $key . '`';
        $placeholder = ':' . $key;
        $placeholders[] = $placeholder;
        $params[$placeholder] = $value;
    }

    if (!$columns) {
        return false;
    }

    $sql = "INSERT INTO `{$table}` (" . implode(',', $columns) . ") VALUES (" . implode(',', $placeholders) . ")";
    $stmt = $modx->prepare($sql);
    return $stmt && $stmt->execute($params);
}

function tp_update_dynamic(modX $modx, $table, array $data, $where, array $whereParams) {
    $sets = array();
    $params = $whereParams;

    foreach ($data as $key => $value) {
        if (!tp_column_exists($modx, $table, $key)) {
            continue;
        }
        $placeholder = ':set_' . $key;
        $sets[] = '`' . $key . '` = ' . $placeholder;
        $params[$placeholder] = $value;
    }

    if (!$sets) {
        return false;
    }

    $sql = "UPDATE `{$table}` SET " . implode(',', $sets) . " WHERE " . $where;
    $stmt = $modx->prepare($sql);
    return $stmt && $stmt->execute($params);
}

$settingsTable = $prefix . 'system_settings';
$key = 'training.training_practice_resource_id';
$stmt = $modx->prepare("SELECT COUNT(*) FROM `{$settingsTable}` WHERE `key` = :key");
$stmt->execute(array(':key' => $key));
if ((int)$stmt->fetchColumn() > 0) {
    tp_update_dynamic($modx, $settingsTable, array(
        'value' => '176',
        'xtype' => 'numberfield',
        'namespace' => 'training',
        'area' => 'training',
        'editedon' => date('Y-m-d H:i:s'),
    ), '`key` = :key', array(':key' => $key));
} else {
    tp_insert_dynamic($modx, $settingsTable, array(
        'key' => $key,
        'value' => '176',
        'xtype' => 'numberfield',
        'namespace' => 'training',
        'area' => 'training',
        'editedon' => date('Y-m-d H:i:s'),
    ));
}

$actionsTable = $prefix . 'actions';
$menusTable = $prefix . 'menus';
$actionId = 0;

$actionsExistsStmt = $modx->query("SHOW TABLES LIKE " . $modx->quote($actionsTable));
if ($actionsExistsStmt && $actionsExistsStmt->fetchColumn()) {
    $stmt = $modx->prepare("SELECT `id` FROM `{$actionsTable}` WHERE `namespace` = :namespace AND `controller` = :controller LIMIT 1");
    $stmt->execute(array(':namespace' => 'training', ':controller' => 'practices'));
    $actionId = (int)$stmt->fetchColumn();

    if ($actionId <= 0) {
        tp_insert_dynamic($modx, $actionsTable, array(
            'namespace' => 'training',
            'controller' => 'practices',
            'haslayout' => 1,
            'lang_topics' => 'training:default',
            'assets' => '',
        ));
        $actionId = (int)$modx->lastInsertId();
    }
}

$menusExistsStmt = $modx->query("SHOW TABLES LIKE " . $modx->quote($menusTable));
if ($actionId > 0 && $menusExistsStmt && $menusExistsStmt->fetchColumn()) {
    $menuKey = 'Практические задания';
    $stmt = $modx->prepare("SELECT `text` FROM `{$menusTable}` WHERE `text` = :text LIMIT 1");
    $stmt->execute(array(':text' => $menuKey));
    $exists = (string)$stmt->fetchColumn();

    $menuData = array(
        'text' => $menuKey,
        'parent' => 'components',
        'action' => $actionId,
        'description' => 'Практические задания',
        'icon' => 'icon-tasks',
        'menuindex' => 99,
        'params' => '',
        'handler' => '',
        'permissions' => '',
        'namespace' => 'training',
    );

    if ($exists !== '') {
        tp_update_dynamic($modx, $menusTable, $menuData, '`text` = :text', array(':text' => $menuKey));
    } else {
        tp_insert_dynamic($modx, $menusTable, $menuData);
    }
}

$modx->cacheManager->refresh(array(
    'system_settings' => array(),
    'menu' => array(),
));

echo "OK\n";
echo "Практики: /manager/?a=" . $actionId . "\n";
echo "Если пункт меню не появился сразу — перелогинься в MODX Manager.\n";
