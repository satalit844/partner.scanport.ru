Пакет 1: модель TrainingModuleLesson

1. Распаковать содержимое папки training поверх core/components/training/
2. Очистить core/cache/
3. Запустить один раз migration: core/components/training/_migrations/20260330_module_lessons.php
   - через MODX Console: include MODX_BASE_PATH . "core/components/training/_migrations/20260330_module_lessons.php";
   - или через CLI из корня сайта: php core/components/training/_migrations/20260330_module_lessons.php
4. Проверить, что появилась таблица training_module_lessons и поля lesson_id в videos/slides

Важно: у тебя в config указано table_prefix = modx_partners без подчёркивания в конце.
PHP-миграция берёт это значение автоматически, поэтому она безопаснее SQL-файла.
