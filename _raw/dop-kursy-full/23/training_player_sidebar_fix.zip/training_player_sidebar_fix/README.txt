Заменить:
core/components/training/elements/chunks/training/player/page.tpl
theme/js/app-training.js
theme/css/training.css
