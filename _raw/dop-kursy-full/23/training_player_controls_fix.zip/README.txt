Заменить 3 файла: page.tpl, app-training.js, training.css
