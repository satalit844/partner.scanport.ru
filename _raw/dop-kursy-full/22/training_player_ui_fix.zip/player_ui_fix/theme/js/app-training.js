var AppTraining = (function () {
    return {
        init: function () {
            this.filtersSwipers();
            this.filtersLogic();
            this.sertModal();
            this.historyModal();
            this.usersCoursesUi();
            this.bindMyCourseLinks();
            this.webMyCourses();
            this.coursePage();
            this.courseStructure();
            this.testListModal();
            this.trainingPlayer();
        },

        bindMyCourseLinks: function () {
            $(document)
                .off('click.appTrainingMyCourseLink')
                .on('click.appTrainingMyCourseLink', '#my-courses .course-item[data-href], .my-courses .course-item[data-href]', function (e) {
                    if ($(e.target).closest('a, button, input, label').length) {
                        return;
                    }

                    var href = $(this).attr('data-href');
                    if (href && href !== '#') {
                        window.location.href = href;
                    }
                })
                .off('keydown.appTrainingMyCourseLink')
                .on('keydown.appTrainingMyCourseLink', '#my-courses .course-item[data-href], .my-courses .course-item[data-href]', function (e) {
                    if (e.key !== 'Enter' && e.key !== ' ') {
                        return;
                    }

                    e.preventDefault();

                    var href = $(this).attr('data-href');
                    if (href && href !== '#') {
                        window.location.href = href;
                    }
                });
        },

        getTrainingConnectorUrl: function ($scope) {
            if ($scope && $scope.length) {
                var local = $scope.data('training-connector');
                if (local) return local;
            }

            if (window.TrainingWebConfig && window.TrainingWebConfig.connectorUrl) {
                return window.TrainingWebConfig.connectorUrl;
            }

            return '/assets/components/training/web.connector.php';
        },

        getTrainingContext: function ($scope) {
            if ($scope && $scope.length) {
                var local = $scope.data('training-context');
                if (local) return local;
            }

            if (window.TrainingWebConfig && window.TrainingWebConfig.contextKey) {
                return window.TrainingWebConfig.contextKey;
            }

            return 'web';
        },

        trainingRequest: function (action, data, $scope) {
            return $.ajax({
                url: this.getTrainingConnectorUrl($scope),
                type: 'POST',
                dataType: 'json',
                data: $.extend({
                    action: action,
                    ctx: this.getTrainingContext($scope)
                }, data || {})
            });
        },

        escapeHtml: function (value) {
            return $('<div>').text(value == null ? '' : String(value)).html();
        },

        webMyCourses: function () {
            var self = this;
            var $wrap = $('#my-courses[data-training-page="mycourses"], .my-courses[data-training-page="mycourses"]').first();
            if (!$wrap.length) return;

            var $list = $wrap.find('.corses-items').first();
            if (!$list.length) return;

            function renderItem(item) {
                var title = self.escapeHtml(item.title || item.pagetitle || 'Без названия');
                var image = self.escapeHtml(item.image || 'theme/images/training/image_2.jpg');
                var url = self.escapeHtml(item.url || '#');
                var progress = parseInt(item.progress_percent || 0, 10);

                if (item.state === 'progress') {
                    return '' +
                        '<div class="course-item ' + self.escapeHtml(item.item_class || 'is-progress') + '" data-href="' + url + '" tabindex="0" role="link">' +
                            '<div class="course-item__head">' +
                                '<div class="course-item__title">' + title + '</div>' +
                                '<div class="course-item__logo"><img src="' + image + '" alt=""></div>' +
                            '</div>' +
                            '<div class="course-item__stats">' +
                                '<div class="course-stat">' +
                                    '<div class="course-stat__value">' + (item.videos_completed || 0) + '/' + (item.videos_total || 0) + '</div>' +
                                    '<div class="course-stat__label">видео</div>' +
                                '</div>' +
                                '<div class="course-stat">' +
                                    '<div class="course-stat__value">' + (item.modules_completed || 0) + '/' + (item.modules_total || 0) + '</div>' +
                                    '<div class="course-stat__label">Модули</div>' +
                                '</div>' +
                                '<div class="course-stat">' +
                                    '<div class="course-stat__value">' + (item.tests_passed || 0) + '/' + (item.tests_total || 0) + '</div>' +
                                    '<div class="course-stat__label">Теста</div>' +
                                '</div>' +
                            '</div>' +
                            '<div class="course-item__progress">' +
                                '<div class="progress-track"><div class="progress-fill" style="width: ' + progress + '%"></div></div>' +
                                '<div class="progress-value">' + progress + '%</div>' +
                            '</div>' +
                        '</div>';
                }

                return '' +
                    '<div class="course-item ' + self.escapeHtml(item.item_class || 'is-new') + '" data-href="' + url + '" tabindex="0" role="link">' +
                        '<div class="course-item__head">' +
                            '<div class="course-item__title">' + title + '</div>' +
                            '<div class="course-item__logo"><img src="' + image + '" alt=""></div>' +
                        '</div>' +
                        '<div class="course-item__status">' +
                            '<span class="course-status__dot" aria-hidden="true"></span>' +
                            '<span>' + self.escapeHtml(item.status_text || '') + '</span>' +
                        '</div>' +
                        '<div class="course-item__progress">' +
                            '<div class="progress-track"><div class="progress-fill" style="width: ' + progress + '%"></div></div>' +
                            '<div class="progress-value">' + progress + '%</div>' +
                        '</div>' +
                    '</div>';
            }

            function applyCurrentFilter() {
                var $activeFilter = $wrap.find('.filters-corses .course-filter__chip.is-active').first();
                if ($activeFilter.length) {
                    $activeFilter.trigger('click');
                }
            }

            function render(rows) {
                if (!rows || !rows.length) {
                    $list.html('<div class="w-100">У вас пока нет назначенных курсов</div>');
                    return;
                }

                var html = '';
                $.each(rows, function (_, item) {
                    html += renderItem(item);
                });

                $list.html(html);
                applyCurrentFilter();
            }

            self.trainingRequest('web/course/mycourses', {}, $wrap)
                .done(function (res) {
                    if (!res || !res.success || !res.object) {
                        $list.html('<div class="w-100">Не удалось загрузить курсы</div>');
                        return;
                    }

                    render(res.object.results || []);
                })
                .fail(function () {
                    $list.html('<div class="w-100">Ошибка загрузки курсов</div>');
                });
        },

        trainingPlayer: function () {
            var self = this;
            var $player = $('.training-player[data-training-page="player"]').first();
            if (!$player.length) return;

            var player = $player.find('.js-player-video').get(0);
            if (!player) return;

            var requestedModule = parseInt($player.attr('data-player-module') || 0, 10) || 0;
            var requestedLesson = parseInt($player.attr('data-player-lesson') || 0, 10) || 0;
            var currentData = null;
            var saveInterval = null;
            var lastSavedTime = -1;
            var loadXhr = null;
            var saveXhr = null;
            var completeSent = false;
            var pendingResumeTime = 0;
            var ignoreLoadedMetadata = false;

            var $title = $player.find('.js-player-title');
            var $subtitle = $player.find('.js-player-subtitle');
            var $counter = $player.find('.js-player-counter');
            var $progressFill = $player.find('.js-player-progress-fill');
            var $progressBar = $player.find('.js-player-progress');
            var $progressTimeCurrent = $player.find('.js-player-time-current');
            var $progressTimeTotal = $player.find('.js-player-time-total');
            var $moduleProgress = $player.find('.js-player-module-progress');
            var $courseProgress = $player.find('.js-player-course-progress');
            var $lessonStatus = $player.find('.js-player-lesson-status');
            var $message = $player.find('.js-player-message');
            var $previewImage = $player.find('.js-player-preview-image');
            var $lessonList = $player.find('.js-player-lesson-list');
            var $slideList = $player.find('.js-player-slide-list');
            var $prevBtn = $player.find('.js-player-prev');
            var $nextBtn = $player.find('.js-player-next');
            var $backBtn = $player.find('.js-player-back');
            var $soundBtn = $player.find('.js-player-sound');
            var $volume = $player.find('.js-player-volume');
            var $sidebarToggle = $player.find('.js-player-sidebar-toggle');
            var $sidebarSearch = $player.find('.js-player-sidebar-search');
            var $resumeModal = $player.find('.js-player-resume-modal');
            var $resumeText = $player.find('.js-player-resume-text');

            function formatTime(value) {
                value = parseInt(value || 0, 10);
                if (!value || value < 0) value = 0;
                var h = Math.floor(value / 3600);
                var m = Math.floor((value % 3600) / 60);
                var s = value % 60;
                if (h > 0) {
                    return h + ':' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
                }
                return m + ':' + String(s).padStart(2, '0');
            }

            function setMessage(text, isError) {
                if (!text) {
                    $message.addClass('d-none').text('').removeClass('text-danger');
                    return;
                }
                $message.removeClass('d-none').text(text);
                $message.toggleClass('text-danger', !!isError);
            }

            function stopSaveInterval() {
                if (saveInterval) {
                    clearInterval(saveInterval);
                    saveInterval = null;
                }
            }

            function startSaveInterval() {
                stopSaveInterval();
                saveInterval = setInterval(function () {
                    saveProgress(false);
                }, 5000);
            }

            function updateUrl(moduleResourceId, lessonId) {
                if (!window.history || !window.history.replaceState) return;
                var url = new URL(window.location.href);
                url.searchParams.set('module', moduleResourceId);
                url.searchParams.set('lesson', lessonId);
                window.history.replaceState({}, '', url.toString());
            }

            function updateVolumeUi() {
                var volume = player.muted ? 0 : player.volume;
                $volume.val(Math.round(volume * 100));
                $soundBtn.toggleClass('is-muted', player.muted || volume <= 0.01);
            }

            function updateVideoProgress() {
                var duration = player.duration || (currentData && currentData.lesson ? parseInt(currentData.lesson.duration_seconds || 0, 10) : 0);
                if (!duration || !isFinite(duration) || duration <= 0) {
                    $progressFill.css('width', '0%');
                    $progressTimeCurrent.text('0:00');
                    $progressTimeTotal.text('0:00');
                    return;
                }
                var pct = Math.max(0, Math.min(100, (player.currentTime / duration) * 100));
                $progressFill.css('width', pct + '%');
                $progressTimeCurrent.text(formatTime(Math.floor(player.currentTime || 0)));
                $progressTimeTotal.text(formatTime(Math.floor(duration)));
                updateActiveSlideByTime();
                maybeCompleteAutomatically();
            }

            function maybeCompleteAutomatically() {
                if (!currentData || !player.duration || !isFinite(player.duration) || completeSent) {
                    return;
                }
                var ratio = player.currentTime / player.duration;
                if (ratio >= 0.9) {
                    completeSent = true;
                    saveProgress(true);
                }
            }

            function updateActiveSlideByTime() {
                if (!currentData || !currentData.slides || !currentData.slides.length) {
                    return;
                }
                var currentMs = Math.floor((player.currentTime || 0) * 1000);
                var activeId = 0;
                $.each(currentData.slides, function (_, slide) {
                    if ((slide.timecode_ms || 0) <= currentMs) {
                        activeId = slide.id;
                    }
                });
                if (!activeId) {
                    activeId = currentData.slides[0].id;
                }
                $slideList.find('.player-slide-item').removeClass('is-active');
                $slideList.find('.player-slide-item[data-slide-id="' + activeId + '"]').addClass('is-active');
            }

            function applyNav(data) {
                var prevUrl = data.nav && data.nav.prev_url ? data.nav.prev_url : '';
                var nextUrl = data.nav && data.nav.next_url ? data.nav.next_url : '';
                var nextLocked = data.nav && parseInt(data.nav.next_locked || 0, 10) === 1;

                $prevBtn.prop('disabled', !prevUrl).attr('data-url', prevUrl || '');
                $nextBtn.prop('disabled', !nextUrl).attr('data-url', nextUrl || '');
                if (nextLocked) {
                    $nextBtn.prop('disabled', true).attr('data-url', '');
                }
            }

            function applySearch() {
                var query = $.trim($sidebarSearch.val() || '').toLowerCase();
                function toggleItems($list) {
                    var visible = 0;
                    $list.find('.player-slide-item').each(function () {
                        var text = $.trim($(this).text() || '').toLowerCase();
                        var show = !query || text.indexOf(query) !== -1;
                        $(this).toggle(show);
                        if (show) visible++;
                    });
                    var $empty = $list.parent().find('.js-player-empty[data-for="' + $list.attr('data-list-type') + '"]');
                    if ($empty.length) {
                        $empty.toggle(visible === 0);
                    }
                }
                toggleItems($lessonList);
                toggleItems($slideList);
            }

            function renderLessons(data) {
                var html = '';
                $.each(data.lessons || [], function (_, item) {
                    var disabled = parseInt(item.locked || 0, 10) === 1;
                    var activeClass = parseInt(item.is_current || 0, 10) === 1 ? ' is-active' : '';
                    var disabledAttr = disabled ? ' disabled aria-disabled="true"' : '';
                    var subtitle = disabled ? 'Заблокировано' : (parseInt(item.completed || 0, 10) === 1 ? 'Пройдено' : ((item.progress_percent || 0) > 0 ? ('В процессе ' + item.progress_percent + '%') : 'Доступно'));
                    html += '' +
                        '<button type="button" class="player-slide-item js-player-lesson-item' + activeClass + '" data-url="' + self.escapeHtml(item.url || '') + '" data-locked="' + (disabled ? '1' : '0') + '"' + disabledAttr + '>' +
                            '<span class="player-slide-item__thumb player-slide-item__thumb--lesson"><img src="theme/images/training/curses/play-ico.png" alt=""></span>' +
                            '<span class="player-slide-item__content">' +
                                '<span class="player-slide-item__text">' + self.escapeHtml(item.title || '') + '</span>' +
                                '<span class="player-slide-item__meta">' + self.escapeHtml(subtitle) + '</span>' +
                            '</span>' +
                        '</button>';
                });
                $lessonList.html(html);
                applySearch();
            }

            function renderSlides(data) {
                var html = '';
                $.each(data.slides || [], function (_, item) {
                    html += '' +
                        '<button type="button" class="player-slide-item js-player-slide-jump" data-slide-id="' + item.id + '" data-timecode="' + (item.timecode_ms || 0) + '">' +
                            '<span class="player-slide-item__thumb"><img src="' + self.escapeHtml(item.image || '') + '" alt=""></span>' +
                            '<span class="player-slide-item__content">' +
                                '<span class="player-slide-item__text">' + self.escapeHtml(item.title || ('Слайд ' + (item.slide_no || ''))) + '</span>' +
                                '<span class="player-slide-item__meta">' + self.escapeHtml(formatTime(Math.floor((item.timecode_ms || 0) / 1000))) + '</span>' +
                            '</span>' +
                        '</button>';
                });
                $slideList.html(html);
                applySearch();
            }

            function showResumeModal(seconds) {
                pendingResumeTime = parseInt(seconds || 0, 10) || 0;
                if (pendingResumeTime <= 5) {
                    return false;
                }
                $resumeText.text('Вы остановились на отметке ' + formatTime(pendingResumeTime) + '. Продолжить с этого места?');
                $resumeModal.addClass('is-open');
                return true;
            }

            function hideResumeModal() {
                $resumeModal.removeClass('is-open');
            }

            function renderData(data) {
                currentData = data || null;
                if (!currentData) return;
                completeSent = currentData.lesson && parseInt(currentData.lesson.completed || 0, 10) === 1;
                requestedModule = parseInt(data.resolved_module_resource_id || requestedModule, 10) || requestedModule;
                requestedLesson = parseInt(data.resolved_lesson_id || requestedLesson, 10) || requestedLesson;

                updateUrl(requestedModule, requestedLesson);
                $title.text((data.module && data.module.title ? data.module.title : '') + ' • ' + (data.lesson && data.lesson.title ? data.lesson.title : ''));
                $subtitle.text((data.course && data.course.title ? data.course.title : '') + (data.lesson && data.lesson.duration_text ? (' • ' + data.lesson.duration_text) : ''));
                $counter.text((data.nav ? data.nav.current_index : 0) + ' из ' + (data.nav ? data.nav.total_lessons : 0));
                $moduleProgress.html('<span>Модуль ' + parseInt(data.module && data.module.progress_percent || 0, 10) + '%</span>');
                $courseProgress.html('<span>Курс ' + parseInt(data.course && data.course.progress_percent || 0, 10) + '%</span>');
                $lessonStatus.toggleClass('d-none', !(data.lesson && parseInt(data.lesson.completed || 0, 10) === 1));
                $previewImage.attr('src', (data.lesson && data.lesson.poster) ? data.lesson.poster : 'theme/images/training/player/img-slide-1.jpg');
                $backBtn.attr('data-url', data.course && data.course.url ? data.course.url : '');

                renderLessons(data);
                renderSlides(data);
                applyNav(data);
                setMessage(data.redirected ? 'Открыт ближайший доступный урок.' : '', false);

                var videoUrl = data.lesson && data.lesson.video_url ? data.lesson.video_url : '';
                var poster = data.lesson && data.lesson.poster ? data.lesson.poster : '';
                if (poster) {
                    player.setAttribute('poster', poster);
                }

                if (videoUrl && player.getAttribute('src') !== videoUrl) {
                    ignoreLoadedMetadata = true;
                    player.src = videoUrl;
                    player.load();
                }

                if (!videoUrl) {
                    setMessage('У текущего урока нет активного видео.', true);
                }
            }

            function loadPlayer(forceMessage) {
                stopSaveInterval();
                hideResumeModal();
                if (loadXhr && loadXhr.abort) {
                    loadXhr.abort();
                }
                setMessage(forceMessage ? 'Загрузка урока…' : '', false);

                loadXhr = self.trainingRequest('web/player/get', {
                    module: requestedModule,
                    lesson: requestedLesson
                }, $player).done(function (res) {
                    if (!res || !res.success || !res.object) {
                        setMessage(res && res.message ? res.message : 'Не удалось загрузить урок.', true);
                        return;
                    }
                    renderData(res.object);
                }).fail(function () {
                    setMessage('Ошибка загрузки урока.', true);
                });
            }

            function saveProgress(markCompleted) {
                if (!currentData || !player || !player.src) {
                    return;
                }

                var currentTime = Math.floor(player.currentTime || 0);
                if (!markCompleted && currentTime === lastSavedTime) {
                    return;
                }
                lastSavedTime = currentTime;

                if (saveXhr && saveXhr.abort) {
                    saveXhr.abort();
                }

                saveXhr = self.trainingRequest('web/player/progress', {
                    module: requestedModule,
                    lesson: requestedLesson,
                    current_time: currentTime,
                    duration_seconds: Math.floor(player.duration || (currentData.lesson ? currentData.lesson.duration_seconds : 0) || 0),
                    completed: markCompleted ? 1 : 0
                }, $player).done(function (res) {
                    if (!res || !res.success || !res.object) {
                        return;
                    }
                    if (res.object.module) {
                        $moduleProgress.html('<span>Модуль ' + parseInt(res.object.module.progress_percent || 0, 10) + '%</span>');
                    }
                    if (res.object.course) {
                        $courseProgress.html('<span>Курс ' + parseInt(res.object.course.progress_percent || 0, 10) + '%</span>');
                    }
                    if (res.object.lesson && parseInt(res.object.lesson.completed || 0, 10) === 1) {
                        $lessonStatus.removeClass('d-none');
                    }
                    if (markCompleted) {
                        loadPlayer(false);
                    } else if (res.object.nav) {
                        currentData.nav = $.extend({}, currentData.nav || {}, res.object.nav || {});
                        applyNav(currentData);
                    }
                });
            }

            $(document)
                .off('click.appTrainingPlayerBack')
                .on('click.appTrainingPlayerBack', '.js-player-back', function () {
                    var url = $(this).attr('data-url') || '';
                    if (url) {
                        window.location.href = url;
                    }
                })
                .off('click.appTrainingPlayerPrev')
                .on('click.appTrainingPlayerPrev', '.js-player-prev, .js-player-next', function () {
                    var url = $(this).attr('data-url') || '';
                    if (!url) {
                        setMessage('Следующий урок пока недоступен.', true);
                        return;
                    }
                    window.location.href = url;
                })
                .off('click.appTrainingPlayerLesson')
                .on('click.appTrainingPlayerLesson', '.js-player-lesson-item', function () {
                    if ($(this).is(':disabled') || $(this).attr('data-locked') === '1') {
                        setMessage('Этот урок пока заблокирован.', true);
                        return;
                    }
                    var url = $(this).attr('data-url') || '';
                    if (url) {
                        window.location.href = url;
                    }
                })
                .off('click.appTrainingPlayerSlide')
                .on('click.appTrainingPlayerSlide', '.js-player-slide-jump', function () {
                    var timecode = parseInt($(this).attr('data-timecode') || 0, 10);
                    if (player && player.duration && isFinite(player.duration)) {
                        player.currentTime = Math.max(0, Math.min(player.duration, Math.floor(timecode / 1000)));
                        updateVideoProgress();
                    }
                });

            $player.off('click.appTrainingPlay').on('click.appTrainingPlay', '.js-player-play', function () {
                if (player.paused) {
                    player.play();
                } else {
                    player.pause();
                }
            });

            $player.off('click.appTrainingRestart').on('click.appTrainingRestart', '.js-player-restart', function () {
                player.currentTime = 0;
                completeSent = false;
                updateVideoProgress();
                saveProgress(false);
            });

            $player.off('click.appTrainingSound').on('click.appTrainingSound', '.js-player-sound', function () {
                player.muted = !player.muted;
                if (!player.muted && player.volume <= 0.01) {
                    player.volume = 0.7;
                }
                updateVolumeUi();
            });

            $volume.off('input.appTrainingVolume change.appTrainingVolume').on('input.appTrainingVolume change.appTrainingVolume', function () {
                var value = Math.max(0, Math.min(100, parseInt($(this).val() || 0, 10)));
                player.volume = value / 100;
                player.muted = value === 0;
                updateVolumeUi();
            });

            $player.off('click.appTrainingSidebarToggle').on('click.appTrainingSidebarToggle', '.js-player-sidebar-toggle', function () {
                $player.toggleClass('is-sidebar-collapsed');
            });

            $sidebarSearch.off('input.appTrainingSidebarSearch').on('input.appTrainingSidebarSearch', function () {
                applySearch();
            });

            $player.off('click.appTrainingResumeStart').on('click.appTrainingResumeStart', '.js-player-start-over', function () {
                hideResumeModal();
                pendingResumeTime = 0;
                player.currentTime = 0;
                player.play();
            });

            $player.off('click.appTrainingResumeContinue').on('click.appTrainingResumeContinue', '.js-player-resume-continue', function () {
                hideResumeModal();
                if (pendingResumeTime > 0 && player.duration && pendingResumeTime < player.duration) {
                    player.currentTime = pendingResumeTime;
                }
                player.play();
            });

            $progressBar.off('click.appTrainingProgress').on('click.appTrainingProgress', function (e) {
                if (!player.duration || !isFinite(player.duration)) return;
                var barWidth = $(this).outerWidth();
                var offsetX = e.pageX - $(this).offset().left;
                var percent = (offsetX / barWidth);
                player.currentTime = Math.max(0, Math.min(player.duration, player.duration * percent));
                updateVideoProgress();
            });

            $(player)
                .off('loadedmetadata.appTrainingPlayer')
                .on('loadedmetadata.appTrainingPlayer', function () {
                    updateVolumeUi();
                    updateVideoProgress();
                    if (!currentData || !currentData.lesson) {
                        return;
                    }
                    var resume = parseInt(currentData.lesson.resume_time || 0, 10);
                    if (ignoreLoadedMetadata) {
                        ignoreLoadedMetadata = false;
                        if (!showResumeModal(resume)) {
                            if (resume > 0 && player.duration && resume < player.duration) {
                                player.currentTime = resume;
                            }
                        }
                    }
                })
                .off('timeupdate.appTrainingPlayer')
                .on('timeupdate.appTrainingPlayer', function () {
                    updateVideoProgress();
                })
                .off('play.appTrainingPlayer')
                .on('play.appTrainingPlayer', function () {
                    startSaveInterval();
                })
                .off('pause.appTrainingPlayer')
                .on('pause.appTrainingPlayer', function () {
                    stopSaveInterval();
                    saveProgress(false);
                })
                .off('ended.appTrainingPlayer')
                .on('ended.appTrainingPlayer', function () {
                    stopSaveInterval();
                    completeSent = true;
                    saveProgress(true);
                })
                .off('volumechange.appTrainingPlayer')
                .on('volumechange.appTrainingPlayer', function () {
                    updateVolumeUi();
                });

            $(window)
                .off('beforeunload.appTrainingPlayer')
                .on('beforeunload.appTrainingPlayer', function () {
                    stopSaveInterval();
                    saveProgress(false);
                });

            updateVolumeUi();
            loadPlayer(true);
        },

        courseStructure: function () {
            var $modules = $('.cs-module');
            if (!$modules.length) return;

            function setBodyHeight($module, open, instant) {
                var $body = $module.find('[data-cs-body]').first();
                if (!$body.length) return;

                var target = open ? $body.get(0).scrollHeight : 0;

                if (instant) {
                    $body.css('transition', 'none').height(target);
                    $body.get(0).offsetHeight;
                    $body.css('transition', '');
                    return;
                }

                $body.height(target);
            }

            $modules.each(function () {
                var $m = $(this);
                var isOpen = $m.hasClass('is-open');
                $m.find('[data-cs-toggle]').attr('aria-expanded', isOpen ? 'true' : 'false');
                setBodyHeight($m, isOpen, true);
            });

            $(document)
                .off('click.appTrainingCourseStruct')
                .on('click.appTrainingCourseStruct', '[data-cs-toggle]', function (e) {
                    e.preventDefault();

                    var $head = $(this);
                    var $module = $head.closest('.cs-module');
                    var isOpen = $module.hasClass('is-open');

                    if (isOpen) {
                        var $body = $module.find('[data-cs-body]').first();
                        $body.height($body.get(0).scrollHeight);
                        $body.get(0).offsetHeight;

                        $module.removeClass('is-open');
                        $head.attr('aria-expanded', 'false');
                        $body.height(0);
                        return;
                    }

                    $module.addClass('is-open');
                    $head.attr('aria-expanded', 'true');
                    setBodyHeight($module, true, false);
                });

            $(document)
                .off('transitionend.appTrainingCourseStruct')
                .on('transitionend.appTrainingCourseStruct', '.cs-body', function () {
                    var $body = $(this);
                    var $module = $body.closest('.cs-module');
                    if ($module.hasClass('is-open')) {
                        $body.height($body.get(0).scrollHeight);
                    }
                });

            this.courseStructureRecalc = function ($module) {
                if (!$module || !$module.length) return;
                if ($module.hasClass('is-open')) setBodyHeight($module, true, false);
            };
        },

        coursePage: function () {
            var COLLAPSED = 169;

            function setExpanded($wrap, $text, on) {
                if (on) {
                    var h = $text.get(0).scrollHeight;
                    $wrap.addClass('is-open');
                    $text.css('max-height', h + 'px');
                    $wrap.find('[data-course-about-toggle]').text('Свернуть');
                } else {
                    $wrap.removeClass('is-open');
                    $text.css('max-height', COLLAPSED + 'px');
                    $wrap.find('[data-course-about-toggle]').text('Показать еще');
                }
            }

            $('.course-about').each(function () {
                var $wrap = $(this);
                var $text = $wrap.find('[data-course-about]').first();
                if (!$text.length) return;

                $text.css('max-height', COLLAPSED + 'px');

                var full = $text.get(0).scrollHeight;
                if (full <= COLLAPSED + 5) {
                    $wrap.find('[data-course-about-toggle]').hide();
                    $text.addClass('is-full');
                } else {
                    $wrap.find('[data-course-about-toggle]').show().text('Показать больше');
                }
            });

            $(document)
                .off('click.appTrainingCourseAbout')
                .on('click.appTrainingCourseAbout', '[data-course-about-toggle]', function () {
                    var $wrap = $(this).closest('.course-about');
                    var $text = $wrap.find('[data-course-about]').first();
                    if (!$text.length) return;

                    var isOpen = $wrap.hasClass('is-open');
                    setExpanded($wrap, $text, !isOpen);
                });

            $(window)
                .off('resize.appTrainingCourseAbout')
                .on('resize.appTrainingCourseAbout', function () {
                    $('.course-about.is-open').each(function () {
                        var $wrap = $(this);
                        var $text = $wrap.find('[data-course-about]').first();
                        if (!$text.length) return;
                        $text.css('max-height', $text.get(0).scrollHeight + 'px');
                    });
                });
        },

        sertModal: function () {
            if (typeof bootstrap === 'undefined') return;

            var modalEl = document.getElementById('sertModal');
            if (!modalEl) return;

            var bsModal = bootstrap.Modal.getInstance(modalEl);
            if (!bsModal) {
                bsModal = new bootstrap.Modal(modalEl, {
                    backdrop: true,
                    keyboard: true
                });
            }

            $(document).on('click', '.sert-btn', function (e) {
                e.preventDefault();

                var img = $(this).data('img') || 'theme/images/training/sert/image_1.jpg';
                var file = $(this).data('file') || img;

                $('#sertModal .sert-modal__img').attr('src', img);
                $('#sertModal .sert-modal__download').attr('href', file);

                bsModal.show();
            });
        },

        testListModal: function () {
            if (typeof bootstrap === 'undefined') return;

            var modalEl = document.getElementById('testListModal');
            if (!modalEl) return;

            var bsModal = bootstrap.Modal.getInstance(modalEl);
            if (!bsModal) {
                bsModal = new bootstrap.Modal(modalEl, {
                    backdrop: true,
                    keyboard: true
                });
            }

            $(document).on('click', '.btn-list-test', function (e) {
                e.preventDefault();
                bsModal.show();
            });
        },

        filtersSwipers: function () {
            if (typeof Swiper === 'undefined') return;

            $('.my-courses .course-filters-swiper').each(function (index, element) {
                if (element.swiper) return;

                new Swiper(element, {
                    slidesPerView: 'auto',
                    spaceBetween: 16,
                    freeMode: {
                        enabled: true,
                        momentum: true
                    },
                    watchOverflow: true
                });
            });
        },

        filtersLogic: function () {
            const $blocks = $('.my-courses');
            if (!$blocks.length) return;

            const map = {
                progress: 'is-progress',
                done: 'is-done',
                new: 'is-new'
            };

            function setActive($scope, $btn) {
                $scope.find('.filters-corses .course-filter__chip')
                    .removeClass('is-active')
                    .attr('aria-selected', 'false');

                $btn.addClass('is-active').attr('aria-selected', 'true');
            }

            function getItemsContainer($scope) {
                let $list = $scope.find('.corses-items').first();
                if ($list.length) return $list;

                $list = $scope.find('.sert-items').first();
                if ($list.length) return $list;

                $list = $scope.find('*').filter(function () {
                    return $(this).find('.course-item, .sert-item').length;
                }).first();

                return $list.length ? $list : $scope;
            }

            function applyFilter($scope, filter) {
                const $list = getItemsContainer($scope);
                const $items = $list.find('.course-item, .sert-item');
                if (!$items.length) return;

                if (filter === 'all') {
                    $items.show();
                    return;
                }

                const cls = map[filter] || ('is-' + filter);
                $items.each(function () {
                    const $item = $(this);
                    $item.toggle($item.hasClass(cls));
                });
            }

            $(document).on('click', '.my-courses .filters-corses .course-filter__chip', function (e) {
                e.preventDefault();

                const $btn = $(this);
                const $scope = $btn.closest('.my-courses');
                const filter = $btn.data('filter') || 'all';

                setActive($scope, $btn);
                applyFilter($scope, filter);
            });

            $blocks.each(function () {
                const $scope = $(this);
                const $active = $scope.find('.filters-corses .course-filter__chip.is-active').first();
                const $first = $scope.find('.filters-corses .course-filter__chip').first();
                const $initBtn = $active.length ? $active : $first;

                if ($initBtn.length) {
                    setActive($scope, $initBtn);
                    applyFilter($scope, $initBtn.data('filter') || 'all');
                }
            });
        },

        historyModal: function () {
            var $any = $('.js-history-item');
            if (!$any.length) return;

            var $modal = $('#historyModal');
            if (!$modal.length) {
                var tpl = `
                  <div class="history-modal" id="historyModal" aria-hidden="true">
                    <div class="history-modal__overlay" data-history-close></div>

                    <button type="button"
                            class="history-modal__close"
                            aria-label="Закрыть"
                            data-history-close>
                      <svg xmlns="http://www.w3.org/2000/svg"
                           width="24" height="24"
                           viewBox="0 0 24 24"
                           fill="none">
                        <path d="M18 6L6 18M6 6L18 18"
                              stroke="black"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round"/>
                      </svg>
                    </button>

                    <div class="history-modal__sheet" role="dialog" aria-modal="true">
                      <div class="history-modal__content">
                        <div class="history-modal__hint" data-hm-hint>Загрузка…</div>

                        <div class="history-modal__grid">
                          <div class="history-modal__row">
                            <div class="history-modal__k">Дата/Время</div>
                            <div class="history-modal__v" data-hm-date>—</div>
                          </div>

                          <div class="history-modal__row">
                            <div class="history-modal__k">Материалы</div>
                            <div class="history-modal__v" data-hm-mat>—</div>
                          </div>

                          <div class="history-modal__row">
                            <div class="history-modal__k">Статус</div>
                            <div class="history-modal__v" data-hm-status>—</div>
                          </div>

                          <div class="history-modal__row">
                            <div class="history-modal__k">Просмотрено</div>
                            <div class="history-modal__v" data-hm-viewed>—</div>
                          </div>

                          <div class="history-modal__row">
                            <div class="history-modal__k">Баллы</div>
                            <div class="history-modal__v" data-hm-score>—</div>
                          </div>

                          <div class="history-modal__row">
                            <div class="history-modal__k">Продолжительность</div>
                            <div class="history-modal__v" data-hm-dur>—</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                `;
                $('body').append(tpl);
                $modal = $('#historyModal');
            }

            var $body = $('body');

            var $hint = $modal.find('[data-hm-hint]');
            var $out = {
                date: $modal.find('[data-hm-date]'),
                mat: $modal.find('[data-hm-mat]'),
                status: $modal.find('[data-hm-status]'),
                viewed: $modal.find('[data-hm-viewed]'),
                score: $modal.find('[data-hm-score]'),
                dur: $modal.find('[data-hm-dur]')
            };

            var currentXhr = null;

            var demoHistoryData = {
                date: '5 сент. 2025 8:54',
                materials: 'Модуль 3. Урок 1. Штрихкодирование 202',
                status: 'В процессе',
                viewed: '6% (1/16)',
                score: '0 (0%)',
                duration: '00:00:01'
            };

            function setLoading(isLoading) {
                $modal.toggleClass('is-loading', !!isLoading);
                $hint.toggle(!!isLoading);
            }

            function setPlaceholders() {
                $out.date.text('—');
                $out.mat.text('—');
                $out.status.text('—');
                $out.viewed.text('—');
                $out.score.text('—');
                $out.dur.text('—');
            }

            function fill(data) {
                $out.date.text(data.date || '—');
                $out.mat.text(data.materials || '—');
                $out.status.text(data.status || '—');
                $out.viewed.text(data.viewed || '—');
                $out.score.text(data.score || '—');
                $out.dur.text(data.duration || '—');
            }

            function openModal() {
                $modal.addClass('is-open').attr('aria-hidden', 'false');
                $body.addClass('is-modal-open');
            }

            function closeModal() {
                $modal.removeClass('is-open').attr('aria-hidden', 'true');
                $body.removeClass('is-modal-open');
                setLoading(false);
                if (currentXhr && currentXhr.abort) currentXhr.abort();
            }

            $(document)
                .off('click.appTrainingHistoryClose')
                .on('click.appTrainingHistoryClose', '#historyModal [data-history-close]', function (e) {
                    e.preventDefault();
                    closeModal();
                });

            $(document)
                .off('keydown.appTrainingHistoryEsc')
                .on('keydown.appTrainingHistoryEsc', function (e) {
                    if (e.key === 'Escape' && $modal.hasClass('is-open')) closeModal();
                });

            $(document)
                .off('click.appTrainingHistoryOpen')
                .on('click.appTrainingHistoryOpen', '.js-history-item', function (e) {
                    if ($(e.target).closest('a, button').length) return;

                    var $item = $(this);

                    setPlaceholders();
                    setLoading(true);
                    openModal();

                    var id = $item.data('historyId');
                    var rowData = {};

                    if ($item.hasClass('history-table__row')) {
                        var date = $.trim($item.find('.history-date').text());
                        var time = $.trim($item.find('.history-time').text());

                        rowData = {
                            date: (date + ' ' + time).trim(),
                            materials: $.trim($item.find('.history-mat__title').text()),
                            status: $.trim($item.find('.history-col--status').text()),
                            viewed: $.trim($item.find('.history-col--viewed').text()),
                            score: $.trim($item.find('.history-col--score').text()),
                            duration: $.trim($item.find('.history-col--dur').text())
                        };
                    } else {
                        var date2 = $.trim($item.find('.history-card__date').text());
                        var time2 = $.trim($item.find('.history-card__time').text());
                        rowData = {
                            date: (date2 + ' ' + time2).trim(),
                            materials: $.trim($item.find('.history-card__title').text()),
                            status: $.trim($item.find('.history-card__status').text()),
                            viewed: $.trim($item.find('.history-card__meta .history-card__kv').eq(0).find('.history-card__v').text()),
                            score: $.trim($item.find('.history-card__meta .history-card__kv').eq(1).find('.history-card__v').text()),
                            duration: $.trim($item.find('.history-card__meta .history-card__kv').eq(2).find('.history-card__v').text())
                        };
                    }

                    setTimeout(function () {
                        fill({
                            date: rowData.date || demoHistoryData.date,
                            materials: rowData.materials || demoHistoryData.materials,
                            status: rowData.status || demoHistoryData.status,
                            viewed: rowData.viewed || demoHistoryData.viewed,
                            score: rowData.score || demoHistoryData.score,
                            duration: rowData.duration || demoHistoryData.duration
                        });
                        setLoading(false);
                    }, 250);
                });
        },

        usersCoursesUi: function () {
            var self = this;
            var $wrap = $('#training-manage-page[data-training-page="managecourses"], .training-manage-page[data-training-page="managecourses"]').first();
            if (!$wrap.length) return;

            var $table = $wrap.find('[data-users-table]').first();
            var $cards = $wrap.find('[data-users-cards]').first();
            var $search = $wrap.find('#users-search .search-input__field').first();
            var activeCourseId = 0;
            var activeResourceId = 0;
            var searchTimer = null;

            function getSelectedIds() {
                var ids = [];
                $wrap.find('.users-check[data-user-id]:checked').each(function () {
                    var id = parseInt($(this).attr('data-user-id'), 10);
                    if (id > 0) ids.push(id);
                });
                return ids;
            }

            function renderStatus(item) {
                if (parseInt(item.show_assign_button || 0, 10) === 1 && parseInt(item.can_assign || 0, 10) === 1) {
                    return '<button type="button" class="users-btn ' + self.escapeHtml(item.button_class || 'users-btn--success') + '" data-row-action="assign" data-user-id="' + item.id + '">' + self.escapeHtml(item.button_text || 'Активировать курс') + '</button>';
                }

                return '<div class="label-chip ' + self.escapeHtml(item.status_class || 'label-chip--blue') + '"><span>' + self.escapeHtml(item.status_text || '—') + '</span></div>';
            }

            function renderTable(rows) {
                var html = '' +
                    '<div class="users-table__head">' +
                        '<div class="users-col users-col--check"><input type="checkbox" class="users-check" data-select-all aria-label="Выбрать все"></div>' +
                        '<div class="users-col users-col--user">Имя пользователя</div>' +
                        '<div class="users-col users-col--status">Статус</div>' +
                        '<div class="users-col users-col--org">Организация</div>' +
                        '<div class="users-col users-col--last">Последний вход</div>' +
                        '<div class="users-col users-col--start">Старт курса</div>' +
                    '</div>';

                if (!rows.length) {
                    html += '<div class="users-table__row"><div class="users-col" style="width:100%">Пользователи не найдены</div></div>';
                    $table.html(html);
                    return;
                }

                $.each(rows, function (_, item) {
                    html += '' +
                        '<div class="users-table__row" data-user-row data-user-id="' + item.id + '">' +
                            '<div class="users-col users-col--check">' +
                                '<input type="checkbox" class="users-check" data-user-id="' + item.id + '" aria-label="Выбрать">' +
                            '</div>' +
                            '<div class="users-col users-col--user">' +
                                '<div class="user-mini">' +
                                    '<span class="user-mini__ava"><img src="theme/images/training/user-ico.svg" class="img-svg" alt=""></span>' +
                                    '<div class="user-mini__txt">' +
                                        '<div class="user-mini__name">' + self.escapeHtml(item.display_name || item.username || '') + '</div>' +
                                        '<div class="user-mini__mail">' + self.escapeHtml(item.email || '') + '</div>' +
                                    '</div>' +
                                '</div>' +
                            '</div>' +
                            '<div class="users-col users-col--status">' + renderStatus(item) + '</div>' +
                            '<div class="users-col users-col--org">' + self.escapeHtml(item.organization || '—') + '</div>' +
                            '<div class="users-col users-col--last">' + self.escapeHtml(item.last_login_formatted || '—') + '</div>' +
                            '<div class="users-col users-col--start">' + self.escapeHtml(item.startedon_formatted || '—') + '</div>' +
                        '</div>';
                });

                $table.html(html);
            }

            function renderCards(rows) {
                if (!rows.length) {
                    $cards.html('<div class="course-card">Пользователи не найдены</div>');
                    return;
                }

                var html = '';
                $.each(rows, function (_, item) {
                    var topStatus = '';
                    if (parseInt(item.show_assign_button || 0, 10) === 1 && parseInt(item.can_assign || 0, 10) === 1) {
                        topStatus = '<button type="button" class="btn course-btn w-100" data-row-action="assign" data-user-id="' + item.id + '">Активировать курс</button>';
                    } else {
                        topStatus = '<div class="label-chip ' + self.escapeHtml(item.status_class || 'label-chip--blue') + ' label-chip--sm"><span>' + self.escapeHtml(item.status_text || '—') + '</span></div>';
                    }

                    html += '' +
                        '<div class="course-card" data-user-card data-user-id="' + item.id + '">' +
                            '<div class="course-card__top">' +
                                '<div class="course-org">' + self.escapeHtml(item.organization || '—') + '</div>' +
                                topStatus +
                            '</div>' +
                            '<div class="course-user">' +
                                '<div class="course-avatar" aria-hidden="true"><img src="theme/images/training/user-ico.svg" class="img-svg" alt=""></div>' +
                                '<div class="course-user__text">' +
                                    '<div class="course-name">' + self.escapeHtml(item.display_name || item.username || '') + '</div>' +
                                    '<div class="course-email">' + self.escapeHtml(item.email || '') + '</div>' +
                                '</div>' +
                            '</div>' +
                            '<div class="course-meta">' +
                                '<div class="course-meta__item">' +
                                    '<div class="course-meta__date">' + self.escapeHtml(item.last_login_formatted || '—') + '</div>' +
                                    '<div class="course-meta__label">Посл. вход</div>' +
                                '</div>' +
                                '<div class="course-meta__item text-end">' +
                                    '<div class="course-meta__date">' + self.escapeHtml(item.startedon_formatted || '—') + '</div>' +
                                    '<div class="course-meta__label">Старт курса</div>' +
                                '</div>' +
                            '</div>' +
                            '<div class="pt-2">' +
                                '<label class="d-flex align-items-center gap-2">' +
                                    '<input type="checkbox" class="users-check" data-user-id="' + item.id + '">' +
                                    '<span>Выбрать</span>' +
                                '</label>' +
                            '</div>' +
                        '</div>';
                });

                $cards.html(html);
            }

            function loadUsers() {
                if (!activeCourseId && !activeResourceId) {
                    renderTable([]);
                    renderCards([]);
                    return;
                }

                self.trainingRequest('web/course/assignableusers', {
                    course_id: activeCourseId,
                    resource_id: activeResourceId,
                    query: $search.val() || '',
                    include_self: 1
                }, $wrap).done(function (res) {
                    if (!res || !res.success || !res.object) {
                        renderTable([]);
                        renderCards([]);
                        return;
                    }

                    var rows = res.object.results || [];
                    renderTable(rows);
                    renderCards(rows);
                }).fail(function () {
                    renderTable([]);
                    renderCards([]);
                });
            }

            function runBulk(action, ids) {
                if (!ids.length) return;

                var processor = action === 'assign' ? 'web/course/assign' : 'web/course/unassign';
                var requests = [];

                $.each(ids, function (_, userId) {
                    requests.push(
                        self.trainingRequest(processor, {
                            course_id: activeCourseId,
                            resource_id: activeResourceId,
                            user_id: userId
                        }, $wrap)
                    );
                });

                $.when.apply($, requests).always(function () {
                    loadUsers();
                });
            }

            $(document)
                .off('click.appTrainingManageCourseFilter')
                .on('click.appTrainingManageCourseFilter', '#training-manage-page .course-filter__chip, .training-manage-page .course-filter__chip', function (e) {
                    e.preventDefault();

                    var $btn = $(this);
                    activeCourseId = parseInt($btn.attr('data-course-id') || 0, 10);
                    activeResourceId = parseInt($btn.attr('data-resource-id') || 0, 10);

                    $btn.closest('.filters-corses, .swiper-wrapper').find('.course-filter__chip')
                        .removeClass('is-active')
                        .attr('aria-selected', 'false');

                    $btn.addClass('is-active').attr('aria-selected', 'true');
                    loadUsers();
                });

            $(document)
                .off('input.appTrainingManageSearch')
                .on('input.appTrainingManageSearch', '#training-manage-page #users-search .search-input__field, .training-manage-page #users-search .search-input__field', function () {
                    clearTimeout(searchTimer);
                    searchTimer = setTimeout(loadUsers, 250);
                });

            $(document)
                .off('change.appTrainingSelectAll')
                .on('change.appTrainingSelectAll', '#training-manage-page [data-select-all], .training-manage-page [data-select-all]', function () {
                    var checked = $(this).is(':checked');
                    $wrap.find('.users-check[data-user-id]').prop('checked', checked);
                });

            $(document)
                .off('click.appTrainingBulkAction')
                .on('click.appTrainingBulkAction', '#training-manage-page [data-bulk-action], .training-manage-page [data-bulk-action]', function (e) {
                    e.preventDefault();
                    var action = $(this).attr('data-bulk-action');
                    runBulk(action, getSelectedIds());
                });

            $(document)
                .off('click.appTrainingRowAction')
                .on('click.appTrainingRowAction', '#training-manage-page [data-row-action], .training-manage-page [data-row-action]', function (e) {
                    e.preventDefault();
                    var action = $(this).attr('data-row-action');
                    var userId = parseInt($(this).attr('data-user-id') || 0, 10);
                    if (!userId) return;
                    runBulk(action, [userId]);
                });

            var $first = $wrap.find('.course-filter__chip.is-active').first();
            if (!$first.length) {
                $first = $wrap.find('.course-filter__chip').first();
            }
            if ($first.length) {
                $first.trigger('click');
            }
        }
    };
})();

AppTraining.init();