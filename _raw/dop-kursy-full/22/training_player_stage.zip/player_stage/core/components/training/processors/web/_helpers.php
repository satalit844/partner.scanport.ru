<?php

require_once dirname(dirname(__DIR__)) . '/model/training/training.class.php';
require_once dirname(dirname(__DIR__)) . '/model/training/services/trainingprogress.class.php';

class TrainingWebHelper
{
    public static function getTraining(modX $modx)
    {
        return new Training($modx);
    }

    public static function getProgressService(modX $modx)
    {
        return new TrainingProgressService($modx, self::getTraining($modx));
    }

    public static function requireAuth(modProcessor $processor, $context = '')
    {
        $context = trim((string)$context);
        if ($context === '') {
            $context = $processor->modx->context ? $processor->modx->context->get('key') : 'web';
        }

        if (
            !$processor->modx->user
            || !(int)$processor->modx->user->get('id')
            || !$processor->modx->user->isAuthenticated($context)
        ) {
            return $processor->failure('Нужно авторизоваться', array('code' => 401, 'context' => $context));
        }

        return null;
    }

    public static function resolveCourseId(modX $modx, $courseId = 0, $resourceId = 0)
    {
        $courseId = (int)$courseId;
        $resourceId = (int)$resourceId;

        if ($courseId > 0) {
            return $courseId;
        }

        if ($resourceId <= 0) {
            return 0;
        }

        /** @var TrainingCourse $course */
        $course = $modx->getObject('TrainingCourse', array(
            'resource_id' => $resourceId,
        ));

        return $course ? (int)$course->get('id') : 0;
    }

    public static function esc($value)
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }

    public static function normalizePath($path)
    {
        return rtrim(str_replace('\\', '/', (string)$path), '/');
    }

    public static function formatDuration($seconds)
    {
        $seconds = (int)$seconds;
        if ($seconds <= 0) {
            return '0 сек';
        }

        $hours = (int)floor($seconds / 3600);
        $minutes = (int)floor(($seconds % 3600) / 60);
        $secs = (int)($seconds % 60);

        if ($hours > 0) {
            return $hours . ' ч ' . $minutes . ' мин';
        }
        if ($minutes > 0) {
            return $minutes . ' мин ' . $secs . ' сек';
        }
        return $secs . ' сек';
    }

    public static function makePlayerUrl(modX $modx, $moduleResourceId, $lessonId)
    {
        $moduleResourceId = (int)$moduleResourceId;
        $lessonId = (int)$lessonId;
        $viewerResourceId = (int)$modx->getOption('training.training_view_resource_id', null, 174);
        if ($viewerResourceId <= 0 || $moduleResourceId <= 0 || $lessonId <= 0) {
            return '';
        }

        $baseUrl = $modx->makeUrl($viewerResourceId);
        if (!$baseUrl) {
            return '';
        }

        return $baseUrl . (strpos($baseUrl, '?') === false ? '?' : '&') . http_build_query(array(
            'module' => $moduleResourceId,
            'lesson' => $lessonId,
        ));
    }
}
