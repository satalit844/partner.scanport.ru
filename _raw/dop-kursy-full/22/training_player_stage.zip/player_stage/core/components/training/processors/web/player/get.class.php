<?php

require_once dirname(dirname(__FILE__)) . '/_helpers.php';

class TrainingWebPlayerGetProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    protected function buildLessons(TrainingProgressService $service, $courseId, TrainingModule $module, $currentLessonId)
    {
        $userId = (int)$this->modx->user->get('id');
        $moduleId = (int)$module->get('id');
        $moduleResourceId = (int)$module->get('resource_id');
        $items = array();
        $lessons = $service->getModuleLessons($moduleId, true, true);

        /** @var TrainingModuleLesson $lesson */
        foreach ($lessons as $lesson) {
            $lessonId = (int)$lesson->get('id');
            $progress = $service->getLessonProgress($courseId, $lessonId, $userId);
            $completed = $progress && (int)$progress->get('completed') === 1;
            $progressPercent = $progress ? (float)$progress->get('progress_percent') : 0;
            $locked = !$service->canAccessLesson($courseId, $moduleId, $lessonId, $userId);
            $title = trim((string)$lesson->get('title'));
            if ($title === '') {
                $title = 'Урок ' . ((int)$lesson->get('sort_order') + 1);
            }

            $items[] = array(
                'id' => $lessonId,
                'title' => $title,
                'sort_order' => (int)$lesson->get('sort_order'),
                'locked' => $locked ? 1 : 0,
                'completed' => $completed ? 1 : 0,
                'progress_percent' => round($progressPercent),
                'is_current' => $lessonId === (int)$currentLessonId ? 1 : 0,
                'url' => $locked ? '' : TrainingWebHelper::makePlayerUrl($this->modx, $moduleResourceId, $lessonId),
            );
        }

        return $items;
    }

    protected function buildSlides(TrainingProgressService $service, $lessonId)
    {
        $items = array();
        $slides = $service->getLessonSlides($lessonId);
        /** @var TrainingModuleSlide $slide */
        foreach ($slides as $slide) {
            $items[] = array(
                'id' => (int)$slide->get('id'),
                'title' => 'Слайд ' . (int)$slide->get('slide_no'),
                'image' => (string)$slide->get('image'),
                'slide_no' => (int)$slide->get('slide_no'),
                'timecode_ms' => (int)$slide->get('timecode_ms'),
            );
        }
        return $items;
    }

    protected function buildVideoItems(TrainingProgressService $service, $lessonId)
    {
        $items = array();
        $videos = $service->getLessonVideoItems($lessonId);
        /** @var TrainingModuleVideo $video */
        foreach ($videos as $video) {
            $items[] = array(
                'id' => (int)$video->get('id'),
                'quality' => (string)$video->get('quality'),
                'mime' => (string)$video->get('mime'),
                'file_path' => (string)$video->get('file_path'),
                'width' => (int)$video->get('width'),
                'height' => (int)$video->get('height'),
                'bitrate' => (int)$video->get('bitrate'),
                'is_default' => (int)$video->get('is_default') === 1 ? 1 : 0,
            );
        }
        return $items;
    }

    public function process()
    {
        if ($failure = TrainingWebHelper::requireAuth($this)) {
            return $failure;
        }

        $service = TrainingWebHelper::getProgressService($this->modx);
        $userId = (int)$this->modx->user->get('id');
        $moduleResourceId = (int)$this->getProperty('module', 0);
        $lessonId = (int)$this->getProperty('lesson', 0);

        if ($moduleResourceId <= 0) {
            return $this->failure('Не указан модуль', array('code' => 400));
        }

        $resolved = $service->resolvePlayerContext($moduleResourceId, $lessonId, $userId);
        if (empty($resolved['success'])) {
            return $this->failure(isset($resolved['message']) ? $resolved['message'] : 'Не удалось открыть урок', $resolved);
        }

        /** @var TrainingModule $module */
        $module = $resolved['module'];
        /** @var TrainingModuleLesson $lesson */
        $lesson = $resolved['lesson'];
        $courseId = (int)$resolved['course_id'];
        $moduleId = (int)$module->get('id');
        $lessonId = (int)$lesson->get('id');

        $service->syncUserCourseForUser($courseId, $userId);
        $lessonProgress = $service->ensureLessonProgress($courseId, $lessonId, $userId, (int)$lesson->get('duration_seconds'));
        $moduleProgress = $service->recalculateModuleProgressFromLessons($courseId, $moduleId, $userId);
        $userCourse = $service->recalculateUserCourse($courseId, $userId);

        /** @var TrainingCourse $course */
        $course = $this->modx->getObject('TrainingCourse', array('id' => $courseId));
        /** @var modResource $courseResource */
        $courseResource = $course ? $course->getOne('Resource') : null;
        /** @var modResource $moduleResource */
        $moduleResource = $module->getOne('Resource');

        $defaultVideo = $service->getLessonDefaultVideo($lessonId);
        if (!$defaultVideo) {
            return $this->failure('У урока нет активного видео', array('code' => 404));
        }

        $prevLessonId = $service->getPreviousLessonId($moduleId, $lessonId, true);
        $nextLessonId = $service->getNextLessonId($moduleId, $lessonId, true);
        $prevUrl = $prevLessonId > 0 ? TrainingWebHelper::makePlayerUrl($this->modx, (int)$module->get('resource_id'), $prevLessonId) : '';
        $nextUrl = ($nextLessonId > 0 && $service->canAccessLesson($courseId, $moduleId, $nextLessonId, $userId))
            ? TrainingWebHelper::makePlayerUrl($this->modx, (int)$module->get('resource_id'), $nextLessonId)
            : '';

        $lessons = $this->buildLessons($service, $courseId, $module, $lessonId);
        $currentIndex = 0;
        $totalLessons = count($lessons);
        foreach ($lessons as $index => $lessonRow) {
            if ((int)$lessonRow['is_current'] === 1) {
                $currentIndex = $index + 1;
                break;
            }
        }

        $slides = $this->buildSlides($service, $lessonId);
        $videoItems = $this->buildVideoItems($service, $lessonId);
        $resumeTime = 0;
        if ($lessonProgress && (int)$lessonProgress->get('completed') !== 1) {
            $resumeTime = max((int)$lessonProgress->get('current_time'), (int)$lessonProgress->get('max_time'));
        }

        $poster = '';
        if (!empty($slides[0]['image'])) {
            $poster = (string)$slides[0]['image'];
        } elseif ((string)$lesson->get('preview_image') !== '') {
            $poster = (string)$lesson->get('preview_image');
        } elseif ($courseResource) {
            $poster = trim((string)$courseResource->getTVValue('image_curse'));
        }

        return $this->success('', array(
            'redirected' => !empty($resolved['redirected']) ? 1 : 0,
            'requested_module_resource_id' => (int)$resolved['requested_module_resource_id'],
            'requested_lesson_id' => (int)$resolved['requested_lesson_id'],
            'resolved_module_resource_id' => (int)$resolved['resolved_module_resource_id'],
            'resolved_lesson_id' => (int)$resolved['resolved_lesson_id'],
            'completion_threshold_percent' => (int)$service->getLessonCompletionThresholdPercent(),
            'course' => array(
                'id' => $courseId,
                'resource_id' => $course ? (int)$course->get('resource_id') : 0,
                'title' => $courseResource ? (string)$courseResource->get('pagetitle') : '',
                'url' => $courseResource ? $this->modx->makeUrl((int)$courseResource->get('id')) : '',
                'progress_percent' => $userCourse ? round((float)$userCourse->get('progress_percent')) : 0,
                'completed_modules' => $userCourse ? (int)$userCourse->get('completed_modules') : 0,
                'total_modules' => $userCourse ? (int)$userCourse->get('total_modules') : 0,
                'status' => $userCourse ? (string)$userCourse->get('status') : 'assigned',
            ),
            'module' => array(
                'id' => $moduleId,
                'resource_id' => (int)$module->get('resource_id'),
                'title' => $moduleResource ? (string)$moduleResource->get('pagetitle') : '',
                'progress_percent' => $moduleProgress ? round((float)$moduleProgress->get('progress_percent')) : 0,
                'completed' => $moduleProgress ? ((int)$moduleProgress->get('completed') === 1 ? 1 : 0) : 0,
                'duration_seconds' => $moduleProgress ? (int)$moduleProgress->get('duration_seconds') : 0,
                'duration_text' => TrainingWebHelper::formatDuration($moduleProgress ? (int)$moduleProgress->get('duration_seconds') : 0),
            ),
            'lesson' => array(
                'id' => $lessonId,
                'title' => (string)$lesson->get('title'),
                'description' => (string)$lesson->get('description'),
                'duration_seconds' => max((int)$lesson->get('duration_seconds'), $lessonProgress ? (int)$lessonProgress->get('duration_seconds') : 0),
                'duration_text' => TrainingWebHelper::formatDuration(max((int)$lesson->get('duration_seconds'), $lessonProgress ? (int)$lessonProgress->get('duration_seconds') : 0)),
                'progress_percent' => $lessonProgress ? round((float)$lessonProgress->get('progress_percent')) : 0,
                'completed' => $lessonProgress ? ((int)$lessonProgress->get('completed') === 1 ? 1 : 0) : 0,
                'current_time' => $lessonProgress ? (int)$lessonProgress->get('current_time') : 0,
                'max_time' => $lessonProgress ? (int)$lessonProgress->get('max_time') : 0,
                'resume_time' => $resumeTime,
                'poster' => $poster,
                'video_url' => (string)$defaultVideo->get('file_path'),
                'quality' => (string)$defaultVideo->get('quality'),
            ),
            'videos' => $videoItems,
            'slides' => $slides,
            'lessons' => $lessons,
            'nav' => array(
                'current_index' => $currentIndex,
                'total_lessons' => $totalLessons,
                'prev_lesson_id' => $prevLessonId,
                'prev_url' => $prevUrl,
                'next_lesson_id' => $nextLessonId,
                'next_url' => $nextUrl,
                'next_locked' => ($nextLessonId > 0 && $nextUrl === '') ? 1 : 0,
            ),
        ));
    }
}

return 'TrainingWebPlayerGetProcessor';
