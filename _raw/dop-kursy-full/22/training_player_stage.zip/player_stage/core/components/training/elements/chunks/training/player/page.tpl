<div class="training-player d-flex align-items-start gap-3 w-100"
     data-training-page="player"
     data-training-connector="{$connector_url}"
     data-training-context="{$context_key}"
     data-player-module="{$requested_module}"
     data-player-lesson="{$requested_lesson}">
    <div class="col player-layout section-block">
        <div class="player-main">
            <div class="player-card">
                <div class="player-card__header d-flex align-items-center justify-content-between gap-3">
                    <div class="d-flex align-items-center gap-3 min-w-0">
                        <button type="button" class="player-nav-icon js-player-back" aria-label="Назад к курсу">
                            <img src="theme/images/training/player/arrow-left.svg" class="img-svg" alt="">
                        </button>

                        <div class="player-title-wrap min-w-0">
                            <div class="player-title js-player-title">Загрузка урока…</div>
                            <div class="subtitle js-player-subtitle">Подготавливаем данные проигрывателя</div>
                        </div>
                    </div>

                    <button type="button" class="player-nav-icon js-player-course-link" aria-label="Открыть курс">
                        <img src="theme/images/training/player/arrow-right-from-line-ico.svg" class="img-svg" alt="">
                    </button>
                </div>

                <div class="player-stage">
                    <div class="player-slide-area">
                        <div class="player-slide-frame">
                            <video class="player-slide-image js-player-video" preload="metadata" playsinline controlslist="nodownload noplaybackrate"></video>
                        </div>

                        <div class="player-controls">
                            <div class="player-controls__left d-flex align-items-center gap-2">
                                <button type="button" class="player-control-btn js-player-play" aria-label="Play/Pause">
                                    <img src="theme/images/training/player/play-ico.svg" class="img-svg" alt="">
                                </button>

                                <button type="button" class="player-control-btn js-player-restart" aria-label="Restart">
                                    <img src="theme/images/training/player/reload-ico.svg" class="img-svg" alt="">
                                </button>

                                <button type="button" class="player-control-btn js-player-sound" aria-label="Sound">
                                    <img src="theme/images/training/player/volume-ico.svg" class="img-svg" alt="">
                                </button>
                            </div>

                            <div class="player-controls__center">
                                <div class="player-progress js-player-progress">
                                    <div class="player-progress__line">
                                        <div class="player-progress__fill js-player-progress-fill" style="width:0%"></div>
                                    </div>
                                </div>
                            </div>

                            <div class="player-controls__right d-flex align-items-center gap-2">
                                <button type="button" class="player-control-btn js-player-fullscreen" aria-label="Fullscreen">
                                    <img src="theme/images/training/player/full-screen-ico.svg" class="img-svg" alt="">
                                </button>
                            </div>
                        </div>

                        <div class="player-bottom-nav">
                            <div class="player-bottom-nav__counter js-player-counter">0 из 0</div>

                            <div class="d-flex align-items-center gap-2 flex-wrap">
                                <button type="button" class="btn btn-player-nav js-player-prev" disabled>
                                    <img src="theme/images/training/player/arrow-left.svg" class="img-svg" alt="">
                                    <span>Назад</span>
                                </button>

                                <button type="button" class="btn btn-player-next js-player-next" disabled>
                                    <span>Далее</span>
                                    <img src="theme/images/training/player/arrow-left.svg" class="img-svg" alt="">
                                </button>
                            </div>
                        </div>

                        <div class="d-flex flex-wrap gap-2 pt-3">
                            <span class="label-chip label-chip--purple js-player-module-progress"><span>Модуль 0%</span></span>
                            <span class="label-chip label-chip--blue js-player-course-progress"><span>Курс 0%</span></span>
                            <span class="label-chip label-chip--green d-none js-player-lesson-status"><span>Урок завершён</span></span>
                        </div>

                        <div class="pt-3 text-info-test js-player-message d-none"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-3 player-sidebar">
        <div class="player-sidebar__video">
            <img src="theme/images/training/player/img-slide-1.jpg" alt="" class="player-speaker-image js-player-preview-image">
        </div>

        <div class="player-sidebar__head d-flex align-items-center justify-content-between gap-2">
            <div class="player-sidebar__title js-player-sidebar-title">Материалы модуля</div>
        </div>

        <div class="player-sidebar__list js-player-lesson-list"></div>
        <div class="player-sidebar__head d-flex align-items-center justify-content-between gap-2 mt-2">
            <div class="player-sidebar__title">Слайды</div>
        </div>
        <div class="player-sidebar__list js-player-slide-list"></div>
    </div>
</div>