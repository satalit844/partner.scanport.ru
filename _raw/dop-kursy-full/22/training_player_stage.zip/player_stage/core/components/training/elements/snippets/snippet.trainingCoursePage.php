<?php
/** @var modX $modx */
/** @var array $scriptProperties */

$corePath = $modx->getOption(
    'training.core_path',
    null,
    $modx->getOption('core_path') . 'components/training/'
);

require_once $corePath . 'model/training/training.class.php';
require_once $corePath . 'model/training/services/trainingprogress.class.php';

if (!function_exists('trainingCoursePageRenderChunk')) {
    function trainingCoursePageRenderChunk($corePath, $relativePath, array $placeholders = array())
    {
        $basePath = rtrim(str_replace('\\', '/', (string)$corePath), '/');
        $path = $basePath . '/elements/chunks/' . ltrim($relativePath, '/');
        if (!is_file($path)) {
            return '';
        }

        $content = (string)file_get_contents($path);
        if ($content === '') {
            return '';
        }

        $replace = array();
        foreach ($placeholders as $key => $value) {
            if (is_array($value) || is_object($value)) {
                $value = '';
            }
            $replace['{$' . $key . '}'] = (string)$value;
        }

        return strtr($content, $replace);
    }
}

if (!function_exists('trainingCoursePageEsc')) {
    function trainingCoursePageEsc($value)
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('trainingCoursePagePlural')) {
    function trainingCoursePagePlural($number, array $forms)
    {
        $number = abs((int)$number) % 100;
        $n1 = $number % 10;
        if ($number > 10 && $number < 20) {
            return $forms[2];
        }
        if ($n1 > 1 && $n1 < 5) {
            return $forms[1];
        }
        if ($n1 == 1) {
            return $forms[0];
        }
        return $forms[2];
    }
}

if (!function_exists('trainingCoursePageFormatDuration')) {
    function trainingCoursePageFormatDuration($seconds)
    {
        $seconds = (int)$seconds;
        if ($seconds <= 0) {
            return '';
        }

        $hours = (int)floor($seconds / 3600);
        $minutes = (int)floor(($seconds % 3600) / 60);
        if ($hours > 0) {
            return $hours . ' часов ' . $minutes . ' минут';
        }
        if ($minutes > 0) {
            return $minutes . ' минут';
        }
        return $seconds . ' сек';
    }
}


if (!function_exists('trainingCoursePageMakePlayerUrl')) {
    function trainingCoursePageMakePlayerUrl(modX $modx, $moduleResourceId, $lessonId)
    {
        $moduleResourceId = (int)$moduleResourceId;
        $lessonId = (int)$lessonId;
        $viewerResourceId = (int)$modx->getOption('training.training_view_resource_id', null, 174);
        if ($viewerResourceId <= 0 || $moduleResourceId <= 0 || $lessonId <= 0) {
            return '';
        }

        $baseUrl = $modx->makeUrl($viewerResourceId);
        if (!$baseUrl) {
            return '';
        }

        return $baseUrl . (strpos($baseUrl, '?') === false ? '?' : '&') . http_build_query(array(
            'module' => $moduleResourceId,
            'lesson' => $lessonId,
        ));
    }
}

if (!function_exists('trainingCoursePageGetUserLabel')) {
    function trainingCoursePageGetUserLabel(modUser $user)
    {
        $profile = $user->getOne('Profile');
        if ($profile) {
            $fullname = trim((string)$profile->get('fullname'));
            if ($fullname !== '') {
                return $fullname;
            }
        }
        return trim((string)$user->get('username'));
    }
}

$resourceId = (int)$modx->getOption('resource_id', $scriptProperties, $modx->resource ? $modx->resource->get('id') : 0);
$viewerResourceId = (int)$modx->getOption('viewer_resource_id', $scriptProperties, (int)$modx->getOption('training.training_view_resource_id', null, 174));
$pageTpl = trim((string)$modx->getOption('pageTpl', $scriptProperties, 'training/course/page.tpl'));
$moduleTpl = trim((string)$modx->getOption('moduleTpl', $scriptProperties, 'training/course/module.tpl'));
$lessonTpl = trim((string)$modx->getOption('lessonTpl', $scriptProperties, 'training/course/lesson.tpl'));

if ($resourceId <= 0) {
    return '<div class="section-block"><div class="alert alert-warning mb-0">Курс не найден.</div></div>';
}

if (!$modx->user || !(int)$modx->user->get('id') || !$modx->user->isAuthenticated($modx->context->get('key'))) {
    return '';
}

$training = new Training($modx);
$service = new TrainingProgressService($modx, $training);
$userId = (int)$modx->user->get('id');

/** @var TrainingCourse $course */
$course = $modx->getObject('TrainingCourse', array('resource_id' => $resourceId, 'is_active' => 1));
/** @var modResource $resource */
$resource = $modx->getObject('modResource', array('id' => $resourceId, 'deleted' => 0));

if (!$course || !$resource) {
    return '<div class="section-block"><div class="alert alert-warning mb-0">Курс недоступен.</div></div>';
}

$courseId = (int)$course->get('id');
if (!$service->hasCourseAccess($courseId, $userId)) {
    return '<div class="section-block"><div class="alert alert-warning mb-0">У вас нет доступа к этому курсу.</div></div>';
}

$service->syncUserCourseForUser($courseId, $userId);
/** @var TrainingUserCourse $userCourse */
$userCourse = $service->recalculateUserCourse($courseId, $userId);
if (!$userCourse || (string)$userCourse->get('status') === 'revoked') {
    return '<div class="section-block"><div class="alert alert-warning mb-0">У вас нет доступа к этому курсу.</div></div>';
}

$courseTitle = trim((string)$resource->get('pagetitle'));
$courseImage = trim((string)$resource->getTVValue('image_curse'));
if ($courseImage === '') {
    $courseImage = 'theme/images/training/curses/image_1.jpg';
}
$courseDescription = trim((string)$resource->getTVValue('desc'));
if ($courseDescription === '') {
    $courseDescription = trim((string)$resource->get('description'));
}
if ($courseDescription === '') {
    $courseDescription = 'Описание курса пока не заполнено.';
}
$courseDescription = nl2br($courseDescription);
$courseDurationText = trim((string)$resource->getTVValue('time_curse'));

$courseStatusText = 'Не начат';
$courseStatusClass = 'label-chip--blue';
$courseProgressPercent = round((float)$userCourse->get('progress_percent'));
if ((string)$userCourse->get('status') === 'completed' || $courseProgressPercent >= 100) {
    $courseStatusText = 'Пройден';
    $courseStatusClass = 'label-chip--green';
} elseif ((string)$userCourse->get('status') === 'in_progress' || $courseProgressPercent > 0) {
    $courseStatusText = 'В процессе';
    $courseStatusClass = 'label-chip--purple';
}

$modulesHtml = '';
$lessonsTotal = 0;
$courseDurationSeconds = 0;
$openFirst = true;
$modules = $service->getCourseModules($courseId, true, false);
/** @var TrainingModule $module */
foreach ($modules as $module) {
    $moduleId = (int)$module->get('id');
    $moduleResourceId = (int)$module->get('resource_id');
    /** @var modResource $moduleResource */
    $moduleResource = $module->getOne('Resource');
    $moduleTitle = $moduleResource ? trim((string)$moduleResource->get('pagetitle')) : ('Модуль ' . $moduleId);

    $lessonRows = $service->getModuleLessons($moduleId, true, true);
    $moduleLessonsCount = count($lessonRows);
    $lessonsTotal += $moduleLessonsCount;

    /** @var TrainingUserModuleProgress $moduleProgress */
    $moduleProgress = $service->recalculateModuleProgressFromLessons($courseId, $moduleId, $userId);
    $moduleProgressPercent = $moduleProgress ? round((float)$moduleProgress->get('progress_percent')) : 0;
    $moduleCompleted = $moduleProgress ? ((int)$moduleProgress->get('completed') === 1) : false;
    $moduleLocked = !$service->canAccessModule($courseId, $moduleId, $userId);

    $moduleDurationSeconds = $moduleProgress ? (int)$moduleProgress->get('duration_seconds') : 0;
    if ($moduleDurationSeconds <= 0) {
        foreach ($lessonRows as $lesson) {
            $moduleDurationSeconds += max(0, (int)$lesson->get('duration_seconds'));
        }
    }
    $courseDurationSeconds += $moduleDurationSeconds;
    $moduleDurationText = trainingCoursePageFormatDuration($moduleDurationSeconds);
    $moduleDurationClass = $moduleDurationText !== '' ? '' : 'd-none';

    $moduleStatusHtml = '<span class="label-chip label-chip--blue"><span>Доступен</span></span>';
    $moduleState = 'available';
    if ($moduleCompleted) {
        $moduleStatusHtml = '<span class="label-chip label-chip--green"><span>Пройден</span></span>';
        $moduleState = 'done';
    } elseif ($moduleLocked) {
        $moduleStatusHtml = '<span class="cs-lock"><img src="theme/images/training/curses/lock-keyhole-ico.svg" class="img-svg" alt=""><span>Заблокировано</span></span>';
        $moduleState = 'locked';
    } else {
        $moduleStatusHtml = '<span class="label-chip label-chip--purple"><span>В процессе (' . $moduleProgressPercent . '%)</span></span>';
        $moduleState = 'progress';
    }

    $moduleLessonsHtml = '';
    /** @var TrainingModuleLesson $lesson */
    foreach ($lessonRows as $lesson) {
        $lessonId = (int)$lesson->get('id');
        $lessonTitle = trim((string)$lesson->get('title'));
        if ($lessonTitle === '') {
            $lessonTitle = 'Урок ' . ((int)$lesson->get('sort_order') + 1);
        }

        $lessonLocked = !$service->canAccessLesson($courseId, $moduleId, $lessonId, $userId);
        $lessonUrl = $lessonLocked ? '' : trainingCoursePageMakePlayerUrl($modx, $moduleResourceId, $lessonId);
        $lessonProgress = $service->getLessonProgress($courseId, $lessonId, $userId);
        $lessonCompleted = $lessonProgress && (int)$lessonProgress->get('completed') === 1;
        $lessonPercent = $lessonProgress ? round((float)$lessonProgress->get('progress_percent')) : 0;

        $lessonStatusHtml = '<span class="label-chip label-chip--blue"><span>Начать</span></span>';
        $lessonStatusMobileHtml = '<span class="label-chip"><span>→</span></span>';
        if ($lessonLocked) {
            $lessonStatusHtml = '<span class="cs-lock"><img src="theme/images/training/curses/lock-keyhole-ico.svg" class="img-svg" alt=""><span>Заблокировано</span></span>';
            $lessonStatusMobileHtml = '<span class="label-chip"><img src="theme/images/training/curses/lock-keyhole-ico.svg" class="img-svg" alt=""></span>';
        } elseif ($lessonCompleted) {
            $lessonStatusHtml = '<a class="label-chip label-chip--green" href="' . trainingCoursePageEsc($lessonUrl) . '" style="text-decoration:none;"><span>Открыть</span></a>';
            $lessonStatusMobileHtml = '<a class="label-chip" href="' . trainingCoursePageEsc($lessonUrl) . '" style="text-decoration:none;"><span>OK</span></a>';
        } elseif ($lessonPercent > 0) {
            $lessonStatusHtml = '<a class="label-chip label-chip--purple" href="' . trainingCoursePageEsc($lessonUrl) . '" style="text-decoration:none;"><span>Продолжить</span></a>';
            $lessonStatusMobileHtml = '<a class="label-chip" href="' . trainingCoursePageEsc($lessonUrl) . '" style="text-decoration:none;"><span>' . $lessonPercent . '%</span></a>';
        } elseif (!$lessonLocked) {
            $lessonStatusHtml = '<a class="label-chip label-chip--blue" href="' . trainingCoursePageEsc($lessonUrl) . '" style="text-decoration:none;"><span>Начать</span></a>';
            $lessonStatusMobileHtml = '<a class="label-chip" href="' . trainingCoursePageEsc($lessonUrl) . '" style="text-decoration:none;"><span>→</span></a>';
        }

        $lessonIconHtml = '<span class="cs-item__ico" aria-hidden="true"><img src="theme/images/training/curses/play-ico.png" alt=""></span>';
        if (!$lessonLocked && $lessonUrl !== '') {
            $lessonIconHtml = '<a href="' . trainingCoursePageEsc($lessonUrl) . '" class="cs-item__playlink" aria-label="Открыть урок"><span class="cs-item__ico" aria-hidden="true"><img src="theme/images/training/curses/play-ico.png" alt=""></span></a>';
        }

        $moduleLessonsHtml .= trainingCoursePageRenderChunk($corePath, $lessonTpl, array(
            'lesson_locked_class' => $lessonLocked ? ' is-locked' : '',
            'lesson_icon_html' => $lessonIconHtml,
            'lesson_title_html' => trainingCoursePageEsc($lessonTitle),
            'lesson_type' => 'Учебный материал',
            'lesson_status_html' => $lessonStatusHtml,
            'lesson_status_mobile_html' => $lessonStatusMobileHtml,
        ));
    }

    $moduleLessonsCountText = $moduleLessonsCount . ' ' . trainingCoursePagePlural($moduleLessonsCount, array('материал', 'материала', 'материалов'));
    $modulesHtml .= trainingCoursePageRenderChunk($corePath, $moduleTpl, array(
        'module_open_class' => $openFirst ? ' is-open' : '',
        'module_aria_expanded' => $openFirst ? 'true' : 'false',
        'module_state' => $moduleState,
        'module_title' => trainingCoursePageEsc($moduleTitle),
        'module_lessons_count_text' => trainingCoursePageEsc($moduleLessonsCountText),
        'module_duration_text' => trainingCoursePageEsc($moduleDurationText),
        'module_duration_class' => $moduleDurationClass,
        'module_status_html' => $moduleStatusHtml,
        'module_lessons_html' => $moduleLessonsHtml,
    ));
    $openFirst = false;
}

if ($courseDurationText === '') {
    $courseDurationText = trainingCoursePageFormatDuration($courseDurationSeconds);
}

return trainingCoursePageRenderChunk($corePath, $pageTpl, array(
    'course_title' => trainingCoursePageEsc($courseTitle),
    'course_image' => trainingCoursePageEsc($courseImage),
    'course_status_text' => trainingCoursePageEsc($courseStatusText),
    'course_status_class' => $courseStatusClass,
    'course_user_label' => trainingCoursePageEsc(trainingCoursePageGetUserLabel($modx->user)),
    'course_duration_text' => trainingCoursePageEsc($courseDurationText),
    'course_duration_class' => $courseDurationText !== '' ? '' : 'd-none',
    'course_description' => $courseDescription,
    'course_progress_percent' => $courseProgressPercent,
    'course_completed_modules' => (int)$userCourse->get('completed_modules'),
    'course_total_modules' => (int)$userCourse->get('total_modules'),
    'course_total_lessons' => $lessonsTotal,
    'course_total_tests' => (int)$modx->getCount('TrainingTestLink', array('course_id' => $courseId)),
    'course_modules_html' => $modulesHtml,
));
