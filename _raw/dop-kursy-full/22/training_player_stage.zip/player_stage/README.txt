Замена файлов для этапа проигрывателя и блокировок.

Что входит:
- backend-проверка доступа к module/lesson через GET-параметры
- запрет перескакивать на следующий урок, пока не завершён предыдущий
- сохранение current_time/max_time и завершение lesson по порогу 90%
- пересчёт прогресса модуля по всем видеоурокам в модуле
- пересчёт прогресса курса по модулям
- страница проигрывателя через snippet + chunk
- обновлённая страница курса: уроки считаются только по active video в TrainingModuleVideo

После замены:
1. Сниппет trainingCoursePage должен смотреть на файл core/components/training/elements/snippets/snippet.trainingCoursePage.php
2. Создай/обнови сниппет trainingPlayerPage и привяжи к файлу core/components/training/elements/snippets/snippet.trainingPlayerPage.php
3. Очисти кэш MODX
