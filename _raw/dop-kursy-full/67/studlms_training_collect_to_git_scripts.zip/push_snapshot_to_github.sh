#!/usr/bin/env bash
set -euo pipefail
SNAPSHOT_PATH="${1:-}"
REPO_URL="${2:-https://github.com/satalit844/partner.scanport.ru.git}"
WORK_DIR="${3:-$HOME/partner.scanport.ru}"
COMMIT_MESSAGE="${4:-Add training component without database}"

if [ -z "$SNAPSHOT_PATH" ]; then
  echo "Usage: ./push_snapshot_to_github.sh /path/to/training_snapshot_YYYYMMDD_HHMMSS/repo"
  exit 1
fi
if [ ! -d "$SNAPSHOT_PATH" ]; then
  echo "Snapshot path not found: $SNAPSHOT_PATH"
  exit 1
fi
if [ ! -d "$WORK_DIR/.git" ]; then
  git clone "$REPO_URL" "$WORK_DIR"
fi
cd "$WORK_DIR"
git pull origin main
find . -mindepth 1 -maxdepth 1 ! -name ".git" -exec rm -rf {} +
cp -a "$SNAPSHOT_PATH"/. "$WORK_DIR"/
git add .
if git diff --cached --quiet; then
  echo "No changes to commit"
  exit 0
fi
git commit -m "$COMMIT_MESSAGE"
git push origin main
echo "Done"
