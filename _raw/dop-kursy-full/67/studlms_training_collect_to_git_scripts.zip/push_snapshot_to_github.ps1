param(
    [Parameter(Mandatory=$true)]
    [string]$SnapshotPath,
    [string]$RepoUrl = "https://github.com/satalit844/partner.scanport.ru.git",
    [string]$WorkDir = "$env:USERPROFILE\Desktop\partner.scanport.ru",
    [string]$CommitMessage = "Add training component without database"
)

$ErrorActionPreference = "Stop"

if (!(Test-Path $SnapshotPath)) { throw "SnapshotPath not found: $SnapshotPath" }
if (!(Get-Command git -ErrorAction SilentlyContinue)) { throw "Git is not installed or not in PATH" }
if (!(Test-Path $WorkDir)) { git clone $RepoUrl $WorkDir }

Set-Location $WorkDir
git pull origin main

Get-ChildItem -Force | Where-Object { $_.Name -ne ".git" } | Remove-Item -Recurse -Force
Copy-Item -Path (Join-Path $SnapshotPath "*") -Destination $WorkDir -Recurse -Force

git add .
$status = git status --porcelain
if ([string]::IsNullOrWhiteSpace($status)) {
    Write-Host "No changes to commit"
    exit 0
}

git commit -m $CommitMessage
git push origin main
Write-Host "Done"
