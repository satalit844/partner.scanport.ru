# Скрипты для сбора training в Git

## 1. На сайте / сервере

Положи `export_training_snapshot.php` в корень MODX рядом с `index.php`.

Запусти через SSH:

```bash
php export_training_snapshot.php
```

Или через MODX Console: вставь код без первой строки `<?php`.

Скрипт создаст:

```text
assets/_git_export/training_snapshot_YYYYMMDD_HHMMSS/
assets/_git_export/training_snapshot_YYYYMMDD_HHMMSS.zip
```

Внутри будет папка `repo` — именно её надо грузить в Git.

## 2. Что исключено

```text
_db/
_resources/
assets/components/training/practices/
assets/components/training/uploads/
assets/components/training/certificates/
core/cache/
логи
видео
исходники курсов ppt/doc/pdf/xlsx
```

Схема таблиц `training/usertest` выгружается, но персональные данные и прогресс пользователей не выгружаются.

## 3. Заливка на GitHub с Windows

```powershell
.\push_snapshot_to_github.ps1 -SnapshotPath "C:\path\to\training_snapshot_YYYYMMDD_HHMMSS\repo"
```

## 4. Заливка через Linux/Mac/сервер

```bash
chmod +x push_snapshot_to_github.sh
./push_snapshot_to_github.sh /path/to/training_snapshot_YYYYMMDD_HHMMSS/repo
```
