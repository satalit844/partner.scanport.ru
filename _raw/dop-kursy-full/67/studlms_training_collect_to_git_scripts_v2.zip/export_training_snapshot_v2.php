<?php
/**
 * MODX Training snapshot exporter v2.
 *
 * Исправление v2:
 * - убран вызов xPDOConnection::prepare(), которого нет в MODX Console;
 * - все SQL-запросы идут через $modx->query();
 * - скрипт можно запускать через MODX Console или через CLI.
 */

set_time_limit(0);
ini_set('memory_limit', '1024M');

/* ================== НАСТРОЙКИ ================== */

$TRAINING_ROOT_RESOURCE_ID = 150; // "Все курсы", если id другой — поменяй.
$EXPORT_ALL_ELEMENTS = false;     // true = выгрузить все шаблоны/чанки/сниппеты/плагины.
$COPY_FULL_THEME = false;         // true = копировать theme целиком.
$COPY_MEDIA = false;              // true = копировать медиа курсов. Обычно НЕ надо в публичный Git.
$MAKE_ZIP = true;

$SAFE_TABLE_DATA_ROW_LIMIT = 5000;
$OUTPUT_ROOT_RELATIVE = 'assets/_git_export';

$INCLUDE_PATHS = array(
    'core/components/training',
    'assets/components/training',
    'theme/css',
    'theme/js',
    'theme/images/training',
);

if ($COPY_FULL_THEME) {
    $INCLUDE_PATHS[] = 'theme';
}

$EXCLUDE_PATH_REGEX = array(
    '#(^|/)_db(/|$)#i',
    '#(^|/)_resources(/|$)#i',
    '#(^|/)core/cache(/|$)#i',
    '#(^|/)cache(/|$)#i',
    '#(^|/)logs?(/|$)#i',
    '#(^|/)tmp(/|$)#i',
    '#(^|/)backups?(/|$)#i',
    '#(^|/)backup(/|$)#i',
    '#(^|/)assets/components/training/practices?(/|$)#i',
    '#(^|/)assets/components/training/uploads?(/|$)#i',
    '#(^|/)assets/components/training/certificates?(/|$)#i',
    '#(^|/)assets/components/training/tmp(/|$)#i',
    '#(^|/)assets/components/training/cache(/|$)#i',
);

$EXCLUDE_EXTENSIONS = array(
    'log', 'bak', 'tmp',
    'sql', 'gz', 'tar', 'rar', '7z',
);

if (!$COPY_MEDIA) {
    $EXCLUDE_EXTENSIONS = array_merge($EXCLUDE_EXTENSIONS, array(
        'mp4', 'mkv', 'mov', 'avi', 'webm', 'mp3', 'wav',
        'ppt', 'pptx', 'doc', 'docx', 'xls', 'xlsx', 'pdf',
    ));
    $EXCLUDE_PATH_REGEX[] = '#(^|/)assets/components/training/courses?(/|$)#i';
}

$SENSITIVE_TABLE_REGEX = '#(user|users|attempt|answer|progress|history|submission|comment|message|certificate|certificates|file|token|session|log|practice_files?|practice_answers?)#i';
$SENSITIVE_COLUMN_REGEX = '#(email|phone|mobile|fullname|username|user_id|member_id|manager_id|director_id|createdby|updatedby|ip|token|password|hash|session)#i';

$ELEMENT_NEEDLES = array(
    'training',
    'Training',
    'partnerstraining',
    'PartnerTraining',
    'UserTest',
    'usertest',
    'testListModal',
    'trainingPlayer',
    'обуч',
    'курс',
    'сертифик',
    'практи',
);

/* ================== MODX BOOTSTRAP ================== */

function out($msg) {
    echo '[' . date('H:i:s') . '] ' . $msg . PHP_EOL;
}

if (!isset($modx) || !is_object($modx)) {
    $startDir = __DIR__;
    $dir = $startDir;
    $configCore = null;

    for ($i = 0; $i < 8; $i++) {
        $try = $dir . DIRECTORY_SEPARATOR . 'config.core.php';
        if (is_file($try)) {
            $configCore = $try;
            break;
        }
        $parent = dirname($dir);
        if ($parent === $dir) break;
        $dir = $parent;
    }

    if (!$configCore) {
        die("Не найден config.core.php. Положи файл в корень MODX рядом с index.php.\n");
    }

    define('MODX_API_MODE', true);
    require_once $configCore;
    require_once MODX_CORE_PATH . 'model/modx/modx.class.php';

    $modx = new modX();
    $modx->initialize('mgr');
    $modx->getService('error', 'error.modError');
}

$modx->setLogLevel(modX::LOG_LEVEL_ERROR);
$modx->setLogTarget('ECHO');

$basePath = rtrim(MODX_BASE_PATH, '/\\') . DIRECTORY_SEPARATOR;
$corePath = rtrim(MODX_CORE_PATH, '/\\') . DIRECTORY_SEPARATOR;
$tablePrefix = $modx->getOption('table_prefix');

$stamp = date('Ymd_His');
$outRoot = $basePath . trim($OUTPUT_ROOT_RELATIVE, '/\\') . DIRECTORY_SEPARATOR . 'training_snapshot_' . $stamp;
$snapshotRoot = $outRoot . DIRECTORY_SEPARATOR . 'repo';

foreach (array(
    $outRoot,
    $snapshotRoot,
    $snapshotRoot . '/db',
    $snapshotRoot . '/modx',
    $snapshotRoot . '/_meta',
) as $d) {
    if (!is_dir($d)) {
        mkdir($d, 0775, true);
    }
}

out('Старт экспорта: ' . $outRoot);

/* ================== HELPERS ================== */

function normalize_path($path) {
    return str_replace('\\', '/', $path);
}

function ensure_dir_for_file($file) {
    $dir = dirname($file);
    if (!is_dir($dir)) {
        mkdir($dir, 0775, true);
    }
}

function write_json($file, $data) {
    ensure_dir_for_file($file);
    file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
}

function sql_ident($name) {
    return '`' . str_replace('`', '``', $name) . '`';
}

function sql_value($value) {
    if ($value === null) return 'NULL';
    if (is_bool($value)) return $value ? '1' : '0';
    return "'" . str_replace(array("\\", "'"), array("\\\\", "\\'"), (string)$value) . "'";
}

function contains_any($text, $needles) {
    $text = (string)$text;
    foreach ($needles as $needle) {
        if ($needle !== '' && mb_stripos($text, $needle) !== false) {
            return true;
        }
    }
    return false;
}

function is_excluded_file($rel, $excludeRegex, $excludeExts) {
    $rel = normalize_path($rel);
    foreach ($excludeRegex as $regex) {
        if (preg_match($regex, $rel)) return true;
    }
    $ext = strtolower(pathinfo($rel, PATHINFO_EXTENSION));
    if ($ext && in_array($ext, $excludeExts, true)) return true;
    return false;
}

function copy_tree_filtered($src, $dst, $basePath, $excludeRegex, $excludeExts, &$manifest, &$excluded) {
    if (!is_dir($src)) {
        if (is_file($src)) {
            $rel = ltrim(normalize_path(substr($src, strlen($basePath))), '/');
            if (!is_excluded_file($rel, $excludeRegex, $excludeExts)) {
                ensure_dir_for_file($dst);
                copy($src, $dst);
                $manifest[] = array('path' => $rel, 'size' => filesize($src));
            } else {
                $excluded[] = $rel;
            }
        }
        return;
    }

    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($src, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($it as $file) {
        $srcPath = $file->getPathname();
        $rel = ltrim(normalize_path(substr($srcPath, strlen($basePath))), '/');

        if (is_excluded_file($rel, $excludeRegex, $excludeExts)) {
            $excluded[] = $rel;
            continue;
        }

        $dstPath = rtrim($dst, '/\\') . DIRECTORY_SEPARATOR . substr($srcPath, strlen($src));
        if ($file->isDir()) {
            if (!is_dir($dstPath)) mkdir($dstPath, 0775, true);
        } else {
            ensure_dir_for_file($dstPath);
            copy($srcPath, $dstPath);
            $manifest[] = array('path' => $rel, 'size' => filesize($srcPath));
        }
    }
}

/* ================== FILES ================== */

out('Копируем файлы...');

$fileManifest = array();
$excludedFiles = array();

foreach ($INCLUDE_PATHS as $relPath) {
    $relPath = trim($relPath, '/\\');
    $src = $basePath . str_replace('/', DIRECTORY_SEPARATOR, $relPath);
    $dst = $snapshotRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relPath);

    if (!file_exists($src)) {
        $excludedFiles[] = $relPath . ' — not found';
        continue;
    }

    copy_tree_filtered($src, $dst, $basePath, $EXCLUDE_PATH_REGEX, $EXCLUDE_EXTENSIONS, $fileManifest, $excludedFiles);
}

write_json($snapshotRoot . '/_meta/files_manifest.json', $fileManifest);
write_json($snapshotRoot . '/_meta/files_excluded.json', array_values(array_unique($excludedFiles)));

/* ================== DATABASE ================== */

out('Экспортируем схему и безопасные данные таблиц...');

$patterns = array(
    $tablePrefix . '%training%',
    $tablePrefix . '%partnerstraining%',
    $tablePrefix . '%usertest%',
);

$tables = array();

foreach ($patterns as $pattern) {
    $sql = "SHOW TABLES LIKE " . $modx->quote($pattern);
    $stmt = $modx->query($sql);
    if (!$stmt) continue;

    while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
        if (!empty($row[0])) {
            $tables[] = $row[0];
        }
    }
}

$tables = array_values(array_unique($tables));
sort($tables);

$schemaSql = "-- Training/UserTest tables schema\n-- Generated: " . date('c') . "\n\n";
$dataSql = "-- Safe reference data only. Personal/progress data excluded.\n-- Generated: " . date('c') . "\n\n";
$tableInfo = array();

foreach ($tables as $table) {
    $createSql = '';
    $stmtCreate = $modx->query('SHOW CREATE TABLE ' . sql_ident($table));
    if ($stmtCreate) {
        $createRow = $stmtCreate->fetch(PDO::FETCH_ASSOC);
        if ($createRow) {
            if (isset($createRow['Create Table'])) {
                $createSql = $createRow['Create Table'];
            } else {
                $values = array_values($createRow);
                $createSql = isset($values[1]) ? $values[1] : '';
            }
        }
    }

    if ($createSql) {
        $schemaSql .= "\n\n-- ----------------------------\n";
        $schemaSql .= "-- Table structure for {$table}\n";
        $schemaSql .= "-- ----------------------------\n";
        $schemaSql .= "DROP TABLE IF EXISTS " . sql_ident($table) . ";\n";
        $schemaSql .= $createSql . ";\n";
    }

    $columns = array();
    $stmtCols = $modx->query('SHOW COLUMNS FROM ' . sql_ident($table));
    if ($stmtCols) {
        while ($col = $stmtCols->fetch(PDO::FETCH_ASSOC)) {
            $columns[] = $col;
        }
    }

    $columnNames = array();
    foreach ($columns as $c) {
        if (isset($c['Field'])) $columnNames[] = $c['Field'];
    }

    $isSensitive = preg_match($SENSITIVE_TABLE_REGEX, $table) ? true : false;
    foreach ($columnNames as $col) {
        if (preg_match($SENSITIVE_COLUMN_REGEX, $col)) {
            $isSensitive = true;
            break;
        }
    }

    $count = 0;
    $stmtCount = $modx->query('SELECT COUNT(*) FROM ' . sql_ident($table));
    if ($stmtCount) {
        $count = (int)$stmtCount->fetchColumn();
    }

    $tableInfo[] = array(
        'table' => $table,
        'rows' => $count,
        'schema_exported' => true,
        'data_exported' => !$isSensitive,
        'reason' => $isSensitive ? 'sensitive table/columns' : 'safe reference table'
    );

    if ($isSensitive) {
        $dataSql .= "\n-- Data skipped for {$table}: sensitive table/columns, rows: {$count}\n";
        continue;
    }

    $limit = (int)$SAFE_TABLE_DATA_ROW_LIMIT;
    $dataSql .= "\n\n-- ----------------------------\n";
    $dataSql .= "-- Safe data for {$table}, rows: {$count}, limit: {$limit}\n";
    $dataSql .= "-- ----------------------------\n";

    $stmtRows = $modx->query('SELECT * FROM ' . sql_ident($table) . ' LIMIT ' . $limit);
    if ($stmtRows) {
        while ($row = $stmtRows->fetch(PDO::FETCH_ASSOC)) {
            $fields = array_map('sql_ident', array_keys($row));
            $values = array_map('sql_value', array_values($row));
            $dataSql .= 'INSERT INTO ' . sql_ident($table) . ' (' . implode(',', $fields) . ') VALUES (' . implode(',', $values) . ");\n";
        }
    }
}

file_put_contents($snapshotRoot . '/db/schema_training_usertest.sql', $schemaSql);
file_put_contents($snapshotRoot . '/db/data_safe_training_usertest.sql', $dataSql);
write_json($snapshotRoot . '/db/tables_manifest.json', $tableInfo);

/* ================== RESOURCES ================== */

out('Экспортируем ресурсы обучения...');

$resourceIds = array();

if ($TRAINING_ROOT_RESOURCE_ID > 0) {
    $rootResource = $modx->getObject('modResource', $TRAINING_ROOT_RESOURCE_ID);
    if ($rootResource) {
        $resourceIds[$TRAINING_ROOT_RESOURCE_ID] = true;
        $children = $modx->getChildIds($TRAINING_ROOT_RESOURCE_ID, 20, array('context' => $rootResource->get('context_key')));
        foreach ($children as $id) $resourceIds[(int)$id] = true;
    }
}

$c = $modx->newQuery('modResource');
$c->where(array(
    array('pagetitle:LIKE' => '%обуч%'),
    array('OR:longtitle:LIKE' => '%обуч%'),
    array('OR:alias:LIKE' => '%obuchen%'),
    array('OR:alias:LIKE' => '%training%'),
    array('OR:content:LIKE' => '%training%'),
    array('OR:content:LIKE' => '%UserTest%'),
    array('OR:content:LIKE' => '%partnerstraining%'),
));
$foundResources = $modx->getCollection('modResource', $c);
foreach ($foundResources as $r) $resourceIds[(int)$r->get('id')] = true;

$resources = array();
$templateIdsUsed = array();

foreach (array_keys($resourceIds) as $id) {
    $r = $modx->getObject('modResource', (int)$id);
    if (!$r) continue;
    $arr = $r->toArray('', false, true);
    $resources[] = $arr;
    $templateIdsUsed[(int)$r->get('template')] = true;
}

usort($resources, function($a, $b) {
    if ($a['parent'] == $b['parent']) return $a['menuindex'] <=> $b['menuindex'];
    return $a['parent'] <=> $b['parent'];
});

write_json($snapshotRoot . '/modx/resources_training.json', $resources);

/* ================== ELEMENTS ================== */

out('Экспортируем элементы MODX...');

$elements = array(
    'templates' => array(),
    'chunks' => array(),
    'snippets' => array(),
    'plugins' => array(),
    'template_vars' => array(),
    'system_settings' => array(),
);

$classes = array(
    'templates' => array('class' => 'modTemplate', 'contentFields' => array('templatename', 'description', 'content')),
    'chunks' => array('class' => 'modChunk', 'contentFields' => array('name', 'description', 'snippet')),
    'snippets' => array('class' => 'modSnippet', 'contentFields' => array('name', 'description', 'snippet')),
    'plugins' => array('class' => 'modPlugin', 'contentFields' => array('name', 'description', 'plugincode')),
    'template_vars' => array('class' => 'modTemplateVar', 'contentFields' => array('name', 'caption', 'description', 'elements', 'default_text')),
);

foreach ($classes as $bucket => $info) {
    $collection = $modx->getCollection($info['class']);
    foreach ($collection as $obj) {
        $arr = $obj->toArray('', false, true);
        $include = $EXPORT_ALL_ELEMENTS;

        if (!$include && $bucket === 'templates' && isset($arr['id']) && isset($templateIdsUsed[(int)$arr['id']])) {
            $include = true;
        }

        if (!$include) {
            $haystack = '';
            foreach ($info['contentFields'] as $field) {
                if (isset($arr[$field])) $haystack .= "\n" . $arr[$field];
            }
            $include = contains_any($haystack, $ELEMENT_NEEDLES);
        }

        if ($include) {
            $elements[$bucket][] = $arr;
        }
    }
}

$settings = $modx->getCollection('modSystemSetting');
foreach ($settings as $obj) {
    $arr = $obj->toArray('', false, true);
    $haystack = ($arr['key'] ?? '') . "\n" . ($arr['value'] ?? '') . "\n" . ($arr['namespace'] ?? '') . "\n" . ($arr['description'] ?? '');
    if ($EXPORT_ALL_ELEMENTS || contains_any($haystack, $ELEMENT_NEEDLES)) {
        if (preg_match('#(password|secret|token|key|smtp|mail|api)#i', $arr['key'] ?? '')) {
            $arr['value'] = '[hidden]';
        }
        $elements['system_settings'][] = $arr;
    }
}

write_json($snapshotRoot . '/modx/elements_training_related.json', $elements);

$contexts = array();
foreach ($modx->getCollection('modContext') as $ctx) {
    $contexts[] = $ctx->toArray('', false, true);
}
write_json($snapshotRoot . '/modx/contexts.json', $contexts);

/* ================== META ================== */

$readme = "# partner.scanport.ru / training snapshot\n\n";
$readme .= "Generated: " . date('c') . "\n\n";
$readme .= "Included:\n";
$readme .= "- core/components/training\n";
$readme .= "- assets/components/training, without practices/uploads/media by default\n";
$readme .= "- theme/css\n";
$readme .= "- theme/js\n";
$readme .= "- theme/images/training\n";
$readme .= "- MODX elements/resources related to training\n";
$readme .= "- DB schema for training/usertest tables\n";
$readme .= "- Safe reference DB data only\n\n";
$readme .= "Excluded intentionally:\n";
$readme .= "- _db\n";
$readme .= "- _resources\n";
$readme .= "- user uploads/practices\n";
$readme .= "- logs/cache/backups\n";
$readme .= "- video and source course media\n";

file_put_contents($snapshotRoot . '/README.md', $readme);

$gitignore = "_db/\n_resources/\nassets/components/training/practices/\nassets/components/training/uploads/\nassets/components/training/certificates/\nassets/components/training/courses/\ncore/cache/\n*.log\n*.sql.gz\n*.bak\n.DS_Store\n";
file_put_contents($snapshotRoot . '/.gitignore', $gitignore);

write_json($snapshotRoot . '/_meta/export_config.json', array(
    'generated_at' => date('c'),
    'base_path' => $basePath,
    'core_path' => $corePath,
    'table_prefix' => $tablePrefix,
    'training_root_resource_id' => $TRAINING_ROOT_RESOURCE_ID,
    'copy_full_theme' => $COPY_FULL_THEME,
    'copy_media' => $COPY_MEDIA,
    'export_all_elements' => $EXPORT_ALL_ELEMENTS,
    'include_paths' => $INCLUDE_PATHS,
));

/* ================== ZIP ================== */

$zipFile = null;
if ($MAKE_ZIP && class_exists('ZipArchive')) {
    out('Собираем ZIP...');
    $zipFile = $outRoot . '.zip';
    $zip = new ZipArchive();

    if ($zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($snapshotRoot, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ($it as $file) {
            if (!$file->isFile()) continue;
            $abs = $file->getPathname();
            $rel = normalize_path(substr($abs, strlen($snapshotRoot) + 1));
            $zip->addFile($abs, $rel);
        }

        $zip->close();
    } else {
        $zipFile = null;
    }
}

out('Готово.');
out('Папка: ' . $snapshotRoot);
if ($zipFile) out('ZIP: ' . $zipFile);

return array(
    'success' => true,
    'snapshot' => $snapshotRoot,
    'zip' => $zipFile,
    'files' => count($fileManifest),
    'tables' => count($tables),
);
