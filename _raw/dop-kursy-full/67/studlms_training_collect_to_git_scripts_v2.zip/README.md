# v2

В первой версии была ошибка в MODX Console:

```text
Call to undefined method xPDOConnection::prepare()
```

В v2 это исправлено: SQL-запросы идут через `$modx->query()`.

## Как запускать

Через MODX Console вставляй код из `export_training_snapshot_v2.php` без первой строки `<?php`.

Через SSH можно положить файл в корень сайта и выполнить:

```bash
php export_training_snapshot_v2.php
```
