<?php
/** MODX Console: добавить/обновить настройку email для уведомлений по практическим заданиям */

$key = 'training.practice_notification_email';
$value = 'partner@scanport.ru';

$setting = $modx->getObject('modSystemSetting', array('key' => $key));
if (!$setting) {
    $setting = $modx->newObject('modSystemSetting');
    $setting->set('key', $key);
}

$setting->fromArray(array(
    'value' => $value,
    'xtype' => 'textfield',
    'namespace' => 'training',
    'area' => 'practice',
    'editedon' => date('Y-m-d H:i:s'),
), '', true, true);

if ($setting->save()) {
    $modx->cacheManager->refresh(array('system_settings' => array()));
    echo "OK: {$key} = {$value}\n";
} else {
    echo "ERROR: не удалось сохранить {$key}\n";
}
