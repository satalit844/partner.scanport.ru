-- Настройка email для уведомлений по практическим заданиям.
-- Перед выполнением проверь префикс таблиц. Если у тебя не modx_, замени modx_system_settings на свой префикс.

INSERT INTO `modx_system_settings`
(`key`, `value`, `xtype`, `namespace`, `area`, `editedon`)
VALUES
('training.practice_notification_email', 'partner@scanport.ru', 'textfield', 'training', 'practice', NOW())
ON DUPLICATE KEY UPDATE
`value` = VALUES(`value`),
`xtype` = VALUES(`xtype`),
`namespace` = VALUES(`namespace`),
`area` = VALUES(`area`),
`editedon` = NOW();
