<?php
/**
 * MODX Console
 * Обновляет чанки формы и письма запроса курса из файлов компонента.
 */

$corePath = $modx->getOption(
    'training.core_path',
    null,
    $modx->getOption('core_path') . 'components/training/'
);

$chunkBase = rtrim($corePath, '/\\') . '/elements/chunks/training/manage/';
$map = array(
    'training.manage.request-course.form' => $chunkBase . 'request-course-form.tpl',
    'training.manage.request-course.email' => $chunkBase . 'request-course-email.tpl',
);

$out = array();
foreach ($map as $chunkName => $filePath) {
    if (!is_file($filePath)) {
        $out[] = 'MISS FILE: ' . $filePath;
        continue;
    }

    $chunk = $modx->getObject('modChunk', array('name' => $chunkName));
    if (!$chunk) {
        $chunk = $modx->newObject('modChunk');
        $chunk->set('name', $chunkName);
        $chunk->set('description', 'Training request course chunk');
        $chunk->set('category', 0);
    }

    $chunk->set('snippet', file_get_contents($filePath));
    $chunk->save();
    $out[] = 'OK: ' . $chunkName;
}

$cacheManager = $modx->getCacheManager();
if ($cacheManager) {
    $cacheManager->refresh(array(
        'db' => array(),
        'auto_publish' => array('contexts' => array('web')),
        'context_settings' => array('contexts' => array('web')),
        'resource' => array('contexts' => array('web')),
    ));
}

return implode("
", $out) . "
Cache refreshed.";
