<?php
/**
 * Опционально: запустить в MODX Console, если нужно сразу сдвинуть дату в текущем шаблоне и пересоздать сертификаты.
 * По умолчанию для course_id=1 ставит дату ниже/правее и принудительно регенерирует сертификаты курса.
 */
$corePath = $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/');
require_once $corePath . 'model/training/training.class.php';
require_once $corePath . 'model/training/services/trainingcertificate.class.php';

$courseId = 1;
$prefix = $modx->getOption('table_prefix');
$templateTable = $prefix . 'training_certificate_templates';

$stmt = $modx->prepare('UPDATE `' . $templateTable . '` SET `completed_date_x` = :x, `completed_date_y` = :y, `updatedon` = NOW() WHERE `course_id` = :course_id');
if ($stmt && $stmt->execute(array(':x' => '190.00', ':y' => '935.00', ':course_id' => $courseId))) {
    echo "UPDATED TEMPLATE DATE POSITION
";
} else {
    echo "TEMPLATE UPDATE FAILED
";
}

$service = new TrainingCertificateService($modx, new Training($modx));
$rows = $service->generateAllForCourse($courseId, true);
echo 'REGENERATED: ' . count($rows) . "
";
$modx->cacheManager->refresh();
echo "DONE
";
