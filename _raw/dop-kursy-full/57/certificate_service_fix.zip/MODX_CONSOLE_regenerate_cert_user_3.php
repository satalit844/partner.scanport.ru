<?php
/** @var modX $modx */
$corePath = $modx->getOption('training.core_path', null, MODX_CORE_PATH . 'components/training/');
require_once $corePath . 'model/training/training.class.php';
require_once $corePath . 'model/training/services/trainingcertificate.class.php';

$service = new TrainingCertificateService($modx, new Training($modx));
$result = $service->ensureCertificatesForUser(3, true);
echo "REGENERATED: " . count((array)$result) . "\n";
echo "DONE\n";
