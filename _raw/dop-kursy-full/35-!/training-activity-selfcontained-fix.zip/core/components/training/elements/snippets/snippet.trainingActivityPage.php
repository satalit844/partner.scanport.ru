<?php
/** @var modX $modx */
/** @var array $scriptProperties */

$corePath = $modx->getOption(
    'training.core_path',
    null,
    $modx->getOption('core_path') . 'components/training/'
);

require_once $corePath . 'model/training/training.class.php';

if (!function_exists('trainingActivityReq')) {
    function trainingActivityReq($name, $default = null)
    {
        $name = (string)$name;
        if ($name === '') {
            return $default;
        }

        if (array_key_exists($name, $_GET)) {
            return $_GET[$name];
        }

        $ampName = 'amp;' . $name;
        if (array_key_exists($ampName, $_GET)) {
            return $_GET[$ampName];
        }

        $qs = isset($_SERVER['QUERY_STRING']) ? (string)$_SERVER['QUERY_STRING'] : '';
        if ($qs !== '') {
            $qs = html_entity_decode($qs, ENT_QUOTES, 'UTF-8');
            $qs = str_replace('&amp;', '&', $qs);
            $parsed = array();
            parse_str($qs, $parsed);
            if (array_key_exists($name, $parsed)) {
                return $parsed[$name];
            }
            if (array_key_exists($ampName, $parsed)) {
                return $parsed[$ampName];
            }
        }

        return $default;
    }
}

if (!function_exists('trainingActivityEsc')) {
    function trainingActivityEsc($value)
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('trainingActivityUrl')) {
    function trainingActivityUrl(modX $modx, $resourceId, array $params = array())
    {
        $url = (string)$modx->makeUrl((int)$resourceId, '', $params);
        $url = html_entity_decode($url, ENT_QUOTES, 'UTF-8');
        return str_replace('&amp;', '&', $url);
    }
}

if (!function_exists('trainingActivityRender')) {
    function trainingActivityRender($template, array $placeholders = array())
    {
        $replace = array();
        foreach ($placeholders as $key => $value) {
            if (is_array($value) || is_object($value)) {
                $value = '';
            }
            $replace['{$' . $key . '}'] = (string)$value;
        }
        return strtr($template, $replace);
    }
}

if (!function_exists('trainingActivityError')) {
    function trainingActivityError($title, $message)
    {
        return '<div class="section-block tests-block"><div class="page-content d-flex flex-column h-100"><div class="test-card position-relative w-100 d-flex flex-column"><div class="test-content text-left mb-auto"><div class="test-title">' . trainingActivityEsc($title) . '</div><div class="test-subtitle mt-4">' . trainingActivityEsc($message) . '</div></div></div></div></div>';
    }
}

$resourceId = (int)$modx->getOption('resource_id', $scriptProperties, $modx->resource ? $modx->resource->get('id') : 0);
if ($resourceId <= 0) {
    return '';
}

if (!$modx->user || !(int)$modx->user->get('id') || !$modx->user->isAuthenticated($modx->context->get('key'))) {
    return '';
}

$activityId = (int)trainingActivityReq('activity', 0);
$backResourceId = (int)trainingActivityReq('back', 0);
$screen = trim((string)trainingActivityReq('screen', ''));
$step = trim((string)trainingActivityReq('step', ''));
$resultId = (int)trainingActivityReq('result_id', 0);
$reset = trainingActivityReq('reset', null);

if ($activityId <= 0) {
    return trainingActivityError('Активность не найдена', 'Не передан параметр activity.');
}

$training = new Training($modx);

/** @var TrainingTestLink|null $activity */
$activity = $modx->getObject('TrainingTestLink', array('id' => $activityId));
if (!$activity) {
    return trainingActivityError('Активность не найдена', 'Не удалось найти запись активности.');
}

$courseId = (int)$activity->get('course_id');
$moduleId = (int)$activity->get('module_id');
$testId = (int)$activity->get('usertest_test_id');
$linkType = trim((string)$activity->get('link_type'));
if ($linkType === '') {
    $linkType = 'test';
}

$moduleTitle = 'Модуль';
if ($moduleId > 0 && ($module = $modx->getObject('TrainingModule', $moduleId))) {
    $moduleResourceId = (int)$module->get('resource_id');
    if ($moduleResourceId > 0 && ($moduleResource = $modx->getObject('modResource', $moduleResourceId))) {
        $moduleTitle = trim((string)$moduleResource->get('pagetitle')) ?: $moduleTitle;
    }
}

$usertestCorePath = $modx->getOption('usertest_core_path', null, $modx->getOption('core_path') . 'components/usertest/');
$usertestModelPath = rtrim($usertestCorePath, '/\\') . '/model/usertest/';
if (is_dir($usertestModelPath)) {
    $modx->addPackage('usertest', $usertestModelPath);
}

$test = null;
if ($testId > 0) {
    $test = $modx->getObject('UserTestTests', array('id' => $testId, 'active' => 1));
}
if (!$test) {
    return trainingActivityError('Тест не найден', 'Не удалось найти активный тест для этой активности.');
}

$title = trim((string)$test->get('name'));
$description = trim((string)$test->get('description'));
$instructionHtml = trim((string)$test->get('instruction'));
$minPassPercent = (float)$activity->get('min_pass_percent');
$maxAttempts = (int)$activity->get('max_attempts');

$instructionUrl = trainingActivityUrl($modx, $resourceId, array(
    'activity' => $activityId,
    'back' => $backResourceId,
    'screen' => 'instruction',
));
$startUrl = trainingActivityUrl($modx, $resourceId, array(
    'activity' => $activityId,
    'back' => $backResourceId,
    'step' => 'start',
));
$backUrl = $backResourceId > 0 ? trainingActivityUrl($modx, $backResourceId) : '';

if ($linkType === 'test') {
    $runUserTest = ($step !== '' || $resultId > 0 || $reset !== null || $_SERVER['REQUEST_METHOD'] === 'POST');

    if ($runUserTest) {
        // Нормализуем GET/POST для сниппета usertest
        $_GET['test_id'] = $testId;
        if ($step !== '') {
            $_GET['step'] = $step;
            $_POST['step'] = $step;
        }
        if ($resultId > 0) {
            $_GET['result_id'] = $resultId;
        }
        if ($reset !== null) {
            $_GET['reset'] = 1;
        }

        $modx->setPlaceholder('training_activity_id', $activityId);
        $modx->setPlaceholder('training_activity_type', $linkType);
        $modx->setPlaceholder('training_activity_title', $title);
        $modx->setPlaceholder('training_activity_back_id', $backResourceId);
        $modx->setPlaceholder('training_activity_min_pass_percent', $minPassPercent > 0 ? rtrim(rtrim(number_format($minPassPercent, 2, '.', ''), '0'), '.') : '');
        $modx->setPlaceholder('training_activity_max_attempts', $maxAttempts);

        return $modx->runSnippet('UserTest', array(
            'id' => $testId,
            'AjaxMode' => 1,
            'tpl' => 'tpl.UserTest.main',
            'tplError' => 'tpl.UserTest.error',
        ));
    }

    if ($screen === 'instruction') {
        $tpl = <<<'HTML'
<div class="section-block tests-block">
    <div class="page-content d-flex flex-column h-100">
        <div class="test-card position-relative w-100 d-flex flex-column">
            <div class="test-header">
                <img src="theme/images/training/tests/logo-scanport.svg" alt="Сканпорт" class="img-svg">
            </div>
            <div class="test-content text-left mb-auto">
                <div class="test-title">Инструкция по прохождению теста</div>
                <div class="test-subtitle mb-4">{$instruction_html}</div>
                <div class="text-info-test mt-3">Проходной балл: {$min_pass_percent}%</div>
                <div class="text-info-test mt-2">Попытки: {$attempts_text}</div>
            </div>
            <div class="test-footer d-flex flex-wrap align-items-center justify-content-between gap-2 gap-sm-4">
                {$back_button_html}
                <a href="{$start_url}" class="btn btn-test col-auto text-decoration-none">
                    <span>Начать тест</span>
                    <img src="theme/images/training/tests/arrow-right-ico.svg" class="img-svg d-none d-sm-block">
                </a>
            </div>
        </div>
    </div>
</div>
HTML;
        $backBtn = $backUrl !== ''
            ? '<a href="' . trainingActivityEsc($backUrl) . '" class="btn btn-test col-auto text-decoration-none"><span>Назад к курсу</span><img src="theme/images/training/tests/arrow-crate-ico.svg" class="img-svg d-none d-sm-block"></a>'
            : '';

        $instruction = $instructionHtml !== '' ? $instructionHtml : '<ul class="test-list mb-5"><li>Перед ответом внимательно прочитайте текст вопроса</li><li>Затем выберите правильный вариант ответа</li><li>Нажмите кнопку <span>«Ответить»</span> для подтверждения ответа</li></ul>';
        return trainingActivityRender($tpl, array(
            'instruction_html' => $instruction,
            'min_pass_percent' => $minPassPercent > 0 ? rtrim(rtrim(number_format($minPassPercent, 2, '.', ''), '0'), '.') : '0',
            'attempts_text' => $maxAttempts > 0 ? '0/' . $maxAttempts : '0/0',
            'start_url' => trainingActivityEsc($startUrl),
            'back_button_html' => $backBtn,
        ));
    }

    $tpl = <<<'HTML'
<div class="section-block tests-block">
    <div class="page-content d-flex flex-column h-100">
        <div class="test-card position-relative w-100 d-flex flex-column">
            <div class="test-header">
                <img src="theme/images/training/tests/logo-scanport.svg" alt="Сканпорт" class="img-svg">
            </div>
            <div class="test-content text-left text-md-center mb-auto my-md-auto">
                <div class="test-title">Добро пожаловать к тесту по материалам {$module_title}</div>
                <div class="test-subtitle mt-2 mt-md-0">{$description}</div>
                <div class="text-info-test mt-4 d-inline-flex gap-2 align-items-center"><span>Попытки</span><span>{$attempts_text}</span></div>
            </div>
            <div class="test-footer d-flex flex-wrap align-items-center justify-content-between gap-2 gap-sm-4">
                {$back_button_html}
                <a href="{$instruction_url}" class="btn btn-test col-auto text-decoration-none">
                    <span>Начать тест</span>
                    <img src="theme/images/training/tests/arrow-right-ico.svg" class="img-svg d-none d-sm-block">
                </a>
            </div>
        </div>
    </div>
</div>
HTML;

    $backBtn = $backUrl !== ''
        ? '<a href="' . trainingActivityEsc($backUrl) . '" class="btn btn-test col-auto text-decoration-none"><span>Назад к курсу</span><img src="theme/images/training/tests/arrow-crate-ico.svg" class="img-svg d-none d-sm-block"></a>'
        : '';

    $desc = $description !== '' ? $description : 'Нажмите «Начать тест», чтобы продолжить.';
    return trainingActivityRender($tpl, array(
        'module_title' => trainingActivityEsc($moduleTitle),
        'description' => $desc,
        'attempts_text' => $maxAttempts > 0 ? '0/' . $maxAttempts : '0/0',
        'instruction_url' => trainingActivityEsc($instructionUrl),
        'back_button_html' => $backBtn,
    ));
}

// Базовый вывод практики, чтобы фронт не падал.
$tpl = <<<'HTML'
<div class="section-block tests-block">
    <div class="page-content d-flex flex-column h-100">
        <div class="test-card position-relative w-100 d-flex flex-column">
            <div class="test-header">
                <img src="theme/images/training/tests/logo-scanport.svg" alt="Сканпорт" class="img-svg">
            </div>
            <div class="test-content text-left mb-auto">
                <div class="test-title">Практическое задание</div>
                <div class="test-subtitle mt-3">{$description}</div>
                <div class="test-subtitle mt-3">{$instruction}</div>
            </div>
            <div class="test-footer d-flex flex-wrap align-items-center justify-content-between gap-2 gap-sm-4">
                {$back_button_html}
            </div>
        </div>
    </div>
</div>
HTML;

$backBtn = $backUrl !== ''
    ? '<a href="' . trainingActivityEsc($backUrl) . '" class="btn btn-test col-auto text-decoration-none"><span>Назад к курсу</span><img src="theme/images/training/tests/arrow-crate-ico.svg" class="img-svg d-none d-sm-block"></a>'
    : '';

return trainingActivityRender($tpl, array(
    'description' => $description,
    'instruction' => $instructionHtml,
    'back_button_html' => $backBtn,
));
