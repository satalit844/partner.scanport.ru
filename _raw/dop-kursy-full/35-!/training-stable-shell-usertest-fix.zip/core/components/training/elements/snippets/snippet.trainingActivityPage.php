<?php
/** @var modX $modx */
/** @var array $scriptProperties */

$corePath = $modx->getOption(
    'training.core_path',
    null,
    $modx->getOption('core_path') . 'components/training/'
);

require_once $corePath . 'model/training/training.class.php';

if (!function_exists('trainingActivityReq')) {
    function trainingActivityReq($name, $default = null)
    {
        $name = (string)$name;
        if ($name === '') {
            return $default;
        }

        if (array_key_exists($name, $_GET)) {
            return $_GET[$name];
        }

        $ampName = 'amp;' . $name;
        if (array_key_exists($ampName, $_GET)) {
            return $_GET[$ampName];
        }

        $qs = isset($_SERVER['QUERY_STRING']) ? (string)$_SERVER['QUERY_STRING'] : '';
        if ($qs !== '') {
            $qs = html_entity_decode($qs, ENT_QUOTES, 'UTF-8');
            $qs = str_replace('&amp;', '&', $qs);
            $parsed = array();
            parse_str($qs, $parsed);
            if (array_key_exists($name, $parsed)) {
                return $parsed[$name];
            }
            if (array_key_exists($ampName, $parsed)) {
                return $parsed[$ampName];
            }
        }

        return $default;
    }
}

if (!function_exists('trainingActivityEsc')) {
    function trainingActivityEsc($value)
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('trainingActivityUrl')) {
    function trainingActivityUrl(modX $modx, $resourceId, array $params = array())
    {
        $url = (string)$modx->makeUrl((int)$resourceId, '', $params);
        $url = html_entity_decode($url, ENT_QUOTES, 'UTF-8');
        return str_replace('&amp;', '&', $url);
    }
}

if (!function_exists('trainingActivityRenderFile')) {
    function trainingActivityRenderFile($corePath, $relativePath, array $placeholders = array())
    {
        $path = rtrim(str_replace('\', '/', (string)$corePath), '/') . '/elements/chunks/' . ltrim($relativePath, '/');
        if (!is_file($path)) {
            return '';
        }

        $content = (string)file_get_contents($path);
        if ($content === '') {
            return '';
        }

        $replace = array();
        foreach ($placeholders as $key => $value) {
            if (is_array($value) || is_object($value)) {
                $value = '';
            }
            $replace['{$' . $key . '}'] = (string)$value;
        }

        return strtr($content, $replace);
    }
}

if (!function_exists('trainingActivityError')) {
    function trainingActivityError($corePath, $title, $message, $backUrl = '')
    {
        return trainingActivityRenderFile($corePath, 'training/activity/error.tpl', array(
            'title' => trainingActivityEsc($title),
            'message' => trainingActivityEsc($message),
            'back_url' => trainingActivityEsc($backUrl),
            'back_button_html' => $backUrl !== ''
                ? '<a href="' . trainingActivityEsc($backUrl) . '" class="btn btn-test col-auto text-decoration-none"><span>Назад к курсу</span><img src="theme/images/training/tests/arrow-crate-ico.svg" class="img-svg d-none d-sm-block"></a>'
                : '',
        ));
    }
}

$resourceId = (int)$modx->getOption('resource_id', $scriptProperties, $modx->resource ? $modx->resource->get('id') : 0);
if ($resourceId <= 0) {
    return '';
}

if (!$modx->user || !(int)$modx->user->get('id') || !$modx->user->isAuthenticated($modx->context->get('key'))) {
    return '';
}

$activityId = (int)trainingActivityReq('activity', 0);
$backResourceId = (int)trainingActivityReq('back', 0);
$screen = trim((string)trainingActivityReq('screen', ''));
$step = trim((string)trainingActivityReq('step', ''));
$resultId = (int)trainingActivityReq('result_id', 0);
$reset = trainingActivityReq('reset', null);

$backUrl = $backResourceId > 0 ? trainingActivityUrl($modx, $backResourceId) : '';

if ($activityId <= 0) {
    return trainingActivityError($corePath, 'Активность не найдена', 'Не передан параметр activity.', $backUrl);
}

$training = new Training($modx);
$activity = $modx->getObject('TrainingTestLink', array('id' => $activityId));
if (!$activity) {
    return trainingActivityError($corePath, 'Активность не найдена', 'Не удалось найти запись активности.', $backUrl);
}

$courseId = (int)$activity->get('course_id');
$moduleId = (int)$activity->get('module_id');
$testId = (int)$activity->get('usertest_test_id');
$linkType = trim((string)$activity->get('link_type'));
if ($linkType === '') {
    $linkType = 'test';
}

$userId = (int)$modx->user->get('id');
if (method_exists($training, 'hasUserCourseAccess') && !$training->hasUserCourseAccess($courseId, $userId)) {
    return trainingActivityError($corePath, 'Нет доступа', 'У вас нет доступа к этой активности.', $backUrl);
}

$moduleTitle = 'Модуль';
if ($moduleId > 0 && ($module = $modx->getObject('TrainingModule', $moduleId))) {
    $moduleResourceId = (int)$module->get('resource_id');
    if ($moduleResourceId > 0 && ($moduleResource = $modx->getObject('modResource', $moduleResourceId))) {
        $moduleTitle = trim((string)$moduleResource->get('pagetitle')) ?: $moduleTitle;
    }
}

$usertest = $modx->getService(
    'usertest',
    'UserTest',
    $modx->getOption('usertest_core_path', null, $modx->getOption('core_path') . 'components/usertest/') . 'model/usertest/',
    array()
);
if (!$usertest) {
    return trainingActivityError($corePath, 'UserTest не найден', 'Не удалось загрузить сервис тестирования.', $backUrl);
}

$testTitle = '';
$testDescription = '';
$testInstruction = '';
$testActive = 0;
$tableTests = $modx->getTableName('UserTestTests');
if ($tableTests) {
    $stmt = $modx->prepare('SELECT `id`,`name`,`description`,`instruction`,`active` FROM `' . $tableTests . '` WHERE `id` = :id LIMIT 1');
    if ($stmt) {
        $stmt->bindValue(':id', $testId, PDO::PARAM_INT);
        if ($stmt->execute()) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row) {
                $testTitle = trim((string)$row['name']);
                $testDescription = trim((string)$row['description']);
                $testInstruction = trim((string)$row['instruction']);
                $testActive = (int)$row['active'];
            }
        }
    }
}

if ($testId <= 0 || $testActive !== 1) {
    return trainingActivityError($corePath, 'Тест не найден', 'Не удалось найти активный тест для этой активности.', $backUrl);
}

$minPassPercent = (float)$activity->get('min_pass_percent');
$maxAttempts = (int)$activity->get('max_attempts');
$attemptsText = $maxAttempts > 0 ? ('0/' . $maxAttempts) : '0/0';
$instructionUrl = trainingActivityUrl($modx, $resourceId, array('activity' => $activityId, 'back' => $backResourceId, 'screen' => 'instruction'));
$testUrl = trainingActivityUrl($modx, $resourceId, array('activity' => $activityId, 'back' => $backResourceId, 'screen' => 'test', 'step' => 'start'));

if ($linkType === 'test') {
    $shouldRunUserTest = false;
    if ($screen === 'test') {
        $shouldRunUserTest = true;
    }
    if ($step !== '' || $resultId > 0 || $reset !== null || $_SERVER['REQUEST_METHOD'] === 'POST') {
        $shouldRunUserTest = true;
    }

    if ($shouldRunUserTest) {
        $_GET['test_id'] = $testId;
        if ($step !== '') {
            $_GET['step'] = $step;
        }
        if ($resultId > 0) {
            $_GET['result_id'] = $resultId;
        }
        if ($reset !== null) {
            $_GET['reset'] = 1;
        }
        return $modx->runSnippet('UserTest', array(
            'id' => $testId,
            'AjaxMode' => 1,
            'tpl' => 'tpl.UserTest.main',
            'tplError' => 'tpl.UserTest.error',
        ));
    }

    if ($screen === 'instruction') {
        return trainingActivityRenderFile($corePath, 'training/activity/instruction.tpl', array(
            'instruction_html' => $testInstruction !== '' ? $testInstruction : '<p>Перед ответом внимательно прочитайте текст вопроса. Затем выберите правильный вариант ответа. В некоторых вопросах может быть несколько правильных ответов. Нажмите кнопку «Начать тест», чтобы перейти к вопросам.</p>',
            'min_pass_percent' => $minPassPercent > 0 ? rtrim(rtrim(number_format($minPassPercent, 2, '.', ''), '0'), '.') : '0',
            'attempts_text' => $attemptsText,
            'start_url' => trainingActivityEsc($testUrl),
            'back_button_html' => $backUrl !== '' ? '<a href="' . trainingActivityEsc($backUrl) . '" class="btn btn-test col-auto text-decoration-none"><span>Назад к курсу</span><img src="theme/images/training/tests/arrow-crate-ico.svg" class="img-svg d-none d-sm-block"></a>' : '',
        ));
    }

    return trainingActivityRenderFile($corePath, 'training/activity/start.tpl', array(
        'title' => trainingActivityEsc($testTitle !== '' ? $testTitle : 'Тест'),
        'description_html' => $testDescription !== '' ? $testDescription : '<p>Нажмите «Начать тест», чтобы перейти к инструкции.</p>',
        'attempts_text' => $attemptsText,
        'instruction_url' => trainingActivityEsc($instructionUrl),
        'back_button_html' => $backUrl !== '' ? '<a href="' . trainingActivityEsc($backUrl) . '" class="btn btn-test col-auto text-decoration-none"><span>Назад к курсу</span><img src="theme/images/training/tests/arrow-crate-ico.svg" class="img-svg d-none d-sm-block"></a>' : '',
    ));
}

return trainingActivityError($corePath, 'Практическое задание', 'Интерфейс практического задания будет подключён следующим шагом.', $backUrl);
