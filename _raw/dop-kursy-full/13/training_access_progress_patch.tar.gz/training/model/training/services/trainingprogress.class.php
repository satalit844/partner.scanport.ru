<?php

class TrainingProgressService
{
    /** @var modX */
    protected $modx;

    /** @var Training */
    protected $training;

    public function __construct(modX $modx, Training $training = null)
    {
        $this->modx = $modx;
        if ($training instanceof Training) {
            $this->training = $training;
        } else {
            require_once dirname(dirname(__DIR__)) . '/training.class.php';
            $this->training = new Training($this->modx);
        }
    }

    public function getNow()
    {
        return date('Y-m-d H:i:s');
    }

    public function hasCourseAccess($courseId, $userId)
    {
        $courseId = (int)$courseId;
        $userId = (int)$userId;
        if ($courseId <= 0 || $userId <= 0) {
            return false;
        }

        if ($this->modx->user && (int)$this->modx->user->get('id') === $userId && $this->modx->user->isMember('Administrator')) {
            return true;
        }

        $userGroupIds = $this->getUserGroupIds($userId);
        $c = $this->modx->newQuery('TrainingCourseAccess');
        $c->where([
            'course_id' => $courseId,
            'is_active' => 1,
        ]);

        $where = [
            [
                'principal_type' => 'user',
                'principal_id' => $userId,
            ]
        ];

        if (!empty($userGroupIds)) {
            $where[] = [
                'principal_type' => 'group',
                'principal_id:IN' => $userGroupIds,
            ];
        }

        $c->andCondition($where, null, 2);
        $items = $this->modx->getIterator('TrainingCourseAccess', $c);
        $now = $this->getNow();
        /** @var TrainingCourseAccess $item */
        foreach ($items as $item) {
            if ($this->isAccessCurrentlyActive($item, $now)) {
                return true;
            }
        }

        return false;
    }

    public function collectAccessibleUserIds($courseId)
    {
        $courseId = (int)$courseId;
        if ($courseId <= 0) {
            return [];
        }

        $ids = [];
        $now = $this->getNow();
        $items = $this->modx->getIterator('TrainingCourseAccess', [
            'course_id' => $courseId,
            'is_active' => 1,
        ]);

        /** @var TrainingCourseAccess $item */
        foreach ($items as $item) {
            if (!$this->isAccessCurrentlyActive($item, $now)) {
                continue;
            }

            $principalType = (string)$item->get('principal_type');
            $principalId = (int)$item->get('principal_id');
            if ($principalId <= 0) {
                continue;
            }

            if ($principalType === 'user') {
                $ids[$principalId] = $principalId;
                continue;
            }

            if ($principalType === 'group') {
                $members = $this->modx->getIterator('modUserGroupMember', [
                    'user_group' => $principalId,
                ]);
                /** @var modUserGroupMember $member */
                foreach ($members as $member) {
                    $memberId = (int)$member->get('member');
                    if ($memberId > 0) {
                        $ids[$memberId] = $memberId;
                    }
                }
            }
        }

        ksort($ids);
        return array_values($ids);
    }

    public function syncUserCourses($courseId)
    {
        $courseId = (int)$courseId;
        if ($courseId <= 0) {
            return [
                'created' => 0,
                'updated' => 0,
                'deactivated' => 0,
                'users' => [],
            ];
        }

        $accessibleUserIds = $this->collectAccessibleUserIds($courseId);
        $existing = $this->modx->getIterator('TrainingUserCourse', [
            'course_id' => $courseId,
        ]);

        $existingMap = [];
        /** @var TrainingUserCourse $userCourse */
        foreach ($existing as $userCourse) {
            $existingMap[(int)$userCourse->get('user_id')] = $userCourse;
        }

        $created = 0;
        $updated = 0;
        $deactivated = 0;
        $activeMap = array_fill_keys($accessibleUserIds, true);
        $now = $this->getNow();

        foreach ($accessibleUserIds as $userId) {
            $userId = (int)$userId;
            $userCourse = isset($existingMap[$userId]) ? $existingMap[$userId] : null;
            if (!$userCourse) {
                $userCourse = $this->ensureUserCourse($courseId, $userId);
                $created++;
            } else {
                if ((string)$userCourse->get('status') === 'revoked') {
                    $userCourse->set('status', 'assigned');
                }
                $userCourse->set('last_activity', $now);
                $userCourse->save();
                $updated++;
            }

            $this->recalculateUserCourse($courseId, $userId);
        }

        foreach ($existingMap as $userId => $userCourse) {
            if (isset($activeMap[$userId])) {
                continue;
            }
            if ((string)$userCourse->get('status') !== 'completed') {
                $userCourse->set('status', 'revoked');
            }
            $userCourse->set('last_activity', $now);
            $userCourse->save();
            $deactivated++;
        }

        return [
            'created' => $created,
            'updated' => $updated,
            'deactivated' => $deactivated,
            'users' => $accessibleUserIds,
        ];
    }

    public function ensureUserCourse($courseId, $userId)
    {
        $courseId = (int)$courseId;
        $userId = (int)$userId;

        /** @var TrainingUserCourse $userCourse */
        $userCourse = $this->modx->getObject('TrainingUserCourse', [
            'course_id' => $courseId,
            'user_id' => $userId,
        ]);

        if (!$userCourse) {
            $userCourse = $this->modx->newObject('TrainingUserCourse');
            $userCourse->fromArray([
                'course_id' => $courseId,
                'user_id' => $userId,
                'status' => 'assigned',
                'current_module_id' => 0,
                'progress_percent' => 0,
                'completed_modules' => 0,
                'total_modules' => 0,
                'startedon' => null,
                'completedon' => null,
                'last_activity' => $this->getNow(),
            ], '', true, true);
            $userCourse->save();
        }

        return $userCourse;
    }

    public function getCourseModules($courseId, $onlyActive = true, $requiredOnly = false)
    {
        $courseId = (int)$courseId;
        $c = $this->modx->newQuery('TrainingModule');
        $c->where(['course_id' => $courseId]);
        if ($onlyActive) {
            $c->where(['is_active' => 1]);
        }
        if ($requiredOnly) {
            $c->where(['is_required' => 1]);
        }
        $c->leftJoin('modResource', 'Resource', 'Resource.id = TrainingModule.resource_id');
        $c->sortby('Resource.menuindex', 'ASC');
        $c->sortby('TrainingModule.id', 'ASC');
        return $this->modx->getCollection('TrainingModule', $c);
    }

    public function saveModuleProgress($courseId, $moduleId, $userId, array $data = [])
    {
        $courseId = (int)$courseId;
        $moduleId = (int)$moduleId;
        $userId = (int)$userId;

        if ($courseId <= 0 || $moduleId <= 0 || $userId <= 0) {
            return false;
        }

        /** @var TrainingModule $module */
        $module = $this->modx->getObject('TrainingModule', [
            'id' => $moduleId,
            'course_id' => $courseId,
        ]);
        if (!$module) {
            return false;
        }

        /** @var TrainingUserModuleProgress $progress */
        $progress = $this->modx->getObject('TrainingUserModuleProgress', [
            'module_id' => $moduleId,
            'user_id' => $userId,
        ]);

        if (!$progress) {
            $progress = $this->modx->newObject('TrainingUserModuleProgress');
            $progress->fromArray([
                'course_id' => $courseId,
                'module_id' => $moduleId,
                'user_id' => $userId,
                'status' => 'not_started',
                'current_time' => 0,
                'max_time' => 0,
                'watched_seconds' => 0,
                'duration_seconds' => max(0, (int)$module->get('duration_seconds')),
                'progress_percent' => 0,
                'completed' => 0,
                'completedon' => null,
                'last_watch' => null,
            ], '', true, true);
        }

        $duration = max(0, (int)$module->get('duration_seconds'));
        $currentTime = isset($data['current_time']) ? max(0, (int)$data['current_time']) : (int)$progress->get('current_time');
        if ($duration > 0 && $currentTime > $duration) {
            $currentTime = $duration;
        }

        $maxTime = max((int)$progress->get('max_time'), $currentTime, isset($data['max_time']) ? (int)$data['max_time'] : 0);
        if ($duration > 0 && $maxTime > $duration) {
            $maxTime = $duration;
        }

        $completed = !empty($data['completed']) ? 1 : 0;
        $progressPercent = 0;
        if ($duration > 0) {
            $progressPercent = round(($maxTime / $duration) * 100, 2);
            if ($progressPercent >= 90) {
                $completed = 1;
            }
        } elseif ($maxTime > 0) {
            $progressPercent = 100;
            $completed = 1;
        }

        $now = $this->getNow();
        $status = $completed ? 'completed' : ($maxTime > 0 ? 'in_progress' : 'not_started');

        $progress->set('course_id', $courseId);
        $progress->set('module_id', $moduleId);
        $progress->set('user_id', $userId);
        $progress->set('status', $status);
        $progress->set('current_time', $currentTime);
        $progress->set('max_time', $maxTime);
        $progress->set('watched_seconds', max((int)$progress->get('watched_seconds'), $maxTime));
        $progress->set('duration_seconds', $duration);
        $progress->set('progress_percent', $progressPercent);
        $progress->set('completed', $completed);
        $progress->set('completedon', $completed ? ($progress->get('completedon') ?: $now) : null);
        $progress->set('last_watch', $now);
        $progress->save();

        $this->recalculateUserCourse($courseId, $userId);
        return $progress;
    }

    public function recalculateUserCourse($courseId, $userId)
    {
        $courseId = (int)$courseId;
        $userId = (int)$userId;
        if ($courseId <= 0 || $userId <= 0) {
            return false;
        }

        /** @var TrainingUserCourse $userCourse */
        $userCourse = $this->ensureUserCourse($courseId, $userId);
        if (!$userCourse) {
            return false;
        }

        $requiredModules = $this->getCourseModules($courseId, true, true);
        $requiredIds = [];
        /** @var TrainingModule $module */
        foreach ($requiredModules as $module) {
            $requiredIds[] = (int)$module->get('id');
        }

        if (empty($requiredIds)) {
            $allActiveModules = $this->getCourseModules($courseId, true, false);
            foreach ($allActiveModules as $module) {
                $requiredIds[] = (int)$module->get('id');
            }
        }

        $totalModules = count($requiredIds);
        $completedModules = 0;
        $currentModuleId = 0;
        $started = false;

        if ($totalModules > 0) {
            $progressItems = $this->modx->getCollection('TrainingUserModuleProgress', [
                'course_id' => $courseId,
                'user_id' => $userId,
            ]);

            $progressMap = [];
            /** @var TrainingUserModuleProgress $item */
            foreach ($progressItems as $item) {
                $progressMap[(int)$item->get('module_id')] = $item;
            }

            foreach ($requiredIds as $moduleId) {
                /** @var TrainingUserModuleProgress|null $item */
                $item = isset($progressMap[$moduleId]) ? $progressMap[$moduleId] : null;
                if ($item && (int)$item->get('completed') === 1) {
                    $completedModules++;
                }
                if ($item && ((int)$item->get('max_time') > 0 || (string)$item->get('status') !== 'not_started')) {
                    $started = true;
                }
                if ($currentModuleId <= 0 && (!$item || (int)$item->get('completed') !== 1)) {
                    $currentModuleId = $moduleId;
                }
            }
        }

        $progressPercent = $totalModules > 0 ? round(($completedModules / $totalModules) * 100, 2) : 0;
        $status = 'assigned';
        $completedOn = null;
        $startedOn = $userCourse->get('startedon');

        if ($completedModules > 0 || $started) {
            $status = 'in_progress';
            if (!$startedOn) {
                $startedOn = $this->getNow();
            }
        }

        if ($totalModules > 0 && $completedModules >= $totalModules) {
            $status = 'completed';
            $completedOn = $userCourse->get('completedon') ?: $this->getNow();
            $currentModuleId = 0;
        }

        $userCourse->set('status', $status);
        $userCourse->set('current_module_id', $currentModuleId);
        $userCourse->set('progress_percent', $progressPercent);
        $userCourse->set('completed_modules', $completedModules);
        $userCourse->set('total_modules', $totalModules);
        $userCourse->set('startedon', $startedOn ?: null);
        $userCourse->set('completedon', $completedOn);
        $userCourse->set('last_activity', $this->getNow());
        $userCourse->save();

        return $userCourse;
    }

    public function isAccessCurrentlyActive($access, $now = null)
    {
        $now = $now ?: $this->getNow();
        $activeFrom = null;
        $activeTo = null;

        if ($access instanceof TrainingCourseAccess) {
            if (!(int)$access->get('is_active')) {
                return false;
            }
            $activeFrom = $access->get('active_from');
            $activeTo = $access->get('active_to');
        } elseif (is_array($access)) {
            if (isset($access['is_active']) && !(int)$access['is_active']) {
                return false;
            }
            $activeFrom = isset($access['active_from']) ? $access['active_from'] : null;
            $activeTo = isset($access['active_to']) ? $access['active_to'] : null;
        }

        if (!empty($activeFrom) && $now < $activeFrom) {
            return false;
        }
        if (!empty($activeTo) && $now > $activeTo) {
            return false;
        }

        return true;
    }

    public function getUserGroupIds($userId)
    {
        $userId = (int)$userId;
        if ($userId <= 0) {
            return [];
        }

        $ids = [];
        $members = $this->modx->getIterator('modUserGroupMember', [
            'member' => $userId,
        ]);

        /** @var modUserGroupMember $member */
        foreach ($members as $member) {
            $groupId = (int)$member->get('user_group');
            if ($groupId > 0) {
                $ids[$groupId] = $groupId;
            }
        }

        return array_values($ids);
    }
}
