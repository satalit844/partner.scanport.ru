Training.panel.CourseTabs = function(config) {
    config = config || {};

    this.courseId = config.courseId || Training.config.course_id;

    Ext.apply(config, {
        id: 'training-course-tabs',
        border: true,
        deferredRender: false,
        defaults: {
            border: false,
            autoHeight: true
        },
        items: [{
            title: 'Общие',
            xtype: 'training-course-general-form',
            courseId: this.courseId
        }, {
            title: 'Модули',
            xtype: 'training-grid-course-modules',
            courseId: this.courseId
        }, {
            title: 'Доступ',
            xtype: 'training-grid-course-access',
            courseId: this.courseId
        }]
    });

    Training.panel.CourseTabs.superclass.constructor.call(this, config);
};

Ext.extend(Training.panel.CourseTabs, MODx.Tabs);
Ext.reg('training-course-tabs', Training.panel.CourseTabs);


Training.combo.CoursePresentationFiles = function(config) {
    config = config || {};
    this.courseId = config.courseId || Training.config.course_id;

    Ext.applyIf(config, {
        hiddenName: config.name || 'source_presentation_selector',
        name: config.name || 'source_presentation_selector',
        fieldLabel: config.fieldLabel || 'Выбрать файл с сервера',
        valueField: 'path',
        displayField: 'path',
        editable: false,
        forceSelection: true,
        triggerAction: 'all',
        mode: 'remote',
        pageSize: 30,
        anchor: '100%',
        emptyText: 'Открыть список доступных презентаций',
        store: new Ext.data.JsonStore({
            url: Training.config.connector_url,
            root: 'results',
            totalProperty: 'total',
            idProperty: 'path',
            fields: ['path', 'name', 'dir', 'ext', 'filesize'],
            baseParams: {
                action: 'mgr/course/presentation/files',
                course_id: this.courseId
            }
        })
    });

    Training.combo.CoursePresentationFiles.superclass.constructor.call(this, config);
};
Ext.extend(Training.combo.CoursePresentationFiles, MODx.combo.ComboBox);
Ext.reg('training-combo-course-presentation-files', Training.combo.CoursePresentationFiles);


Training.form.CourseGeneral = function(config) {
    config = config || {};
    this.courseId = config.courseId || Training.config.course_id;

    Ext.apply(config, {
        id: 'training-course-general-form',
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/course/update'
        },
        bodyCssClass: 'main-wrapper',
        cls: 'container',
        labelWidth: 190,
        autoHeight: true,
        border: false,
        bodyStyle: 'padding:16px;background:#fff;border:1px solid #e5e5e5;border-radius:6px;',
        defaults: {
            anchor: '100%'
        },
        items: [{
            html: '<div style="padding:0 0 16px;color:#666;line-height:1.6;">На уровне курса храним исходную презентацию, PDF и разобранные слайды. Сначала выбираем файл презентации, затем запускаем разбор в PDF и JPG-слайды.</div>',
            border: false
        }, {
            xtype: 'hidden',
            name: 'id',
            value: this.courseId
        }, {
            xtype: 'fieldset',
            title: 'Основное',
            autoHeight: true,
            defaults: {anchor: '100%'},
            items: [{
                xtype: 'displayfield',
                fieldLabel: 'ID курса',
                name: 'id_label'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Resource ID',
                name: 'resource_id'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Название',
                name: 'pagetitle'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Алиас',
                name: 'alias'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Контекст',
                name: 'context_key'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'URI',
                name: 'uri'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Опубликован ресурс',
                name: 'published_label'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Модулей',
                name: 'modules_count'
            }, {
                xtype: 'xcheckbox',
                boxLabel: 'Курс активен',
                hideLabel: true,
                name: 'is_active',
                inputValue: 1,
                checked: true
            }]
        }, {
            xtype: 'fieldset',
            title: 'Презентация и слайды',
            autoHeight: true,
            defaults: {anchor: '100%'},
            items: [{
                xtype: 'button',
                text: 'Выбрать файл с сервера',
                style: 'margin-bottom:10px;',
                handler: function() {
                    var field = this.getForm().findField('source_presentation');
                    if (field) {
                        Training.utils.openPathBrowser(field, {
                            source: Training.config.media_source || 3,
                            allowedFileTypes: 'ppt,pptx,pdf'
                        });
                    }
                },
                scope: this
            }, {
                xtype: 'textfield',
                fieldLabel: 'Исходный PPT/PPTX/PDF',
                name: 'source_presentation',
                anchor: '100%',
                emptyText: '/assets/uploads/training/course-1/source.pptx'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Статус презентации',
                name: 'presentation_status'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'PDF',
                name: 'presentation_pdf',
                renderer: Training.utils.renderFileLink
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Папка слайдов',
                name: 'slides_dir'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Папка найдена',
                name: 'slides_dir_exists_label'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Слайдов в папке',
                name: 'available_slides_count'
            }]
        }],
        buttons: [{
            text: 'Сохранить',
            handler: this.saveForm,
            scope: this
        }, {
            text: 'Разобрать PPTX в слайды',
            handler: this.processPresentation,
            scope: this
        }, {
            text: 'Открыть ресурс',
            handler: function() {
                var form = this.getForm();
                var values = form.getValues();
                if (values.resource_id) {
                    MODx.loadPage('resource/update', 'id=' + values.resource_id);
                }
            },
            scope: this
        }, {
            text: 'Назад к списку',
            handler: function() {
                window.location.href = Training.utils.buildUrl({}, ['course_id', 'module_id']);
            }
        }]
    });

    Training.form.CourseGeneral.superclass.constructor.call(this, config);

    this.on('afterrender', this.loadCourse, this);
};

Ext.extend(Training.form.CourseGeneral, MODx.FormPanel, {
    loadCourse: function() {
        var form = this.getForm();
        this.getEl().mask('Загружаем курс...');
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/course/get',
                id: this.courseId
            },
            listeners: {
                success: {
                    fn: function(r) {
                        this.getEl().unmask();
                        var obj = Training.utils.getResultData(r);
                        form.setValues(obj);
                        Training.utils.setCheckboxValue(form, 'is_active', obj.is_active);
                    },
                    scope: this
                },
                failure: {
                    fn: function(r) {
                        this.getEl().unmask();
                        MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось загрузить курс');
                    },
                    scope: this
                }
            }
        });
    },

    saveForm: function() {
        var form = this.getForm();
        if (!form.isValid()) {
            return false;
        }

        var values = form.getValues();
        values.action = 'mgr/course/update';
        values.id = this.courseId;
        values.is_active = Training.utils.toBool(form.findField('is_active').getValue()) ? 1 : 0;

        this.getEl().mask('Сохраняем курс...');
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: values,
            listeners: {
                success: {
                    fn: function() {
                        this.getEl().unmask();
                        this.loadCourse();
                        MODx.msg.alert('Готово', 'Курс сохранён');
                    },
                    scope: this
                },
                failure: {
                    fn: function(r) {
                        this.getEl().unmask();
                        MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось сохранить курс');
                    },
                    scope: this
                }
            }
        });
    },

    processPresentation: function() {
        var values = this.getForm().getValues();
        this.getEl().mask('Обрабатываем презентацию...');

        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/course/presentation/process',
                course_id: this.courseId,
                source_presentation: values.source_presentation || ''
            },
            listeners: {
                success: {
                    fn: function(r) {
                        this.getEl().unmask();
                        this.loadCourse();
                        var message = 'Презентация обработана';
                        if (r && r.object && typeof r.object.slides_count !== 'undefined') {
                            message += '. Слайдов: ' + r.object.slides_count;
                        }
                        MODx.msg.alert('Готово', message);
                    },
                    scope: this
                },
                failure: {
                    fn: function(r) {
                        this.getEl().unmask();
                        MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось обработать презентацию');
                    },
                    scope: this
                }
            }
        });
    }
});

Ext.reg('training-course-general-form', Training.form.CourseGeneral);
