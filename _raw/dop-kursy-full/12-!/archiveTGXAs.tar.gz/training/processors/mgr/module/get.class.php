<?php

require_once dirname(__DIR__) . '/_media_helper.php';

class TrainingModuleGetProcessor extends modObjectGetProcessor
{
    public $classKey = 'TrainingModule';
    public $objectType = 'training.module';

    public function checkPermissions()
    {
        return true;
    }

    public function initialize()
    {
        if (!$this->getProperty('id')) {
            return $this->modx->lexicon('invalid_data');
        }
        return parent::initialize();
    }

    protected function fetchResourceData($id)
    {
        $id = (int)$id;
        if ($id <= 0) return null;
        $resource = $this->modx->getObject('modResource', ['id' => $id]);
        if ($resource) {
            return [
                'pagetitle' => $resource->get('pagetitle'),
                'alias' => $resource->get('alias'),
                'context_key' => $resource->get('context_key'),
                'uri' => $resource->get('uri'),
                'published' => (int)$resource->get('published'),
            ];
        }
        $table = $this->modx->getTableName('modResource');
        $stmt = $this->modx->prepare("SELECT pagetitle, alias, context_key, uri, published FROM {$table} WHERE id = :id LIMIT 1");
        if ($stmt && $stmt->execute([':id' => $id])) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row) {
                $row['published'] = (int)$row['published'];
                return $row;
            }
        }
        return null;
    }

    public function cleanup()
    {
        $array = $this->object->toArray();
        $resourceRow = $this->fetchResourceData($array['resource_id']);
        if ($resourceRow) {
            $array = array_merge($array, $resourceRow);
            $array['published_label'] = !empty($resourceRow['published']) ? 'Да' : 'Нет';
        } else {
            $array['pagetitle'] = '—';
            $array['alias'] = '—';
            $array['context_key'] = '—';
            $array['uri'] = '—';
            $array['published'] = 0;
            $array['published_label'] = 'Нет';
        }

        /** @var TrainingCourse $course */
        $course = $this->modx->getObject('TrainingCourse', ['id' => $array['course_id']]);
        $array['course_title'] = '—';
        if ($course) {
            $courseRow = $this->fetchResourceData($course->get('resource_id'));
            if ($courseRow && !empty($courseRow['pagetitle'])) {
                $array['course_title'] = $courseRow['pagetitle'];
            }
        }

        $array['videos_count'] = (int)$this->modx->getCount('TrainingModuleVideo', ['module_id' => $array['id']]);
        $array['slides_count'] = (int)$this->modx->getCount('TrainingModuleSlide', ['module_id' => $array['id']]);
        $dirs = TrainingMediaHelper::resolveModuleVideoDirs($this->modx, $this->object);
        $array['video_output_dir'] = $dirs['video_web'];

        $courseSlidesDir = '';
        $courseSlidesExists = 'Нет';
        $courseSlidesCount = 0;
        $coursePresentationStatus = 'none';
        if ($course) {
            $coursePresentationStatus = (string)$course->get('presentation_status');
            $courseDirs = TrainingMediaHelper::resolveCoursePresentationDirs($this->modx, $course);
            $courseSlidesDir = !empty($course->get('slides_dir')) ? $course->get('slides_dir') : $courseDirs['slides_web'];
            $abs = TrainingMediaHelper::webPathToFs($this->modx, $courseSlidesDir);
            if ($abs && is_dir($abs)) {
                $courseSlidesExists = 'Да';
                foreach ((array)scandir($abs) as $item) {
                    if ($item === '.' || $item === '..') continue;
                    $full = rtrim($abs, '/\\') . '/' . $item;
                    if (is_file($full) && preg_match('#\.(jpg|jpeg|png|webp|gif)$#i', $item)) $courseSlidesCount++;
                }
            }
        }

        $array['course_presentation_status'] = $coursePresentationStatus ?: 'none';
        $array['course_slides_dir'] = $courseSlidesDir;
        $array['course_slides_dir_exists_label'] = $courseSlidesExists;
        $array['available_course_slides'] = $courseSlidesCount;
        $array['id_label'] = $array['id'];
        $array['course_id_label'] = $array['course_id'];
        $array['duration_human'] = $this->formatSeconds((int)$array['duration_seconds']);
        $array['createdon'] = !empty($array['createdon']) ? $array['createdon'] : '—';
        $array['updatedon'] = !empty($array['updatedon']) ? $array['updatedon'] : '—';
        $array['is_active'] = (int)!empty($array['is_active']);
        $array['is_required'] = (int)!empty($array['is_required']);
        $array['source_video'] = (string)$array['source_video'];
        $array['video_status'] = !empty($array['video_status']) ? $array['video_status'] : 'none';
        $array['presentation_status'] = !empty($array['presentation_status']) ? $array['presentation_status'] : 'none';

        return $this->success('', $array);
    }

    protected function formatSeconds($seconds)
    {
        $seconds = (int)$seconds;
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        $seconds = $seconds % 60;
        return $hours > 0 ? sprintf('%d:%02d:%02d', $hours, $minutes, $seconds) : sprintf('%d:%02d', $minutes, $seconds);
    }
}

return 'TrainingModuleGetProcessor';
