<?php

require_once dirname(__FILE__) . '/_helpers.php';

class TrainingModuleSlideCreateProcessor extends modObjectCreateProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    public $classKey = 'TrainingModuleSlide';
    protected function boolValue($value)
    {
        return in_array((string)$value, ['1', 'true', 'yes', 'on'], true) || $value === true || $value === 1 ? 1 : 0;
    }

    public $objectType = 'training.module.slide';

    public function beforeSet()
    {
        $moduleId = (int)$this->getProperty('module_id');
        $image = trim((string)$this->getProperty('image'));
        $slideNo = (int)$this->getProperty('slide_no', 0);

        if ($moduleId <= 0) {
            return 'Не указан модуль';
        }

        if ($image === '') {
            return 'Выберите изображение слайда';
        }

        $image = TrainingModuleSlideHelper::normalizeWebPath($this->modx, $image);

        if ($slideNo <= 0) {
            $slideNo = $this->getNextSlideNo($moduleId, basename($image));
        }

        $this->setProperty('module_id', $moduleId);
        $this->setProperty('image', $image);
        $this->setProperty('slide_no', $slideNo);
        $this->setProperty('timecode_ms', max(0, (int)$this->getProperty('timecode_ms', 0)));
        $this->setProperty('is_active', $this->boolValue($this->getProperty('is_active', 1)));

        return parent::beforeSet();
    }

    protected function getNextSlideNo($moduleId, $filename)
    {
        $fromFilename = TrainingModuleSlideHelper::extractSlideNumber($filename);
        if ($fromFilename > 0) {
            return $fromFilename;
        }

        $c = $this->modx->newQuery('TrainingModuleSlide');
        $c->where(['module_id' => (int)$moduleId]);
        $c->sortby('slide_no', 'DESC');
        $c->limit(1);

        /** @var TrainingModuleSlide $last */
        $last = $this->modx->getObject('TrainingModuleSlide', $c);
        if ($last) {
            return ((int)$last->get('slide_no')) + 1;
        }

        return 1;
    }
}

return 'TrainingModuleSlideCreateProcessor';
