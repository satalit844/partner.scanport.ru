<?php

class TrainingCourseUpdateProcessor extends modObjectUpdateProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    public $classKey = 'TrainingCourse';
    public $objectType = 'training.course';

    public function beforeSet()
    {
        $id = (int)$this->getProperty('id');
        if (!$id) {
            return 'Не указан ID курса';
        }

        /** @var TrainingCourse $object */
        $object = $this->modx->getObject($this->classKey, ['id' => $id]);
        if (!$object) {
            return 'Курс не найден';
        }

        $this->setProperty('is_active', $this->hasProperty('is_active') ? (int)$this->getProperty('is_active', 0) : (int)$object->get('is_active'));
        $this->setProperty('source_presentation', $this->hasProperty('source_presentation') ? trim((string)$this->getProperty('source_presentation', '')) : (string)$object->get('source_presentation'));
        $this->setProperty('presentation_pdf', $this->hasProperty('presentation_pdf') ? trim((string)$this->getProperty('presentation_pdf', '')) : (string)$object->get('presentation_pdf'));
        $this->setProperty('slides_dir', $this->hasProperty('slides_dir') ? trim((string)$this->getProperty('slides_dir', '')) : (string)$object->get('slides_dir'));

        $status = $this->hasProperty('presentation_status') ? trim((string)$this->getProperty('presentation_status', '')) : (string)$object->get('presentation_status');
        if ($status === '') {
            $status = 'none';
        }
        $this->setProperty('presentation_status', $status);

        return parent::beforeSet();
    }
}

return 'TrainingCourseUpdateProcessor';
