Training.panel.ModuleTabs = function(config) {
    config = config || {};

    this.moduleId = config.moduleId || Training.config.module_id;
    this.courseId = config.courseId || Training.config.course_id;

    Ext.apply(config, {
        id: 'training-module-tabs',
        border: true,
        deferredRender: false,
        defaults: {
            border: false,
            autoHeight: true
        },
        items: [{
            title: 'Общие',
            xtype: 'training-module-general-form',
            moduleId: this.moduleId,
            courseId: this.courseId
        }, {
            title: 'Видео',
            xtype: 'training-grid-module-videos',
            moduleId: this.moduleId
        }, {
            title: 'Слайды',
            xtype: 'training-grid-module-slides',
            moduleId: this.moduleId
        }]
    });

    Training.panel.ModuleTabs.superclass.constructor.call(this, config);
};

Ext.extend(Training.panel.ModuleTabs, MODx.Tabs);
Ext.reg('training-module-tabs', Training.panel.ModuleTabs);


Training.combo.ModuleVideoFiles = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;

    Ext.applyIf(config, {
        hiddenName: config.name || 'video_source_selector',
        name: config.name || 'video_source_selector',
        fieldLabel: config.fieldLabel || 'Выбрать файл с сервера',
        valueField: 'path',
        displayField: 'path',
        editable: false,
        forceSelection: true,
        triggerAction: 'all',
        mode: 'remote',
        pageSize: 30,
        anchor: '100%',
        emptyText: 'Открыть список доступных видеофайлов',
        store: new Ext.data.JsonStore({
            url: Training.config.connector_url,
            root: 'results',
            totalProperty: 'total',
            idProperty: 'path',
            fields: ['path', 'name', 'dir', 'ext', 'filesize'],
            baseParams: {
                action: 'mgr/module/video/files',
                module_id: this.moduleId
            }
        })
    });

    Training.combo.ModuleVideoFiles.superclass.constructor.call(this, config);
};

Ext.extend(Training.combo.ModuleVideoFiles, MODx.combo.ComboBox);
Ext.reg('training-combo-module-video-files', Training.combo.ModuleVideoFiles);


Training.form.ModuleGeneral = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;
    this.courseId = config.courseId || Training.config.course_id;

    Ext.apply(config, {
        id: 'training-module-general-form',
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/module/update'
        },
        bodyCssClass: 'main-wrapper',
        cls: 'container',
        labelWidth: 220,
        autoHeight: true,
        border: false,
        bodyStyle: 'padding:16px;background:#fff;border:1px solid #e5e5e5;border-radius:6px;',
        defaults: {
            anchor: '100%'
        },
        items: [{
            html: '<div style="padding:0 0 16px;color:#666;line-height:1.6;">Модуль хранит исходное видео, статусы генерации и привязанные слайды. Сначала выбираем или загружаем презентацию на курс, потом указываем исходное видео у модуля и запускаем генерацию качеств.</div>',
            border: false
        }, {
            xtype: 'hidden',
            name: 'id',
            value: this.moduleId
        }, {
            xtype: 'hidden',
            name: 'course_id',
            value: this.courseId
        }, {
            xtype: 'fieldset',
            title: 'Основное',
            autoHeight: true,
            defaults: {anchor: '100%'},
            items: [{
                xtype: 'displayfield',
                fieldLabel: 'ID модуля',
                name: 'id_label'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'ID курса',
                name: 'course_id_label'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Курс',
                name: 'course_title'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Resource ID модуля',
                name: 'resource_id'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Название модуля',
                name: 'pagetitle'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'URI',
                name: 'uri'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Опубликован ресурс',
                name: 'published_label'
            }, {
                xtype: 'xcheckbox',
                boxLabel: 'Модуль активен',
                hideLabel: true,
                name: 'is_active',
                inputValue: 1,
                checked: true
            }, {
                xtype: 'xcheckbox',
                boxLabel: 'Модуль обязателен для прохождения',
                hideLabel: true,
                name: 'is_required',
                inputValue: 1,
                checked: true
            }]
        }, {
            xtype: 'fieldset',
            title: 'Видео',
            autoHeight: true,
            defaults: {anchor: '100%'},
            items: [{
                xtype: 'training-combo-module-video-files',
                moduleId: this.moduleId,
                listeners: {
                    select: {
                        fn: function(combo, record) {
                            var form = this.getForm();
                            var field = form.findField('source_video');
                            if (field) {
                                field.setValue(record.data.path || '');
                            }
                        },
                        scope: this
                    }
                }
            }, {
                xtype: 'textfield',
                fieldLabel: 'Исходное видео',
                name: 'source_video',
                anchor: '100%',
                emptyText: '/assets/uploads/training/module-1/video.mkv'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Статус видео',
                name: 'video_status'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Папка видео модуля',
                name: 'video_output_dir'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Длительность',
                name: 'duration_human'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Привязано видео',
                name: 'videos_count'
            }]
        }, {
            xtype: 'fieldset',
            title: 'Слайды курса',
            autoHeight: true,
            defaults: {anchor: '100%'},
            items: [{
                xtype: 'displayfield',
                fieldLabel: 'Статус презентации модуля',
                name: 'presentation_status'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Статус презентации курса',
                name: 'course_presentation_status'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Папка слайдов курса',
                name: 'course_slides_dir'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Папка найдена',
                name: 'course_slides_dir_exists_label'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Слайдов в папке курса',
                name: 'available_course_slides'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Привязано слайдов',
                name: 'slides_count'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Создан',
                name: 'createdon'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Обновлён',
                name: 'updatedon'
            }]
        }],
        buttons: [{
            text: 'Сохранить',
            handler: this.saveForm,
            scope: this
        }, {
            text: 'Сгенерировать качества видео',
            handler: this.transcodeVideo,
            scope: this
        }, {
            text: 'Авторасставить таймкоды',
            handler: this.autoTimecodes,
            scope: this
        }, {
            text: 'Открыть ресурс',
            handler: function() {
                var form = this.getForm();
                var values = form.getValues();
                if (values.resource_id) {
                    MODx.loadPage('resource/update', 'id=' + values.resource_id);
                }
            },
            scope: this
        }, {
            text: 'Назад к модулям курса',
            handler: function() {
                var form = this.getForm();
                var values = form.getValues();
                window.location.href = Training.utils.buildUrl({
                    course_id: values.course_id || this.courseId
                }, ['module_id']);
            },
            scope: this
        }, {
            text: 'Назад к курсам',
            handler: function() {
                window.location.href = Training.utils.buildUrl({}, ['course_id', 'module_id']);
            }
        }]
    });

    Training.form.ModuleGeneral.superclass.constructor.call(this, config);

    this.on('afterrender', this.loadModule, this);
};

Ext.extend(Training.form.ModuleGeneral, MODx.FormPanel, {
    loadModule: function() {
        this.getForm().load({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/module/get',
                id: this.moduleId
            },
            success: function(form, action) {
                var obj = action && action.result && action.result.object ? action.result.object : {};
                Training.utils.setCheckboxValue(form, 'is_active', obj.is_active);
                Training.utils.setCheckboxValue(form, 'is_required', obj.is_required);
            },
            scope: this
        });
    },

    saveForm: function() {
        var form = this.getForm();
        if (!form.isValid()) {
            return false;
        }

        this.getEl().mask('Сохраняем модуль...');
        form.submit({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/module/update'
            },
            success: function() {
                this.getEl().unmask();
                this.loadModule();
                MODx.msg.alert('Готово', 'Модуль сохранён');
            },
            failure: function(f, action) {
                this.getEl().unmask();
                MODx.msg.alert('Ошибка', action && action.result && action.result.message ? action.result.message : 'Не удалось сохранить модуль');
            },
            scope: this
        });
    },

    transcodeVideo: function() {
        var values = this.getForm().getValues();
        this.getEl().mask('Генерируем видео...');

        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/module/video/transcode',
                module_id: this.moduleId,
                source_video: values.source_video || ''
            },
            listeners: {
                success: {
                    fn: function(r) {
                        this.getEl().unmask();
                        this.loadModule();

                        var videosGrid = Ext.getCmp('training-grid-module-videos');
                        if (videosGrid) {
                            videosGrid.refresh();
                        }
                        var slidesGrid = Ext.getCmp('training-grid-module-slides');
                        if (slidesGrid) {
                            slidesGrid.refresh();
                        }

                        var message = 'Видео обработано';
                        if (r && r.object && r.object.qualities) {
                            message += '. Качества: ' + r.object.qualities.join(', ');
                        }
                        if (r && r.object && r.object.timed_slides) {
                            message += '. Слайдов с таймкодами: ' + r.object.timed_slides;
                        }
                        MODx.msg.alert('Готово', message);
                    },
                    scope: this
                },
                failure: {
                    fn: function(r) {
                        this.getEl().unmask();
                        MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось обработать видео');
                    },
                    scope: this
                }
            }
        });
    },

    autoTimecodes: function() {
        this.getEl().mask('Расставляем таймкоды...');

        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/module/slide/autotimecodes',
                module_id: this.moduleId
            },
            listeners: {
                success: {
                    fn: function(r) {
                        this.getEl().unmask();
                        this.loadModule();
                        var slidesGrid = Ext.getCmp('training-grid-module-slides');
                        if (slidesGrid) {
                            slidesGrid.refresh();
                        }
                        var message = 'Таймкоды расставлены';
                        if (r && r.object && typeof r.object.updated !== 'undefined') {
                            message += '. Обновлено слайдов: ' + r.object.updated;
                        }
                        MODx.msg.alert('Готово', message);
                    },
                    scope: this
                },
                failure: {
                    fn: function(r) {
                        this.getEl().unmask();
                        MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось расставить таймкоды');
                    },
                    scope: this
                }
            }
        });
    }
});

Ext.reg('training-module-general-form', Training.form.ModuleGeneral);
