<?php

require_once dirname(__DIR__) . '/_media_helper.php';

class TrainingCourseGetProcessor extends modObjectGetProcessor
{
    public $classKey = 'TrainingCourse';
    public $objectType = 'training.course';

    public function initialize()
    {
        if (!$this->getProperty('id')) {
            return $this->modx->lexicon('invalid_data');
        }

        return parent::initialize();
    }

    public function cleanup()
    {
        $array = $this->object->toArray();

        /** @var modResource $resource */
        $resource = $this->modx->getObject('modResource', [
            'id' => $array['resource_id']
        ]);

        if ($resource) {
            $array['pagetitle'] = $resource->get('pagetitle');
            $array['alias'] = $resource->get('alias');
            $array['context_key'] = $resource->get('context_key');
            $array['uri'] = $resource->get('uri');
            $array['published'] = (int)$resource->get('published');
            $array['published_label'] = $array['published'] ? 'Да' : 'Нет';
        }

        $modulesCount = $this->modx->getCount('TrainingModule', [
            'course_id' => $array['id']
        ]);
        $array['modules_count'] = $modulesCount;
        $array['id_label'] = $array['id'];

        $dirs = TrainingMediaHelper::resolveCoursePresentationDirs($this->modx, $this->object);
        $slidesCount = 0;
        if (!empty($dirs['slides_absolute']) && is_dir($dirs['slides_absolute'])) {
            $items = scandir($dirs['slides_absolute']);
            foreach ($items as $item) {
                if ($item === '.' || $item === '..') {
                    continue;
                }
                if (is_file($dirs['slides_absolute'] . $item) && preg_match('#\.(jpg|jpeg|png|webp|gif)$#i', $item)) {
                    $slidesCount++;
                }
            }
        }

        $array['is_active'] = (int)!empty($array['is_active']);
        $array['source_presentation'] = !empty($array['source_presentation']) ? $array['source_presentation'] : '';
        $array['presentation_pdf'] = !empty($array['presentation_pdf']) ? $array['presentation_pdf'] : '—';
        $array['slides_dir'] = !empty($array['slides_dir']) ? $array['slides_dir'] : $dirs['slides_web'];
        $array['slides_dir_exists_label'] = (!empty($array['slides_dir']) && is_dir(TrainingMediaHelper::webPathToFs($this->modx, $array['slides_dir']))) ? 'Да' : 'Нет';
        $array['presentation_status'] = !empty($array['presentation_status']) ? $array['presentation_status'] : 'none';
        $array['available_slides_count'] = $slidesCount;

        return $this->success('', $array);
    }
}

return 'TrainingCourseGetProcessor';
