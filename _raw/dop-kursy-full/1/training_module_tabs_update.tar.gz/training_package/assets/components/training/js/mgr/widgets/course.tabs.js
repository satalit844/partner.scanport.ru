Training.panel.CourseTabs = function(config) {
    config = config || {};

    this.courseId = config.courseId || Training.config.course_id;

    Ext.apply(config, {
        id: 'training-course-tabs',
        border: true,
        deferredRender: false,
        defaults: {
            border: false,
            autoHeight: true
        },
        items: [{
            title: 'Общие',
            xtype: 'training-course-general-form',
            courseId: this.courseId
        }, {
            title: 'Модули',
            xtype: 'training-grid-course-modules',
            courseId: this.courseId
        }]
    });

    Training.panel.CourseTabs.superclass.constructor.call(this, config);
};

Ext.extend(Training.panel.CourseTabs, MODx.Tabs);
Ext.reg('training-course-tabs', Training.panel.CourseTabs);


Training.form.CourseGeneral = function(config) {
    config = config || {};
    this.courseId = config.courseId || Training.config.course_id;

    Ext.apply(config, {
        id: 'training-course-general-form',
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/course/update'
        },
        bodyCssClass: 'main-wrapper',
        cls: 'panel-desc',
        labelWidth: 160,
        autoHeight: true,
        defaults: {
            anchor: '100%'
        },
        items: [{
            xtype: 'hidden',
            name: 'id',
            value: this.courseId
        }, {
            xtype: 'textfield',
            fieldLabel: 'ID курса',
            name: 'id_label',
            readOnly: true
        }, {
            xtype: 'textfield',
            fieldLabel: 'Resource ID',
            name: 'resource_id',
            readOnly: true
        }, {
            xtype: 'textfield',
            fieldLabel: 'Название',
            name: 'pagetitle',
            readOnly: true
        }, {
            xtype: 'textfield',
            fieldLabel: 'Алиас',
            name: 'alias',
            readOnly: true
        }, {
            xtype: 'textfield',
            fieldLabel: 'Контекст',
            name: 'context_key',
            readOnly: true
        }, {
            xtype: 'xcheckbox',
            boxLabel: 'Курс активен в training',
            hideLabel: true,
            name: 'is_active',
            inputValue: 1
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Модулей',
            name: 'modules_count'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Опубликован',
            name: 'published_label'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'URI',
            name: 'uri'
        }],
        buttons: [{
            text: 'Сохранить',
            handler: this.submit,
            scope: this
        }, {
            text: 'Открыть ресурс',
            handler: function() {
                var form = this.getForm();
                var values = form.getValues();
                if (values.resource_id) {
                    MODx.loadPage('resource/update', 'id=' + values.resource_id);
                }
            },
            scope: this
        }, {
            text: 'Назад к списку',
            handler: function() {
                var url = new URL(window.location.href);
                url.searchParams.delete('course_id');
                window.location.href = url.toString();
            }
        }]
    });

    Training.form.CourseGeneral.superclass.constructor.call(this, config);

    this.on('afterrender', this.loadCourse, this);
};

Ext.extend(Training.form.CourseGeneral, MODx.FormPanel, {
    loadCourse: function() {
        this.getForm().load({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/course/get',
                id: this.courseId
            }
        });
    }
});

Ext.reg('training-course-general-form', Training.form.CourseGeneral);