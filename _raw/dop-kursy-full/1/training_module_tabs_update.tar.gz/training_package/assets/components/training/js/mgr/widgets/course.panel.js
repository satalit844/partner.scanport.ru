Training.panel.Course = function(config) {
    config = config || {};

    Ext.apply(config, {
        id: 'training-panel-course',
        baseCls: 'modx-formpanel',
        layout: 'anchor',
        hideMode: 'offsets',
        items: [{
            html: '<h2>Модули курса</h2>',
            cls: '',
            style: {margin: '15px 0'}
        }, {
            xtype: 'training-grid-course-modules',
            courseId: Training.config.course_id,
            cls: 'main-wrapper',
            preventRender: true
        }]
    });

    Training.panel.Course.superclass.constructor.call(this, config);
};

Ext.extend(Training.panel.Course, MODx.Panel);
Ext.reg('training-panel-course', Training.panel.Course);