Training.panel.ModuleTabs = function(config) {
    config = config || {};

    this.moduleId = config.moduleId || Training.config.module_id;
    this.courseId = config.courseId || Training.config.course_id;

    Ext.apply(config, {
        id: 'training-module-tabs',
        border: true,
        deferredRender: false,
        defaults: {
            border: false,
            autoHeight: true
        },
        items: [{
            title: 'Общие',
            xtype: 'training-module-general-form',
            moduleId: this.moduleId,
            courseId: this.courseId
        }, {
            title: 'Видео',
            xtype: 'training-grid-module-videos',
            moduleId: this.moduleId
        }, {
            title: 'Слайды',
            xtype: 'training-grid-module-slides',
            moduleId: this.moduleId
        }]
    });

    Training.panel.ModuleTabs.superclass.constructor.call(this, config);
};

Ext.extend(Training.panel.ModuleTabs, MODx.Tabs);
Ext.reg('training-module-tabs', Training.panel.ModuleTabs);


Training.form.ModuleGeneral = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;
    this.courseId = config.courseId || Training.config.course_id;

    Ext.apply(config, {
        id: 'training-module-general-form',
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/module/update'
        },
        bodyCssClass: 'main-wrapper',
        cls: 'panel-desc',
        labelWidth: 180,
        autoHeight: true,
        defaults: {
            anchor: '100%'
        },
        items: [{
            xtype: 'hidden',
            name: 'id',
            value: this.moduleId
        }, {
            xtype: 'hidden',
            name: 'course_id',
            value: this.courseId
        }, {
            xtype: 'textfield',
            fieldLabel: 'ID модуля',
            name: 'id_label',
            readOnly: true
        }, {
            xtype: 'textfield',
            fieldLabel: 'ID курса',
            name: 'course_id_label',
            readOnly: true
        }, {
            xtype: 'textfield',
            fieldLabel: 'Курс',
            name: 'course_title',
            readOnly: true
        }, {
            xtype: 'textfield',
            fieldLabel: 'Resource ID',
            name: 'resource_id',
            readOnly: true
        }, {
            xtype: 'textfield',
            fieldLabel: 'Название модуля',
            name: 'pagetitle',
            readOnly: true
        }, {
            xtype: 'textfield',
            fieldLabel: 'Алиас',
            name: 'alias',
            readOnly: true
        }, {
            xtype: 'textfield',
            fieldLabel: 'Контекст',
            name: 'context_key',
            readOnly: true
        }, {
            xtype: 'displayfield',
            fieldLabel: 'URI',
            name: 'uri'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Опубликован',
            name: 'published_label'
        }, {
            xtype: 'xcheckbox',
            boxLabel: 'Модуль активен в training',
            hideLabel: true,
            name: 'is_active',
            inputValue: 1
        }, {
            xtype: 'xcheckbox',
            boxLabel: 'Модуль обязателен для прохождения',
            hideLabel: true,
            name: 'is_required',
            inputValue: 1
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Длительность',
            name: 'duration_human'
        }, {
            xtype: 'textfield',
            fieldLabel: 'Статус видео',
            name: 'video_status',
            readOnly: true
        }, {
            xtype: 'textfield',
            fieldLabel: 'Статус презентации',
            name: 'presentation_status',
            readOnly: true
        }, {
            xtype: 'textfield',
            fieldLabel: 'Исходное видео',
            name: 'source_video',
            readOnly: true
        }, {
            xtype: 'textfield',
            fieldLabel: 'Исходная презентация',
            name: 'source_presentation',
            readOnly: true
        }, {
            xtype: 'textfield',
            fieldLabel: 'PDF презентации',
            name: 'presentation_pdf',
            readOnly: true
        }, {
            xtype: 'textfield',
            fieldLabel: 'Папка со слайдами',
            name: 'slides_dir',
            readOnly: true
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Видеофайлов',
            name: 'videos_count'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Слайдов',
            name: 'slides_count'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Создан',
            name: 'createdon'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Обновлен',
            name: 'updatedon'
        }],
        buttons: [{
            text: 'Сохранить',
            handler: this.submit,
            scope: this
        }, {
            text: 'Открыть ресурс',
            handler: function() {
                var form = this.getForm();
                var values = form.getValues();
                if (values.resource_id) {
                    MODx.loadPage('resource/update', 'id=' + values.resource_id);
                }
            },
            scope: this
        }, {
            text: 'Назад к модулям курса',
            handler: function() {
                var form = this.getForm();
                var values = form.getValues();
                window.location.href = Training.utils.buildUrl({
                    course_id: values.course_id || this.courseId
                }, ['module_id']);
            },
            scope: this
        }, {
            text: 'Назад к курсам',
            handler: function() {
                window.location.href = Training.utils.buildUrl({}, ['course_id', 'module_id']);
            }
        }]
    });

    Training.form.ModuleGeneral.superclass.constructor.call(this, config);

    this.on('afterrender', this.loadModule, this);
};

Ext.extend(Training.form.ModuleGeneral, MODx.FormPanel, {
    loadModule: function() {
        this.getForm().load({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/module/get',
                id: this.moduleId
            }
        });
    }
});

Ext.reg('training-module-general-form', Training.form.ModuleGeneral);
