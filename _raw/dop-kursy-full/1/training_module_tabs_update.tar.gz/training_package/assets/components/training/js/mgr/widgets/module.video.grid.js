Training.grid.ModuleVideos = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;

    Ext.applyIf(config, {
        id: 'training-grid-module-videos',
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/module/videos/getlist',
            module_id: this.moduleId
        },
        fields: [
            'id',
            'module_id',
            'quality',
            'mime',
            'file_path',
            'width',
            'height',
            'bitrate',
            'filesize',
            'is_default',
            'is_active'
        ],
        paging: true,
        remoteSort: true,
        sortBy: 'id',
        sortDir: 'ASC',
        autoHeight: true,
        anchor: '100%',
        columns: [{
            header: 'ID',
            dataIndex: 'id',
            width: 60
        }, {
            header: 'Качество',
            dataIndex: 'quality',
            width: 90
        }, {
            header: 'MIME',
            dataIndex: 'mime',
            width: 100
        }, {
            header: 'Файл',
            dataIndex: 'file_path',
            width: 320,
            renderer: Training.utils.renderFileLink
        }, {
            header: 'Размер',
            dataIndex: 'filesize',
            width: 90,
            renderer: Training.utils.renderBytes
        }, {
            header: 'Разрешение',
            dataIndex: 'width',
            width: 90,
            renderer: function(value, meta, rec) {
                return (rec.data.width || 0) + '×' + (rec.data.height || 0);
            }
        }, {
            header: 'Битрейт',
            dataIndex: 'bitrate',
            width: 80
        }, {
            header: 'По умолчанию',
            dataIndex: 'is_default',
            width: 100,
            renderer: Training.utils.renderBoolean
        }, {
            header: 'Активен',
            dataIndex: 'is_active',
            width: 90,
            renderer: Training.utils.renderBoolean
        }],
        tbar: [{
            text: 'Обновить',
            handler: function() {
                this.refresh();
            },
            scope: this
        }],
        listeners: {
            rowdblclick: {
                fn: function(grid, rowIndex) {
                    var rec = grid.store.getAt(rowIndex);
                    if (rec && rec.data.file_path) {
                        window.open(Training.utils.normalizeLink(rec.data.file_path), '_blank');
                    }
                },
                scope: this
            }
        }
    });

    Training.grid.ModuleVideos.superclass.constructor.call(this, config);
};

Ext.extend(Training.grid.ModuleVideos, MODx.grid.Grid, {
    getMenu: function() {
        var rec = this.menu && this.menu.record ? this.menu.record : null;
        if (!rec || !rec.file_path && !(rec.data && rec.data.file_path)) {
            return false;
        }

        this.addContextMenuItem([{
            text: 'Открыть видео',
            handler: function() {
                var path = Training.utils.getRecordValue(rec, 'file_path');
                if (path) {
                    window.open(Training.utils.normalizeLink(path), '_blank');
                }
            },
            scope: this
        }]);
    }
});

Ext.reg('training-grid-module-videos', Training.grid.ModuleVideos);
