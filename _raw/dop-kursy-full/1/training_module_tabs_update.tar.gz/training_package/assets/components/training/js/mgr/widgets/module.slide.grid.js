Training.grid.ModuleSlides = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;

    Ext.applyIf(config, {
        id: 'training-grid-module-slides',
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/module/slides/getlist',
            module_id: this.moduleId
        },
        fields: [
            'id',
            'module_id',
            'slide_no',
            'image',
            'timecode_ms',
            'timecode_human',
            'is_active'
        ],
        paging: true,
        remoteSort: true,
        sortBy: 'slide_no',
        sortDir: 'ASC',
        autoHeight: true,
        anchor: '100%',
        columns: [{
            header: 'ID',
            dataIndex: 'id',
            width: 60
        }, {
            header: '№ слайда',
            dataIndex: 'slide_no',
            width: 80
        }, {
            header: 'Превью',
            dataIndex: 'image',
            width: 110,
            renderer: Training.utils.renderSlidePreview
        }, {
            header: 'Изображение',
            dataIndex: 'image',
            width: 300,
            renderer: Training.utils.renderFileLink
        }, {
            header: 'Таймкод',
            dataIndex: 'timecode_human',
            width: 100
        }, {
            header: 'Активен',
            dataIndex: 'is_active',
            width: 90,
            renderer: Training.utils.renderBoolean
        }],
        tbar: [{
            text: 'Обновить',
            handler: function() {
                this.refresh();
            },
            scope: this
        }],
        listeners: {
            rowdblclick: {
                fn: function(grid, rowIndex) {
                    var rec = grid.store.getAt(rowIndex);
                    if (rec && rec.data.image) {
                        window.open(Training.utils.normalizeLink(rec.data.image), '_blank');
                    }
                },
                scope: this
            }
        }
    });

    Training.grid.ModuleSlides.superclass.constructor.call(this, config);
};

Ext.extend(Training.grid.ModuleSlides, MODx.grid.Grid, {
    getMenu: function() {
        var rec = this.menu && this.menu.record ? this.menu.record : null;
        if (!rec || !rec.image && !(rec.data && rec.data.image)) {
            return false;
        }

        this.addContextMenuItem([{
            text: 'Открыть слайд',
            handler: function() {
                var image = Training.utils.getRecordValue(rec, 'image');
                if (image) {
                    window.open(Training.utils.normalizeLink(image), '_blank');
                }
            },
            scope: this
        }]);
    }
});

Ext.reg('training-grid-module-slides', Training.grid.ModuleSlides);
