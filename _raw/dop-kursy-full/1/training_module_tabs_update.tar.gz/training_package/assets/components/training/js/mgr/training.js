var Training = function(config) {
    config = config || {};
    Training.superclass.constructor.call(this, config);
};
Ext.extend(Training, Ext.Component, {});
Ext.reg('training', Training);

Training = new Training();

Training.config = Training.config || {};
Training.utils = Training.utils || {};
Training.grid = Training.grid || {};
Training.panel = Training.panel || {};
Training.page = Training.page || {};
Training.form = Training.form || {};
Training.window = Training.window || {};
Training.combo = Training.combo || {};

Training.utils.toBool = function(value) {
    return value === true || value === 1 || value === '1' || value === 'true';
};

Training.utils.getRecordValue = function(rec, key) {
    if (!rec) {
        return null;
    }

    if (rec.data && typeof rec.data[key] !== 'undefined') {
        return rec.data[key];
    }

    if (typeof rec[key] !== 'undefined') {
        return rec[key];
    }

    return null;
};

Training.utils.renderBoolean = function(value) {
    var active = Training.utils.toBool(value);

    if (active) {
        return '<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:#e6f6ea;color:#1f7a35;font-weight:600;cursor:pointer;">Да</span>';
    }

    return '<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:#f3f3f3;color:#888;font-weight:600;cursor:pointer;">Нет</span>';
};

Training.utils.escapeHtml = function(value) {
    value = value || '';
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
};

Training.utils.normalizeLink = function(value) {
    value = value || '';
    value = String(value).replace(/^\s+|\s+$/g, '');

    if (!value) {
        return '';
    }

    if (/^(https?:)?\/\//i.test(value) || value.indexOf('/') === 0) {
        return value;
    }

    return '/' + value.replace(/^\.?\//, '');
};

Training.utils.renderFileLink = function(value) {
    var url = Training.utils.normalizeLink(value);

    if (!url) {
        return '—';
    }

    return '<a href="' + Training.utils.escapeHtml(url) + '" target="_blank">' + Training.utils.escapeHtml(value) + '</a>';
};

Training.utils.renderSlidePreview = function(value) {
    var url = Training.utils.normalizeLink(value);

    if (!url) {
        return '—';
    }

    return '<a href="' + Training.utils.escapeHtml(url) + '" target="_blank"><img src="' + Training.utils.escapeHtml(url) + '" alt="" style="max-width:80px;max-height:48px;border-radius:4px;border:1px solid #ddd;display:block;margin:4px auto;" /></a>';
};

Training.utils.formatSeconds = function(value) {
    var total = parseInt(value, 10) || 0;
    var hours = Math.floor(total / 3600);
    var minutes = Math.floor((total % 3600) / 60);
    var seconds = total % 60;
    var parts = [];

    if (hours > 0) {
        parts.push(hours);
        parts.push(String(minutes).padStart(2, '0'));
    } else {
        parts.push(minutes);
    }

    parts.push(String(seconds).padStart(2, '0'));

    return parts.join(':');
};

Training.utils.formatBytes = function(value) {
    var bytes = parseInt(value, 10) || 0;
    var units = ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ'];
    var unitIndex = 0;

    if (!bytes) {
        return '0 Б';
    }

    while (bytes >= 1024 && unitIndex < units.length - 1) {
        bytes = bytes / 1024;
        unitIndex++;
    }

    return (Math.round(bytes * 100) / 100) + ' ' + units[unitIndex];
};

Training.utils.renderSeconds = function(value) {
    return Training.utils.formatSeconds(value || 0);
};

Training.utils.renderBytes = function(value) {
    return Training.utils.formatBytes(value || 0);
};

Training.utils.buildUrl = function(paramsToSet, paramsToRemove) {
    var url = new URL(window.location.href);
    var key;

    paramsToSet = paramsToSet || {};
    paramsToRemove = paramsToRemove || [];

    for (key in paramsToSet) {
        if (paramsToSet.hasOwnProperty(key)) {
            url.searchParams.set(key, paramsToSet[key]);
        }
    }

    Ext.each(paramsToRemove, function(param) {
        url.searchParams.delete(param);
    });

    return url.toString();
};
