<?php

class TrainingCourseGetProcessor extends modObjectGetProcessor
{
    public $classKey = 'TrainingCourse';
    public $objectType = 'training.course';

    public function initialize()
    {
        if (!$this->getProperty('id')) {
            return $this->modx->lexicon('invalid_data');
        }

        return parent::initialize();
    }

    public function cleanup()
    {
        $array = $this->object->toArray();

        /** @var modResource $resource */
        $resource = $this->modx->getObject('modResource', [
            'id' => $array['resource_id']
        ]);

        if ($resource) {
            $array['pagetitle'] = $resource->get('pagetitle');
            $array['alias'] = $resource->get('alias');
            $array['context_key'] = $resource->get('context_key');
            $array['uri'] = $resource->get('uri');
            $array['published'] = (int)$resource->get('published');
            $array['published_label'] = $array['published'] ? 'Да' : 'Нет';
        }

        $modulesCount = $this->modx->getCount('TrainingModule', [
            'course_id' => $array['id']
        ]);
        $array['modules_count'] = $modulesCount;

        $array['id_label'] = $array['id'];

        return $this->success('', $array);
    }
}

return 'TrainingCourseGetProcessor';