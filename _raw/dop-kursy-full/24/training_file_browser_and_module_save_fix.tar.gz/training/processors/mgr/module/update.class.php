<?php

class TrainingModuleUpdateProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    public function process()
    {
        $id = (int)$this->getProperty('id');
        if ($id <= 0) {
            return $this->failure('Не указан ID модуля');
        }

        /** @var TrainingModule $module */
        $module = $this->modx->getObject('TrainingModule', ['id' => $id]);
        if (!$module) {
            return $this->failure('Модуль не найден');
        }

        if ($this->hasProperty('course_id')) {
            $module->set('course_id', (int)$this->getProperty('course_id'));
        }

        $module->set('is_active', $this->getBooleanProperty('is_active', (bool)$module->get('is_active')) ? 1 : 0);
        $module->set('is_required', $this->getBooleanProperty('is_required', (bool)$module->get('is_required')) ? 1 : 0);

        if ($this->hasProperty('source_video')) {
            $module->set('source_video', trim((string)$this->getProperty('source_video', '')));
        }

        if ($this->hasProperty('source_presentation')) {
            $module->set('source_presentation', trim((string)$this->getProperty('source_presentation', '')));
        }

        if ($this->hasProperty('presentation_pdf')) {
            $module->set('presentation_pdf', trim((string)$this->getProperty('presentation_pdf', '')));
        }

        if ($this->hasProperty('slides_dir')) {
            $module->set('slides_dir', trim((string)$this->getProperty('slides_dir', '')));
        }

        if ($this->hasProperty('video_status')) {
            $videoStatus = trim((string)$this->getProperty('video_status', ''));
            $module->set('video_status', $videoStatus !== '' ? $videoStatus : 'none');
        }

        if ($this->hasProperty('presentation_status')) {
            $presentationStatus = trim((string)$this->getProperty('presentation_status', ''));
            $module->set('presentation_status', $presentationStatus !== '' ? $presentationStatus : 'none');
        }

        $module->set('updatedon', date('Y-m-d H:i:s'));

        if (!$module->save()) {
            return $this->failure('Не удалось сохранить модуль');
        }

        return $this->success('Модуль сохранён', $module->toArray());
    }

    protected function getBooleanProperty($key, $default = false)
    {
        if (!$this->hasProperty($key)) {
            return (bool)$default;
        }

        $value = $this->getProperty($key);
        return in_array($value, [true, 1, '1', 'true', 'yes', 'on'], true);
    }
}

return 'TrainingModuleUpdateProcessor';
