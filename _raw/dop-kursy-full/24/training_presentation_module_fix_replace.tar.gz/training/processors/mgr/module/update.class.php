<?php

class TrainingModuleUpdateProcessor extends modObjectUpdateProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    public $classKey = 'TrainingModule';
    public $objectType = 'training.module';

    public function beforeSet()
    {
        $id = (int)$this->getProperty('id');
        if (!$id) {
            return 'Не указан ID модуля';
        }

        /** @var TrainingModule $object */
        $object = $this->modx->getObject($this->classKey, ['id' => $id]);
        if (!$object) {
            return 'Модуль не найден';
        }

        $this->setProperty('is_active', $this->hasProperty('is_active') ? (int)$this->getProperty('is_active', 0) : (int)$object->get('is_active'));
        $this->setProperty('is_required', $this->hasProperty('is_required') ? (int)$this->getProperty('is_required', 0) : (int)$object->get('is_required'));
        $this->setProperty('source_video', $this->hasProperty('source_video') ? trim((string)$this->getProperty('source_video', '')) : (string)$object->get('source_video'));
        $this->setProperty('source_presentation', $this->hasProperty('source_presentation') ? trim((string)$this->getProperty('source_presentation', '')) : (string)$object->get('source_presentation'));
        $this->setProperty('presentation_pdf', $this->hasProperty('presentation_pdf') ? trim((string)$this->getProperty('presentation_pdf', '')) : (string)$object->get('presentation_pdf'));
        $this->setProperty('slides_dir', $this->hasProperty('slides_dir') ? trim((string)$this->getProperty('slides_dir', '')) : (string)$object->get('slides_dir'));

        $videoStatus = $this->hasProperty('video_status') ? trim((string)$this->getProperty('video_status', '')) : (string)$object->get('video_status');
        if ($videoStatus === '') {
            $videoStatus = 'none';
        }
        $this->setProperty('video_status', $videoStatus);

        $presentationStatus = $this->hasProperty('presentation_status') ? trim((string)$this->getProperty('presentation_status', '')) : (string)$object->get('presentation_status');
        if ($presentationStatus === '') {
            $presentationStatus = 'none';
        }
        $this->setProperty('presentation_status', $presentationStatus);

        return parent::beforeSet();
    }
}

return 'TrainingModuleUpdateProcessor';
