<?php

class TrainingModuleUpdateProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    public function process()
    {
        $id = (int)$this->getProperty('id');
        if ($id <= 0) {
            return $this->failure('Не указан ID модуля');
        }

        /** @var TrainingModule $module */
        $module = $this->modx->getObject('TrainingModule', ['id' => $id]);
        if (!$module) {
            return $this->failure('Модуль не найден');
        }

        $table = $this->modx->getTableName('TrainingModule');
        $columns = $this->getActualColumns($table);
        if (empty($columns)) {
            return $this->failure('Не удалось получить структуру таблицы модуля');
        }

        $set = [];

        if ($this->hasProperty('course_id') && in_array('course_id', $columns, true)) {
            $set['course_id'] = (int)$this->getProperty('course_id');
        }

        if (in_array('is_active', $columns, true)) {
            $set['is_active'] = $this->getBooleanProperty('is_active', (bool)$module->get('is_active')) ? 1 : 0;
        }

        if (in_array('is_required', $columns, true)) {
            $set['is_required'] = $this->getBooleanProperty('is_required', (bool)$module->get('is_required')) ? 1 : 0;
        }

        if ($this->hasProperty('source_presentation') && in_array('source_presentation', $columns, true)) {
            $set['source_presentation'] = trim((string)$this->getProperty('source_presentation', ''));
        }

        if ($this->hasProperty('presentation_status') && in_array('presentation_status', $columns, true)) {
            $presentationStatus = trim((string)$this->getProperty('presentation_status', ''));
            $set['presentation_status'] = $presentationStatus !== '' ? $presentationStatus : 'none';
        }

        if ($this->hasProperty('presentation_pdf') && in_array('presentation_pdf', $columns, true)) {
            $set['presentation_pdf'] = trim((string)$this->getProperty('presentation_pdf', ''));
        }

        if ($this->hasProperty('slides_dir') && in_array('slides_dir', $columns, true)) {
            $set['slides_dir'] = trim((string)$this->getProperty('slides_dir', ''));
        }

        if ($this->hasProperty('source_video') && in_array('source_video', $columns, true)) {
            $set['source_video'] = trim((string)$this->getProperty('source_video', ''));
        }

        if ($this->hasProperty('video_status') && in_array('video_status', $columns, true)) {
            $videoStatus = trim((string)$this->getProperty('video_status', ''));
            $set['video_status'] = $videoStatus !== '' ? $videoStatus : 'none';
        }

        if (in_array('updatedon', $columns, true)) {
            $set['updatedon'] = date('Y-m-d H:i:s');
        }

        if (empty($set)) {
            return $this->success('Нет полей для сохранения', $module->toArray());
        }

        $pairs = [];
        foreach (array_keys($set) as $column) {
            $pairs[] = '`' . $column . '` = :' . $column;
        }

        $sql = 'UPDATE `' . $table . '` SET ' . implode(', ', $pairs) . ' WHERE `id` = :id';
        $stmt = $this->modx->prepare($sql);
        if (!$stmt) {
            return $this->failure('Не удалось подготовить SQL для сохранения модуля');
        }

        foreach ($set as $column => $value) {
            $stmt->bindValue(':' . $column, $value);
        }
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);

        try {
            if (!$stmt->execute()) {
                $info = $stmt->errorInfo();
                $message = 'SQL ошибка при сохранении модуля';
                if (!empty($info[2])) {
                    $message .= ': ' . $info[2];
                }
                $this->modx->log(modX::LOG_LEVEL_ERROR, '[training] ' . $message);
                return $this->failure($message);
            }
        } catch (Exception $e) {
            $message = 'Исключение при сохранении модуля: ' . $e->getMessage();
            $this->modx->log(modX::LOG_LEVEL_ERROR, '[training] ' . $message);
            return $this->failure($message);
        }

        $module = $this->modx->getObject('TrainingModule', ['id' => $id]);

        return $this->success('Модуль сохранён', $module ? $module->toArray() : ['id' => $id]);
    }

    protected function getActualColumns($table)
    {
        $columns = [];
        $sql = 'SHOW COLUMNS FROM `' . $table . '`';
        $stmt = $this->modx->query($sql);
        if (!$stmt) {
            return $columns;
        }

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            if (!empty($row['Field'])) {
                $columns[] = $row['Field'];
            }
        }

        return $columns;
    }

    protected function getBooleanProperty($key, $default = false)
    {
        if (!$this->hasProperty($key)) {
            return (bool)$default;
        }

        $value = $this->getProperty($key);
        return in_array($value, [true, 1, '1', 'true', 'yes', 'on'], true);
    }
}

return 'TrainingModuleUpdateProcessor';
