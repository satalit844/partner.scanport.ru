var Training = function(config) {
    config = config || {};
    Training.superclass.constructor.call(this, config);
};
Ext.extend(Training, Ext.Component, {});
Ext.reg('training', Training);

Training = new Training();

Training.config = Training.config || {};
Training.utils = Training.utils || {};
Training.grid = Training.grid || {};
Training.panel = Training.panel || {};
Training.page = Training.page || {};
Training.form = Training.form || {};
Training.window = Training.window || {};
Training.combo = Training.combo || {};

Training.utils.toBool = function(value) {
    return value === true || value === 1 || value === '1' || value === 'true' || value === 'yes';
};

Training.utils.getRecordValue = function(rec, key) {
    if (!rec) {
        return null;
    }

    if (rec.data && typeof rec.data[key] !== 'undefined') {
        return rec.data[key];
    }

    if (typeof rec[key] !== 'undefined') {
        return rec[key];
    }

    return null;
};

Training.utils.renderBoolean = function(value) {
    var active = Training.utils.toBool(value);
    if (active) {
        return '<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:#e6f6ea;color:#1f7a35;font-weight:600;">Да</span>';
    }
    return '<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:#f3f3f3;color:#888;font-weight:600;">Нет</span>';
};

Training.utils.escapeHtml = function(value) {
    value = value || '';
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
};

Training.utils.normalizeLink = function(value) {
    value = value || '';
    value = String(value).replace(/^\s+|\s+$/g, '');
    if (!value) {
        return '';
    }
    if (/^(https?:)?\/\//i.test(value) || value.indexOf('/') === 0) {
        return value;
    }
    return '/' + value.replace(/^\.?\//, '');
};

Training.utils.renderFileLink = function(value) {
    var url = Training.utils.normalizeLink(value);
    if (!url || url === '—') {
        return '—';
    }
    return '<a href="' + Training.utils.escapeHtml(url) + '" target="_blank">' + Training.utils.escapeHtml(value) + '</a>';
};

Training.utils.renderSlidePreview = function(value) {
    var url = Training.utils.normalizeLink(value);
    if (!url) {
        return '—';
    }
    return '<a href="' + Training.utils.escapeHtml(url) + '" target="_blank"><img src="' + Training.utils.escapeHtml(url) + '" alt="" style="max-width:80px;max-height:48px;border-radius:4px;border:1px solid #ddd;display:block;margin:4px auto;" /></a>';
};

Training.utils.formatSeconds = function(value) {
    var total = parseInt(value, 10) || 0;
    var hours = Math.floor(total / 3600);
    var minutes = Math.floor((total % 3600) / 60);
    var seconds = total % 60;
    if (hours > 0) {
        return hours + ':' + String(minutes).padStart(2, '0') + ':' + String(seconds).padStart(2, '0');
    }
    return minutes + ':' + String(seconds).padStart(2, '0');
};

Training.utils.formatBytes = function(value) {
    var bytes = parseInt(value, 10) || 0;
    var units = ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ'];
    var unitIndex = 0;

    if (!bytes) {
        return '0 Б';
    }

    while (bytes >= 1024 && unitIndex < units.length - 1) {
        bytes = bytes / 1024;
        unitIndex++;
    }

    return (Math.round(bytes * 100) / 100) + ' ' + units[unitIndex];
};

Training.utils.renderSeconds = function(value) {
    return Training.utils.formatSeconds(value || 0);
};

Training.utils.renderBytes = function(value) {
    return Training.utils.formatBytes(value || 0);
};

Training.utils.getGridSelectionModel = function(grid) {
    if (!grid) {
        return null;
    }
    if (grid.sm) {
        return grid.sm;
    }
    if (grid.getSelectionModel) {
        return grid.getSelectionModel();
    }
    return null;
};

Training.utils.getSelectedRecords = function(grid) {
    var sm = Training.utils.getGridSelectionModel(grid);
    if (sm && sm.getSelections) {
        return sm.getSelections() || [];
    }
    if (sm && sm.getSelected) {
        var rec = sm.getSelected();
        return rec ? [rec] : [];
    }

    if (grid && typeof grid.getSelectedAsList === 'function') {
        var ids = String(grid.getSelectedAsList() || '').split(',');
        var results = [];
        Ext.each(ids, function(id) {
            id = parseInt(id, 10) || 0;
            if (id && grid.store) {
                var rec = grid.store.getById ? grid.store.getById(id) : null;
                if (!rec && grid.store.each) {
                    grid.store.each(function(item) {
                        if (!rec && parseInt(item.get('id'), 10) === id) {
                            rec = item;
                        }
                    });
                }
                if (rec) {
                    results.push(rec);
                }
            }
        });
        return results;
    }

    return [];
};

Training.utils.getSelectedIds = function(grid) {
    if (grid && typeof grid.getSelectedAsList === 'function') {
        var list = String(grid.getSelectedAsList() || '').replace(/\s+/g, '');
        if (list) {
            return Ext.pluck(Ext.filter(list.split(','), function(item) {
                return !!parseInt(item, 10);
            }), undefined) || list.split(',');
        }
    }

    var ids = [];
    Ext.each(Training.utils.getSelectedRecords(grid), function(rec) {
        var id = parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0;
        if (id) {
            ids.push(id);
        }
    });
    return ids;
};

Training.utils.setCheckboxValue = function(form, fieldName, value) {
    if (!form || !form.findField) {
        return;
    }
    var field = form.findField(fieldName);
    if (field && field.setValue) {
        field.setValue(Training.utils.toBool(value) ? 1 : 0);
    }
};

Training.utils.setFormValues = function(form, values) {
    values = values || {};
    if (!form || !form.findField) {
        return;
    }
    for (var key in values) {
        if (!values.hasOwnProperty(key)) {
            continue;
        }
        var field = form.findField(key);
        if (!field || !field.setValue) {
            continue;
        }
        field.setValue(values[key]);
    }
};

Training.utils.applyPathFromRecord = function(win, record, targetFieldName, extra) {
    if (!win || !record) {
        return;
    }
    var form = win.fp ? win.fp.getForm() : (win.getForm ? win.getForm() : null);
    if (!form) {
        return;
    }
    var path = record.data && record.data.path ? record.data.path : '';
    var targetField = form.findField(targetFieldName);
    if (targetField) {
        targetField.setValue(path || '');
    }
    if (extra && typeof extra === 'function') {
        extra(form, record);
    }
};

Training.utils.extractBrowserPath = function(data) {
    if (Ext.isArray(data) && data.length) {
        data = data[0];
    }
    if (!data) {
        return '';
    }
    if (typeof data === 'string') {
        return Training.utils.normalizeLink(data);
    }

    var keys = ['fullRelativeUrl', 'relativeUrl', 'url', 'path', 'value', 'file', 'pathname'];
    for (var i = 0; i < keys.length; i++) {
        if (data[keys[i]]) {
            return Training.utils.normalizeLink(data[keys[i]]);
        }
    }

    if (data.relativePath) {
        return Training.utils.normalizeLink(data.relativePath);
    }

    return '';
};

Training.utils.getResultData = function(action) {
    if (!action) {
        return {};
    }
    if (action.result) {
        return action.result.object || action.result.data || action.result;
    }
    if (action.object || action.data) {
        return action.object || action.data;
    }
    return action;
};

Training.utils.getSelectedRecordsFromSm = function(sm) {
    if (!sm) {
        return [];
    }
    if (sm.getSelections) {
        return sm.getSelections() || [];
    }
    if (sm.getSelected) {
        var rec = sm.getSelected();
        return rec ? [rec] : [];
    }
    return [];
};

Training.utils.getSelectedIds = function(grid) {
    var ids = [];
    Ext.each(Training.utils.getSelectedRecords(grid), function(rec) {
        var id = parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0;
        if (id) {
            ids.push(id);
        }
    });
    return ids;
};

Training.utils.getMediaSource = function(source) {
    source = parseInt(source || Training.config.media_source || MODx.config['default_media_source'] || 3, 10) || 3;
    return source;
};

Training.utils.getBrowserTreePath = function(node) {
    if (!node) {
        return '';
    }
    if (node.id == '/') {
        return '';
    }
    if (node.attributes && typeof node.attributes.path !== 'undefined') {
        return node.attributes.path + '/';
    }
    return '';
};


Training.utils._fileBrowser = Training.utils._fileBrowser || null;
Training.utils._fileBrowserId = Training.utils._fileBrowserId || null;

Training.utils.destroyFileBrowser = function(browser) {
    browser = browser || Training.utils._fileBrowser || null;
    if (!browser || browser._trainingDestroying) {
        return;
    }

    browser._trainingDestroying = true;

    try {
        if (browser.win && browser.win.hide) {
            browser.win.hide();
        }
    } catch (e) {}

    try {
        if (browser.win && browser.win.destroy) {
            browser.win.destroy();
        }
    } catch (e) {}

    try {
        if (browser.destroy) {
            browser.destroy();
        }
    } catch (e) {}

    try {
        if (browser.id) {
            var cmp = Ext.getCmp(browser.id);
            if (cmp) {
                Ext.destroy(cmp);
            }
        }
    } catch (e) {}

    try {
        if (browser.win && browser.win.id) {
            var winCmp = Ext.getCmp(browser.win.id);
            if (winCmp) {
                Ext.destroy(winCmp);
            }
        }
    } catch (e) {}

    if (Training.utils._fileBrowser === browser) {
        Training.utils._fileBrowser = null;
    }
    if (browser.id && Training.utils._fileBrowserId === browser.id) {
        Training.utils._fileBrowserId = null;
    }
};

Training.utils.destroyAllFileBrowsers = function() {
    var ids = [];

    try {
        if (Training.utils._fileBrowser && Training.utils._fileBrowser.id) {
            ids.push(Training.utils._fileBrowser.id);
        }
    } catch (e) {}

    try {
        if (Training.utils._fileBrowserId) {
            ids.push(Training.utils._fileBrowserId);
        }
    } catch (e) {}

    try {
        Ext.ComponentMgr.all.each(function(item) {
            var xtype = '';
            try {
                xtype = item.getXType ? item.getXType() : (item.xtype || '');
            } catch (e) {}

            var itemId = item && item.id ? String(item.id) : '';
            if ((xtype && xtype === 'modx-browser') || itemId.indexOf('training-file-browser-') === 0) {
                ids.push(itemId);
                try {
                    if (item.hide) {
                        item.hide();
                    }
                } catch (e) {}
                try {
                    if (item.destroy) {
                        item.destroy();
                    }
                } catch (e) {}
            }
        });
    } catch (e) {}

    ids = ids.filter(function(v, i, a) { return v && a.indexOf(v) === i; });
    Ext.each(ids, function(id) {
        try {
            var cmp = Ext.getCmp(id);
            if (cmp) {
                Ext.destroy(cmp);
            }
        } catch (e) {}
    });

    Training.utils._fileBrowser = null;
    Training.utils._fileBrowserId = null;
};

Training.utils.resetBrowserFileInputs = function(browser) {
    if (!browser || !browser.win || !browser.win.getEl) {
        return;
    }

    try {
        var el = browser.win.getEl();
        if (!el || !el.dom || !el.dom.querySelectorAll) {
            return;
        }

        var inputs = el.dom.querySelectorAll('input[type="file"]');
        for (var i = 0; i < inputs.length; i++) {
            try {
                inputs[i].value = '';
            } catch (e) {}
        }
    } catch (e) {}
};

Training.utils.openFileBrowser = function(config) {
    config = config || {};

    var source = Training.utils.getMediaSource(config.source);
    var browserId = 'training-file-browser-' + Ext.id();

    Training.utils.destroyAllFileBrowsers();

    var browser = MODx.load({
        xtype: 'modx-browser',
        id: browserId,
        source: source,
        multiple: false,
        hideSourceCombo: true,
        hideFiles: false,
        rootVisible: false,
        allowedFileTypes: config.allowedFileTypes || '',
        wctx: config.wctx || MODx.config['default_context'] || 'web',
        openTo: config.openTo || '',
        rootId: config.rootId || '/',
        listeners: {
            select: {
                fn: function(data) {
                    var path = Training.utils.extractBrowserPath(data);
                    if (path && typeof config.onSelect === 'function') {
                        config.onSelect.call(config.scope || this, path, data);
                    }

                    Training.utils.resetBrowserFileInputs(browser);

                    try {
                        if (browser && browser.hide) {
                            browser.hide();
                        } else if (browser && browser.win && browser.win.hide) {
                            browser.win.hide();
                        }
                    } catch (e) {}

                    Training.utils._fileBrowser = null;
                    Training.utils._fileBrowserId = null;
                },
                scope: config.scope || this
            }
        }
    });

    if (!browser) {
        MODx.msg.alert('Ошибка', 'Не удалось открыть браузер файлов MODX');
        return null;
    }

    Training.utils._fileBrowser = browser;
    Training.utils._fileBrowserId = browserId;

    if (browser.win) {
        browser.win.closeAction = 'close';

        if (browser.win.on) {
            browser.win.on('show', function() {
                Training.utils.resetBrowserFileInputs(browser);
            });
            browser.win.on('hide', function() {
                Training.utils.resetBrowserFileInputs(browser);
                Training.utils._fileBrowser = null;
                Training.utils._fileBrowserId = null;
            });
            browser.win.on('close', function() {
                Training.utils.resetBrowserFileInputs(browser);
                Training.utils._fileBrowser = null;
                Training.utils._fileBrowserId = null;
            });
        }
    }

    try {
        if (browser.show) {
            browser.show();
        } else if (browser.win && browser.win.show) {
            browser.win.show();
        }

        if (browser.win && browser.win.toFront) {
            browser.win.toFront();
        }

        return browser;
    } catch (e) {
        Training.utils.destroyFileBrowser(browser);
        MODx.msg.alert('Ошибка', 'Не удалось открыть браузер файлов MODX');
        return null;
    }
};

Training.utils.getAllowedFileTypesForField = function(fieldName) {
    fieldName = String(fieldName || '').toLowerCase();
    if (fieldName.indexOf('presentation') !== -1) {
        return 'ppt,pptx,pdf';
    }
    if (fieldName === 'source_video' || fieldName === 'file_path') {
        return 'mkv,mp4,m3u8,mov,avi,webm';
    }
    if (fieldName === 'image') {
        return 'jpg,jpeg,png,webp,gif';
    }
    return '';
};

Training.utils.openPathBrowser = function(field, cfg) {
    cfg = cfg || {};
    if (!field) {
        return false;
    }
    var fieldName = field.name || cfg.fieldName || '';
    return Training.utils.openFileBrowser({
        source: cfg.source || Training.config.media_source || 3,
        allowedFileTypes: cfg.allowedFileTypes || Training.utils.getAllowedFileTypesForField(fieldName),
        openTo: cfg.openTo || '',
        scope: cfg.scope || field,
        onSelect: function(path, data) {
            if (field.setValue) {
                field.setValue(path || '');
            }
            if (typeof cfg.onSelect === 'function') {
                cfg.onSelect.call(cfg.scope || field, path, data, field);
            }
        }
    });
};

Training.utils.buildUrl = function(paramsToSet, paramsToRemove) {

    var url = new URL(window.location.href);
    paramsToSet = paramsToSet || {};
    paramsToRemove = paramsToRemove || [];

    for (var key in paramsToSet) {
        if (paramsToSet.hasOwnProperty(key)) {
            url.searchParams.set(key, paramsToSet[key]);
        }
    }

    Ext.each(paramsToRemove, function(param) {
        url.searchParams.delete(param);
    });

    return url.toString();
};
