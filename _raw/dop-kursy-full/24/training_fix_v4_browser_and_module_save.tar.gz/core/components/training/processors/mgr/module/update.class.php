<?php

class TrainingModuleUpdateProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    public function process()
    {
        $id = (int)$this->getProperty('id');
        if ($id <= 0) {
            return $this->failure('Не указан ID модуля');
        }

        /** @var TrainingModule $module */
        $module = $this->modx->getObject('TrainingModule', ['id' => $id]);
        if (!$module) {
            return $this->failure('Модуль не найден');
        }

        $table = $this->modx->getTableName('TrainingModule');
        if (!$table) {
            return $this->failure('Не удалось определить таблицу модуля');
        }

        $data = [];

        if ($this->hasProperty('course_id')) {
            $data['course_id'] = (int)$this->getProperty('course_id');
        }

        if ($this->hasProperty('is_active')) {
            $data['is_active'] = $this->getBooleanProperty('is_active', (bool)$module->get('is_active')) ? 1 : 0;
        }

        if ($this->hasProperty('is_required')) {
            $data['is_required'] = $this->getBooleanProperty('is_required', (bool)$module->get('is_required')) ? 1 : 0;
        }

        if ($this->hasProperty('source_video')) {
            $data['source_video'] = trim((string)$this->getProperty('source_video', ''));
        }

        if ($this->hasProperty('source_presentation')) {
            $data['source_presentation'] = trim((string)$this->getProperty('source_presentation', ''));
        }

        if ($this->hasProperty('presentation_pdf')) {
            $data['presentation_pdf'] = trim((string)$this->getProperty('presentation_pdf', ''));
        }

        if ($this->hasProperty('slides_dir')) {
            $data['slides_dir'] = trim((string)$this->getProperty('slides_dir', ''));
        }

        if ($this->hasProperty('video_status')) {
            $videoStatus = trim((string)$this->getProperty('video_status', ''));
            $data['video_status'] = $videoStatus !== '' ? $videoStatus : 'none';
        }

        if ($this->hasProperty('presentation_status')) {
            $presentationStatus = trim((string)$this->getProperty('presentation_status', ''));
            $data['presentation_status'] = $presentationStatus !== '' ? $presentationStatus : 'none';
        }

        $data['updatedon'] = date('Y-m-d H:i:s');

        $set = [];
        $params = [':id' => $id];
        foreach ($data as $field => $value) {
            $set[] = "`{$field}` = :{$field}";
            $params[':' . $field] = $value;
        }

        if (!$set) {
            return $this->success('Модуль сохранён', $module->toArray());
        }

        $sql = "UPDATE {$table} SET " . implode(', ', $set) . " WHERE `id` = :id LIMIT 1";
        $stmt = $this->modx->prepare($sql);
        if (!$stmt) {
            return $this->failure('Не удалось подготовить сохранение модуля');
        }

        if (!$stmt->execute($params)) {
            $error = $stmt->errorInfo();
            $message = 'Не удалось сохранить модуль';
            if (!empty($error[2])) {
                $message .= ': ' . $error[2];
            }
            return $this->failure($message);
        }

        $module = $this->modx->getObject('TrainingModule', ['id' => $id]);
        return $this->success('Модуль сохранён', $module ? $module->toArray() : ['id' => $id]);
    }

    protected function getBooleanProperty($key, $default = false)
    {
        if (!$this->hasProperty($key)) {
            return (bool)$default;
        }

        $value = $this->getProperty($key);
        return in_array($value, [true, 1, '1', 'true', 'yes', 'on'], true);
    }
}

return 'TrainingModuleUpdateProcessor';
