<?php

class TrainingModuleUpdateProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    public function process()
    {
        $id = (int)$this->getProperty('id');
        if ($id <= 0) {
            return $this->failure('Не указан ID модуля');
        }

        $table = $this->resolveModuleTableName();
        if ($table === '') {
            return $this->failure('Не найдена таблица модулей');
        }

        if (!$this->moduleExists($table, $id)) {
            return $this->failure('Модуль не найден');
        }

        $data = [];

        if ($this->hasProperty('course_id')) {
            $data['course_id'] = (int)$this->getProperty('course_id');
        }

        if ($this->hasProperty('is_active')) {
            $data['is_active'] = $this->getBooleanProperty('is_active', true) ? 1 : 0;
        }

        if ($this->hasProperty('is_required')) {
            $data['is_required'] = $this->getBooleanProperty('is_required', true) ? 1 : 0;
        }

        if ($this->hasProperty('source_video')) {
            $data['source_video'] = trim((string)$this->getProperty('source_video', ''));
        }

        if ($this->hasProperty('source_presentation')) {
            $data['source_presentation'] = trim((string)$this->getProperty('source_presentation', ''));
        }

        if ($this->hasProperty('presentation_pdf')) {
            $data['presentation_pdf'] = trim((string)$this->getProperty('presentation_pdf', ''));
        }

        if ($this->hasProperty('slides_dir')) {
            $data['slides_dir'] = trim((string)$this->getProperty('slides_dir', ''));
        }

        if ($this->hasProperty('video_status')) {
            $videoStatus = trim((string)$this->getProperty('video_status', ''));
            $data['video_status'] = $videoStatus !== '' ? $videoStatus : 'none';
        }

        if ($this->hasProperty('presentation_status')) {
            $presentationStatus = trim((string)$this->getProperty('presentation_status', ''));
            $data['presentation_status'] = $presentationStatus !== '' ? $presentationStatus : 'none';
        }

        $data['updatedon'] = date('Y-m-d H:i:s');

        if (empty($data)) {
            return $this->success('Нет изменений', ['id' => $id]);
        }

        if (!$this->updateModuleRow($table, $id, $data)) {
            return $this->failure('Не удалось сохранить модуль');
        }

        return $this->success('Модуль сохранён', ['id' => $id]);
    }

    protected function updateModuleRow($table, $id, array $data)
    {
        $set = [];
        $bindings = [];

        foreach ($data as $field => $value) {
            $set[] = "`{$field}` = :{$field}";
            $bindings[':' . $field] = $value;
        }

        $bindings[':id'] = (int)$id;

        $sql = "UPDATE {$table} SET " . implode(', ', $set) . " WHERE `id` = :id LIMIT 1";
        $stmt = $this->modx->prepare($sql);

        if (!$stmt) {
            $this->modx->log(modX::LOG_LEVEL_ERROR, '[training] module update prepare failed: ' . $sql);
            return false;
        }

        $result = $stmt->execute($bindings);
        if (!$result) {
            $error = $stmt->errorInfo();
            $this->modx->log(modX::LOG_LEVEL_ERROR, '[training] module update execute failed: ' . print_r($error, true));
            return false;
        }

        return true;
    }

    protected function moduleExists($table, $id)
    {
        $stmt = $this->modx->prepare("SELECT `id` FROM {$table} WHERE `id` = :id LIMIT 1");
        if (!$stmt) {
            return false;
        }

        if (!$stmt->execute([':id' => (int)$id])) {
            return false;
        }

        return (bool)$stmt->fetch(PDO::FETCH_ASSOC);
    }

    protected function resolveModuleTableName()
    {
        $prefix = (string)$this->modx->getOption('table_prefix', null, 'modx_');
        $candidates = [];

        $modelTable = '';
        try {
            $modelTable = (string)$this->modx->getTableName('TrainingModule');
        } catch (Exception $e) {
            $modelTable = '';
        }

        if ($modelTable !== '') {
            $candidates[] = $modelTable;
        }

        $candidates[] = $prefix . 'partnerstraining_modules';
        $candidates[] = $prefix . 'training_modules';

        $candidates = array_values(array_unique(array_filter($candidates)));

        foreach ($candidates as $table) {
            if ($this->tableExists($table)) {
                return $table;
            }
        }

        return '';
    }

    protected function tableExists($table)
    {
        $stmt = $this->modx->prepare('SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table LIMIT 1');
        if (!$stmt) {
            return false;
        }

        if (!$stmt->execute([':table' => $table])) {
            return false;
        }

        return (bool)$stmt->fetchColumn();
    }

    protected function getBooleanProperty($key, $default = false)
    {
        if (!$this->hasProperty($key)) {
            return (bool)$default;
        }

        $value = $this->getProperty($key);
        return in_array($value, [true, 1, '1', 'true', 'yes', 'on'], true);
    }
}

return 'TrainingModuleUpdateProcessor';
