<?php

class TrainingModuleUpdateProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    public function process()
    {
        try {
            $id = (int)$this->getProperty('id');
            if ($id <= 0) {
                return $this->failure('Не указан ID модуля');
            }

            $table = $this->modx->getTableName('TrainingModule');
            if (!$table) {
                return $this->failure('Не удалось определить таблицу модулей');
            }

            $module = $this->modx->getObject('TrainingModule', ['id' => $id]);
            if (!$module) {
                return $this->failure('Модуль не найден');
            }

            $existingColumns = $this->getTableColumns($table);
            if (empty($existingColumns)) {
                return $this->failure('Не удалось получить структуру таблицы модулей');
            }

            $current = $this->fetchCurrentRow($table, $id);
            if (!$current) {
                return $this->failure('Не удалось загрузить текущие данные модуля');
            }

            $data = [];

            if (isset($existingColumns['course_id'])) {
                $data['course_id'] = $this->hasProperty('course_id')
                    ? (int)$this->getProperty('course_id')
                    : (int)$current['course_id'];
            }

            if (isset($existingColumns['is_active'])) {
                $data['is_active'] = $this->hasProperty('is_active')
                    ? ($this->toBool($this->getProperty('is_active')) ? 1 : 0)
                    : (int)$current['is_active'];
            }

            if (isset($existingColumns['is_required'])) {
                $data['is_required'] = $this->hasProperty('is_required')
                    ? ($this->toBool($this->getProperty('is_required')) ? 1 : 0)
                    : (int)$current['is_required'];
            }

            if (isset($existingColumns['source_video'])) {
                $data['source_video'] = $this->hasProperty('source_video')
                    ? trim((string)$this->getProperty('source_video', ''))
                    : (string)$current['source_video'];
            }

            if (isset($existingColumns['source_presentation'])) {
                $data['source_presentation'] = $this->hasProperty('source_presentation')
                    ? trim((string)$this->getProperty('source_presentation', ''))
                    : (string)$current['source_presentation'];
            }

            if (isset($existingColumns['presentation_pdf'])) {
                $data['presentation_pdf'] = $this->hasProperty('presentation_pdf')
                    ? trim((string)$this->getProperty('presentation_pdf', ''))
                    : (string)$current['presentation_pdf'];
            }

            if (isset($existingColumns['slides_dir'])) {
                $data['slides_dir'] = $this->hasProperty('slides_dir')
                    ? trim((string)$this->getProperty('slides_dir', ''))
                    : (string)$current['slides_dir'];
            }

            if (isset($existingColumns['video_status'])) {
                $videoStatus = $this->hasProperty('video_status')
                    ? trim((string)$this->getProperty('video_status', ''))
                    : (string)$current['video_status'];
                $data['video_status'] = $videoStatus !== '' ? $videoStatus : 'none';
            }

            if (isset($existingColumns['presentation_status'])) {
                $presentationStatus = $this->hasProperty('presentation_status')
                    ? trim((string)$this->getProperty('presentation_status', ''))
                    : (string)$current['presentation_status'];
                $data['presentation_status'] = $presentationStatus !== '' ? $presentationStatus : 'none';
            }

            if (isset($existingColumns['updatedon'])) {
                $data['updatedon'] = date('Y-m-d H:i:s');
            }

            if (empty($data)) {
                return $this->success('Нет полей для обновления', ['id' => $id]);
            }

            $set = [];
            $params = [':id' => $id];
            foreach ($data as $field => $value) {
                $set[] = "`{$field}` = :{$field}";
                $params[':' . $field] = $value;
            }

            $sql = "UPDATE {$table} SET " . implode(', ', $set) . " WHERE `id` = :id LIMIT 1";
            $stmt = $this->modx->prepare($sql);
            if (!$stmt) {
                return $this->failure('Не удалось подготовить SQL для сохранения модуля');
            }

            if (!$stmt->execute($params)) {
                $errorInfo = $stmt->errorInfo();
                $message = !empty($errorInfo[2]) ? $errorInfo[2] : 'SQL execute error';
                $this->modx->log(modX::LOG_LEVEL_ERROR, '[training] module/update SQL error: ' . $message);
                return $this->failure('Ошибка сохранения модуля: ' . $message);
            }

            $module = $this->modx->getObject('TrainingModule', ['id' => $id]);
            return $this->success('Модуль сохранён', $module ? $module->toArray() : ['id' => $id]);
        } catch (Throwable $e) {
            $this->modx->log(modX::LOG_LEVEL_ERROR, '[training] module/update fatal: ' . $e->getMessage() . "\n" . $e->getTraceAsString());
            return $this->failure('Ошибка сохранения модуля: ' . $e->getMessage());
        } catch (Exception $e) {
            $this->modx->log(modX::LOG_LEVEL_ERROR, '[training] module/update fatal: ' . $e->getMessage() . "\n" . $e->getTraceAsString());
            return $this->failure('Ошибка сохранения модуля: ' . $e->getMessage());
        }
    }

    protected function getTableColumns($table)
    {
        $columns = [];
        $stmt = $this->modx->prepare('SHOW COLUMNS FROM ' . $table);
        if (!$stmt || !$stmt->execute()) {
            return $columns;
        }

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            if (!empty($row['Field'])) {
                $columns[$row['Field']] = true;
            }
        }

        return $columns;
    }

    protected function fetchCurrentRow($table, $id)
    {
        $stmt = $this->modx->prepare('SELECT * FROM ' . $table . ' WHERE `id` = :id LIMIT 1');
        if (!$stmt || !$stmt->execute([':id' => (int)$id])) {
            return null;
        }

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return is_array($row) ? $row : null;
    }

    protected function toBool($value)
    {
        return in_array($value, [true, 1, '1', 'true', 'yes', 'on'], true);
    }
}

return 'TrainingModuleUpdateProcessor';
