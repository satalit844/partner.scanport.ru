Training.panel.CourseTabs = function(config) {
    config = config || {};
    this.courseId = config.courseId || Training.config.course_id;

    Ext.apply(config, {
        id: 'training-course-tabs',
        border: true,
        deferredRender: false,
        defaults: {border: false, autoHeight: true},
        items: [{
            title: 'Общие',
            xtype: 'training-course-general-form',
            courseId: this.courseId
        }, {
            title: 'Модули',
            xtype: 'training-grid-course-modules',
            courseId: this.courseId
        }]
    });

    Training.panel.CourseTabs.superclass.constructor.call(this, config);
};
Ext.extend(Training.panel.CourseTabs, MODx.Tabs);
Ext.reg('training-course-tabs', Training.panel.CourseTabs);

Training.form.CourseGeneral = function(config) {
    config = config || {};
    this.courseId = config.courseId || Training.config.course_id;

    Ext.apply(config, {
        id: 'training-course-general-form',
        url: Training.config.connector_url,
        baseParams: {action: 'mgr/course/update'},
        bodyCssClass: 'main-wrapper',
        cls: 'container',
        labelWidth: 190,
        autoHeight: true,
        border: false,
        bodyStyle: 'padding:18px;background:#fff;border:1px solid #e5e5e5;border-radius:6px;',
        defaults: {anchor: '100%'},
        items: [{
            html: '<div style="padding:0 0 16px;color:#666;line-height:1.6;">На уровне курса храним исходную презентацию, PDF и разобранные слайды. Сначала выбираем файл презентации, затем запускаем разбор в PDF и JPG-слайды.</div>',
            border: false
        }, {
            xtype: 'hidden',
            name: 'id',
            value: this.courseId
        }, {
            xtype: 'fieldset',
            title: 'Основное',
            autoHeight: true,
            defaults: {anchor: '100%'},
            items: [{xtype: 'displayfield', fieldLabel: 'ID курса', name: 'id_label'},
                {xtype: 'displayfield', fieldLabel: 'Resource ID', name: 'resource_id'},
                {xtype: 'displayfield', fieldLabel: 'Название', name: 'pagetitle'},
                {xtype: 'displayfield', fieldLabel: 'Алиас', name: 'alias'},
                {xtype: 'displayfield', fieldLabel: 'Контекст', name: 'context_key'},
                {xtype: 'displayfield', fieldLabel: 'URI', name: 'uri'},
                {xtype: 'displayfield', fieldLabel: 'Опубликован ресурс', name: 'published_label'},
                {xtype: 'displayfield', fieldLabel: 'Модулей', name: 'modules_count'},
                {xtype: 'xcheckbox', boxLabel: 'Курс активен', hideLabel: true, name: 'is_active', inputValue: 1, checked: true}
            ]
        }, {
            xtype: 'fieldset',
            title: 'Презентация и слайды',
            autoHeight: true,
            defaults: {anchor: '100%'},
            items: [{
                xtype: 'trigger',
                fieldLabel: 'Выбрать файл с сервера',
                name: 'source_presentation_browser',
                anchor: '100%',
                editable: false,
                emptyText: 'Открыть стандартный браузер файлов MODX',
                triggerClass: 'x-form-search-trigger',
                onTriggerClick: function() {
                    var browserField = this;
                    var form = browserField.findParentByType('form').getForm();
                    Training.utils.openPathBrowser(browserField, {
                        allowedFileTypes: 'ppt,pptx,pdf',
                        openTo: form.findField('source_presentation').getValue() || '/assets/uploads/training/',
                        onSelect: function(path) {
                            browserField.setValue(path);
                            var target = form.findField('source_presentation');
                            if (target) {
                                target.setValue(path);
                            }
                        }
                    });
                }
            }, {
                xtype: 'trigger',
                fieldLabel: 'Исходный PPT/PPTX/PDF',
                name: 'source_presentation',
                anchor: '100%',
                emptyText: '/assets/uploads/training/course-1/source.pptx',
                triggerClass: 'x-form-search-trigger',
                onTriggerClick: function() {
                    var field = this;
                    Training.utils.openPathBrowser(field, {
                        allowedFileTypes: 'ppt,pptx,pdf',
                        openTo: field.getValue() || '/assets/uploads/training/'
                    });
                }
            },
            {xtype: 'displayfield', fieldLabel: 'Статус презентации', name: 'presentation_status'},
            {xtype: 'displayfield', fieldLabel: 'PDF', name: 'presentation_pdf'},
            {xtype: 'displayfield', fieldLabel: 'Папка слайдов', name: 'slides_dir'},
            {xtype: 'displayfield', fieldLabel: 'Папка найдена', name: 'slides_dir_exists_label'},
            {xtype: 'displayfield', fieldLabel: 'Слайдов в папке', name: 'available_slides_count'}]
        }],
        buttons: [{text: 'Сохранить', handler: this.saveForm, scope: this},
            {text: 'Разобрать PPTX в слайды', handler: this.processPresentation, scope: this},
            {text: 'Открыть ресурс', handler: function() {
                var values = this.getForm().getValues();
                if (values.resource_id) {
                    MODx.loadPage('resource/update', 'id=' + values.resource_id);
                }
            }, scope: this},
            {text: 'Назад к списку', handler: function() {
                window.location.href = Training.utils.buildUrl({}, ['course_id', 'module_id']);
            }}]
    });

    Training.form.CourseGeneral.superclass.constructor.call(this, config);
    this.on('afterrender', this.loadCourse, this);
};

Ext.extend(Training.form.CourseGeneral, MODx.FormPanel, {
    applyCourseData: function(obj) {
        obj = obj || {};
        var form = this.getForm();
        Training.utils.setFormValues(form, obj);
        Training.utils.setCheckboxValue(form, 'is_active', obj.is_active);
        var browser = form.findField('source_presentation_browser');
        if (browser) {
            browser.setValue(obj.source_presentation || '');
        }
    },

    loadCourse: function() {
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {action: 'mgr/course/get', id: this.courseId},
            listeners: {
                success: {fn: function(r) {
                    this.applyCourseData(Training.utils.getResultData(r));
                }, scope: this},
                failure: {fn: function(r) {
                    MODx.msg.alert('Ошибка', r && r.message ? r.message : 'Не удалось загрузить карточку курса');
                }, scope: this}
            }
        });
    },

    saveForm: function() {
        var form = this.getForm();
        if (!form.isValid()) {
            return false;
        }
        this.getEl().mask('Сохраняем курс...');
        form.submit({
            url: Training.config.connector_url,
            params: {action: 'mgr/course/update'},
            success: function(fp, action) {
                this.getEl().unmask();
                this.applyCourseData(Training.utils.getResultData(action));
                this.loadCourse();
                MODx.msg.alert('Готово', 'Курс сохранён');
            },
            failure: function(fp, action) {
                this.getEl().unmask();
                MODx.msg.alert('Ошибка', action && action.result && action.result.message ? action.result.message : 'Не удалось сохранить курс');
            },
            scope: this
        });
    },

    processPresentation: function() {
        var values = this.getForm().getValues();
        this.getEl().mask('Обрабатываем презентацию...');
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/course/presentation/process',
                course_id: this.courseId,
                source_presentation: values.source_presentation || ''
            },
            listeners: {
                success: {fn: function(r) {
                    this.getEl().unmask();
                    this.loadCourse();
                    var data = Training.utils.getResultData(r);
                    var message = 'Презентация обработана';
                    if (typeof data.slides_count !== 'undefined') {
                        message += '. Слайдов: ' + data.slides_count;
                    }
                    MODx.msg.alert('Готово', message);
                }, scope: this},
                failure: {fn: function(r) {
                    this.getEl().unmask();
                    MODx.msg.alert('Ошибка', r && r.message ? r.message : 'Не удалось обработать презентацию');
                }, scope: this}
            }
        });
    }
});
Ext.reg('training-course-general-form', Training.form.CourseGeneral);
