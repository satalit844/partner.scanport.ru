Training.grid.ModuleVideos = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;
    this.sm = new Ext.grid.CheckboxSelectionModel();

    Ext.applyIf(config, {
        id: 'training-grid-module-videos',
        url: Training.config.connector_url,
        baseParams: {action: 'mgr/module/videos/getlist', module_id: this.moduleId},
        sm: this.sm,
        fields: ['id', 'module_id', 'quality', 'mime', 'file_path', 'width', 'height', 'bitrate', 'filesize', 'is_default', 'is_active'],
        paging: true,
        remoteSort: true,
        sortBy: 'id',
        sortDir: 'ASC',
        autoHeight: true,
        anchor: '100%',
        save_action: 'mgr/module/video/update',
        columns: [this.sm,
            {header: 'ID', dataIndex: 'id', width: 60},
            {header: 'Качество', dataIndex: 'quality', width: 90},
            {header: 'MIME', dataIndex: 'mime', width: 140},
            {header: 'Файл', dataIndex: 'file_path', width: 360, renderer: Training.utils.renderFileLink},
            {header: 'Размер', dataIndex: 'filesize', width: 100, renderer: Training.utils.renderBytes},
            {header: 'Разрешение', dataIndex: 'width', width: 110, renderer: function(value, meta, rec) { return (rec.data.width || 0) + '×' + (rec.data.height || 0); }},
            {header: 'Битрейт', dataIndex: 'bitrate', width: 80},
            {header: 'По умолчанию', dataIndex: 'is_default', width: 110, renderer: Training.utils.renderBoolean},
            {header: 'Активен', dataIndex: 'is_active', width: 90, renderer: Training.utils.renderBoolean}
        ],
        tbar: [{text: 'Сгенерировать из исходника', handler: this.transcodeFromSource, scope: this}, '-',
            {text: 'Добавить видео', handler: this.createVideo, scope: this}, '-',
            {text: 'Изменить', handler: this.updateVideo, scope: this},
            {text: 'Удалить', handler: this.removeVideo, scope: this}, '->',
            {text: 'Обновить', handler: function() { this.refresh(); }, scope: this}],
        listeners: {
            rowdblclick: {fn: function(grid, rowIndex) { var rec = grid.store.getAt(rowIndex); if (rec) { this.updateVideo(rec); } }, scope: this}
        }
    });

    Training.grid.ModuleVideos.superclass.constructor.call(this, config);
};

Ext.extend(Training.grid.ModuleVideos, MODx.grid.Grid, {
    getSelectedVideoRecords: function() {
        return this.sm && this.sm.getSelections ? this.sm.getSelections() : [];
    },

    getSingleSelectedVideo: function() {
        var records = this.getSelectedVideoRecords();
        return records.length ? records[0] : null;
    },

    transcodeFromSource: function() {
        var formPanel = Ext.getCmp('training-module-general-form');
        var values = formPanel ? formPanel.getForm().getValues() : {};
        this.getEl().mask('Генерируем видео...');
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {action: 'mgr/module/video/transcode', module_id: this.moduleId, source_video: values.source_video || ''},
            listeners: {
                success: {fn: function(r) {
                    this.getEl().unmask();
                    this.refresh();
                    if (formPanel && formPanel.loadModule) { formPanel.loadModule(); }
                    var slidesGrid = Ext.getCmp('training-grid-module-slides');
                    if (slidesGrid) { slidesGrid.refresh(); }
                    MODx.msg.alert('Готово', 'Варианты видео созданы');
                }, scope: this},
                failure: {fn: function(r) {
                    this.getEl().unmask();
                    MODx.msg.alert('Ошибка', r && r.message ? r.message : 'Не удалось обработать видео');
                }, scope: this}
            }
        });
    },

    createVideo: function() {
        var w = MODx.load({
            xtype: 'training-window-module-video',
            title: 'Добавить видео',
            baseParams: {action: 'mgr/module/video/create'},
            moduleId: this.moduleId,
            listeners: {success: {fn: function() { this.refresh(); }, scope: this}}
        });
        w.show();
        w.reset();
        w.setValues({module_id: this.moduleId, is_default: 0, is_active: 1, mime: 'video/mp4'});
    },

    updateVideo: function(rec) {
        rec = rec || this.menu.record || this.getSingleSelectedVideo();
        if (!rec) {
            MODx.msg.alert('Внимание', 'Выбери одно видео для редактирования');
            return false;
        }
        var w = MODx.load({
            xtype: 'training-window-module-video',
            title: 'Изменить видео',
            baseParams: {action: 'mgr/module/video/update'},
            moduleId: this.moduleId,
            listeners: {success: {fn: function() { this.refresh(); }, scope: this}}
        });
        w.show();
        w.reset();
        w.setValues(rec.data || rec);
    },

    removeVideo: function(rec) {
        var ids = [];
        if (rec) {
            ids = [parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0];
        } else if (this.menu && this.menu.record) {
            ids = [parseInt(Training.utils.getRecordValue(this.menu.record, 'id'), 10) || 0];
        } else {
            Ext.each(this.getSelectedVideoRecords(), function(item) {
                var id = parseInt(Training.utils.getRecordValue(item, 'id'), 10) || 0;
                if (id) { ids.push(id); }
            });
        }
        ids = Training.utils.uniqueInts(ids);
        if (!ids.length) {
            MODx.msg.alert('Внимание', 'Выбери видео для удаления');
            return false;
        }
        MODx.msg.confirm({
            title: 'Удаление',
            text: ids.length > 1 ? 'Удалить выбранные видео?' : 'Удалить привязку видео?',
            url: Training.config.connector_url,
            params: {action: 'mgr/module/video/remove', ids: ids.join(',')},
            listeners: {success: {fn: function() { this.refresh(); }, scope: this}}
        });
    },

    getMenu: function() {
        var rec = this.menu && this.menu.record ? this.menu.record : null;
        if (!rec) { return false; }
        this.addContextMenuItem([{text: 'Изменить', handler: function() { this.updateVideo(rec); }, scope: this},
            {text: 'Удалить', handler: function() { this.removeVideo(rec); }, scope: this}, '-',
            {text: 'Открыть видео', handler: function() {
                var path = Training.utils.getRecordValue(rec, 'file_path');
                if (path) { window.open(Training.utils.normalizeLink(path), '_blank'); }
            }, scope: this}]);
    }
});
Ext.reg('training-grid-module-videos', Training.grid.ModuleVideos);

Training.window.ModuleVideo = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;

    Ext.applyIf(config, {
        width: 760,
        autoHeight: true,
        url: Training.config.connector_url,
        fields: [{xtype: 'hidden', name: 'id'},
            {xtype: 'hidden', name: 'module_id', value: this.moduleId},
            {
                xtype: 'trigger',
                fieldLabel: 'Файл на сервере',
                name: 'file_selector',
                anchor: '100%',
                editable: false,
                emptyText: 'Открыть стандартный браузер файлов MODX',
                triggerClass: 'x-form-search-trigger',
                onTriggerClick: function() {
                    var browserField = this;
                    var form = browserField.findParentByType('window').fp.getForm();
                    Training.utils.openPathBrowser(browserField, {
                        allowedFileTypes: 'mkv,mp4,mov,avi,m4v,webm,m3u8',
                        openTo: form.findField('file_path').getValue() || '/assets/training/courses/',
                        onSelect: function(path) {
                            browserField.setValue(path);
                            var fileField = form.findField('file_path');
                            if (fileField) { fileField.setValue(path); }
                            var mimeField = form.findField('mime');
                            if (mimeField) { mimeField.setValue(/\.m3u8$/i.test(path) ? 'application/vnd.apple.mpegurl' : 'video/mp4'); }
                            var qualityField = form.findField('quality');
                            if (qualityField && !qualityField.getValue()) {
                                var m = String(path).match(/(1080p|720p|480p|320p|hls)/i);
                                if (m) { qualityField.setValue(m[1]); }
                            }
                        }
                    });
                }
            },
            {xtype: 'textfield', fieldLabel: 'Качество', name: 'quality', anchor: '100%', allowBlank: false, emptyText: '1080p / 720p / 480p / 320p / hls'},
            {
                xtype: 'trigger',
                fieldLabel: 'Путь к файлу',
                name: 'file_path',
                anchor: '100%',
                allowBlank: false,
                emptyText: '/assets/training/...',
                triggerClass: 'x-form-search-trigger',
                onTriggerClick: function() {
                    var field = this;
                    Training.utils.openPathBrowser(field, {
                        allowedFileTypes: 'mkv,mp4,mov,avi,m4v,webm,m3u8',
                        openTo: field.getValue() || '/assets/training/courses/'
                    });
                }
            },
            {xtype: 'textfield', fieldLabel: 'MIME', name: 'mime', anchor: '100%', value: 'video/mp4'},
            {
                layout: 'column', border: false, defaults: {layout: 'form', border: false, labelAlign: 'top'}, items: [
                    {columnWidth: .25, items: [{xtype: 'numberfield', fieldLabel: 'Ширина', name: 'width', anchor: '95%'}]},
                    {columnWidth: .25, items: [{xtype: 'numberfield', fieldLabel: 'Высота', name: 'height', anchor: '95%'}]},
                    {columnWidth: .25, items: [{xtype: 'numberfield', fieldLabel: 'Битрейт', name: 'bitrate', anchor: '95%'}]},
                    {columnWidth: .25, items: [{xtype: 'numberfield', fieldLabel: 'Размер файла', name: 'filesize', anchor: '95%'}]}
                ]
            },
            {xtype: 'xcheckbox', boxLabel: 'Видео по умолчанию', hideLabel: true, name: 'is_default', inputValue: 1},
            {xtype: 'xcheckbox', boxLabel: 'Видео активно', hideLabel: true, name: 'is_active', inputValue: 1, checked: true}
        ]
    });
    Training.window.ModuleVideo.superclass.constructor.call(this, config);
};
Ext.extend(Training.window.ModuleVideo, MODx.Window);
Ext.reg('training-window-module-video', Training.window.ModuleVideo);
