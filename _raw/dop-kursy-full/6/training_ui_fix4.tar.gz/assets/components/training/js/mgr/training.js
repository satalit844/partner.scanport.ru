var Training = function(config) {
    config = config || {};
    Training.superclass.constructor.call(this, config);
};
Ext.extend(Training, Ext.Component, {});
Ext.reg('training', Training);

Training = new Training();

Training.config = Training.config || {};
Training.utils = Training.utils || {};
Training.grid = Training.grid || {};
Training.panel = Training.panel || {};
Training.page = Training.page || {};
Training.form = Training.form || {};
Training.window = Training.window || {};
Training.combo = Training.combo || {};

Training.utils.toBool = function(value) {
    return value === true || value === 1 || value === '1' || value === 'true' || value === 'yes' || value === 'on';
};

Training.utils.getResultData = function(action) {
    if (!action) {
        return {};
    }
    if (action.result) {
        if (action.result.object && typeof action.result.object === 'object') {
            return action.result.object;
        }
        if (action.result.results && Ext.isArray(action.result.results) && action.result.results.length) {
            return action.result.results[0];
        }
        return action.result;
    }
    return action;
};

Training.utils.getRecordValue = function(rec, key) {
    if (!rec) {
        return null;
    }

    if (rec.data && typeof rec.data[key] !== 'undefined') {
        return rec.data[key];
    }

    if (typeof rec[key] !== 'undefined') {
        return rec[key];
    }

    return null;
};

Training.utils.renderBoolean = function(value) {
    var active = Training.utils.toBool(value);
    if (active) {
        return '<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:#e6f6ea;color:#1f7a35;font-weight:600;">Да</span>';
    }
    return '<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:#f3f3f3;color:#888;font-weight:600;">Нет</span>';
};

Training.utils.escapeHtml = function(value) {
    value = value || '';
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
};

Training.utils.normalizeLink = function(value) {
    value = value || '';
    value = String(value).replace(/^\s+|\s+$/g, '');
    if (!value) {
        return '';
    }
    if (/^(https?:)?\/\//i.test(value) || value.indexOf('/') === 0) {
        return value;
    }
    return '/' + value.replace(/^\.?\//, '');
};

Training.utils.renderFileLink = function(value) {
    var url = Training.utils.normalizeLink(value);
    if (!url || value === '—') {
        return '—';
    }
    return '<a href="' + Training.utils.escapeHtml(url) + '" target="_blank">' + Training.utils.escapeHtml(value) + '</a>';
};

Training.utils.renderSlidePreview = function(value) {
    var url = Training.utils.normalizeLink(value);
    if (!url) {
        return '—';
    }
    return '<a href="' + Training.utils.escapeHtml(url) + '" target="_blank"><img src="' + Training.utils.escapeHtml(url) + '" alt="" style="max-width:80px;max-height:48px;border-radius:4px;border:1px solid #ddd;display:block;margin:4px auto;" /></a>';
};

Training.utils.formatSeconds = function(value) {
    var total = parseInt(value, 10) || 0;
    var hours = Math.floor(total / 3600);
    var minutes = Math.floor((total % 3600) / 60);
    var seconds = total % 60;
    if (hours > 0) {
        return hours + ':' + String(minutes).padStart(2, '0') + ':' + String(seconds).padStart(2, '0');
    }
    return minutes + ':' + String(seconds).padStart(2, '0');
};

Training.utils.formatBytes = function(value) {
    var bytes = parseInt(value, 10) || 0;
    var units = ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ'];
    var unitIndex = 0;

    if (!bytes) {
        return '0 Б';
    }

    while (bytes >= 1024 && unitIndex < units.length - 1) {
        bytes = bytes / 1024;
        unitIndex++;
    }

    return (Math.round(bytes * 100) / 100) + ' ' + units[unitIndex];
};

Training.utils.renderSeconds = function(value) {
    return Training.utils.formatSeconds(value || 0);
};

Training.utils.renderBytes = function(value) {
    return Training.utils.formatBytes(value || 0);
};

Training.utils.getGridSelectionModel = function(grid) {
    if (!grid) {
        return null;
    }
    if (grid.sm) {
        return grid.sm;
    }
    if (grid.getSelectionModel) {
        return grid.getSelectionModel();
    }
    return null;
};

Training.utils.getSelectedRecordsFromSm = function(sm) {
    if (!sm) {
        return [];
    }
    if (typeof sm.getSelections === 'function') {
        return sm.getSelections() || [];
    }
    if (typeof sm.getSelected === 'function') {
        var rec = sm.getSelected();
        return rec ? [rec] : [];
    }
    return [];
};

Training.utils.getSelectedRecords = function(grid) {
    var sm = Training.utils.getGridSelectionModel(grid);
    if (sm) {
        return Training.utils.getSelectedRecordsFromSm(sm);
    }
    return [];
};

Training.utils.getSelectedIds = function(grid) {
    var ids = [];
    Ext.each(Training.utils.getSelectedRecords(grid), function(rec) {
        var id = parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0;
        if (id) {
            ids.push(id);
        }
    });
    return ids;
};


Training.utils.uniqueInts = function(items) {
    var seen = {};
    var out = [];
    Ext.each(items || [], function(item) {
        var id = parseInt(item, 10) || 0;
        if (id && !seen[id]) {
            seen[id] = true;
            out.push(id);
        }
    });
    return out;
};

Training.utils.setCheckboxValue = function(form, fieldName, value) {
    if (!form || !form.findField) {
        return;
    }
    var field = form.findField(fieldName);
    if (field && field.setValue) {
        field.setValue(Training.utils.toBool(value) ? 1 : 0);
    }
};

Training.utils.setFormValues = function(form, values) {
    values = values || {};
    if (!form || !form.findField) {
        return;
    }
    for (var key in values) {
        if (!values.hasOwnProperty(key)) {
            continue;
        }
        var field = form.findField(key);
        if (!field || !field.setValue) {
            continue;
        }
        field.setValue(values[key]);
    }
};

Training.utils.extractBrowserPath = function(data) {
    if (Ext.isArray(data) && data.length) {
        data = data[0];
    }
    if (!data) {
        return '';
    }
    if (typeof data === 'string') {
        return Training.utils.normalizeLink(data);
    }

    var keys = ['fullRelativeUrl', 'relativeUrl', 'url', 'path', 'value', 'file', 'pathname'];
    for (var i = 0; i < keys.length; i++) {
        if (data[keys[i]]) {
            return Training.utils.normalizeLink(data[keys[i]]);
        }
    }

    if (data.relativePath) {
        return Training.utils.normalizeLink(data.relativePath);
    }

    return '';
};

Training.utils.openFileBrowser = function(config) {
    config = config || {};
    var source = config.source || MODx.config.default_media_source || 1;
    var browser = MODx.load({
        xtype: 'modx-browser',
        id: Ext.id(),
        multiple: false,
        source: source,
        hideSourceCombo: false,
        rootVisible: true,
        wctx: MODx.ctx || 'web',
        allowedFileTypes: config.allowedFileTypes || '',
        openTo: config.openTo || '',
        listeners: {
            select: {
                fn: function(data) {
                    var path = Training.utils.extractBrowserPath(data);
                    if (path && typeof config.onSelect === 'function') {
                        config.onSelect.call(config.scope || this, path, data);
                    }
                },
                scope: config.scope || this
            }
        }
    });

    if (browser && browser.setSource) {
        browser.setSource(source);
    }
    if (browser && browser.show) {
        browser.show();
        return browser;
    }
    MODx.msg.alert('Ошибка', 'Не удалось открыть браузер файлов MODX');
    return null;
};

Training.utils.openPathBrowser = function(field, options) {
    options = options || {};
    if (!field) {
        return null;
    }
    var openTo = options.openTo || (field.getValue ? field.getValue() : '') || '';
    return Training.utils.openFileBrowser({
        scope: options.scope || field,
        allowedFileTypes: options.allowedFileTypes || '',
        openTo: openTo,
        source: options.source || field.browserSource || MODx.config.default_media_source || 1,
        onSelect: function(path) {
            if (field.setValue) {
                field.setValue(path);
            }
            if (typeof options.onSelect === 'function') {
                options.onSelect.call(options.scope || field, path, field);
            }
        }
    });
};

Training.utils.applyPathFromRecord = function(win, record, targetFieldName, extra) {
    if (!win || !record) {
        return;
    }
    var form = win.fp ? win.fp.getForm() : (win.getForm ? win.getForm() : null);
    if (!form) {
        return;
    }
    var path = record.data && record.data.path ? record.data.path : '';
    var targetField = form.findField(targetFieldName);
    if (targetField) {
        targetField.setValue(path || '');
    }
    if (extra && typeof extra === 'function') {
        extra(form, record);
    }
};

Training.utils.buildUrl = function(paramsToSet, paramsToRemove) {
    var url = new URL(window.location.href);
    paramsToSet = paramsToSet || {};
    paramsToRemove = paramsToRemove || [];

    for (var key in paramsToSet) {
        if (paramsToSet.hasOwnProperty(key)) {
            url.searchParams.set(key, paramsToSet[key]);
        }
    }

    Ext.each(paramsToRemove, function(param) {
        url.searchParams.delete(param);
    });

    return url.toString();
};
