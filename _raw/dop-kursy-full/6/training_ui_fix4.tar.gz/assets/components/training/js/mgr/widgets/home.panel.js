Training.panel.Home = function(config) {
    config = config || {};

    Ext.apply(config, {
        id: 'training-panel-home',
        baseCls: 'modx-formpanel',
        layout: 'anchor',
        hideMode: 'offsets',
        items: [{
            html: '<h2>Курсы</h2>',
            cls: '',
            style: {margin: '15px 0'}
        }, {
            xtype: 'training-grid-courses',
            cls: 'main-wrapper',
            preventRender: true
        }]
    });

    Training.panel.Home.superclass.constructor.call(this, config);
};

Ext.extend(Training.panel.Home, MODx.Panel);
Ext.reg('training-panel-home', Training.panel.Home);