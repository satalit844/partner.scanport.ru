<?php

$_lang['training'] = 'Курсы';
$_lang['training.menu'] = 'Курсы';
$_lang['training.menu_desc'] = 'Управление курсами, модулями, доступами и прогрессом пользователей';

$_lang['training.courses'] = 'Курсы';
$_lang['training.course_id'] = 'ID';
$_lang['training.course_resource_id'] = 'ID ресурса';
$_lang['training.course_pagetitle'] = 'Название курса';
$_lang['training.course_uri'] = 'URI';
$_lang['training.course_modules_count'] = 'Модулей';
$_lang['training.course_active'] = 'Активен';
$_lang['training.course_sequential'] = 'Последовательно';
$_lang['training.course_createdon'] = 'Создан';
$_lang['training.search'] = 'Поиск';
$_lang['training.sync'] = 'Синхронизировать';
$_lang['training.sync_success'] = 'Синхронизация завершена';
$_lang['training.courses_parent_id_not_set'] = 'Не задана системная настройка training.courses_parent_id';
$_lang['training.module'] = 'Модуль';
