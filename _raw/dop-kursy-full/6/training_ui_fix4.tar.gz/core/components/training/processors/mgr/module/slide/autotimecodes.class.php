<?php

require_once dirname(dirname(__DIR__)) . '/_media_helper.php';

class TrainingModuleSlideAutotimecodesProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }
    public function process()
    {
        $moduleId = (int)$this->getProperty('module_id');
        if ($moduleId <= 0) {
            return $this->failure('Не указан модуль');
        }

        /** @var TrainingModule $module */
        $module = $this->modx->getObject('TrainingModule', ['id' => $moduleId]);
        if (!$module) {
            return $this->failure('Модуль не найден');
        }

        $durationSeconds = (int)$module->get('duration_seconds');
        if ($durationSeconds <= 0) {
            return $this->failure('У модуля пока нет длительности. Сначала обработай видео');
        }

        $updated = TrainingMediaHelper::applyEvenSlideTimecodes($this->modx, $moduleId, $durationSeconds * 1000);
        if ($updated > 0) {
            $module->set('presentation_status', 'ready');
            $module->save();
        }

        return $this->success('Таймкоды расставлены', [
            'updated' => $updated,
            'duration_seconds' => $durationSeconds,
            'duration_human' => TrainingMediaHelper::formatSeconds($durationSeconds),
        ]);
    }
}

return 'TrainingModuleSlideAutotimecodesProcessor';
