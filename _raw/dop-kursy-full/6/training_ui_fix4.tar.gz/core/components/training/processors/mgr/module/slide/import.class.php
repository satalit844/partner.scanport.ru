<?php

require_once dirname(__FILE__) . '/_helpers.php';

class TrainingModuleSlideImportProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }
    public function process()
    {
        $moduleId = (int)$this->getProperty('module_id');
        if ($moduleId <= 0) {
            return $this->failure('Не указан модуль');
        }

        $scan = TrainingModuleSlideHelper::scanCourseSlides($this->modx, $moduleId);
        if (empty($scan['dir']['exists'])) {
            $checked = !empty($scan['dir']['checked']) ? implode("
", $scan['dir']['checked']) : '—';
            return $this->failure("Папка со слайдами курса не найдена.
Проверено:
" . $checked);
        }

        $c = $this->modx->newQuery('TrainingModuleSlide');
        $c->where(['module_id' => $moduleId]);

        /** @var TrainingModuleSlide[] $existingItems */
        $existingItems = $this->modx->getCollection('TrainingModuleSlide', $c);
        $existingByImage = [];
        $maxSlideNo = 0;

        foreach ($existingItems as $item) {
            $existingByImage[(string)$item->get('image')] = true;
            $maxSlideNo = max($maxSlideNo, (int)$item->get('slide_no'));
        }

        $created = 0;

        foreach ($scan['slides'] as $slide) {
            if (!empty($existingByImage[$slide['path']])) {
                continue;
            }

            /** @var TrainingModuleSlide $item */
            $item = $this->modx->newObject('TrainingModuleSlide');
            $item->set('module_id', $moduleId);
            $item->set('image', $slide['path']);

            $slideNo = (int)$slide['slide_no'];
            if ($slideNo <= 0 || $slideNo <= $maxSlideNo) {
                $slideNo = $maxSlideNo + 1;
            }

            $item->set('slide_no', $slideNo);
            $item->set('timecode_ms', 0);
            $item->set('is_active', 1);
            $item->save();

            $existingByImage[$slide['path']] = true;
            $maxSlideNo = max($maxSlideNo, $slideNo);
            $created++;
        }

        return $this->success('Импорт завершён', [
            'created' => $created,
            'available_dir' => $scan['dir']['web'],
        ]);
    }
}

return 'TrainingModuleSlideImportProcessor';
