<?php

class TrainingModuleUpdateProcessor extends modObjectUpdateProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    public $classKey = 'TrainingModule';
    public $objectType = 'training.module';

    public function beforeSet()
    {
        $id = (int)$this->getProperty('id');
        if (!$id) {
            return 'Не указан ID модуля';
        }

        $this->setProperty('is_active', (int)$this->getProperty('is_active', 0));
        $this->setProperty('is_required', (int)$this->getProperty('is_required', 0));
        $this->setProperty('source_video', trim((string)$this->getProperty('source_video', '')));

        $status = trim((string)$this->getProperty('video_status', ''));
        if ($status === '') {
            $status = 'none';
        }
        $this->setProperty('video_status', $status);

        return parent::beforeSet();
    }
}

return 'TrainingModuleUpdateProcessor';
