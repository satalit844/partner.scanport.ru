<?php

class TrainingModuleSlideRemoveProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    public function process()
    {
        $ids = $this->collectIds();
        if (empty($ids)) {
            return $this->failure('Не выбраны слайды для удаления');
        }

        $removed = 0;
        foreach ($ids as $id) {
            /** @var TrainingModuleSlide $item */
            $item = $this->modx->getObject('TrainingModuleSlide', ['id' => $id]);
            if ($item && $item->remove()) {
                $removed++;
            }
        }

        return $this->success('Слайды удалены', ['removed' => $removed]);
    }

    protected function collectIds()
    {
        $raw = $this->getProperty('ids', $this->getProperty('id', ''));
        if (is_array($raw)) {
            return array_values(array_filter(array_map('intval', $raw)));
        }

        $raw = trim((string)$raw);
        if ($raw === '') {
            return [];
        }

        $parts = array_filter(array_map('trim', explode(',', $raw)));
        return array_values(array_filter(array_map('intval', $parts)));
    }
}

return 'TrainingModuleSlideRemoveProcessor';
