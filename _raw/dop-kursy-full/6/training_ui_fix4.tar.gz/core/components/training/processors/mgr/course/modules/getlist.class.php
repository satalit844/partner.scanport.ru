<?php

class TrainingCourseModulesGetListProcessor extends modObjectGetListProcessor
{
    public $classKey = 'TrainingModule';
    public $objectType = 'training.module';
    public $defaultSortField = 'Resource.menuindex';
    public $defaultSortDirection = 'ASC';

    public function prepareQueryBeforeCount(xPDOQuery $c)
    {
        $courseId = (int)$this->getProperty('course_id');
        if (!$courseId) {
            $c->where(['1 = 0']);
            return $c;
        }

        $query = trim($this->getProperty('query', ''));

        $c->leftJoin('modResource', 'Resource', 'Resource.id = TrainingModule.resource_id');

        $c->select($this->modx->getSelectColumns('TrainingModule', 'TrainingModule'));
        $c->select([
            'Resource.pagetitle AS title',
            'Resource.menuindex AS menuindex',
            'Resource.published AS published',
        ]);

        $c->where([
            'TrainingModule.course_id' => $courseId,
        ]);

        if ($query !== '') {
            $c->where([
                'TrainingModule.id:=' => (int)$query,
                'OR:TrainingModule.resource_id:=' => (int)$query,
                'OR:Resource.pagetitle:LIKE' => '%' . $query . '%',
            ]);
        }

        return $c;
    }

    public function prepareRow(xPDOObject $object)
    {
        $array = $object->toArray();

        $array['title'] = !empty($array['title']) ? $array['title'] : '—';
        $array['published'] = (int)!empty($array['published']);
        $array['is_active'] = (int)!empty($array['is_active']);
        $array['videos_count'] = (int)$this->modx->getCount('TrainingModuleVideo', [
            'module_id' => $array['id'],
        ]);
        $array['slides_count'] = (int)$this->modx->getCount('TrainingModuleSlide', [
            'module_id' => $array['id'],
        ]);

        return $array;
    }
}

return 'TrainingCourseModulesGetListProcessor';
