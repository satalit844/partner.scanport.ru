<?php

require_once dirname(__DIR__) . '/_media_helper.php';

class TrainingModuleGetProcessor extends modObjectGetProcessor
{
    public $classKey = 'TrainingModule';
    public $objectType = 'training.module';

    public function initialize()
    {
        if (!$this->getProperty('id')) {
            return $this->modx->lexicon('invalid_data');
        }

        return parent::initialize();
    }

    public function cleanup()
    {
        $array = $this->object->toArray();

        /** @var modResource $resource */
        $resource = $this->modx->getObject('modResource', [
            'id' => $array['resource_id'],
        ]);

        if ($resource) {
            $array['pagetitle'] = $resource->get('pagetitle');
            $array['alias'] = $resource->get('alias');
            $array['context_key'] = $resource->get('context_key');
            $array['uri'] = $resource->get('uri');
            $array['published'] = (int)$resource->get('published');
            $array['published_label'] = $array['published'] ? 'Да' : 'Нет';
        } else {
            $array['pagetitle'] = '—';
            $array['alias'] = '';
            $array['context_key'] = '';
            $array['uri'] = '—';
            $array['published'] = 0;
            $array['published_label'] = 'Нет';
        }

        /** @var TrainingCourse $course */
        $course = $this->modx->getObject('TrainingCourse', [
            'id' => $array['course_id'],
        ]);

        $array['course_title'] = '—';
        if ($course) {
            /** @var modResource $courseResource */
            $courseResource = $this->modx->getObject('modResource', [
                'id' => $course->get('resource_id'),
            ]);
            if ($courseResource) {
                $array['course_title'] = $courseResource->get('pagetitle');
            }
        }

        $array['videos_count'] = (int)$this->modx->getCount('TrainingModuleVideo', ['module_id' => $array['id']]);
        $array['slides_count'] = (int)$this->modx->getCount('TrainingModuleSlide', ['module_id' => $array['id']]);

        $dirs = TrainingMediaHelper::resolveModuleVideoDirs($this->modx, $this->object);
        $array['video_output_dir'] = $dirs['video_web'];

        $courseSlidesDir = '';
        $courseSlidesExists = 'Нет';
        $courseSlidesCount = 0;
        $coursePresentationStatus = 'none';
        if ($course) {
            $coursePresentationStatus = (string)$course->get('presentation_status');
            $courseDirs = TrainingMediaHelper::resolveCoursePresentationDirs($this->modx, $course);
            $courseSlidesDir = !empty($course->get('slides_dir')) ? $course->get('slides_dir') : $courseDirs['slides_web'];
            $abs = TrainingMediaHelper::webPathToFs($this->modx, $courseSlidesDir);
            if ($abs && is_dir($abs)) {
                $courseSlidesExists = 'Да';
                $items = scandir($abs);
                foreach ((array)$items as $item) {
                    if ($item === '.' || $item === '..') {
                        continue;
                    }
                    $full = rtrim($abs, '/\\') . '/' . $item;
                    if (is_file($full) && preg_match('#\.(jpg|jpeg|png|webp|gif)$#i', $item)) {
                        $courseSlidesCount++;
                    }
                }
            }
        }
        $array['course_presentation_status'] = $coursePresentationStatus ?: 'none';
        $array['course_slides_dir'] = $courseSlidesDir;
        $array['course_slides_dir_exists_label'] = $courseSlidesExists;
        $array['available_course_slides'] = $courseSlidesCount;
        $array['id_label'] = $array['id'];
        $array['course_id_label'] = $array['course_id'];
        $array['duration_human'] = $this->formatSeconds((int)$array['duration_seconds']);
        $array['createdon'] = !empty($array['createdon']) ? $array['createdon'] : '—';
        $array['updatedon'] = !empty($array['updatedon']) ? $array['updatedon'] : '—';
        $array['is_active'] = (int)!empty($array['is_active']);
        $array['is_required'] = (int)!empty($array['is_required']);
        $array['source_video'] = !empty($array['source_video']) ? $array['source_video'] : '';
        $array['video_status'] = !empty($array['video_status']) ? $array['video_status'] : 'none';
        $array['presentation_status'] = !empty($array['presentation_status']) ? $array['presentation_status'] : 'none';

        return $this->success('', $array);
    }

    protected function formatSeconds($seconds)
    {
        $seconds = (int)$seconds;
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        $seconds = $seconds % 60;

        if ($hours > 0) {
            return sprintf('%d:%02d:%02d', $hours, $minutes, $seconds);
        }

        return sprintf('%d:%02d', $minutes, $seconds);
    }
}

return 'TrainingModuleGetProcessor';
