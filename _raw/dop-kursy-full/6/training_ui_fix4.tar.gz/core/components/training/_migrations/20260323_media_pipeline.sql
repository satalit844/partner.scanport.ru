-- Замени __TABLE_PREFIX__ на реальный префикс таблиц MODX, например modx_ или свой.
ALTER TABLE `__TABLE_PREFIX__training_courses`
    ADD COLUMN `source_presentation` VARCHAR(255) NOT NULL DEFAULT '' AFTER `is_sequential`,
    ADD COLUMN `presentation_pdf` VARCHAR(255) NOT NULL DEFAULT '' AFTER `source_presentation`,
    ADD COLUMN `slides_dir` VARCHAR(255) NOT NULL DEFAULT '' AFTER `presentation_pdf`,
    ADD COLUMN `presentation_status` VARCHAR(32) NOT NULL DEFAULT 'none' AFTER `slides_dir`;
