-- Замени __TABLE_PREFIX__ на свой префикс таблиц MODX.
-- Этот файл нужен, если поля media/ui ещё не были добавлены в БД.

ALTER TABLE `__TABLE_PREFIX__training_courses`
    ADD COLUMN IF NOT EXISTS `source_presentation` VARCHAR(255) NOT NULL DEFAULT '' AFTER `is_sequential`,
    ADD COLUMN IF NOT EXISTS `presentation_pdf` VARCHAR(255) NOT NULL DEFAULT '' AFTER `source_presentation`,
    ADD COLUMN IF NOT EXISTS `slides_dir` VARCHAR(255) NOT NULL DEFAULT '' AFTER `presentation_pdf`,
    ADD COLUMN IF NOT EXISTS `presentation_status` VARCHAR(32) NOT NULL DEFAULT 'none' AFTER `slides_dir`;

ALTER TABLE `__TABLE_PREFIX__training_modules`
    ADD COLUMN IF NOT EXISTS `is_required` TINYINT(1) NOT NULL DEFAULT 1 AFTER `is_active`,
    ADD COLUMN IF NOT EXISTS `duration_seconds` INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `sort_order`,
    ADD COLUMN IF NOT EXISTS `video_status` VARCHAR(32) NOT NULL DEFAULT 'none' AFTER `duration_seconds`,
    ADD COLUMN IF NOT EXISTS `presentation_status` VARCHAR(32) NOT NULL DEFAULT 'none' AFTER `video_status`,
    ADD COLUMN IF NOT EXISTS `source_video` VARCHAR(255) NOT NULL DEFAULT '' AFTER `presentation_status`,
    ADD COLUMN IF NOT EXISTS `source_presentation` VARCHAR(255) NOT NULL DEFAULT '' AFTER `source_video`,
    ADD COLUMN IF NOT EXISTS `presentation_pdf` VARCHAR(255) NOT NULL DEFAULT '' AFTER `source_presentation`,
    ADD COLUMN IF NOT EXISTS `slides_dir` VARCHAR(255) NOT NULL DEFAULT '' AFTER `presentation_pdf`;
