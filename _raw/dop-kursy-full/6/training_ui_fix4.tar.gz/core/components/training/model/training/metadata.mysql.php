<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'TrainingCourse',
    1 => 'TrainingModule',
    2 => 'TrainingModuleVideo',
    3 => 'TrainingModuleSlide',
    4 => 'TrainingCourseAccess',
    5 => 'TrainingUserCourse',
    6 => 'TrainingUserModuleProgress',
    7 => 'TrainingTestLink',
    8 => 'TrainingUserTestStatus',
  ),
);