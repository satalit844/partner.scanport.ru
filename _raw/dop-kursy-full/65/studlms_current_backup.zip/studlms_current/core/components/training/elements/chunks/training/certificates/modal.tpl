<div class="modal fade sert-modal-bootstrap" id="sertModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered sert-modal__dialog">
        <div class="modal-content sert-modal">
            <div class="modal-body sert-modal__body">
                <div class="sert-modal__preview">
                    <img class="sert-modal__img" src="" alt="">
                </div>
                <div class="sert-modal__actions">
                    <a class="sert-modal__download" href="#" download>
                        <span>Скачать</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none" aria-hidden="true">
                            <path d="M16 21.3333V5.33331" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M9.3335 14.6667L16.0002 21.3334L22.6668 14.6667" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M6.6665 26.6667H25.3332" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
