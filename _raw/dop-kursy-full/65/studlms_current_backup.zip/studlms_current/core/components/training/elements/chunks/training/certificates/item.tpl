<div class="sert-item {$certificate_state_class}" data-cert-state="{$certificate_state}" data-valid-to="{$certificate_valid_to_iso}">
    <div class="sert-item__head">
        <div class="sert-item__logo">
            <img src="theme/images/training/sert/sert-logo.svg" class="img-svg" alt="">
        </div>
        <div class="sert-item__body">
            <div class="sert-item__title">{$certificate_title}</div>
            <div class="sert-status">{$certificate_status_text}</div>
        </div>
    </div>

    <button type="button"
            class="sert-btn"
            data-img="{$certificate_preview}"
            data-file="{$certificate_file}"
            data-title="{$certificate_title}">
        <span>Скачать</span>
        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 28 28" fill="none" aria-hidden="true">
            <path d="M14 18.6667V4.66669" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M8.1665 12.8333L13.9998 18.6667L19.8332 12.8333" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M5.8335 23.3333H22.1668" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    </button>
</div>
