<?php
return include MODX_CORE_PATH . 'components/training/elements/snippets/trainingManageCoursesPage.php';
