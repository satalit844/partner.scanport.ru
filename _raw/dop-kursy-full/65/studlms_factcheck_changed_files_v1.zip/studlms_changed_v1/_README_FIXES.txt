StudLMS factcheck fixes v1

Изменены:
- theme/css/training.css
- theme/js/app-training.js
- core/components/training/elements/snippets/trainingMenuRender.php
- _resources/01.base

Плеер не трогался. Логика управления курсами не трогалась. Почта не трогалась.
Архив studlms_current_backup.zip — исходное состояние из свежих архивов.
