StudLMS factcheck v2 — исправление бокового меню

Изменены только:
- theme/css/training.css
- core/components/training/elements/snippets/trainingMenuRender.php

Что сделано:
1. Для пункта «Обучение» принудительно используется theme/images/study-university.svg.
2. Для стрелки используется theme/images/menu_arrow.svg.
3. Убран конфликтующий override из training.css, который переворачивал стрелку и менял вес заголовка.
4. Оставлено только выделение активного подпункта меню.

Плеер, управление курсами, тесты, сертификаты, почта не трогались.
