<?php
/**
 * Один раз перенести уже загруженные файлы практик из
 * assets/components/training/practices/ в assets/training/practices/
 * и поправить пути в training_practice_files.
 *
 * Таблицы и настройки не создаёт.
 */

$oldRel = 'assets/components/training/practices/';
$newRel = 'assets/training/practices/';

$oldDir = rtrim($modx->getOption('base_path'), '/') . '/' . $oldRel;
$newDir = rtrim($modx->getOption('base_path'), '/') . '/' . $newRel;

function trainingPracticeStage4CopyDir($src, $dst) {
    if (!is_dir($src)) {
        return array(0, 0);
    }
    if (!is_dir($dst)) {
        mkdir($dst, 0755, true);
    }

    $copied = 0;
    $skipped = 0;
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($src, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($it as $item) {
        $target = $dst . DIRECTORY_SEPARATOR . $it->getSubPathName();
        if ($item->isDir()) {
            if (!is_dir($target)) {
                mkdir($target, 0755, true);
            }
            continue;
        }

        if (is_file($target)) {
            $skipped++;
            continue;
        }

        if (!is_dir(dirname($target))) {
            mkdir(dirname($target), 0755, true);
        }

        if (copy($item->getPathname(), $target)) {
            $copied++;
        }
    }

    return array($copied, $skipped);
}

$table = $modx->getOption('table_prefix') . 'training_practice_files';
$tables = array(
    $table,
    rtrim($modx->getOption('table_prefix'), '_') . 'training_practice_files',
    'modx_partnerstraining_practice_files',
    'modx_training_practice_files',
);

$foundTable = '';
foreach (array_unique($tables) as $candidate) {
    $candidate = preg_replace('/[^a-zA-Z0-9_]/', '', $candidate);
    $stmt = $modx->query('SHOW TABLES LIKE ' . $modx->quote($candidate));
    if ($stmt && $stmt->fetchColumn()) {
        $foundTable = $candidate;
        break;
    }
}

if ($foundTable === '') {
    echo "Не найдена таблица training_practice_files\n";
    return;
}

list($copied, $skipped) = trainingPracticeStage4CopyDir($oldDir, $newDir);

$stmt = $modx->prepare("UPDATE `{$foundTable}` SET `path` = REPLACE(`path`, :old_path, :new_path), `url` = REPLACE(`url`, :old_url, :new_url) WHERE `path` LIKE :old_path_like OR `url` LIKE :old_url_like");
$stmt->execute(array(
    ':old_path' => $oldRel,
    ':new_path' => $newRel,
    ':old_url' => '/' . $oldRel,
    ':new_url' => '/' . $newRel,
    ':old_path_like' => $oldRel . '%',
    ':old_url_like' => '/' . $oldRel . '%',
));

$updated = $stmt->rowCount();

echo "Готово\n";
echo "Таблица: {$foundTable}\n";
echo "Скопировано файлов: {$copied}\n";
echo "Пропущено существующих: {$skipped}\n";
echo "Обновлено строк в БД: {$updated}\n";
echo "Новая папка: {$newRel}\n";
