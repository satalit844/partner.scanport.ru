<?php
require_once dirname(dirname(__FILE__)) . '/_helper.php';

class TrainingPracticeMgrAttemptsGetListProcessor extends modProcessor
{
    public function process()
    {
        $attemptsTable = trainingPracticeMgrTable($this->modx, 'training_practice_attempts');
        $practicesTable = trainingPracticeMgrTable($this->modx, 'training_practices');
        $coursesTable = trainingPracticeMgrTable($this->modx, 'training_courses');
        $modulesTable = trainingPracticeMgrTable($this->modx, 'training_modules');
        $usersTable = trainingPracticeMgrTable($this->modx, 'users');
        $attributesTable = trainingPracticeMgrTable($this->modx, 'user_attributes');
        $contentTable = trainingPracticeMgrTable($this->modx, 'site_content');

        $start = max(0, (int)$this->getProperty('start', 0));
        $limit = max(0, (int)$this->getProperty('limit', 20));
        $query = trim((string)$this->getProperty('query', ''));
        $practiceId = (int)$this->getProperty('practice_id', 0);
        $status = trim((string)$this->getProperty('status', ''));

        $where = array('1=1');
        $params = array();

        if ($practiceId > 0) {
            $where[] = 'a.`practice_id` = :practice_id';
            $params[':practice_id'] = $practiceId;
        }

        if ($status !== '') {
            $where[] = 'a.`status` = :status';
            $params[':status'] = $status;
        }

        if ($query !== '') {
            $where[] = '(p.`title` LIKE :query OR a.`title` LIKE :query OR ua.`fullname` LIKE :query OR u.`username` LIKE :query OR u.`email` LIKE :query OR cr.`pagetitle` LIKE :query OR mr.`pagetitle` LIKE :query)';
            $params[':query'] = '%' . $query . '%';
        }

        $whereSql = implode(' AND ', $where);

        $countSql = "
            SELECT COUNT(*)
            FROM {$attemptsTable} a
            LEFT JOIN {$practicesTable} p ON p.`id` = a.`practice_id`
            LEFT JOIN {$coursesTable} tc ON tc.`id` = a.`course_id`
            LEFT JOIN {$modulesTable} tm ON tm.`id` = a.`module_id`
            LEFT JOIN {$contentTable} cr ON cr.`id` = IFNULL(NULLIF(tc.`resource_id`, 0), a.`course_id`)
            LEFT JOIN {$contentTable} mr ON mr.`id` = IFNULL(NULLIF(tm.`resource_id`, 0), a.`module_id`)
            LEFT JOIN {$usersTable} u ON u.`id` = a.`user_id`
            LEFT JOIN {$attributesTable} ua ON ua.`internalKey` = u.`id`
            WHERE {$whereSql}
        ";

        $countStmt = $this->modx->prepare($countSql);
        if (!$countStmt || !$countStmt->execute($params)) {
            return $this->failure('Не удалось загрузить попытки практических заданий');
        }
        $total = (int)$countStmt->fetchColumn();

        $sort = preg_replace('/[^a-zA-Z0-9_]/', '', (string)$this->getProperty('sort', 'id'));
        $sortMap = array(
            'id' => 'a.`id`',
            'practice_title' => 'p.`title`',
            'user_display' => 'ua.`fullname`',
            'status' => 'a.`status`',
            'status_text' => 'a.`status`',
            'attempt_num' => 'a.`attempt_num`',
            'attempt_no' => 'a.`attempt_no`',
            'submittedon' => 'a.`submittedon`',
            'submittedon_formatted' => 'a.`submittedon`',
            'createdon' => 'a.`createdon`',
            'createdon_formatted' => 'a.`createdon`',
            'reviewedon' => 'a.`reviewedon`',
            'reviewedon_formatted' => 'a.`reviewedon`',
            'course_display' => 'cr.`pagetitle`',
            'module_display' => 'mr.`pagetitle`',
        );
        $sortSql = isset($sortMap[$sort]) ? $sortMap[$sort] : 'a.`id`';
        $dir = strtoupper((string)$this->getProperty('dir', 'DESC')) === 'ASC' ? 'ASC' : 'DESC';

        $sql = "
            SELECT
                a.*,
                COALESCE(NULLIF(p.`title`, ''), NULLIF(a.`title`, ''), CONCAT('Практика #', a.`practice_id`)) AS `practice_title`,
                cr.`pagetitle` AS `course_title`,
                mr.`pagetitle` AS `module_title`,
                u.`username`,
                u.`email`,
                ua.`fullname`
            FROM {$attemptsTable} a
            LEFT JOIN {$practicesTable} p ON p.`id` = a.`practice_id`
            LEFT JOIN {$coursesTable} tc ON tc.`id` = a.`course_id`
            LEFT JOIN {$modulesTable} tm ON tm.`id` = a.`module_id`
            LEFT JOIN {$contentTable} cr ON cr.`id` = IFNULL(NULLIF(tc.`resource_id`, 0), a.`course_id`)
            LEFT JOIN {$contentTable} mr ON mr.`id` = IFNULL(NULLIF(tm.`resource_id`, 0), a.`module_id`)
            LEFT JOIN {$usersTable} u ON u.`id` = a.`user_id`
            LEFT JOIN {$attributesTable} ua ON ua.`internalKey` = u.`id`
            WHERE {$whereSql}
            ORDER BY {$sortSql} {$dir}, a.`id` DESC
        ";

        if ($limit > 0) {
            $sql .= " LIMIT {$start}, {$limit}";
        }

        $stmt = $this->modx->prepare($sql);
        if (!$stmt || !$stmt->execute($params)) {
            return $this->failure('Не удалось загрузить список попыток');
        }

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $results = array();

        foreach ($rows as $row) {
            $fullname = trim((string)$row['fullname']);
            if ($fullname === '') {
                $fullname = trim((string)$row['username']);
            }
            if ($fullname === '') {
                $fullname = 'Пользователь #' . (int)$row['user_id'];
            }

            $row['user_display'] = $fullname;
            $row['status_text'] = trainingPracticeMgrStatusText($row['status']);
            $row['createdon_formatted'] = trainingPracticeMgrDate($row['createdon']);
            $row['submittedon_formatted'] = trainingPracticeMgrDate($row['submittedon']);
            $row['reviewedon_formatted'] = trainingPracticeMgrDate($row['reviewedon']);
            $row['deadline_at_formatted'] = trainingPracticeMgrDate($row['deadline_at']);
            $row['course_display'] = trim((string)$row['course_title']) !== '' ? $row['course_title'] : ('Курс #' . (int)$row['course_id']);
            $row['module_display'] = trim((string)$row['module_title']) !== '' ? $row['module_title'] : ('Модуль #' . (int)$row['module_id']);
            $row['attempt_num'] = (int)(!empty($row['attempt_num']) ? $row['attempt_num'] : $row['attempt_no']);
            $row['attempt_no'] = $row['attempt_num'];
            $results[] = $row;
        }

        return $this->outputArray($results, $total);
    }
}

return 'TrainingPracticeMgrAttemptsGetListProcessor';
