<?php
require_once dirname(dirname(__FILE__)) . '/_helper.php';

class TrainingPracticeMgrMessagesCreateProcessor extends modProcessor
{
    public function process()
    {
        $attemptId = trainingPracticeMgrGetInt($this, 'attempt_id');
        $message = trim((string)$this->getProperty('message', ''));

        if ($attemptId <= 0) {
            return $this->failure('Выберите попытку');
        }
        if ($message === '') {
            return $this->failure('Напишите сообщение');
        }

        $attemptsTable = trainingPracticeMgrTable($this->modx, 'training_practice_attempts');
        $messagesTable = trainingPracticeMgrTable($this->modx, 'training_practice_messages');

        $stmt = $this->modx->prepare("SELECT * FROM {$attemptsTable} WHERE `id` = :id LIMIT 1");
        $stmt->execute(array(':id' => $attemptId));
        $attempt = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$attempt) {
            return $this->failure('Попытка не найдена');
        }

        $mentorId = (int)$this->modx->user->get('id');

        $stmt = $this->modx->prepare("\n            INSERT INTO {$messagesTable}\n            (`attempt_id`, `practice_id`, `author_id`, `author_type`, `user_id`, `sender_role`, `message`, `is_system`, `createdon`)\n            VALUES\n            (:attempt_id, :practice_id, :author_id, 'mentor', :user_id, 'mentor', :message, 0, NOW())\n        ");
        $stmt->execute(array(
            ':attempt_id' => $attemptId,
            ':practice_id' => (int)$attempt['practice_id'],
            ':author_id' => $mentorId,
            ':user_id' => (int)$attempt['user_id'],
            ':message' => $message,
        ));

        if ((string)$attempt['status'] === 'submitted') {
            $stmt = $this->modx->prepare("\n                UPDATE {$attemptsTable}\n                SET `status` = 'in_review', `reviewedon` = NOW(), `reviewedby` = :reviewedby, `reviewer_user_id` = :reviewedby, `updatedon` = NOW()\n                WHERE `id` = :id\n            ");
            $stmt->execute(array(
                ':reviewedby' => $mentorId,
                ':id' => $attemptId,
            ));
            $attempt['status'] = 'in_review';
        }

        $this->recalculateProgress($attempt);

        return $this->success('Сообщение отправлено');
    }

    protected function recalculateProgress(array $attempt)
    {
        $corePath = $this->modx->getOption('training.core_path', null, $this->modx->getOption('core_path') . 'components/training/');
        $trainingClass = $corePath . 'model/training/training.class.php';
        $progressClass = $corePath . 'model/training/services/trainingprogress.class.php';

        if (!is_file($trainingClass) || !is_file($progressClass)) {
            return;
        }

        try {
            require_once $trainingClass;
            require_once $progressClass;
            $training = new Training($this->modx);
            $service = new TrainingProgressService($this->modx, $training);
            $service->recalculateModuleProgressFromLessons((int)$attempt['course_id'], (int)$attempt['module_id'], (int)$attempt['user_id']);
            $service->recalculateUserCourse((int)$attempt['course_id'], (int)$attempt['user_id']);
        } catch (Exception $e) {
            $this->modx->log(modX::LOG_LEVEL_WARN, '[training] practice manager message progress recalc failed: ' . $e->getMessage());
        }
    }
}

return 'TrainingPracticeMgrMessagesCreateProcessor';
