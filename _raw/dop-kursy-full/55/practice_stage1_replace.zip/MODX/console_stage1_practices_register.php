<?php
/**
 * MODX Console: training практические задания, этап 1.
 * Запускать из MODX Console один раз после замены файлов.
 * Скрипт ничего не трогает в UserTest и не отключает AjaxMode.
 */

/** @var modX $modx */
$modx->setLogLevel(modX::LOG_LEVEL_INFO);
$modx->setLogTarget('ECHO');

$prefix = (string)$modx->getOption('table_prefix');
$corePath = rtrim((string)$modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/'), '/') . '/';

function training_stage1_table_name(modX $modx, $name) {
    $prefix = (string)$modx->getOption('table_prefix');
    return preg_replace('/[^a-zA-Z0-9_]/', '', $prefix . $name);
}

function training_stage1_table_exists(modX $modx, $table) {
    $stmt = $modx->query('SHOW TABLES LIKE ' . $modx->quote($table));
    return $stmt && $stmt->fetchColumn();
}

function training_stage1_column_exists(modX $modx, $table, $column) {
    $stmt = $modx->query('SHOW COLUMNS FROM `' . $table . '` LIKE ' . $modx->quote($column));
    return $stmt && $stmt->fetchColumn();
}

function training_stage1_exec(modX $modx, $sql, $label) {
    $stmt = $modx->exec($sql);
    echo $label . ': OK' . PHP_EOL;
    return $stmt;
}

$tables = array(
    'practices' => training_stage1_table_name($modx, 'training_practices'),
    'attempts' => training_stage1_table_name($modx, 'training_practice_attempts'),
    'messages' => training_stage1_table_name($modx, 'training_practice_messages'),
    'files' => training_stage1_table_name($modx, 'training_practice_files'),
    'links' => training_stage1_table_name($modx, 'training_test_links'),
);

echo 'START training practices stage 1' . PHP_EOL;
echo 'corePath: ' . $corePath . PHP_EOL;

if (!training_stage1_table_exists($modx, $tables['practices'])) {
    training_stage1_exec($modx, "
        CREATE TABLE `{$tables['practices']}` (
          `id` int unsigned NOT NULL AUTO_INCREMENT,
          `course_id` int unsigned NOT NULL DEFAULT 0,
          `module_id` int unsigned NOT NULL DEFAULT 0,
          `title` varchar(255) NOT NULL DEFAULT '',
          `description` mediumtext NULL,
          `template_file` varchar(500) NOT NULL DEFAULT '',
          `template_file_name` varchar(255) NOT NULL DEFAULT '',
          `image` varchar(500) NOT NULL DEFAULT '',
          `deadline_at` datetime NULL,
          `deadline_days` int unsigned NOT NULL DEFAULT 0,
          `allowed_extensions` varchar(255) NOT NULL DEFAULT 'pdf,doc,docx,xls,xlsx,png,jpg,jpeg,zip',
          `max_file_size` int unsigned NOT NULL DEFAULT 52428800,
          `active` tinyint unsigned NOT NULL DEFAULT 1,
          `rank` int unsigned NOT NULL DEFAULT 0,
          `createdon` datetime NULL,
          `editedon` datetime NULL,
          PRIMARY KEY (`id`),
          KEY `course_id` (`course_id`),
          KEY `module_id` (`module_id`),
          KEY `active` (`active`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ", 'create practices table');
} else {
    echo 'practices table: exists' . PHP_EOL;
}

if (!training_stage1_table_exists($modx, $tables['attempts'])) {
    training_stage1_exec($modx, "
        CREATE TABLE `{$tables['attempts']}` (
          `id` int unsigned NOT NULL AUTO_INCREMENT,
          `practice_id` int unsigned NOT NULL DEFAULT 0,
          `test_link_id` int unsigned NOT NULL DEFAULT 0,
          `course_id` int unsigned NOT NULL DEFAULT 0,
          `module_id` int unsigned NOT NULL DEFAULT 0,
          `user_id` int unsigned NOT NULL DEFAULT 0,
          `attempt_num` int unsigned NOT NULL DEFAULT 1,
          `attempt_no` int unsigned NOT NULL DEFAULT 1,
          `status` varchar(32) NOT NULL DEFAULT 'draft',
          `deadline_at` datetime NULL,
          `title` varchar(255) NOT NULL DEFAULT '',
          `score` decimal(7,2) NOT NULL DEFAULT 0.00,
          `max_score` decimal(7,2) NOT NULL DEFAULT 0.00,
          `review_comment` text NULL,
          `reviewer_user_id` int unsigned NOT NULL DEFAULT 0,
          `submittedon` datetime NULL,
          `reviewedon` datetime NULL,
          `reviewedby` int unsigned NOT NULL DEFAULT 0,
          `is_latest` tinyint unsigned NOT NULL DEFAULT 1,
          `createdon` datetime NULL,
          `updatedon` datetime NULL,
          PRIMARY KEY (`id`),
          KEY `practice_user` (`practice_id`, `user_id`),
          KEY `test_link_id` (`test_link_id`),
          KEY `course_module_user` (`course_id`, `module_id`, `user_id`),
          KEY `status` (`status`),
          KEY `is_latest` (`is_latest`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ", 'create attempts table');
} else {
    echo 'attempts table: exists' . PHP_EOL;
}

$attemptColumns = array(
    'practice_id' => "ALTER TABLE `{$tables['attempts']}` ADD `practice_id` int unsigned NOT NULL DEFAULT 0 AFTER `id`",
    'test_link_id' => "ALTER TABLE `{$tables['attempts']}` ADD `test_link_id` int unsigned NOT NULL DEFAULT 0 AFTER `practice_id`",
    'attempt_num' => "ALTER TABLE `{$tables['attempts']}` ADD `attempt_num` int unsigned NOT NULL DEFAULT 1 AFTER `user_id`",
    'attempt_no' => "ALTER TABLE `{$tables['attempts']}` ADD `attempt_no` int unsigned NOT NULL DEFAULT 1 AFTER `attempt_num`",
    'title' => "ALTER TABLE `{$tables['attempts']}` ADD `title` varchar(255) NOT NULL DEFAULT '' AFTER `deadline_at`",
    'is_latest' => "ALTER TABLE `{$tables['attempts']}` ADD `is_latest` tinyint unsigned NOT NULL DEFAULT 1 AFTER `reviewedby`",
);
foreach ($attemptColumns as $column => $sql) {
    if (!training_stage1_column_exists($modx, $tables['attempts'], $column)) {
        training_stage1_exec($modx, $sql, 'add attempts.' . $column);
    }
}

if (!training_stage1_table_exists($modx, $tables['messages'])) {
    training_stage1_exec($modx, "
        CREATE TABLE `{$tables['messages']}` (
          `id` int unsigned NOT NULL AUTO_INCREMENT,
          `attempt_id` int unsigned NOT NULL DEFAULT 0,
          `practice_id` int unsigned NOT NULL DEFAULT 0,
          `author_id` int unsigned NOT NULL DEFAULT 0,
          `author_type` varchar(50) NOT NULL DEFAULT 'user',
          `user_id` int unsigned NOT NULL DEFAULT 0,
          `sender_role` varchar(16) NOT NULL DEFAULT 'employee',
          `message` mediumtext NULL,
          `attachment` varchar(255) NOT NULL DEFAULT '',
          `is_system` tinyint(1) NOT NULL DEFAULT 0,
          `createdon` datetime NULL,
          PRIMARY KEY (`id`),
          KEY `attempt_id` (`attempt_id`),
          KEY `practice_id` (`practice_id`),
          KEY `author_id` (`author_id`),
          KEY `user_id` (`user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ", 'create messages table');
} else {
    echo 'messages table: exists' . PHP_EOL;
}

foreach (array(
    'user_id' => "ALTER TABLE `{$tables['messages']}` ADD `user_id` int unsigned NOT NULL DEFAULT 0 AFTER `author_type`",
    'sender_role' => "ALTER TABLE `{$tables['messages']}` ADD `sender_role` varchar(16) NOT NULL DEFAULT 'employee' AFTER `user_id`",
) as $column => $sql) {
    if (!training_stage1_column_exists($modx, $tables['messages'], $column)) {
        training_stage1_exec($modx, $sql, 'add messages.' . $column);
    }
}

if (!training_stage1_table_exists($modx, $tables['files'])) {
    training_stage1_exec($modx, "
        CREATE TABLE `{$tables['files']}` (
          `id` int unsigned NOT NULL AUTO_INCREMENT,
          `attempt_id` int unsigned NOT NULL DEFAULT 0,
          `message_id` int unsigned NOT NULL DEFAULT 0,
          `practice_id` int unsigned NOT NULL DEFAULT 0,
          `user_id` int unsigned NOT NULL DEFAULT 0,
          `path` varchar(500) NOT NULL DEFAULT '',
          `url` varchar(500) NOT NULL DEFAULT '',
          `name` varchar(255) NOT NULL DEFAULT '',
          `original_name` varchar(255) NOT NULL DEFAULT '',
          `mime` varchar(255) NOT NULL DEFAULT '',
          `extension` varchar(50) NOT NULL DEFAULT '',
          `size` int unsigned NOT NULL DEFAULT 0,
          `hash` varchar(64) NOT NULL DEFAULT '',
          `createdon` datetime NULL,
          PRIMARY KEY (`id`),
          KEY `attempt_id` (`attempt_id`),
          KEY `message_id` (`message_id`),
          KEY `practice_id` (`practice_id`),
          KEY `user_id` (`user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ", 'create files table');
} else {
    echo 'files table: exists' . PHP_EOL;
}

if (training_stage1_table_exists($modx, $tables['links'])) {
    if (!training_stage1_column_exists($modx, $tables['links'], 'link_type')) {
        training_stage1_exec($modx, "ALTER TABLE `{$tables['links']}` ADD `link_type` varchar(32) NOT NULL DEFAULT 'test' AFTER `usertest_test_id`", 'add test_links.link_type');
    }
    training_stage1_exec($modx, "UPDATE `{$tables['links']}` SET `link_type` = 'test' WHERE `link_type` = 'module' OR `link_type` = '' OR `link_type` IS NULL", 'normalize old test link_type');
} else {
    echo 'WARNING: test_links table not found: ' . $tables['links'] . PHP_EOL;
}

$settingKey = 'training.training_practice_resource_id';
$setting = $modx->getObject('modSystemSetting', array('key' => $settingKey));
if (!$setting) {
    $setting = $modx->newObject('modSystemSetting');
    $setting->fromArray(array(
        'key' => $settingKey,
        'value' => '176',
        'xtype' => 'textfield',
        'namespace' => 'training',
        'area' => 'training',
    ), '', true, true);
    $setting->save();
    echo 'setting created: ' . $settingKey . '=176' . PHP_EOL;
} else {
    echo 'setting exists: ' . $settingKey . '=' . $setting->get('value') . PHP_EOL;
}

$snippetName = 'trainingPracticePage';
$snippet = $modx->getObject('modSnippet', array('name' => $snippetName));
$snippetContent = "<?php\nreturn require MODX_CORE_PATH . 'components/training/elements/snippets/trainingPracticePage.php';";
if (!$snippet) {
    $snippet = $modx->newObject('modSnippet');
    $snippet->fromArray(array(
        'name' => $snippetName,
        'description' => 'Страница практического задания training',
        'snippet' => $snippetContent,
        'static' => 0,
        'source' => 1,
    ), '', true, true);
    $snippet->save();
    echo 'snippet created: ' . $snippetName . PHP_EOL;
} else {
    echo 'snippet exists: ' . $snippetName . PHP_EOL;
}

$practiceResourceId = (int)$modx->getOption($settingKey, null, 176);
$practiceResource = $practiceResourceId > 0 ? $modx->getObject('modResource', $practiceResourceId) : null;
if ($practiceResource) {
    echo 'practice resource exists: id=' . $practiceResourceId . ', pagetitle=' . $practiceResource->get('pagetitle') . PHP_EOL;
} else {
    echo 'WARNING: practice resource not found by id=' . $practiceResourceId . PHP_EOL;
    echo 'Create resource manually with template 14.Обучение and set system setting ' . $settingKey . ' to its id.' . PHP_EOL;
}

$modx->cacheManager->refresh(array(
    'system_settings' => array(),
    'resource' => array(),
    'scripts' => array(),
));

echo 'DONE' . PHP_EOL;
