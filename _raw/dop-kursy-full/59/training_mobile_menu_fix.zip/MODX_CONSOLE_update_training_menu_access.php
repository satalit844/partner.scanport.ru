<?php
/** @var modX $modx */
$name = 'trainingHasTrainingMenuAccess';
$code = "return include MODX_CORE_PATH . 'components/training/elements/snippets/trainingHasTrainingMenuAccess.php';";
$snippet = $modx->getObject('modSnippet', array('name' => $name));
if (!$snippet) {
    $snippet = $modx->newObject('modSnippet');
    $snippet->set('name', $name);
}
$snippet->set('snippet', $code);
$snippet->set('category', 0);
$snippet->save();
$modx->cacheManager->refresh();
return 'UPDATED: ' . $name;
