<?php
/**
 * trainingHasTrainingMenuAccess
 * Returns 1 when current user should see the expanded Training menu.
 * Checks real training access instead of hardcoded user ids.
 *
 * @var modX $modx
 */

if (!$modx->user || !(int)$modx->user->get('id')) {
    return '0';
}

$userId = (int)$modx->user->get('id');

if (!$modx->user->isAuthenticated('web') && !$modx->user->isAuthenticated('mgr')) {
    $contextKey = $modx->context ? (string)$modx->context->get('key') : '';
    if ($contextKey === '' || !$modx->user->isAuthenticated($contextKey)) {
        return '0';
    }
}

if ((int)$modx->user->get('sudo') === 1) {
    return '1';
}

if (method_exists($modx->user, 'isMember')) {
    if ($modx->user->isMember('Administrator') || $modx->user->isMember('Администратор')) {
        return '1';
    }
}

if (!function_exists('trainingMenuTableExists')) {
    function trainingMenuTableExists(modX $modx, $table)
    {
        $table = str_replace('`', '', (string)$table);
        if ($table === '') {
            return false;
        }

        $stmt = $modx->query('SHOW TABLES LIKE ' . $modx->quote($table));
        return $stmt && $stmt->fetch(PDO::FETCH_NUM);
    }
}

if (!function_exists('trainingMenuColumnExists')) {
    function trainingMenuColumnExists(modX $modx, $table, $column)
    {
        $table = str_replace('`', '', (string)$table);
        $column = str_replace('`', '', (string)$column);
        if ($table === '' || $column === '') {
            return false;
        }

        $stmt = $modx->query('SHOW COLUMNS FROM `' . $table . '` LIKE ' . $modx->quote($column));
        return $stmt && $stmt->fetch(PDO::FETCH_NUM);
    }
}

if (!function_exists('trainingMenuResolveTable')) {
    function trainingMenuResolveTable(modX $modx, array $names)
    {
        $prefix = (string)$modx->getOption('table_prefix', null, '');
        $candidates = array();

        foreach ($names as $name) {
            $name = trim((string)$name);
            if ($name === '') {
                continue;
            }

            $candidates[] = $name;
            $candidates[] = $prefix . $name;
            $candidates[] = rtrim($prefix, '_') . '_' . $name;

            if (strpos($name, 'training_') === 0) {
                $candidates[] = $prefix . 'partners' . $name;
                $candidates[] = $prefix . 'partnerstraining_' . substr($name, strlen('training_'));
                $candidates[] = rtrim($prefix, '_') . '_partnerstraining_' . substr($name, strlen('training_'));
            }
        }

        $candidates = array_values(array_unique(array_filter($candidates)));
        foreach ($candidates as $table) {
            if (trainingMenuTableExists($modx, $table)) {
                return str_replace('`', '', $table);
            }
        }

        return '';
    }
}

if (!function_exists('trainingMenuHasRows')) {
    function trainingMenuHasRows(modX $modx, $sql, array $params = array())
    {
        $stmt = $modx->prepare($sql);
        if (!$stmt || !$stmt->execute($params)) {
            if ($stmt && method_exists($stmt, 'errorInfo')) {
                $modx->log(modX::LOG_LEVEL_ERROR, '[trainingHasTrainingMenuAccess] SQL error: ' . print_r($stmt->errorInfo(), true) . "\n" . $sql);
            }
            return false;
        }

        return (int)$stmt->fetchColumn() > 0;
    }
}

$userCoursesTable = trainingMenuResolveTable($modx, array(
    'training_user_courses',
    'partnerstraining_user_courses',
));

if ($userCoursesTable !== '') {
    $where = '`user_id` = :user_id';
    if (trainingMenuColumnExists($modx, $userCoursesTable, 'status')) {
        $where .= ' AND (`status` IS NULL OR `status` <> "revoked")';
    }

    if (trainingMenuHasRows($modx, 'SELECT COUNT(*) FROM `' . $userCoursesTable . '` WHERE ' . $where . ' LIMIT 1', array(':user_id' => $userId))) {
        return '1';
    }
}

$courseAccessTable = trainingMenuResolveTable($modx, array(
    'training_course_access',
    'partnerstraining_course_access',
));

if ($courseAccessTable !== '') {
    $conditions = array();
    $params = array(':user_id' => $userId);

    if (trainingMenuColumnExists($modx, $courseAccessTable, 'principal_type') && trainingMenuColumnExists($modx, $courseAccessTable, 'principal_id')) {
        $conditions[] = '(`principal_type` = "user" AND `principal_id` = :user_id)';
    }

    if (trainingMenuColumnExists($modx, $courseAccessTable, 'user_id')) {
        $conditions[] = '`user_id` = :user_id';
    }

    if (trainingMenuColumnExists($modx, $courseAccessTable, 'assigned_by')) {
        $conditions[] = '`assigned_by` = :user_id';
    }

    $groupIds = array();
    $memberships = $modx->getCollection('modUserGroupMember', array('member' => $userId));
    foreach ($memberships as $membership) {
        $gid = (int)$membership->get('user_group');
        if ($gid > 0) {
            $groupIds[] = $gid;
        }
    }
    $groupIds = array_values(array_unique($groupIds));

    if (!empty($groupIds)) {
        $ph = array();
        foreach ($groupIds as $idx => $gid) {
            $key = ':group_' . $idx;
            $ph[] = $key;
            $params[$key] = $gid;
        }
        if (trainingMenuColumnExists($modx, $courseAccessTable, 'principal_type') && trainingMenuColumnExists($modx, $courseAccessTable, 'principal_id')) {
            $conditions[] = '(`principal_type` IN ("usergroup", "group") AND `principal_id` IN (' . implode(',', $ph) . '))';
        }
        if (trainingMenuColumnExists($modx, $courseAccessTable, 'usergroup_id')) {
            $conditions[] = '`usergroup_id` IN (' . implode(',', $ph) . ')';
        }
    }

    if (!empty($conditions)) {
        $where = '(' . implode(' OR ', $conditions) . ')';
        if (trainingMenuColumnExists($modx, $courseAccessTable, 'is_active')) {
            $where .= ' AND `is_active` = 1';
        }
        if (trainingMenuColumnExists($modx, $courseAccessTable, 'active_from')) {
            $where .= ' AND (`active_from` IS NULL OR `active_from` = "0000-00-00 00:00:00" OR `active_from` <= NOW())';
        }
        if (trainingMenuColumnExists($modx, $courseAccessTable, 'active_to')) {
            $where .= ' AND (`active_to` IS NULL OR `active_to` = "0000-00-00 00:00:00" OR `active_to` >= NOW())';
        }

        if (trainingMenuHasRows($modx, 'SELECT COUNT(*) FROM `' . $courseAccessTable . '` WHERE ' . $where . ' LIMIT 1', $params)) {
            return '1';
        }
    }
}

$managerLinkTable = trainingMenuResolveTable($modx, array(
    'training_user_manager_link',
    'partnerstraining_user_manager_link',
));

if ($managerLinkTable !== '') {
    $where = '`manager_user_id` = :user_id';
    if (trainingMenuColumnExists($modx, $managerLinkTable, 'is_active')) {
        $where .= ' AND `is_active` = 1';
    }

    if (trainingMenuHasRows($modx, 'SELECT COUNT(*) FROM `' . $managerLinkTable . '` WHERE ' . $where . ' LIMIT 1', array(':user_id' => $userId))) {
        return '1';
    }
}

return '0';
