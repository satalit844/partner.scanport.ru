<?php
/**
 * Run once in MODX Console.
 * Creates/updates snippet trainingHasTrainingMenuAccess to include file implementation.
 */

$name = 'trainingHasTrainingMenuAccess';
$content = "return include MODX_CORE_PATH . 'components/training/elements/snippets/trainingHasTrainingMenuAccess.php';";

/** @var modSnippet $snippet */
$snippet = $modx->getObject('modSnippet', array('name' => $name));
if (!$snippet) {
    $snippet = $modx->newObject('modSnippet');
    $snippet->set('name', $name);
}

$snippet->set('description', 'Checks whether current user should see the expanded Training menu.');
$snippet->set('snippet', $content);
$snippet->save();

$modx->cacheManager->refresh();

return 'OK: snippet ' . $name . ' updated. Clear MODX cache if needed.';
