FILES:
01.base
theme/css/style.css
core/components/training/elements/snippets/trainingHasTrainingMenuAccess.php
core/components/training/elements/snippets/snippet.trainingHasTrainingMenuAccess.php
MODX/MODX_CONSOLE_update_training_menu_snippet.php
