<?php

require_once dirname(dirname(__FILE__)) . '/_helpers.php';

class TrainingWebPlayerProgressProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    protected function saveLessonVideoProgressRow(TrainingProgressService $service, array $videoRow, $courseId, $moduleId, $lessonId, $userId, array $data = array())
    {
        if (!TrainingWebHelper::hasLessonVideoProgressTable($this->modx)) {
            return null;
        }

        $lessonVideoId = (int)$videoRow['id'];
        if ($lessonVideoId <= 0) {
            return null;
        }

        $table = TrainingWebHelper::lessonVideoProgressTable($this->modx);
        $existing = TrainingWebHelper::fetchLessonVideoProgressRow($this->modx, $courseId, $lessonId, $lessonVideoId, $userId);
        $durationSeconds = max(0, isset($data['duration_seconds']) ? (int)$data['duration_seconds'] : (int)$videoRow['duration_seconds']);
        if ($durationSeconds <= 0 && $existing) {
            $durationSeconds = max(0, (int)$existing['duration_seconds']);
        }

        $currentTime = max(0, isset($data['current_time']) ? (int)$data['current_time'] : 0);
        $inputMaxTime = max(0, isset($data['max_time']) ? (int)$data['max_time'] : $currentTime);
        $maxTime = max($currentTime, $inputMaxTime, $existing ? (int)$existing['max_time'] : 0);

        if ($durationSeconds > 0) {
            if ($currentTime > $durationSeconds) {
                $currentTime = $durationSeconds;
            }
            if ($maxTime > $durationSeconds) {
                $maxTime = $durationSeconds;
            }
        }

        $completed = !empty($data['completed']) ? 1 : 0;
        $thresholdPercent = (int)$service->getLessonCompletionThresholdPercent();
        $progressPercent = 0.0;
        if ($durationSeconds > 0) {
            $progressPercent = round(min(100, ($maxTime / $durationSeconds) * 100), 2);
            if ($progressPercent >= $thresholdPercent) {
                $completed = 1;
            }
        } elseif ($maxTime > 0) {
            $progressPercent = 100.0;
            $completed = 1;
        }

        $status = 'not_started';
        if ($completed) {
            $status = 'completed';
            $progressPercent = 100.0;
        } elseif ($maxTime > 0 || $currentTime > 0) {
            $status = 'in_progress';
        }

        $now = date('Y-m-d H:i:s');
        $watchedSeconds = max($maxTime, $existing ? (int)$existing['watched_seconds'] : 0);
        $completedOn = $completed ? ($existing && !empty($existing['completedon']) ? $existing['completedon'] : $now) : null;

        if ($existing) {
            $sql = 'UPDATE `' . $table . '` SET '
                . '`module_id` = :module_id, '
                . '`status` = :status, '
                . '`current_time` = :current_time, '
                . '`max_time` = :max_time, '
                . '`watched_seconds` = :watched_seconds, '
                . '`duration_seconds` = :duration_seconds, '
                . '`progress_percent` = :progress_percent, '
                . '`completed` = :completed, '
                . '`completedon` = :completedon, '
                . '`last_watch` = :last_watch, '
                . '`updatedon` = :updatedon '
                . 'WHERE `id` = :id';
            $params = array(
                ':id' => (int)$existing['id'],
                ':module_id' => (int)$moduleId,
                ':status' => $status,
                ':current_time' => $currentTime,
                ':max_time' => $maxTime,
                ':watched_seconds' => $watchedSeconds,
                ':duration_seconds' => $durationSeconds,
                ':progress_percent' => $progressPercent,
                ':completed' => $completed,
                ':completedon' => $completedOn,
                ':last_watch' => $now,
                ':updatedon' => $now,
            );
        } else {
            $sql = 'INSERT INTO `' . $table . '` '
                . '(`course_id`,`module_id`,`lesson_id`,`lesson_video_id`,`user_id`,`status`,`current_time`,`max_time`,`watched_seconds`,`duration_seconds`,`progress_percent`,`completed`,`completedon`,`last_watch`,`createdon`,`updatedon`) '
                . 'VALUES '
                . '(:course_id,:module_id,:lesson_id,:lesson_video_id,:user_id,:status,:current_time,:max_time,:watched_seconds,:duration_seconds,:progress_percent,:completed,:completedon,:last_watch,:createdon,:updatedon)';
            $params = array(
                ':course_id' => (int)$courseId,
                ':module_id' => (int)$moduleId,
                ':lesson_id' => (int)$lessonId,
                ':lesson_video_id' => $lessonVideoId,
                ':user_id' => (int)$userId,
                ':status' => $status,
                ':current_time' => $currentTime,
                ':max_time' => $maxTime,
                ':watched_seconds' => $watchedSeconds,
                ':duration_seconds' => $durationSeconds,
                ':progress_percent' => $progressPercent,
                ':completed' => $completed,
                ':completedon' => $completedOn,
                ':last_watch' => $now,
                ':createdon' => $now,
                ':updatedon' => $now,
            );
        }

        $stmt = $this->modx->prepare($sql);
        if (!$stmt || !$stmt->execute($params)) {
            return null;
        }

        return TrainingWebHelper::fetchLessonVideoProgressRow($this->modx, $courseId, $lessonId, $lessonVideoId, $userId);
    }

    protected function syncAggregatedLessonProgress(TrainingProgressService $service, array $videoRows, $courseId, $moduleId, $lessonId, $userId, $currentLessonVideoId)
    {
        $progressRows = TrainingWebHelper::fetchLessonVideoProgressRows($this->modx, $courseId, $lessonId, $userId);
        if (empty($progressRows)) {
            return null;
        }

        $aggregate = TrainingWebHelper::buildLessonVideoAggregate($videoRows, $progressRows, $currentLessonVideoId);
        return $service->saveLessonProgress($courseId, $moduleId, $lessonId, $userId, array(
            'current_time' => (int)$aggregate['current_time'],
            'max_time' => (int)$aggregate['max_time'],
            'duration_seconds' => (int)$aggregate['duration_seconds'],
            'completed' => (int)$aggregate['completed'] === 1 ? 1 : 0,
        ));
    }

    public function process()
    {
        if ($failure = TrainingWebHelper::requireAuth($this)) {
            return $failure;
        }

        $service = TrainingWebHelper::getProgressService($this->modx);
        $userId = (int)$this->modx->user->get('id');
        $moduleResourceId = (int)$this->getProperty('module', 0);
        $lessonId = (int)$this->getProperty('lesson', 0);
        $lessonVideoId = (int)$this->getProperty('video', $this->getProperty('lesson_video_id', 0));
        $currentTime = max(0, (int)$this->getProperty('current_time', 0));
        $durationSeconds = max(0, (int)$this->getProperty('duration_seconds', 0));
        $completed = (int)$this->getProperty('completed', 0) === 1;

        if ($moduleResourceId <= 0 || $lessonId <= 0) {
            return $this->failure('Не указан урок', array('code' => 400));
        }

        $resolved = $service->resolvePlayerContext($moduleResourceId, $lessonId, $userId);
        if (empty($resolved['success'])) {
            return $this->failure(isset($resolved['message']) ? $resolved['message'] : 'Недоступный урок', $resolved);
        }

        if ((int)$resolved['resolved_module_resource_id'] !== $moduleResourceId || (int)$resolved['resolved_lesson_id'] !== $lessonId) {
            return $this->failure('Урок недоступен для сохранения прогресса', array('code' => 403));
        }

        /** @var TrainingModule $module */
        $module = $resolved['module'];
        $courseId = (int)$resolved['course_id'];
        $moduleId = (int)$module->get('id');
        $videoRows = TrainingWebHelper::fetchLessonVideoRows($this->modx, $lessonId);

        if ($lessonVideoId > 0 && !empty($videoRows) && TrainingWebHelper::hasLessonVideoProgressTable($this->modx)) {
            $videoRow = TrainingWebHelper::findRowById($videoRows, $lessonVideoId);
            if (!$videoRow) {
                return $this->failure('Видео урока не найдено', array('code' => 404));
            }

            $qualityRows = TrainingWebHelper::fetchQualityRows($this->modx, $lessonId, $lessonVideoId);
            if (empty($qualityRows)) {
                return $this->failure('У выбранного видео нет активных качеств', array('code' => 404));
            }

            $videoProgress = $this->saveLessonVideoProgressRow($service, $videoRow, $courseId, $moduleId, $lessonId, $userId, array(
                'current_time' => $currentTime,
                'max_time' => $currentTime,
                'duration_seconds' => $durationSeconds > 0 ? $durationSeconds : (int)$videoRow['duration_seconds'],
                'completed' => $completed ? 1 : 0,
            ));

            if (!$videoProgress) {
                return $this->failure('Не удалось сохранить прогресс видео', array('code' => 500));
            }

            $lessonProgress = $this->syncAggregatedLessonProgress($service, $videoRows, $courseId, $moduleId, $lessonId, $userId, $lessonVideoId);
        } else {
            $videoProgress = null;
            $lessonProgress = $service->saveLessonProgress($courseId, $moduleId, $lessonId, $userId, array(
                'current_time' => $currentTime,
                'max_time' => $currentTime,
                'duration_seconds' => $durationSeconds,
                'completed' => $completed ? 1 : 0,
            ));
        }

        if (!$lessonProgress) {
            return $this->failure('Не удалось сохранить прогресс', array('code' => 500));
        }

        $moduleProgress = $service->recalculateModuleProgressFromLessons($courseId, $moduleId, $userId);
        $userCourse = $service->recalculateUserCourse($courseId, $userId);
        $nextLessonId = $service->getNextLessonId($moduleId, $lessonId, true);
        $nextAccessible = $nextLessonId > 0 ? $service->canAccessLesson($courseId, $moduleId, $nextLessonId, $userId) : false;

        return $this->success('', array(
            'lesson' => array(
                'id' => $lessonId,
                'progress_percent' => round((float)$lessonProgress->get('progress_percent')),
                'completed' => (int)$lessonProgress->get('completed') === 1 ? 1 : 0,
                'current_time' => (int)$lessonProgress->get('current_time'),
                'max_time' => (int)$lessonProgress->get('max_time'),
            ),
            'lesson_video' => array(
                'id' => $lessonVideoId,
                'progress_percent' => $videoProgress ? round((float)$videoProgress['progress_percent']) : 0,
                'completed' => $videoProgress ? ((int)$videoProgress['completed'] === 1 ? 1 : 0) : 0,
                'current_time' => $videoProgress ? (int)$videoProgress['current_time'] : 0,
                'max_time' => $videoProgress ? (int)$videoProgress['max_time'] : 0,
            ),
            'module' => array(
                'id' => $moduleId,
                'progress_percent' => $moduleProgress ? round((float)$moduleProgress->get('progress_percent')) : 0,
                'completed' => $moduleProgress ? ((int)$moduleProgress->get('completed') === 1 ? 1 : 0) : 0,
            ),
            'course' => array(
                'progress_percent' => $userCourse ? round((float)$userCourse->get('progress_percent')) : 0,
                'completed_modules' => $userCourse ? (int)$userCourse->get('completed_modules') : 0,
                'total_modules' => $userCourse ? (int)$userCourse->get('total_modules') : 0,
                'status' => $userCourse ? (string)$userCourse->get('status') : 'assigned',
            ),
            'nav' => array(
                'next_lesson_id' => $nextLessonId,
                'next_accessible' => $nextAccessible ? 1 : 0,
                'next_url' => $nextAccessible ? TrainingWebHelper::makePlayerUrl($this->modx, $moduleResourceId, $nextLessonId) : '',
            ),
        ));
    }
}

return 'TrainingWebPlayerProgressProcessor';
