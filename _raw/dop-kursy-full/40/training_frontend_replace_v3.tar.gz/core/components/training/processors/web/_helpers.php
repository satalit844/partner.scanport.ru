<?php

require_once dirname(dirname(__DIR__)) . '/model/training/training.class.php';
require_once dirname(dirname(__DIR__)) . '/model/training/services/trainingprogress.class.php';

class TrainingWebHelper
{
    protected static $resolvedTables = array();

    public static function getTraining(modX $modx)
    {
        return new Training($modx);
    }

    public static function getProgressService(modX $modx)
    {
        return new TrainingProgressService($modx, self::getTraining($modx));
    }

    public static function requireAuth(modProcessor $processor, $context = '')
    {
        $context = trim((string)$context);
        if ($context === '') {
            $context = $processor->modx->context ? $processor->modx->context->get('key') : 'web';
        }

        if (
            !$processor->modx->user
            || !(int)$processor->modx->user->get('id')
            || !$processor->modx->user->isAuthenticated($context)
        ) {
            return $processor->failure('Нужно авторизоваться', array('code' => 401, 'context' => $context));
        }

        return null;
    }

    public static function resolveCourseId(modX $modx, $courseId = 0, $resourceId = 0)
    {
        $courseId = (int)$courseId;
        $resourceId = (int)$resourceId;

        if ($courseId > 0) {
            return $courseId;
        }

        if ($resourceId <= 0) {
            return 0;
        }

        /** @var TrainingCourse $course */
        $course = $modx->getObject('TrainingCourse', array(
            'resource_id' => $resourceId,
        ));

        return $course ? (int)$course->get('id') : 0;
    }

    public static function esc($value)
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }

    public static function normalizePath($path)
    {
        return rtrim(str_replace('\\', '/', (string)$path), '/');
    }

    public static function formatDuration($seconds)
    {
        $seconds = (int)$seconds;
        if ($seconds <= 0) {
            return '0 сек';
        }

        $hours = (int)floor($seconds / 3600);
        $minutes = (int)floor(($seconds % 3600) / 60);
        $secs = (int)($seconds % 60);

        if ($hours > 0) {
            return $hours . ' ч ' . $minutes . ' мин';
        }
        if ($minutes > 0) {
            return $minutes . ' мин ' . $secs . ' сек';
        }
        return $secs . ' сек';
    }

    public static function makePlayerUrl(modX $modx, $moduleResourceId, $lessonId, $lessonVideoId = 0)
    {
        $moduleResourceId = (int)$moduleResourceId;
        $lessonId = (int)$lessonId;
        $lessonVideoId = (int)$lessonVideoId;
        $viewerResourceId = (int)$modx->getOption('training.training_view_resource_id', null, 174);
        if ($viewerResourceId <= 0 || $moduleResourceId <= 0 || $lessonId <= 0) {
            return '';
        }

        $baseUrl = $modx->makeUrl($viewerResourceId);
        if (!$baseUrl) {
            return '';
        }

        $query = array(
            'module' => $moduleResourceId,
            'lesson' => $lessonId,
        );
        if ($lessonVideoId > 0) {
            $query['video'] = $lessonVideoId;
        }

        return $baseUrl . (strpos($baseUrl, '?') === false ? '?' : '&') . http_build_query($query);
    }

    protected static function tableExists(modX $modx, $table)
    {
        $table = trim((string)$table);
        if ($table === '') {
            return false;
        }

        $stmt = $modx->prepare('SHOW TABLES LIKE :table');
        if (!$stmt) {
            return false;
        }

        if (!$stmt->execute(array(':table' => $table))) {
            return false;
        }

        return (bool)$stmt->fetchColumn();
    }

    public static function table(modX $modx, $name)
    {
        $name = ltrim((string)$name, '_');
        if ($name === '') {
            return '';
        }
        if (isset(self::$resolvedTables[$name])) {
            return self::$resolvedTables[$name];
        }

        $prefix = (string)$modx->getOption('table_prefix', null, 'modx_');
        $map = array(
            'lesson_videos' => array(
                $prefix . 'partnerstraining_lesson_videos',
                'modx_partnerstraining_lesson_videos',
                $modx->getTableName('TrainingLessonVideo'),
            ),
            'module_videos' => array(
                $prefix . 'partnerstraining_module_videos',
                'modx_partnerstraining_module_videos',
                $modx->getTableName('TrainingModuleVideo'),
            ),
            'module_slides' => array(
                $prefix . 'partnerstraining_module_slides',
                'modx_partnerstraining_module_slides',
                $modx->getTableName('TrainingModuleSlide'),
            ),
            'user_lesson_video_progress' => array(
                $prefix . 'partnerstraining_user_lesson_video_progress',
                'modx_partnerstraining_user_lesson_video_progress',
            ),
        );

        $candidates = isset($map[$name]) ? $map[$name] : array();
        foreach (array_values(array_unique(array_filter($candidates))) as $candidate) {
            if (self::tableExists($modx, $candidate)) {
                self::$resolvedTables[$name] = $candidate;
                return $candidate;
            }
        }

        self::$resolvedTables[$name] = $prefix . 'partnerstraining_' . $name;
        return self::$resolvedTables[$name];
    }

    public static function lessonVideosTable(modX $modx)
    {
        return self::table($modx, 'lesson_videos');
    }

    public static function qualitiesTable(modX $modx)
    {
        return self::table($modx, 'module_videos');
    }

    public static function slidesTable(modX $modx)
    {
        return self::table($modx, 'module_slides');
    }

    public static function lessonVideoProgressTable(modX $modx)
    {
        return self::table($modx, 'user_lesson_video_progress');
    }

    public static function hasLessonVideoProgressTable(modX $modx)
    {
        return self::tableExists($modx, self::lessonVideoProgressTable($modx));
    }

    public static function fetchLessonVideoRows(modX $modx, $lessonId)
    {
        $lessonId = (int)$lessonId;
        if ($lessonId <= 0) {
            return array();
        }

        $sql = 'SELECT * FROM `' . self::lessonVideosTable($modx) . '` WHERE `lesson_id` = :lesson_id AND `is_active` = 1 ORDER BY `is_default` DESC, `sort_order` ASC, `id` ASC';
        $stmt = $modx->prepare($sql);
        if (!$stmt || !$stmt->execute(array(':lesson_id' => $lessonId))) {
            return array();
        }

        return (array)$stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function fetchQualityRows(modX $modx, $lessonId, $lessonVideoId)
    {
        $lessonId = (int)$lessonId;
        $lessonVideoId = (int)$lessonVideoId;
        if ($lessonId <= 0 || $lessonVideoId <= 0) {
            return array();
        }

        $sql = 'SELECT * FROM `' . self::qualitiesTable($modx) . '` WHERE `lesson_id` = :lesson_id AND `lesson_video_id` = :lesson_video_id AND `is_active` = 1 ORDER BY `is_default` DESC, `height` DESC, `width` DESC, `bitrate` DESC, `id` ASC';
        $stmt = $modx->prepare($sql);
        if (!$stmt || !$stmt->execute(array(':lesson_id' => $lessonId, ':lesson_video_id' => $lessonVideoId))) {
            return array();
        }

        return (array)$stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function fetchSlideRows(modX $modx, $lessonId, $lessonVideoId = 0, $includeShared = true)
    {
        $lessonId = (int)$lessonId;
        $lessonVideoId = (int)$lessonVideoId;
        if ($lessonId <= 0) {
            return array();
        }

        $params = array(':lesson_id' => $lessonId);
        $where = ' `lesson_id` = :lesson_id AND `is_active` = 1 ';
        if ($lessonVideoId > 0) {
            if ($includeShared) {
                $where .= ' AND (`lesson_video_id` = :lesson_video_id OR `lesson_video_id` = 0) ';
            } else {
                $where .= ' AND `lesson_video_id` = :lesson_video_id ';
            }
            $params[':lesson_video_id'] = $lessonVideoId;
        } else {
            $where .= ' AND `lesson_video_id` = 0 ';
        }

        $sql = 'SELECT * FROM `' . self::slidesTable($modx) . '` WHERE ' . $where . ' ORDER BY `slide_no` ASC, `timecode_ms` ASC, `id` ASC';
        $stmt = $modx->prepare($sql);
        if (!$stmt || !$stmt->execute($params)) {
            return array();
        }

        return (array)$stmt->fetchAll(PDO::FETCH_ASSOC);
    }


    public static function fetchAllLessonSlides(modX $modx, $lessonId)
    {
        $lessonId = (int)$lessonId;
        if ($lessonId <= 0) {
            return array();
        }

        $sql = 'SELECT * FROM `' . self::slidesTable($modx) . '` WHERE `lesson_id` = :lesson_id AND `is_active` = 1 ORDER BY `slide_no` ASC, `timecode_ms` ASC, `id` ASC';
        $stmt = $modx->prepare($sql);
        if (!$stmt || !$stmt->execute(array(':lesson_id' => $lessonId))) {
            return array();
        }

        return (array)$stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function fetchLessonVideoProgressRows(modX $modx, $courseId, $lessonId, $userId)
    {
        $courseId = (int)$courseId;
        $lessonId = (int)$lessonId;
        $userId = (int)$userId;
        if ($courseId <= 0 || $lessonId <= 0 || $userId <= 0 || !self::hasLessonVideoProgressTable($modx)) {
            return array();
        }

        $sql = 'SELECT * FROM `' . self::lessonVideoProgressTable($modx) . '` WHERE `course_id` = :course_id AND `lesson_id` = :lesson_id AND `user_id` = :user_id';
        $stmt = $modx->prepare($sql);
        if (!$stmt || !$stmt->execute(array(':course_id' => $courseId, ':lesson_id' => $lessonId, ':user_id' => $userId))) {
            return array();
        }

        $rows = array();
        foreach ((array)$stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $rows[(int)$row['lesson_video_id']] = $row;
        }

        return $rows;
    }

    public static function fetchLessonVideoProgressRow(modX $modx, $courseId, $lessonId, $lessonVideoId, $userId)
    {
        $rows = self::fetchLessonVideoProgressRows($modx, $courseId, $lessonId, $userId);
        return isset($rows[(int)$lessonVideoId]) ? $rows[(int)$lessonVideoId] : null;
    }

    public static function findRowById(array $rows, $id)
    {
        $id = (int)$id;
        if ($id <= 0) {
            return null;
        }
        foreach ($rows as $row) {
            if ((int)$row['id'] === $id) {
                return $row;
            }
        }
        return null;
    }

    public static function pickActiveLessonVideoRow(modX $modx, $courseId, $lessonId, $userId, $requestedLessonVideoId = 0)
    {
        $videos = self::fetchLessonVideoRows($modx, $lessonId);
        if (empty($videos)) {
            return null;
        }

        $requestedLessonVideoId = (int)$requestedLessonVideoId;
        if ($requestedLessonVideoId > 0) {
            $requestedRow = self::findRowById($videos, $requestedLessonVideoId);
            if ($requestedRow) {
                return $requestedRow;
            }
        }

        $progressRows = self::fetchLessonVideoProgressRows($modx, $courseId, $lessonId, $userId);
        $bestRow = null;
        $bestScore = '';

        foreach ($videos as $row) {
            $videoId = (int)$row['id'];
            $progress = isset($progressRows[$videoId]) ? $progressRows[$videoId] : null;
            if (!$progress) {
                continue;
            }

            $hasProgress =
                (int)$progress['completed'] === 1
                || (int)$progress['max_time'] > 0
                || (int)$progress['current_time'] > 0
                || !empty($progress['last_watch'])
                || ((string)$progress['status'] !== '' && (string)$progress['status'] !== 'not_started');
            if (!$hasProgress) {
                continue;
            }

            $lastWatch = !empty($progress['last_watch']) ? strtotime((string)$progress['last_watch']) : 0;
            if ($lastWatch < 0) {
                $lastWatch = 0;
            }
            $incompleteStarted = (int)$progress['completed'] === 1 ? 0 : 1;
            $score = sprintf(
                '%01d|%010d|%010d|%010d|%01d|%05d|%05d',
                $incompleteStarted,
                $lastWatch,
                max((int)$progress['max_time'], (int)$progress['current_time']),
                (int)$progress['current_time'],
                (int)$row['is_default'],
                max(0, 99999 - (int)$row['sort_order']),
                max(0, 99999 - (int)$row['id'])
            );

            if ($bestRow === null || strcmp($score, $bestScore) > 0) {
                $bestRow = $row;
                $bestScore = $score;
            }
        }

        if ($bestRow) {
            return $bestRow;
        }

        foreach ($videos as $row) {
            if ((int)$row['is_default'] === 1) {
                return $row;
            }
        }

        return reset($videos);
    }

    public static function buildLessonVideoAggregate(array $videoRows, array $progressRows, $currentLessonVideoId = 0)
    {
        $currentLessonVideoId = (int)$currentLessonVideoId;
        $totalDuration = 0;
        $totalMaxTime = 0;
        $completedVideos = 0;
        $started = false;
        $currentTime = 0;
        $bestCurrentScore = -1;

        foreach ($videoRows as $videoRow) {
            $videoId = (int)(isset($videoRow['id']) ? $videoRow['id'] : 0);
            if ($videoId <= 0) {
                continue;
            }

            $videoDuration = max(0, (int)(isset($videoRow['duration_seconds']) ? $videoRow['duration_seconds'] : 0));
            $progress = isset($progressRows[$videoId]) ? $progressRows[$videoId] : null;

            if ($videoDuration <= 0 && $progress && isset($progress['duration_seconds'])) {
                $videoDuration = max(0, (int)$progress['duration_seconds']);
            }

            $totalDuration += $videoDuration;

            if (!$progress) {
                continue;
            }

            $rowCurrent = max(0, (int)$progress['current_time']);
            $rowMax = max($rowCurrent, max(0, (int)$progress['max_time']));
            if ($videoDuration > 0 && $rowMax > $videoDuration) {
                $rowMax = $videoDuration;
            }
            if ($videoDuration > 0 && $rowCurrent > $videoDuration) {
                $rowCurrent = $videoDuration;
            }

            $totalMaxTime += $rowMax;

            $rowStarted =
                (int)$progress['completed'] === 1
                || $rowCurrent > 0
                || $rowMax > 0
                || ((string)$progress['status'] !== '' && (string)$progress['status'] !== 'not_started');
            if ($rowStarted) {
                $started = true;
            }

            $rowCompleted = (int)$progress['completed'] === 1;
            if (!$rowCompleted && $videoDuration > 0 && $rowMax >= $videoDuration) {
                $rowCompleted = true;
            }
            if ($rowCompleted) {
                $completedVideos++;
            }

            $lastWatch = !empty($progress['last_watch']) ? strtotime((string)$progress['last_watch']) : 0;
            if ($lastWatch < 0) {
                $lastWatch = 0;
            }
            $score = ($currentLessonVideoId > 0 && $videoId === $currentLessonVideoId ? 1000000000 : 0)
                + ($lastWatch * 10)
                + $rowCurrent;
            if ($score > $bestCurrentScore) {
                $bestCurrentScore = $score;
                $currentTime = $rowCurrent;
            }
        }

        $completed = !empty($videoRows) && $completedVideos >= count($videoRows) ? 1 : 0;
        if ($currentTime <= 0) {
            $currentTime = $totalMaxTime;
        }

        return array(
            'duration_seconds' => $totalDuration,
            'max_time' => $totalMaxTime,
            'current_time' => $currentTime,
            'started' => $started ? 1 : 0,
            'completed' => $completed,
        );
    }
}
