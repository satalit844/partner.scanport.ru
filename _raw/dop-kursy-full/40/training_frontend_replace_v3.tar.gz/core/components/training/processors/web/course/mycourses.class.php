<?php

require_once dirname(dirname(__FILE__)) . '/_helpers.php';

class TrainingWebCourseMycoursesProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    protected function scalar($sql, array $params = array())
    {
        $stmt = $this->modx->prepare($sql);
        if (!$stmt || !$stmt->execute($params)) {
            return 0;
        }
        return (int)$stmt->fetchColumn();
    }

    protected function fetchAll($sql, array $params = array())
    {
        $stmt = $this->modx->prepare($sql);
        if (!$stmt || !$stmt->execute($params)) {
            return array();
        }
        return (array)$stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    protected function getTable($name)
    {
        $prefix = (string)$this->modx->getOption('table_prefix', null, 'modx_');
        return $prefix . $name;
    }

    protected function isTestPassed(array $link, $userId)
    {
        $testId = isset($link['usertest_test_id']) ? (int)$link['usertest_test_id'] : 0;
        if ($testId <= 0 || $userId <= 0) {
            return false;
        }

        $resultsTable = $this->getTable('partnersusertest_results');
        $sql = 'SELECT `test_point`, `max_point`, `status_id` FROM `' . $resultsTable . '` WHERE `test_id` = :test_id AND `user_id` = :user_id ORDER BY `id` DESC';
        $rows = $this->fetchAll($sql, array(':test_id' => $testId, ':user_id' => $userId));
        if (empty($rows)) {
            return false;
        }

        $minPassPercent = isset($link['min_pass_percent']) ? (float)$link['min_pass_percent'] : 0.0;
        foreach ($rows as $row) {
            $maxPoint = (float)$row['max_point'];
            $testPoint = (float)$row['test_point'];
            $statusId = (int)$row['status_id'];
            $percent = $maxPoint > 0 ? ($testPoint / $maxPoint) * 100 : ($statusId === 2 ? 100 : 0);
            if ($statusId === 2 && $percent >= $minPassPercent) {
                return true;
            }
            if ($minPassPercent <= 0 && $statusId === 2) {
                return true;
            }
        }

        return false;
    }

    protected function isPracticeCompleted(array $link, $userId)
    {
        $linkId = isset($link['id']) ? (int)$link['id'] : 0;
        if ($linkId <= 0 || $userId <= 0) {
            return false;
        }

        $table = $this->getTable('partnerstraining_practice_attempts');
        $statuses = array('accepted', 'completed', 'passed', 'reviewed');
        $in = array();
        $params = array(':test_link_id' => $linkId, ':user_id' => $userId);
        foreach ($statuses as $index => $status) {
            $key = ':status' . $index;
            $in[] = $key;
            $params[$key] = $status;
        }

        $sql = 'SELECT COUNT(*) FROM `' . $table . '` WHERE `test_link_id` = :test_link_id AND `user_id` = :user_id AND `status` IN (' . implode(',', $in) . ')';
        return $this->scalar($sql, $params) > 0;
    }

    public function process()
    {
        if ($failure = TrainingWebHelper::requireAuth($this)) {
            return $failure;
        }

        $userId = (int)$this->modx->user->get('id');
        $coursesTable = $this->getTable('partnerstraining_courses');
        $userCoursesTable = $this->getTable('partnerstraining_user_courses');
        $modulesTable = $this->getTable('partnerstraining_modules');
        $lessonsTable = $this->getTable('partnerstraining_module_lessons');
        $lessonVideosTable = TrainingWebHelper::lessonVideosTable($this->modx);
        $testLinksTable = $this->getTable('partnerstraining_test_links');
        $resourcesTable = $this->modx->getTableName('modResource');
        $videoProgressTable = TrainingWebHelper::lessonVideoProgressTable($this->modx);
        $hasVideoProgress = TrainingWebHelper::hasLessonVideoProgressTable($this->modx);

        $sql = 'SELECT uc.*, c.resource_id, r.pagetitle, r.id AS course_resource_id '
            . 'FROM `' . $userCoursesTable . '` uc '
            . 'INNER JOIN `' . $coursesTable . '` c ON c.id = uc.course_id '
            . 'LEFT JOIN `' . $resourcesTable . '` r ON r.id = c.resource_id '
            . 'WHERE uc.user_id = :user_id '
            . 'ORDER BY COALESCE(uc.last_activity, uc.startedon, uc.completedon) DESC, uc.course_id ASC';
        $rows = $this->fetchAll($sql, array(':user_id' => $userId));

        $results = array();
        foreach ($rows as $row) {
            $courseId = (int)$row['course_id'];
            $resourceId = (int)$row['resource_id'];
            if ($courseId <= 0 || $resourceId <= 0) {
                continue;
            }

            $courseResource = $this->modx->getObject('modResource', array('id' => $resourceId));
            $courseTitle = $courseResource ? (string)$courseResource->get('pagetitle') : (string)$row['pagetitle'];
            $courseUrl = $courseResource ? $this->modx->makeUrl($resourceId) : '';
            $courseImage = $courseResource ? trim((string)$courseResource->getTVValue('image_curse')) : '';
            if ($courseImage === '') {
                $courseImage = 'theme/images/training/image_2.jpg';
            }

            $videosTotalSql = 'SELECT COUNT(v.id) '
                . 'FROM `' . $lessonVideosTable . '` v '
                . 'INNER JOIN `' . $lessonsTable . '` l ON l.id = v.lesson_id AND l.is_active = 1 '
                . 'INNER JOIN `' . $modulesTable . '` m ON m.id = l.module_id AND m.is_active = 1 '
                . 'WHERE m.course_id = :course_id AND v.is_active = 1';
            $videosTotal = $this->scalar($videosTotalSql, array(':course_id' => $courseId));

            $videosCompleted = 0;
            if ($hasVideoProgress) {
                $videosCompleted = $this->scalar(
                    'SELECT COUNT(*) FROM `' . $videoProgressTable . '` WHERE `course_id` = :course_id AND `user_id` = :user_id AND `completed` = 1',
                    array(':course_id' => $courseId, ':user_id' => $userId)
                );
            }

            $testLinks = $this->fetchAll(
                'SELECT * FROM `' . $testLinksTable . '` WHERE `course_id` = :course_id ORDER BY `module_id` ASC, `sort_order` ASC, `id` ASC',
                array(':course_id' => $courseId)
            );
            $testsTotal = 0;
            $testsPassed = 0;
            $practicesTotal = 0;
            $practicesCompleted = 0;
            foreach ($testLinks as $link) {
                $linkType = isset($link['link_type']) ? (string)$link['link_type'] : 'test';
                if ($linkType === 'practice') {
                    $practicesTotal++;
                    if ($this->isPracticeCompleted($link, $userId)) {
                        $practicesCompleted++;
                    }
                } else {
                    $testsTotal++;
                    if ($this->isTestPassed($link, $userId)) {
                        $testsPassed++;
                    }
                }
            }

            $progressPercent = (int)round((float)$row['progress_percent']);
            $status = (string)$row['status'];
            $itemClass = 'is-new';
            $state = 'new';
            $statusText = 'Не начат';
            if ($status === 'completed' || $progressPercent >= 100) {
                $itemClass = 'is-done';
                $state = 'done';
                $statusText = 'Курс завершен';
            } elseif ($status === 'in_progress' || $progressPercent > 0) {
                $itemClass = 'is-progress';
                $state = 'progress';
                $statusText = 'В процессе';
            }

            $results[] = array(
                'id' => $courseId,
                'title' => $courseTitle,
                'pagetitle' => $courseTitle,
                'url' => $courseUrl,
                'image' => $courseImage,
                'progress_percent' => $progressPercent,
                'videos_total' => $videosTotal,
                'videos_completed' => $videosCompleted,
                'tests_total' => $testsTotal,
                'tests_passed' => $testsPassed,
                'practices_total' => $practicesTotal,
                'practices_completed' => $practicesCompleted,
                'videos_text' => $videosCompleted . '/' . $videosTotal,
                'tests_text' => $testsPassed . '/' . $testsTotal,
                'practices_text' => $practicesCompleted . '/' . $practicesTotal,
                'state' => $state,
                'item_class' => $itemClass,
                'status_text' => $statusText,
            );
        }

        return $this->success('', array('results' => $results));
    }
}

return 'TrainingWebCourseMycoursesProcessor';
