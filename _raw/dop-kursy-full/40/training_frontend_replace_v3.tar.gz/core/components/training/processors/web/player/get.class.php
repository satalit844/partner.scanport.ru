<?php

require_once dirname(dirname(__FILE__)) . '/_helpers.php';

class TrainingWebPlayerGetProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    protected function formatPlayerTime($seconds)
    {
        $seconds = max(0, (int)$seconds);
        $hours = (int)floor($seconds / 3600);
        $minutes = (int)floor(($seconds % 3600) / 60);
        $secs = (int)($seconds % 60);

        if ($hours > 0) {
            return $hours . ':' . str_pad((string)$minutes, 2, '0', STR_PAD_LEFT) . ':' . str_pad((string)$secs, 2, '0', STR_PAD_LEFT);
        }

        return $minutes . ':' . str_pad((string)$secs, 2, '0', STR_PAD_LEFT);
    }

    protected function buildSlides($lessonId, array $lessonVideos, $currentLessonVideoId)
    {
        $items = array();
        $videoMap = array();
        $videoIndex = 0;

        foreach ($lessonVideos as $videoItem) {
            $videoId = (int)$videoItem['id'];
            if ($videoId <= 0) {
                continue;
            }
            $videoIndex++;
            $videoMap[$videoId] = array(
                'index' => $videoIndex,
                'title' => (string)$videoItem['title'],
                'duration_text' => (string)$videoItem['duration_text'],
                'thumb' => (string)$videoItem['thumb'],
                'is_current' => (int)$videoItem['id'] === (int)$currentLessonVideoId ? 1 : 0,
            );
        }

        foreach (TrainingWebHelper::fetchAllLessonSlides($this->modx, $lessonId) as $slide) {
            $slideVideoId = (int)$slide['lesson_video_id'];
            $videoInfo = $slideVideoId > 0 && isset($videoMap[$slideVideoId]) ? $videoMap[$slideVideoId] : null;
            $slideTitle = $videoInfo ? $videoInfo['title'] : ('Слайд ' . (int)$slide['slide_no']);
            $metaParts = array();
            if ($videoInfo) {
                $metaParts[] = 'Видео ' . (int)$videoInfo['index'];
                if ((string)$videoInfo['duration_text'] !== '') {
                    $metaParts[] = (string)$videoInfo['duration_text'];
                }
            } else {
                $metaParts[] = 'Общий слайд';
            }
            if ((int)$slide['timecode_ms'] > 0) {
                $metaParts[] = $this->formatPlayerTime((int)floor(((int)$slide['timecode_ms']) / 1000));
            }

            $items[] = array(
                'id' => (int)$slide['id'],
                'title' => $slideTitle,
                'image' => (string)$slide['image'],
                'thumb' => (string)$slide['image'],
                'slide_no' => (int)$slide['slide_no'],
                'timecode_ms' => (int)$slide['timecode_ms'],
                'lesson_video_id' => $slideVideoId,
                'video_title' => $videoInfo ? (string)$videoInfo['title'] : '',
                'video_index' => $videoInfo ? (int)$videoInfo['index'] : 0,
                'video_duration_text' => $videoInfo ? (string)$videoInfo['duration_text'] : '',
                'is_shared' => $slideVideoId === 0 ? 1 : 0,
                'is_current_video' => $videoInfo ? (int)$videoInfo['is_current'] : 0,
                'meta_text' => implode(' • ', array_filter($metaParts)),
            );
        }

        return $items;
    }

    protected function buildQualityItems($lessonId, $lessonVideoId)
    {
        $items = array();
        foreach (TrainingWebHelper::fetchQualityRows($this->modx, $lessonId, $lessonVideoId) as $qualityRow) {
            $items[] = array(
                'id' => (int)$qualityRow['id'],
                'lesson_video_id' => (int)$qualityRow['lesson_video_id'],
                'quality' => (string)$qualityRow['quality'],
                'mime' => (string)$qualityRow['mime'],
                'file_path' => (string)$qualityRow['file_path'],
                'width' => (int)$qualityRow['width'],
                'height' => (int)$qualityRow['height'],
                'bitrate' => (int)$qualityRow['bitrate'],
                'is_default' => (int)$qualityRow['is_default'] === 1 ? 1 : 0,
            );
        }
        return $items;
    }

    protected function buildLessonVideos(TrainingModuleLesson $lesson, $courseId, $userId, $currentLessonVideoId)
    {
        $items = array();
        $lessonId = (int)$lesson->get('id');
        $lessonPreview = trim((string)$lesson->get('preview_image'));
        $progressRows = TrainingWebHelper::fetchLessonVideoProgressRows($this->modx, $courseId, $lessonId, $userId);
        $videoRows = TrainingWebHelper::fetchLessonVideoRows($this->modx, $lessonId);

        foreach ($videoRows as $videoRow) {
            $videoId = (int)$videoRow['id'];
            $qualityItems = $this->buildQualityItems($lessonId, $videoId);
            $defaultQuality = !empty($qualityItems) ? reset($qualityItems) : null;
            foreach ($qualityItems as $qualityItem) {
                if ((int)$qualityItem['is_default'] === 1) {
                    $defaultQuality = $qualityItem;
                    break;
                }
            }

            $videoProgress = isset($progressRows[$videoId]) ? $progressRows[$videoId] : null;
            $videoDuration = max(0, (int)$videoRow['duration_seconds']);
            if ($videoDuration <= 0 && $videoProgress) {
                $videoDuration = max(0, (int)$videoProgress['duration_seconds']);
            }

            $maxTime = $videoProgress ? max((int)$videoProgress['max_time'], (int)$videoProgress['current_time']) : 0;
            if ($videoDuration > 0 && $maxTime > $videoDuration) {
                $maxTime = $videoDuration;
            }
            $currentTime = $videoProgress ? min($videoDuration > 0 ? $videoDuration : PHP_INT_MAX, max(0, (int)$videoProgress['current_time'])) : 0;
            $completed = $videoProgress && (int)$videoProgress['completed'] === 1;
            if (!$completed && $videoDuration > 0 && $maxTime >= $videoDuration) {
                $completed = true;
            }
            $progressPercent = 0;
            if ($videoDuration > 0) {
                $progressPercent = (int)round(min(100, ($maxTime / $videoDuration) * 100));
            } elseif ($completed) {
                $progressPercent = 100;
            }

            $resumeTime = !$completed ? $maxTime : 0;
            $thumb = $lessonPreview;
            $videoSlides = TrainingWebHelper::fetchSlideRows($this->modx, $lessonId, $videoId, false);
            if (!empty($videoSlides[0]['image'])) {
                $thumb = (string)$videoSlides[0]['image'];
            } elseif ($thumb === '') {
                $sharedSlides = TrainingWebHelper::fetchSlideRows($this->modx, $lessonId, 0, false);
                if (!empty($sharedSlides[0]['image'])) {
                    $thumb = (string)$sharedSlides[0]['image'];
                }
            }

            $title = trim((string)$videoRow['title']);
            if ($title === '') {
                $title = 'Видео ' . ((int)$videoRow['sort_order'] > 0 ? (int)$videoRow['sort_order'] : $videoId);
            }

            $statusText = 'Не начат';
            if (empty($qualityItems)) {
                $statusText = 'Видео недоступно';
            } elseif ($completed) {
                $statusText = 'Просмотрено';
            } elseif ($resumeTime > 0) {
                $statusText = 'Продолжить с ' . $this->formatPlayerTime($resumeTime);
            }

            $metaParts = array();
            if ($videoDuration > 0) {
                $metaParts[] = TrainingWebHelper::formatDuration($videoDuration);
            }
            $metaParts[] = $statusText;

            $items[] = array(
                'id' => $videoId,
                'title' => $title,
                'sort_order' => (int)$videoRow['sort_order'],
                'duration_seconds' => $videoDuration,
                'duration_text' => TrainingWebHelper::formatDuration($videoDuration),
                'progress_percent' => $progressPercent,
                'completed' => $completed ? 1 : 0,
                'current_time' => $currentTime,
                'max_time' => $maxTime,
                'resume_time' => $resumeTime,
                'thumb' => $thumb,
                'status_text' => $statusText,
                'meta_text' => implode(' • ', array_filter($metaParts)),
                'qualities_total' => count($qualityItems),
                'slides_total' => count($videoSlides),
                'is_default' => (int)$videoRow['is_default'] === 1 ? 1 : 0,
                'is_current' => $videoId === (int)$currentLessonVideoId ? 1 : 0,
                'is_available' => !empty($qualityItems) ? 1 : 0,
                'video_url' => $defaultQuality ? (string)$defaultQuality['file_path'] : '',
                'quality' => $defaultQuality ? (string)$defaultQuality['quality'] : '',
            );
        }

        return $items;
    }

    public function process()
    {
        if ($failure = TrainingWebHelper::requireAuth($this)) {
            return $failure;
        }

        $service = TrainingWebHelper::getProgressService($this->modx);
        $userId = (int)$this->modx->user->get('id');
        $moduleResourceId = (int)$this->getProperty('module', 0);
        $lessonId = (int)$this->getProperty('lesson', 0);
        $requestedLessonVideoId = (int)$this->getProperty('video', $this->getProperty('lesson_video_id', 0));

        if ($moduleResourceId <= 0) {
            return $this->failure('Не указан модуль', array('code' => 400));
        }

        $resolved = $service->resolvePlayerContext($moduleResourceId, $lessonId, $userId);
        if (empty($resolved['success'])) {
            return $this->failure(isset($resolved['message']) ? $resolved['message'] : 'Не удалось открыть урок', $resolved);
        }

        /** @var TrainingModule $module */
        $module = $resolved['module'];
        /** @var TrainingModuleLesson $lesson */
        $lesson = $resolved['lesson'];
        $courseId = (int)$resolved['course_id'];
        $moduleId = (int)$module->get('id');
        $lessonId = (int)$lesson->get('id');

        $service->syncUserCourseForUser($courseId, $userId);

        $activeLessonVideo = TrainingWebHelper::pickActiveLessonVideoRow(
            $this->modx,
            $courseId,
            $lessonId,
            $userId,
            $requestedLessonVideoId
        );
        if (!$activeLessonVideo) {
            return $this->failure('У урока нет активного видео', array('code' => 404));
        }

        $activeLessonVideoId = (int)$activeLessonVideo['id'];
        $qualityItems = $this->buildQualityItems($lessonId, $activeLessonVideoId);
        if (empty($qualityItems)) {
            $videoRows = TrainingWebHelper::fetchLessonVideoRows($this->modx, $lessonId);
            foreach ($videoRows as $candidateVideo) {
                $candidateQualities = $this->buildQualityItems($lessonId, (int)$candidateVideo['id']);
                if (!empty($candidateQualities)) {
                    $activeLessonVideo = $candidateVideo;
                    $activeLessonVideoId = (int)$candidateVideo['id'];
                    $qualityItems = $candidateQualities;
                    break;
                }
            }
        }
        if (empty($qualityItems)) {
            return $this->failure('У выбранного видео нет активных качеств', array('code' => 404));
        }

        $progressRows = TrainingWebHelper::fetchLessonVideoProgressRows($this->modx, $courseId, $lessonId, $userId);
        if (!empty($progressRows)) {
            $aggregate = TrainingWebHelper::buildLessonVideoAggregate(
                TrainingWebHelper::fetchLessonVideoRows($this->modx, $lessonId),
                $progressRows,
                $activeLessonVideoId
            );
            $lessonProgress = $service->saveLessonProgress($courseId, $moduleId, $lessonId, $userId, array(
                'current_time' => (int)$aggregate['current_time'],
                'max_time' => (int)$aggregate['max_time'],
                'duration_seconds' => (int)$aggregate['duration_seconds'],
                'completed' => (int)$aggregate['completed'] === 1 ? 1 : 0,
            ));
        } else {
            $lessonProgress = $service->ensureLessonProgress($courseId, $lessonId, $userId, (int)$lesson->get('duration_seconds'));
        }

        $moduleProgress = $service->recalculateModuleProgressFromLessons($courseId, $moduleId, $userId);
        $userCourse = $service->recalculateUserCourse($courseId, $userId);

        /** @var TrainingCourse $course */
        $course = $this->modx->getObject('TrainingCourse', array('id' => $courseId));
        /** @var modResource $courseResource */
        $courseResource = $course ? $course->getOne('Resource') : null;
        /** @var modResource $moduleResource */
        $moduleResource = $module->getOne('Resource');

        $prevLessonId = $service->getPreviousLessonId($moduleId, $lessonId, true);
        $nextLessonId = $service->getNextLessonId($moduleId, $lessonId, true);
        $prevUrl = $prevLessonId > 0 ? TrainingWebHelper::makePlayerUrl($this->modx, (int)$module->get('resource_id'), $prevLessonId, 0) : '';
        $nextUrl = ($nextLessonId > 0 && $service->canAccessLesson($courseId, $moduleId, $nextLessonId, $userId))
            ? TrainingWebHelper::makePlayerUrl($this->modx, (int)$module->get('resource_id'), $nextLessonId, 0)
            : '';

        $lessons = array();
        $lessonRows = $service->getModuleLessons($moduleId, true, true);
        foreach ($lessonRows as $item) {
            $itemId = (int)$item->get('id');
            $itemProgress = $service->getLessonProgress($courseId, $itemId, $userId);
            $itemCompleted = $itemProgress && (int)$itemProgress->get('completed') === 1;
            $itemPercent = $itemProgress ? (float)$itemProgress->get('progress_percent') : 0;
            $itemLocked = !$service->canAccessLesson($courseId, $moduleId, $itemId, $userId);
            $itemTitle = trim((string)$item->get('title'));
            if ($itemTitle === '') {
                $itemTitle = 'Урок ' . (((int)$item->get('sort_order') > 0 ? (int)$item->get('sort_order') : $itemId));
            }
            $lessons[] = array(
                'id' => $itemId,
                'title' => $itemTitle,
                'locked' => $itemLocked ? 1 : 0,
                'completed' => $itemCompleted ? 1 : 0,
                'progress_percent' => (int)round($itemPercent),
                'is_current' => $itemId === $lessonId ? 1 : 0,
                'url' => $itemLocked ? '' : TrainingWebHelper::makePlayerUrl($this->modx, (int)$module->get('resource_id'), $itemId, 0),
            );
        }

        $currentIndex = 0;
        $totalLessons = count($lessons);
        foreach ($lessons as $index => $lessonRow) {
            if ((int)$lessonRow['is_current'] === 1) {
                $currentIndex = $index + 1;
                break;
            }
        }

        $currentVideoIndex = 0;
        $totalVideos = count($lessonVideos);
        foreach ($lessonVideos as $videoListItem) {
            if ((int)$videoListItem['id'] === $activeLessonVideoId) {
                $currentVideoIndex = (int)$videoListItem['sort_order'] > 0 ? (int)$videoListItem['sort_order'] : ($currentVideoIndex + 1);
                break;
            }
            $currentVideoIndex++;
        }
        if ($currentVideoIndex <= 0 && $totalVideos > 0) {
            $currentVideoIndex = 1;
        }

        $videoProgress = isset($progressRows[$activeLessonVideoId]) ? $progressRows[$activeLessonVideoId] : null;
        $currentVideoDuration = max(0, (int)$activeLessonVideo['duration_seconds']);
        if ($currentVideoDuration <= 0 && $videoProgress) {
            $currentVideoDuration = max(0, (int)$videoProgress['duration_seconds']);
        }
        $videoMaxTime = $videoProgress ? max((int)$videoProgress['max_time'], (int)$videoProgress['current_time']) : 0;
        if ($currentVideoDuration > 0 && $videoMaxTime > $currentVideoDuration) {
            $videoMaxTime = $currentVideoDuration;
        }
        $videoCompleted = $videoProgress && (int)$videoProgress['completed'] === 1;
        if (!$videoCompleted && $currentVideoDuration > 0 && $videoMaxTime >= $currentVideoDuration) {
            $videoCompleted = true;
        }
        $videoResumeTime = !$videoCompleted ? $videoMaxTime : 0;
        $videoProgressPercent = 0;
        if ($currentVideoDuration > 0) {
            $videoProgressPercent = (int)round(min(100, ($videoMaxTime / $currentVideoDuration) * 100));
        } elseif ($videoCompleted) {
            $videoProgressPercent = 100;
        }

        $slides = $this->buildSlides($lessonId, $lessonVideos, $activeLessonVideoId);
        $poster = '';
        foreach ($slides as $slideItem) {
            if ((int)$slideItem['lesson_video_id'] === $activeLessonVideoId && (string)$slideItem['image'] !== '') {
                $poster = (string)$slideItem['image'];
                break;
            }
        }
        if ($poster === '') {
            foreach ($slides as $slideItem) {
                if ((int)$slideItem['lesson_video_id'] === 0 && (string)$slideItem['image'] !== '') {
                    $poster = (string)$slideItem['image'];
                    break;
                }
            }
        }
        if ($poster === '' && (string)$lesson->get('preview_image') !== '') {
            $poster = (string)$lesson->get('preview_image');
        } elseif ($poster === '' && $courseResource) {
            $poster = trim((string)$courseResource->getTVValue('image_curse'));
        }

        $defaultQuality = reset($qualityItems);
        foreach ($qualityItems as $qualityItem) {
            if ((int)$qualityItem['is_default'] === 1) {
                $defaultQuality = $qualityItem;
                break;
            }
        }

        return $this->success('', array(
            'redirected' => !empty($resolved['redirected']) ? 1 : 0,
            'requested_module_resource_id' => (int)$resolved['requested_module_resource_id'],
            'requested_lesson_id' => (int)$resolved['requested_lesson_id'],
            'requested_lesson_video_id' => $requestedLessonVideoId,
            'resolved_module_resource_id' => (int)$resolved['resolved_module_resource_id'],
            'resolved_lesson_id' => (int)$resolved['resolved_lesson_id'],
            'resolved_lesson_video_id' => $activeLessonVideoId,
            'completion_threshold_percent' => (int)$service->getLessonCompletionThresholdPercent(),
            'course' => array(
                'id' => $courseId,
                'resource_id' => $course ? (int)$course->get('resource_id') : 0,
                'title' => $courseResource ? (string)$courseResource->get('pagetitle') : '',
                'url' => $courseResource ? $this->modx->makeUrl((int)$courseResource->get('id')) : '',
                'progress_percent' => $userCourse ? round((float)$userCourse->get('progress_percent')) : 0,
                'completed_modules' => $userCourse ? (int)$userCourse->get('completed_modules') : 0,
                'total_modules' => $userCourse ? (int)$userCourse->get('total_modules') : 0,
                'status' => $userCourse ? (string)$userCourse->get('status') : 'assigned',
            ),
            'module' => array(
                'id' => $moduleId,
                'resource_id' => (int)$module->get('resource_id'),
                'title' => $moduleResource ? (string)$moduleResource->get('pagetitle') : '',
                'progress_percent' => $moduleProgress ? round((float)$moduleProgress->get('progress_percent')) : 0,
                'completed' => $moduleProgress ? ((int)$moduleProgress->get('completed') === 1 ? 1 : 0) : 0,
                'duration_seconds' => $moduleProgress ? (int)$moduleProgress->get('duration_seconds') : 0,
                'duration_text' => TrainingWebHelper::formatDuration($moduleProgress ? (int)$moduleProgress->get('duration_seconds') : 0),
            ),
            'lesson' => array(
                'id' => $lessonId,
                'title' => (string)$lesson->get('title'),
                'description' => (string)$lesson->get('description'),
                'duration_seconds' => max((int)$lesson->get('duration_seconds'), $lessonProgress ? (int)$lessonProgress->get('duration_seconds') : 0),
                'duration_text' => TrainingWebHelper::formatDuration(max((int)$lesson->get('duration_seconds'), $lessonProgress ? (int)$lessonProgress->get('duration_seconds') : 0)),
                'progress_percent' => $lessonProgress ? round((float)$lessonProgress->get('progress_percent')) : 0,
                'completed' => $lessonProgress ? ((int)$lessonProgress->get('completed') === 1 ? 1 : 0) : 0,
                'current_time' => $lessonProgress ? (int)$lessonProgress->get('current_time') : 0,
                'max_time' => $lessonProgress ? (int)$lessonProgress->get('max_time') : 0,
                'poster' => $poster,
            ),
            'lesson_video' => array(
                'id' => $activeLessonVideoId,
                'title' => trim((string)$activeLessonVideo['title']) !== '' ? (string)$activeLessonVideo['title'] : ('Видео ' . $activeLessonVideoId),
                'sort_order' => (int)$activeLessonVideo['sort_order'],
                'duration_seconds' => $currentVideoDuration,
                'duration_text' => TrainingWebHelper::formatDuration($currentVideoDuration),
                'progress_percent' => $videoProgressPercent,
                'completed' => $videoCompleted ? 1 : 0,
                'current_time' => $videoProgress ? (int)$videoProgress['current_time'] : 0,
                'max_time' => $videoMaxTime,
                'resume_time' => $videoResumeTime,
                'poster' => $poster,
                'video_url' => $defaultQuality ? (string)$defaultQuality['file_path'] : '',
                'quality' => $defaultQuality ? (string)$defaultQuality['quality'] : '',
                'is_default' => (int)$activeLessonVideo['is_default'] === 1 ? 1 : 0,
                'current_index' => $currentVideoIndex,
                'total_videos' => $totalVideos,
            ),
            'lesson_videos' => $lessonVideos,
            'videos' => $qualityItems,
            'slides' => $slides,
            'lessons' => $lessons,
            'nav' => array(
                'current_index' => $currentIndex,
                'total_lessons' => $totalLessons,
                'prev_lesson_id' => $prevLessonId,
                'prev_url' => $prevUrl,
                'next_lesson_id' => $nextLessonId,
                'next_url' => $nextUrl,
                'next_locked' => ($nextLessonId > 0 && $nextUrl === '') ? 1 : 0,
            ),
        ));
    }
}

return 'TrainingWebPlayerGetProcessor';
