<?php
/** @var modX $modx */
/** @var array $scriptProperties */

$corePath = $modx->getOption(
    'training.core_path',
    null,
    $modx->getOption('core_path') . 'components/training/'
);
require_once $corePath . 'processors/web/_helpers.php';

if (!function_exists('trainingCoursePageTable')) {
    function trainingCoursePageTable(modX $modx, $name)
    {
        return (string)$modx->getOption('table_prefix', null, 'modx_') . $name;
    }
}

if (!function_exists('trainingCoursePageEsc')) {
    function trainingCoursePageEsc($value)
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('trainingCoursePageFetchAll')) {
    function trainingCoursePageFetchAll(modX $modx, $sql, array $params = array())
    {
        $stmt = $modx->prepare($sql);
        if (!$stmt || !$stmt->execute($params)) {
            return array();
        }
        return (array)$stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

if (!function_exists('trainingCoursePageScalar')) {
    function trainingCoursePageScalar(modX $modx, $sql, array $params = array())
    {
        $stmt = $modx->prepare($sql);
        if (!$stmt || !$stmt->execute($params)) {
            return 0;
        }
        return (int)$stmt->fetchColumn();
    }
}

if (!function_exists('trainingCoursePageStatusChip')) {
    function trainingCoursePageStatusChip($text, $class = 'label-chip--purple')
    {
        return '<span class="label-chip ' . trainingCoursePageEsc($class) . '"><span>' . trainingCoursePageEsc($text) . '</span></span>';
    }
}

if (!function_exists('trainingCoursePageTestPassed')) {
    function trainingCoursePageTestPassed(modX $modx, array $link, $userId)
    {
        $testId = isset($link['usertest_test_id']) ? (int)$link['usertest_test_id'] : 0;
        if ($testId <= 0 || $userId <= 0) {
            return false;
        }
        $table = trainingCoursePageTable($modx, 'partnersusertest_results');
        $rows = trainingCoursePageFetchAll(
            $modx,
            'SELECT `test_point`, `max_point`, `status_id` FROM `' . $table . '` WHERE `test_id` = :test_id AND `user_id` = :user_id ORDER BY `id` DESC',
            array(':test_id' => $testId, ':user_id' => $userId)
        );
        if (empty($rows)) {
            return false;
        }
        $minPassPercent = isset($link['min_pass_percent']) ? (float)$link['min_pass_percent'] : 0.0;
        foreach ($rows as $row) {
            $maxPoint = (float)$row['max_point'];
            $testPoint = (float)$row['test_point'];
            $statusId = (int)$row['status_id'];
            $percent = $maxPoint > 0 ? ($testPoint / $maxPoint) * 100 : ($statusId === 2 ? 100 : 0);
            if ($statusId === 2 && ($minPassPercent <= 0 || $percent >= $minPassPercent)) {
                return true;
            }
        }
        return false;
    }
}

if (!function_exists('trainingCoursePagePracticeDone')) {
    function trainingCoursePagePracticeDone(modX $modx, array $link, $userId)
    {
        $linkId = isset($link['id']) ? (int)$link['id'] : 0;
        if ($linkId <= 0 || $userId <= 0) {
            return false;
        }
        $table = trainingCoursePageTable($modx, 'partnerstraining_practice_attempts');
        $statuses = array('accepted', 'completed', 'passed', 'reviewed');
        $params = array(':test_link_id' => $linkId, ':user_id' => $userId);
        $in = array();
        foreach ($statuses as $index => $status) {
            $key = ':status' . $index;
            $in[] = $key;
            $params[$key] = $status;
        }
        return trainingCoursePageScalar(
            $modx,
            'SELECT COUNT(*) FROM `' . $table . '` WHERE `test_link_id` = :test_link_id AND `user_id` = :user_id AND `status` IN (' . implode(',', $in) . ')',
            $params
        ) > 0;
    }
}

$resourceId = (int)$modx->getOption('resource_id', $scriptProperties, $modx->resource ? $modx->resource->get('id') : 0);
$courseId = (int)$modx->getOption('course_id', $scriptProperties, 0);
$userId = $modx->user ? (int)$modx->user->get('id') : 0;
if ($userId <= 0 || $resourceId <= 0) {
    return '';
}

$courseId = TrainingWebHelper::resolveCourseId($modx, $courseId, $resourceId);
if ($courseId <= 0) {
    return '';
}

$service = TrainingWebHelper::getProgressService($modx);
if (method_exists($service, 'syncUserCourseForUser')) {
    $service->syncUserCourseForUser($courseId, $userId);
}

$course = $modx->getObject('TrainingCourse', array('id' => $courseId));
$courseResource = $course ? $course->getOne('Resource') : null;
if (!$courseResource) {
    return '';
}

$userCourse = $modx->getObject('TrainingUserCourse', array('course_id' => $courseId, 'user_id' => $userId));
$courseImage = trim((string)$courseResource->getTVValue('image_curse'));
if ($courseImage === '') {
    $courseImage = 'theme/images/training/curses/image_1.jpg';
}

$modulesTable = trainingCoursePageTable($modx, 'partnerstraining_modules');
$lessonsTable = trainingCoursePageTable($modx, 'partnerstraining_module_lessons');
$testLinksTable = trainingCoursePageTable($modx, 'partnerstraining_test_links');
$lessonVideosTable = TrainingWebHelper::lessonVideosTable($modx);
$videoProgressTable = TrainingWebHelper::lessonVideoProgressTable($modx);
$hasVideoProgress = TrainingWebHelper::hasLessonVideoProgressTable($modx);
$resourcesTable = $modx->getTableName('modResource');

$videosTotal = trainingCoursePageScalar(
    $modx,
    'SELECT COUNT(v.id) FROM `' . $lessonVideosTable . '` v '
    . 'INNER JOIN `' . $lessonsTable . '` l ON l.id = v.lesson_id AND l.is_active = 1 '
    . 'INNER JOIN `' . $modulesTable . '` m ON m.id = l.module_id AND m.is_active = 1 '
    . 'WHERE m.course_id = :course_id AND v.is_active = 1',
    array(':course_id' => $courseId)
);
$videosCompleted = $hasVideoProgress
    ? trainingCoursePageScalar($modx, 'SELECT COUNT(*) FROM `' . $videoProgressTable . '` WHERE `course_id` = :course_id AND `user_id` = :user_id AND `completed` = 1', array(':course_id' => $courseId, ':user_id' => $userId))
    : 0;

$allTestLinks = trainingCoursePageFetchAll(
    $modx,
    'SELECT * FROM `' . $testLinksTable . '` WHERE `course_id` = :course_id ORDER BY `module_id` ASC, `sort_order` ASC, `id` ASC',
    array(':course_id' => $courseId)
);
$testsTotal = 0;
$testsPassed = 0;
$practicesTotal = 0;
$practicesCompleted = 0;
foreach ($allTestLinks as $link) {
    $type = isset($link['link_type']) ? (string)$link['link_type'] : 'test';
    if ($type === 'practice') {
        $practicesTotal++;
        if (trainingCoursePagePracticeDone($modx, $link, $userId)) {
            $practicesCompleted++;
        }
    } else {
        $testsTotal++;
        if (trainingCoursePageTestPassed($modx, $link, $userId)) {
            $testsPassed++;
        }
    }
}

$progressPercent = $userCourse ? (int)round((float)$userCourse->get('progress_percent')) : 0;
$courseStatusText = 'Не начат';
$courseStatusClass = 'label-chip--blue';
if ($userCourse && ((string)$userCourse->get('status') === 'completed' || $progressPercent >= 100)) {
    $courseStatusText = 'Завершен';
    $courseStatusClass = 'label-chip--green';
} elseif ($progressPercent > 0 || ($userCourse && (string)$userCourse->get('status') === 'in_progress')) {
    $courseStatusText = 'В процессе';
    $courseStatusClass = 'label-chip--purple';
}

$modules = trainingCoursePageFetchAll(
    $modx,
    'SELECT m.*, r.pagetitle AS resource_title, r.id AS resource_id, r.menuindex '
    . 'FROM `' . $modulesTable . '` m '
    . 'LEFT JOIN `' . $resourcesTable . '` r ON r.id = m.resource_id '
    . 'WHERE m.course_id = :course_id AND m.is_active = 1 '
    . 'ORDER BY COALESCE(r.menuindex, 99999) ASC, m.id ASC',
    array(':course_id' => $courseId)
);

$openModuleId = $userCourse ? (int)$userCourse->get('current_module_id') : 0;
if ($openModuleId <= 0 && !empty($modules[0]['id'])) {
    $openModuleId = (int)$modules[0]['id'];
}

$htmlModules = '';
$moduleCounter = 0;
foreach ($modules as $moduleRow) {
    $moduleId = (int)$moduleRow['id'];
    $moduleCounter++;
    $moduleTitle = trim((string)$moduleRow['resource_title']);
    if ($moduleTitle === '') {
        $moduleTitle = 'Модуль ' . $moduleCounter;
    }

    $lessonRows = trainingCoursePageFetchAll(
        $modx,
        'SELECT * FROM `' . $lessonsTable . '` WHERE `module_id` = :module_id AND `is_active` = 1 ORDER BY `sort_order` ASC, `id` ASC',
        array(':module_id' => $moduleId)
    );
    $testRows = trainingCoursePageFetchAll(
        $modx,
        'SELECT * FROM `' . $testLinksTable . '` WHERE `module_id` = :module_id ORDER BY `sort_order` ASC, `id` ASC',
        array(':module_id' => $moduleId)
    );

    $moduleDuration = 0;
    $completedItems = 0;
    $totalItems = count($lessonRows) + count($testRows);
    $moduleItemsHtml = '';
    $lessonsCompleted = true;

    foreach ($lessonRows as $lessonRow) {
        $lessonId = (int)$lessonRow['id'];
        $lessonTitle = trim((string)$lessonRow['title']);
        if ($lessonTitle === '') {
            $lessonTitle = 'Урок ' . ((int)$lessonRow['sort_order'] > 0 ? (int)$lessonRow['sort_order'] : $lessonId);
        }

        $lessonProgress = method_exists($service, 'getLessonProgress') ? $service->getLessonProgress($courseId, $lessonId, $userId) : null;
        $lessonCompleted = $lessonProgress && (int)$lessonProgress->get('completed') === 1;
        if ($lessonCompleted) {
            $completedItems++;
        } else {
            $lessonsCompleted = false;
        }

        $lessonDuration = 0;
        $videoRows = TrainingWebHelper::fetchLessonVideoRows($modx, $lessonId);
        foreach ($videoRows as $videoRow) {
            $lessonDuration += max(0, (int)$videoRow['duration_seconds']);
        }
        $moduleDuration += $lessonDuration;

        $activeVideoRow = TrainingWebHelper::pickActiveLessonVideoRow($modx, $courseId, $lessonId, $userId, 0);
        $activeVideoId = $activeVideoRow ? (int)$activeVideoRow['id'] : 0;
        $lessonLocked = method_exists($service, 'canAccessLesson') ? !$service->canAccessLesson($courseId, $moduleId, $lessonId, $userId) : false;
        $lessonUrl = $lessonLocked ? '' : TrainingWebHelper::makePlayerUrl($modx, (int)$moduleRow['resource_id'], $lessonId, $activeVideoId);

        $actionHtml = $lessonLocked
            ? '<span class="cs-lock"><img src="theme/images/training/curses/lock-keyhole-ico.svg" class="img-svg" alt=""><span>Заблокировано</span></span>'
            : '<a class="btn btn-player-next" href="' . trainingCoursePageEsc($lessonUrl) . '"><span>Продолжить</span></a>';

        $moduleItemsHtml .= '<div class="cs-item">'
            . '<span class="cs-item__ico" aria-hidden="true"><img src="theme/images/training/curses/play-ico.png" alt=""></span>'
            . '<div class="cs-item__txt">'
            . '<div class="cs-item__title">' . trainingCoursePageEsc($lessonTitle) . '</div>'
            . '<div class="cs-item__type">Учебный материал</div>'
            . '</div>'
            . '<div class="cs-item__status">' . $actionHtml . '</div>'
            . '</div>';
    }

    foreach ($testRows as $testRow) {
        $type = isset($testRow['link_type']) ? (string)$testRow['link_type'] : 'test';
        $isPractice = $type === 'practice';
        $itemTitle = $isPractice ? 'Практическое задание' : 'Тест';
        if (!$isPractice && isset($testRow['usertest_test_id']) && (int)$testRow['usertest_test_id'] > 0) {
            $testTitle = trainingCoursePageFetchAll(
                $modx,
                'SELECT `name` FROM `' . trainingCoursePageTable($modx, 'partnersusertest_tests') . '` WHERE `id` = :id LIMIT 1',
                array(':id' => (int)$testRow['usertest_test_id'])
            );
            if (!empty($testTitle[0]['name'])) {
                $itemTitle = (string)$testTitle[0]['name'];
            }
        }
        $done = $isPractice ? trainingCoursePagePracticeDone($modx, $testRow, $userId) : trainingCoursePageTestPassed($modx, $testRow, $userId);
        if ($done) {
            $completedItems++;
        }
        $locked = !$lessonsCompleted;
        if ($locked) {
            $actionHtml = '<span class="cs-lock"><img src="theme/images/training/curses/lock-keyhole-ico.svg" class="img-svg" alt=""><span>Заблокировано</span></span>';
        } else {
            $actionHtml = $done
                ? trainingCoursePageStatusChip('Выполнено', 'label-chip--green')
                : trainingCoursePageStatusChip('Доступно', 'label-chip--purple');
        }

        $moduleItemsHtml .= '<div class="cs-item">'
            . '<span class="cs-item__ico" aria-hidden="true"><img src="theme/images/training/curses/play-ico.png" alt=""></span>'
            . '<div class="cs-item__txt">'
            . '<div class="cs-item__title">' . trainingCoursePageEsc($itemTitle) . '</div>'
            . '<div class="cs-item__type">' . trainingCoursePageEsc($isPractice ? 'Задание' : 'Тест') . '</div>'
            . '</div>'
            . '<div class="cs-item__status">' . $actionHtml . '</div>'
            . '</div>';
    }

    $moduleLabelText = $completedItems >= max(1, $totalItems)
        ? 'Завершен (' . $completedItems . '/' . $totalItems . ')'
        : 'В процессе (' . $completedItems . '/' . $totalItems . ')';
    $moduleLabelClass = $completedItems >= max(1, $totalItems) ? 'label-chip--green' : 'label-chip--purple';
    $moduleIsOpen = $moduleId === $openModuleId ? ' is-open' : '';
    $materialsCountText = $totalItems . ' ' . ($totalItems === 1 ? 'материал' : ($totalItems < 5 ? 'материала' : 'материалов'));

    $htmlModules .= '<div class="cs-module' . $moduleIsOpen . '" data-cs-module>'
        . '<button type="button" class="cs-head" data-cs-toggle aria-expanded="' . ($moduleId === $openModuleId ? 'true' : 'false') . '">'
        . '<span class="cs-head__ico" aria-hidden="true"><img src="theme/images/training/curses/shapka-ico.png" alt=""></span>'
        . '<span class="cs-head__main">'
        . '<span class="cs-head__title">' . trainingCoursePageEsc($moduleTitle) . '</span>'
        . '<span class="cs-head__meta"><span class="cs-head__count">' . trainingCoursePageEsc($materialsCountText) . '</span><img src="theme/images/training/curses/arrow-down-ico.svg" class="img-svg cs-head__arrow d-none d-xl-block" alt=""></span>'
        . '</span>'
        . '<span class="cs-head__right d-none d-xl-flex">'
        . '<span class="cs-head__time"><img src="theme/images/training/curses/clock-ico.svg" class="img-svg"><span>' . trainingCoursePageEsc(TrainingWebHelper::formatDuration($moduleDuration)) . '</span></span>'
        . trainingCoursePageStatusChip($moduleLabelText, $moduleLabelClass)
        . '</span>'
        . '<span class="cs-head__right d-flex d-xl-none"><img src="theme/images/training/curses/arrow-down-ico.svg" class="img-svg cs-head__arrow" alt=""></span>'
        . '</button>'
        . '<div class="cs-body" data-cs-body>' . $moduleItemsHtml . '</div>'
        . '</div>';
}

$html = '';
$html .= '<div class="section-block course-page mb-3 mb-lg-4">';
$html .= '<div class="course-hero mb-3 mb-xl-4">';
$html .= '<div class="course-hero__media">';
$html .= '<div class="course-hero__img"><img src="' . trainingCoursePageEsc($courseImage) . '" alt="' . trainingCoursePageEsc($courseResource->get('pagetitle')) . '"></div>';
$html .= '</div>';
$html .= '<div class="course-hero__body d-flex flex-column align-items-start gap-4">';
$html .= '<div class="course-hero__top">';
$html .= '<div class="course-hero__title">' . trainingCoursePageEsc($courseResource->get('pagetitle')) . '</div>';
$html .= '</div>';
$html .= '<div class="course-hero__chips">';
$html .= trainingCoursePageStatusChip($courseStatusText, $courseStatusClass);
$html .= '<span class="course-chip"><span class="course-chip__ico" aria-hidden="true"><img src="theme/images/training/curses/clock-ico.svg" class="img-svg" alt=""></span><span class="course-chip__txt">Продолжительность ' . trainingCoursePageEsc(trim((string)$courseResource->getTVValue('time_curse'))) . '</span></span>';
$html .= '</div>';
$html .= '<div class="course-item__info">';
$html .= '<div class="course-item__stats">';
$html .= '<div class="course-stat"><div class="course-stat__value">' . $videosCompleted . '/' . $videosTotal . '</div><div class="course-stat__label">видео</div></div>';
$html .= '<div class="course-stat"><div class="course-stat__value">' . $practicesCompleted . '/' . $practicesTotal . '</div><div class="course-stat__label">Практические работы</div></div>';
$html .= '<div class="course-stat"><div class="course-stat__value">' . $testsPassed . '/' . $testsTotal . '</div><div class="course-stat__label">Тесты</div></div>';
$html .= '</div>';
$html .= '<div class="course-item__progress"><div class="progress-track"><div class="progress-fill" style="width:' . $progressPercent . '%"></div></div><div class="progress-value">' . $progressPercent . '%</div></div>';
$html .= '</div>';
$html .= '</div>';
$html .= '</div>';
$html .= '<div class="course-about">';
$html .= '<div class="course-about__title mb-3">О курсе</div>';
$html .= '<div class="course-about__text mb-3" data-course-about>' . (string)$courseResource->get('description') . '</div>';
$html .= '<button type="button" class="course-about__toggle" data-course-about-toggle>Показать больше</button>';
$html .= '</div>';
$html .= '</div>';

$html .= '<div class="section-block course-structure-block">';
$html .= '<div class="title-training mb-3 mb-xl-4">Структура курса</div>';
$html .= '<div class="course-structure">' . $htmlModules . '</div>';
$html .= '</div>';

return $html;
