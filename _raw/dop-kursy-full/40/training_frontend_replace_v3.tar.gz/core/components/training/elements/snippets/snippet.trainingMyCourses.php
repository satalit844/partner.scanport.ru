<?php
/** @var modX $modx */
/** @var array $scriptProperties */

$corePath = $modx->getOption(
    'training.core_path',
    null,
    $modx->getOption('core_path') . 'components/training/'
);
$connectorUrl = $modx->getOption('assets_url') . 'components/training/web.connector.php';
$contextKey = $modx->context ? $modx->context->get('key') : 'web';

return '
<div class="my-courses" id="my-courses" data-training-page="mycourses" data-training-connector="' . htmlspecialchars($connectorUrl, ENT_QUOTES, 'UTF-8') . '" data-training-context="' . htmlspecialchars($contextKey, ENT_QUOTES, 'UTF-8') . '">
    <div class="filters-corses mb-3 mb-xl-4">
        <div class="course-filters-swiper swiper">
            <div class="swiper-wrapper filters-items align-items-center">
                <div class="swiper-slide"><button type="button" class="course-filter__chip is-active" data-filter="all" aria-selected="true">Все</button></div>
                <div class="swiper-slide"><button type="button" class="course-filter__chip" data-filter="progress" aria-selected="false">В процессе</button></div>
                <div class="swiper-slide"><button type="button" class="course-filter__chip" data-filter="new" aria-selected="false">Не начатые</button></div>
                <div class="swiper-slide"><button type="button" class="course-filter__chip" data-filter="done" aria-selected="false">Завершенные</button></div>
            </div>
        </div>
    </div>
    <div class="corses-items d-flex flex-wrap gap-3"></div>
</div>';
