<?php

require_once dirname(dirname(__DIR__)) . '/lesson/_video_helper.php';

class TrainingCourseModulesGetListProcessor extends modObjectGetListProcessor
{
    public $classKey = 'TrainingModule';
    public $objectType = 'training.module';
    public $defaultSortField = 'Resource.menuindex';
    public $defaultSortDirection = 'ASC';

    public function prepareQueryBeforeCount(xPDOQuery $c)
    {
        $courseId = (int)$this->getProperty('course_id');
        if ($courseId <= 0) {
            $c->where(['1 = 0']);
            return $c;
        }

        $query = trim((string)$this->getProperty('query', ''));

        $c->leftJoin('modResource', 'Resource', 'Resource.id = TrainingModule.resource_id');
        $c->select($this->modx->getSelectColumns('TrainingModule', 'TrainingModule'));
        $c->select([
            'Resource.pagetitle AS title',
            'Resource.menuindex AS menuindex',
            'Resource.published AS published',
        ]);
        $c->where(['TrainingModule.course_id' => $courseId]);

        if ($query !== '') {
            $c->where([
                'TrainingModule.id:=' => (int)$query,
                'OR:TrainingModule.resource_id:=' => (int)$query,
                'OR:Resource.pagetitle:LIKE' => '%' . $query . '%',
            ]);
        }

        return $c;
    }

    protected function countModuleLessons($moduleId)
    {
        return (int)$this->modx->getCount('TrainingModuleLesson', ['module_id' => (int)$moduleId]);
    }

    protected function countModuleVideos($moduleId)
    {
        $sql = "SELECT COUNT(*) FROM `" . TrainingLessonVideoHelper::lessonVideosTable($this->modx) . "` lv"
            . ' INNER JOIN `' . $this->modx->getTableName('TrainingModuleLesson') . '` l ON l.`id` = lv.`lesson_id`'
            . " WHERE l.`module_id` = :module_id AND TRIM(COALESCE(lv.`source_video`, '')) != ''";
        $stmt = $this->modx->prepare($sql);
        if (!$stmt || !$stmt->execute([':module_id' => (int)$moduleId])) {
            return 0;
        }
        return (int)$stmt->fetchColumn();
    }

    protected function countModuleSlides($moduleId)
    {
        $sql = 'SELECT COUNT(*) FROM `' . TrainingLessonVideoHelper::slidesTable($this->modx) . '` WHERE `module_id` = :module_id AND `lesson_video_id` > 0 AND `is_active` = 1';
        $stmt = $this->modx->prepare($sql);
        if (!$stmt || !$stmt->execute([':module_id' => (int)$moduleId])) {
            return 0;
        }
        return (int)$stmt->fetchColumn();
    }

    public function prepareRow(xPDOObject $object)
    {
        $row = $object->toArray();
        $row['title'] = !empty($row['title']) ? $row['title'] : '—';
        $row['published'] = (int)!empty($row['published']);
        $row['is_active'] = (int)!empty($row['is_active']);
        $row['lessons_count'] = $this->countModuleLessons((int)$row['id']);
        $row['videos_count'] = $this->countModuleVideos((int)$row['id']);
        $row['slides_count'] = $this->countModuleSlides((int)$row['id']);
        return $row;
    }
}
return 'TrainingCourseModulesGetListProcessor';
