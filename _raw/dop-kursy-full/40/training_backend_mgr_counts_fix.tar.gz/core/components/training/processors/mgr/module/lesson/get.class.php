<?php
class TrainingModuleLessonGetProcessor extends modProcessor
{
    /** @var string */
    protected $modulesTable;
    /** @var string */
    protected $lessonsTable;
    /** @var string */
    protected $lessonVideosTable;
    /** @var string */
    protected $slidesTable;
    /** @var string */
    protected $resourcesTable;

    public function initialize()
    {
        $prefix = $this->modx->getOption('table_prefix', null, 'modx_');

        $this->modulesTable = $prefix . 'partnerstraining_modules';
        $this->lessonsTable = $prefix . 'partnerstraining_module_lessons';
        $this->lessonVideosTable = $prefix . 'partnerstraining_lesson_videos';
        $this->slidesTable = $prefix . 'partnerstraining_module_slides';
        $this->resourcesTable = $prefix . 'site_content';

        return parent::initialize();
    }

    public function process()
    {
        $lessonId = (int)$this->getProperty('id', 0);
        if ($lessonId <= 0) {
            return $this->failure('Не указан id урока');
        }

        $sql = "
            SELECT
                l.*,
                l.id AS id_label,
                COALESCE(r.pagetitle, CONCAT('Модуль #', l.module_id)) AS module_title,
                COALESCE(vc.videos_count, 0) AS videos_count,
                COALESCE(sc.slides_count, 0) AS slides_count
            FROM {$this->lessonsTable} AS l
            LEFT JOIN {$this->modulesTable} AS m
                ON m.id = l.module_id
            LEFT JOIN {$this->resourcesTable} AS r
                ON r.id = m.resource_id
            LEFT JOIN (
                SELECT
                    lv.lesson_id,
                    COUNT(*) AS videos_count
                FROM {$this->lessonVideosTable} AS lv
                WHERE COALESCE(lv.source_video, '') <> ''
                GROUP BY lv.lesson_id
            ) AS vc
                ON vc.lesson_id = l.id
            LEFT JOIN (
                SELECT
                    s.lesson_id,
                    COUNT(*) AS slides_count
                FROM {$this->slidesTable} AS s
                WHERE s.lesson_video_id > 0
                  AND s.is_active = 1
                GROUP BY s.lesson_id
            ) AS sc
                ON sc.lesson_id = l.id
            WHERE l.id = :lesson_id
            LIMIT 1
        ";

        $stmt = $this->modx->prepare($sql);
        $stmt->bindValue(':lesson_id', $lessonId, PDO::PARAM_INT);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            return $this->failure('Урок не найден');
        }

        $row['id'] = (int)$row['id'];
        $row['id_label'] = (int)$row['id_label'];
        $row['module_id'] = (int)$row['module_id'];
        $row['sort_order'] = (int)$row['sort_order'];
        $row['duration_seconds'] = (int)$row['duration_seconds'];
        $row['is_default'] = (int)$row['is_default'];
        $row['is_active'] = (int)$row['is_active'];
        $row['videos_count'] = (int)$row['videos_count'];
        $row['slides_count'] = (int)$row['slides_count'];

        return $this->success('', $row);
    }
}
return 'TrainingModuleLessonGetProcessor';
