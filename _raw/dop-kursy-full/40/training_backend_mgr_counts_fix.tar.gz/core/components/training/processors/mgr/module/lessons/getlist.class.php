<?php
class TrainingModuleLessonsGetListProcessor extends modProcessor
{
    /** @var string */
    protected $lessonsTable;
    /** @var string */
    protected $lessonVideosTable;
    /** @var string */
    protected $slidesTable;

    public function initialize()
    {
        $prefix = $this->modx->getOption('table_prefix', null, 'modx_');

        $this->lessonsTable = $prefix . 'partnerstraining_module_lessons';
        $this->lessonVideosTable = $prefix . 'partnerstraining_lesson_videos';
        $this->slidesTable = $prefix . 'partnerstraining_module_slides';

        return parent::initialize();
    }

    public function process()
    {
        $moduleId = (int)$this->getProperty('module_id', 0);
        if ($moduleId <= 0) {
            return $this->failure('Не указан module_id');
        }

        $start = max(0, (int)$this->getProperty('start', 0));
        $limit = (int)$this->getProperty('limit', 20);
        if ($limit <= 0) {
            $limit = 20;
        }

        $sort = (string)$this->getProperty('sort', 'sort_order');
        $dir = strtoupper((string)$this->getProperty('dir', 'ASC'));
        $dir = $dir === 'DESC' ? 'DESC' : 'ASC';

        $sortMap = [
            'id' => 'l.id',
            'title' => 'l.title',
            'sort_order' => 'l.sort_order',
            'videos_count' => 'videos_count',
            'slides_count' => 'slides_count',
            'is_default' => 'l.is_default',
            'is_active' => 'l.is_active',
        ];
        $sortField = isset($sortMap[$sort]) ? $sortMap[$sort] : $sortMap['sort_order'];

        $countSql = "
            SELECT COUNT(*)
            FROM {$this->lessonsTable} AS l
            WHERE l.module_id = :module_id
        ";
        $countStmt = $this->modx->prepare($countSql);
        $countStmt->bindValue(':module_id', $moduleId, PDO::PARAM_INT);
        $countStmt->execute();
        $total = (int)$countStmt->fetchColumn();

        $sql = "
            SELECT
                l.id,
                l.module_id,
                l.title,
                l.sort_order,
                l.is_default,
                l.is_active,
                COALESCE(vc.videos_count, 0) AS videos_count,
                COALESCE(sc.slides_count, 0) AS slides_count
            FROM {$this->lessonsTable} AS l
            LEFT JOIN (
                SELECT
                    lv.lesson_id,
                    COUNT(*) AS videos_count
                FROM {$this->lessonVideosTable} AS lv
                WHERE COALESCE(lv.source_video, '') <> ''
                GROUP BY lv.lesson_id
            ) AS vc
                ON vc.lesson_id = l.id
            LEFT JOIN (
                SELECT
                    s.lesson_id,
                    COUNT(*) AS slides_count
                FROM {$this->slidesTable} AS s
                WHERE s.lesson_video_id > 0
                  AND s.is_active = 1
                GROUP BY s.lesson_id
            ) AS sc
                ON sc.lesson_id = l.id
            WHERE l.module_id = :module_id
            ORDER BY {$sortField} {$dir}
            LIMIT :start, :limit
        ";

        $stmt = $this->modx->prepare($sql);
        $stmt->bindValue(':module_id', $moduleId, PDO::PARAM_INT);
        $stmt->bindValue(':start', $start, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as &$row) {
            $row['id'] = (int)$row['id'];
            $row['module_id'] = (int)$row['module_id'];
            $row['sort_order'] = (int)$row['sort_order'];
            $row['is_default'] = (int)$row['is_default'];
            $row['is_active'] = (int)$row['is_active'];
            $row['videos_count'] = (int)$row['videos_count'];
            $row['slides_count'] = (int)$row['slides_count'];
        }
        unset($row);

        return $this->outputArray($rows, $total);
    }
}
return 'TrainingModuleLessonsGetListProcessor';
