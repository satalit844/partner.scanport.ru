<?php
class TrainingCourseModulesGetListProcessor extends modProcessor
{
    /** @var string */
    protected $modulesTable;
    /** @var string */
    protected $lessonsTable;
    /** @var string */
    protected $lessonVideosTable;
    /** @var string */
    protected $slidesTable;
    /** @var string */
    protected $resourcesTable;

    public function initialize()
    {
        $prefix = $this->modx->getOption('table_prefix', null, 'modx_');

        $this->modulesTable = $prefix . 'partnerstraining_modules';
        $this->lessonsTable = $prefix . 'partnerstraining_module_lessons';
        $this->lessonVideosTable = $prefix . 'partnerstraining_lesson_videos';
        $this->slidesTable = $prefix . 'partnerstraining_module_slides';
        $this->resourcesTable = $prefix . 'site_content';

        return parent::initialize();
    }

    public function process()
    {
        $courseId = (int)$this->getProperty('course_id', 0);
        if ($courseId <= 0) {
            return $this->failure('Не указан course_id');
        }

        $start = max(0, (int)$this->getProperty('start', 0));
        $limit = (int)$this->getProperty('limit', 20);
        if ($limit <= 0) {
            $limit = 20;
        }

        $sort = (string)$this->getProperty('sort', 'menuindex');
        $dir = strtoupper((string)$this->getProperty('dir', 'ASC'));
        $dir = $dir === 'DESC' ? 'DESC' : 'ASC';

        $sortMap = [
            'id' => 'm.id',
            'resource_id' => 'm.resource_id',
            'title' => 'title',
            'menuindex' => 'menuindex',
            'published' => 'published',
            'is_active' => 'm.is_active',
            'lessons_count' => 'lessons_count',
            'videos_count' => 'videos_count',
            'slides_count' => 'slides_count',
        ];
        $sortField = isset($sortMap[$sort]) ? $sortMap[$sort] : $sortMap['menuindex'];

        $countSql = "
            SELECT COUNT(*)
            FROM {$this->modulesTable} AS m
            WHERE m.course_id = :course_id
        ";
        $countStmt = $this->modx->prepare($countSql);
        $countStmt->bindValue(':course_id', $courseId, PDO::PARAM_INT);
        $countStmt->execute();
        $total = (int)$countStmt->fetchColumn();

        $sql = "
            SELECT
                m.id,
                m.course_id,
                m.resource_id,
                COALESCE(r.pagetitle, CONCAT('Модуль #', m.id)) AS title,
                COALESCE(r.menuindex, 0) AS menuindex,
                COALESCE(r.published, 0) AS published,
                m.is_active,
                COALESCE(lc.lessons_count, 0) AS lessons_count,
                COALESCE(vc.videos_count, 0) AS videos_count,
                COALESCE(sc.slides_count, 0) AS slides_count
            FROM {$this->modulesTable} AS m
            LEFT JOIN {$this->resourcesTable} AS r
                ON r.id = m.resource_id
            LEFT JOIN (
                SELECT
                    ml.module_id,
                    COUNT(*) AS lessons_count
                FROM {$this->lessonsTable} AS ml
                GROUP BY ml.module_id
            ) AS lc
                ON lc.module_id = m.id
            LEFT JOIN (
                SELECT
                    ml.module_id,
                    COUNT(*) AS videos_count
                FROM {$this->lessonVideosTable} AS lv
                INNER JOIN {$this->lessonsTable} AS ml
                    ON ml.id = lv.lesson_id
                WHERE COALESCE(lv.source_video, '') <> ''
                GROUP BY ml.module_id
            ) AS vc
                ON vc.module_id = m.id
            LEFT JOIN (
                SELECT
                    ml.module_id,
                    COUNT(*) AS slides_count
                FROM {$this->slidesTable} AS s
                INNER JOIN {$this->lessonsTable} AS ml
                    ON ml.id = s.lesson_id
                WHERE s.lesson_video_id > 0
                  AND s.is_active = 1
                GROUP BY ml.module_id
            ) AS sc
                ON sc.module_id = m.id
            WHERE m.course_id = :course_id
            ORDER BY {$sortField} {$dir}
            LIMIT :start, :limit
        ";

        $stmt = $this->modx->prepare($sql);
        $stmt->bindValue(':course_id', $courseId, PDO::PARAM_INT);
        $stmt->bindValue(':start', $start, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as &$row) {
            $row['id'] = (int)$row['id'];
            $row['course_id'] = (int)$row['course_id'];
            $row['resource_id'] = (int)$row['resource_id'];
            $row['menuindex'] = (int)$row['menuindex'];
            $row['published'] = (int)$row['published'];
            $row['is_active'] = (int)$row['is_active'];
            $row['lessons_count'] = (int)$row['lessons_count'];
            $row['videos_count'] = (int)$row['videos_count'];
            $row['slides_count'] = (int)$row['slides_count'];
        }
        unset($row);

        return $this->outputArray($rows, $total);
    }
}
return 'TrainingCourseModulesGetListProcessor';
