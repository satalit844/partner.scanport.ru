<?php

$corePath = dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/';
require_once $corePath . 'model/training/training.class.php';
require_once $corePath . 'model/training/services/trainingcertificate.class.php';

class TrainingCourseCertificateGenerateProcessor extends modProcessor
{
    public function process()
    {
        $courseId = (int)$this->getProperty('course_id', 0);
        if ($courseId <= 0) {
            return $this->failure('Не указан курс');
        }

        $force = (int)$this->getProperty('force', 0) === 1;
        $service = new TrainingCertificateService($this->modx, new Training($this->modx));
        $users = $service->getCompletedUsersForCourse($courseId);
        $generated = 0;
        foreach ($users as $user) {
            if ($service->ensureUserCertificate($courseId, (int)$user['user_id'], $force)) {
                $generated++;
            }
        }

        return $this->success('', array(
            'generated_count' => $generated,
            'total_completed' => count($users),
        ));
    }
}
return 'TrainingCourseCertificateGenerateProcessor';
