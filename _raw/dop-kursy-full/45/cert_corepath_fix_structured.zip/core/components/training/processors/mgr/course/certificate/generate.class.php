<?php

$corePath = $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/');
require_once $corePath . 'model/training/training.class.php';
require_once $corePath . 'model/training/services/trainingcertificate.class.php';

class TrainingCourseCertificateGenerateProcessor extends modProcessor
{
    public function process()
    {
        $courseId = (int)$this->getProperty('course_id', 0);
        if ($courseId <= 0) {
            return $this->failure('Не указан курс');
        }

        $force = (int)$this->getProperty('force', 1) === 1;
        $userIdsRaw = trim((string)$this->getProperty('user_ids', ''));
        $service = new TrainingCertificateService($this->modx, new Training($this->modx));

        $result = array();
        if ($userIdsRaw !== '') {
            $count = 0;
            foreach (array_unique(array_filter(array_map('intval', explode(',', $userIdsRaw)))) as $userId) {
                $cert = $service->ensureUserCertificate($courseId, $userId, $force);
                if ($cert) {
                    $count++;
                }
            }
            $result['generated_count'] = $count;
        } else {
            $generated = $service->generateAllForCourse($courseId, $force);
            $result['generated_count'] = count($generated);
        }

        return $this->success('Сертификаты сгенерированы', $result);
    }
}
return 'TrainingCourseCertificateGenerateProcessor';
