<?php

$corePath = $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/');
require_once $corePath . 'model/training/training.class.php';
require_once $corePath . 'model/training/services/trainingcertificate.class.php';

class TrainingCourseCertificatesGetListProcessor extends modProcessor
{
    public function process()
    {
        $courseId = (int)$this->getProperty('course_id', 0);
        if ($courseId <= 0) {
            return $this->success('', array('total' => 0, 'results' => array()));
        }

        $service = new TrainingCertificateService($this->modx, new Training($this->modx));
        $rows = $service->listIssuedCertificatesForCourse($courseId);
        foreach ($rows as &$row) {
            $row['id'] = (int)$row['user_id'];
            $row['certificate_generated'] = !empty($row['certificate_id']) ? 1 : 0;
            $row['certificate_generated_label'] = !empty($row['certificate_id']) ? 'Да' : 'Нет';
            $row['completedon_formatted'] = (!empty($row['completedon']) && $row['completedon'] !== '0000-00-00 00:00:00') ? date('d.m.Y H:i', strtotime($row['completedon'])) : '—';
            $row['issuedon_formatted'] = (!empty($row['issuedon']) && $row['issuedon'] !== '0000-00-00 00:00:00') ? date('d.m.Y H:i', strtotime($row['issuedon'])) : '—';
            $row['file_path'] = !empty($row['file_path']) ? $row['file_path'] : '—';
        }
        unset($row);
        return $this->outputArray($rows, count($rows));
    }

    protected function outputArray(array $array, $count = false)
    {
        if ($count === false) {
            $count = count($array);
        }
        return $this->success('', array('total' => $count, 'results' => array_values($array)));
    }
}
return 'TrainingCourseCertificatesGetListProcessor';
