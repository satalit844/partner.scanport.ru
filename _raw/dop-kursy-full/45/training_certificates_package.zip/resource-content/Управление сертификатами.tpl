{'!trainingManageCertificatesPage' | snippet}
