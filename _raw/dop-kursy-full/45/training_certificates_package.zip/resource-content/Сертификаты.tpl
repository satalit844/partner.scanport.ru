{'!trainingCertificatesPage' | snippet}
