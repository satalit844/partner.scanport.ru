<div class="modal fade" id="sertModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content sert-modal">
            <div class="modal-body">
                <div class="sert-modal__wrap">
                    <img class="sert-modal__img" src="" alt="">
                    <div class="sert-modal__actions">
                        <a class="sert-modal__download" href="#" download>Скачать сертификат</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
