<div class="section-block training-type mb-4 certificates-page">
    <div class="d-flex align-items-start justify-content-between gap-3 flex-wrap mb-4">
        <div>
            <div class="title-training mb-3">{$page_title}</div>
            <div class="subtitle">{$page_subtitle}</div>
        </div>
        {$toolbar_html}
    </div>

    <div class="sert-items d-flex flex-column gap-3">
        {$items_html}
    </div>

    {$modal_html}
</div>
