<form method="get" class="d-flex align-items-center gap-2 certificates-page__toolbar">
    <select name="{$select_name}" class="form-select form-select-lg" onchange="this.form.submit()" style="min-width:320px;border-radius:18px;">
        {$select_options_html}
    </select>
</form>
