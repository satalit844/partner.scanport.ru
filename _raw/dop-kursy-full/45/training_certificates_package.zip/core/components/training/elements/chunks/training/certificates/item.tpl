<div class="sert-item is-done">
    <div class="sert-item__head">
        <div class="sert-item__logo"><img src="theme/images/training/sert/sert-logo.svg" alt=""></div>
        <div>
            <div class="sert-item__title">{$certificate_title}</div>
            <div class="sert-status">{$certificate_status} • {$certificate_issuedon}</div>
        </div>
    </div>
    <button type="button" class="sert-btn" data-img="{$certificate_preview}" data-file="{$certificate_file}">
        <span>Открыть</span>
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M12 16L12 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M7 11L12 16L17 11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M5 20H19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    </button>
</div>
