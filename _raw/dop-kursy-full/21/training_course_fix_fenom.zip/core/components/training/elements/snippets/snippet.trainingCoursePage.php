<?php
/** @var modX $modx */
/** @var array $scriptProperties */

$corePath = $modx->getOption(
    'training.core_path',
    null,
    $modx->getOption('core_path') . 'components/training/'
);

require_once $corePath . 'model/training/training.class.php';
require_once $corePath . 'model/training/services/trainingprogress.class.php';

if (!function_exists('trainingCoursePageRenderChunk')) {
    function trainingCoursePageRenderChunk(modX $modx, $corePath, $relativePath, array $placeholders = array())
    {
        $path = rtrim($corePath, '/\\') . '/elements/chunks/' . ltrim($relativePath, '/\\');
        if (!is_file($path)) {
            return '';
        }

        $content = (string)file_get_contents($path);
        if ($content === '') {
            return '';
        }

        $replace = array();
        foreach ($placeholders as $key => $value) {
            if (is_array($value) || is_object($value)) {
                $value = '';
            }
            $replace['{$' . $key . '}'] = (string)$value;
        }

        return strtr($content, $replace);
    }
}

if (!function_exists('trainingCoursePageFormatDuration')) {
    function trainingCoursePageFormatDuration($seconds)
    {
        $seconds = (int)$seconds;
        if ($seconds <= 0) {
            return '';
        }

        $hours = (int)floor($seconds / 3600);
        $minutes = (int)floor(($seconds % 3600) / 60);

        if ($hours > 0) {
            if ($minutes > 0) {
                return $hours . ' ч ' . $minutes . ' минут';
            }
            return $hours . ' ч';
        }

        if ($minutes > 0) {
            return $minutes . ' минут';
        }

        return $seconds . ' сек';
    }
}

if (!function_exists('trainingCoursePagePlural')) {
    function trainingCoursePagePlural($number, array $forms)
    {
        $number = abs((int)$number) % 100;
        $n1 = $number % 10;

        if ($number > 10 && $number < 20) {
            return $forms[2];
        }
        if ($n1 > 1 && $n1 < 5) {
            return $forms[1];
        }
        if ($n1 == 1) {
            return $forms[0];
        }

        return $forms[2];
    }
}

if (!function_exists('trainingCoursePageEsc')) {
    function trainingCoursePageEsc($value)
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('trainingCoursePageGetProfileExtended')) {
    function trainingCoursePageGetProfileExtended(modUser $user)
    {
        $profile = $user->getOne('Profile');
        if (!$profile) {
            return array();
        }

        $extended = $profile->get('extended');
        if (is_array($extended)) {
            return $extended;
        }

        $extended = trim((string)$extended);
        if ($extended === '') {
            return array();
        }

        $decoded = json_decode($extended, true);
        return is_array($decoded) ? $decoded : array();
    }
}

if (!function_exists('trainingCoursePageExtractOrganization')) {
    function trainingCoursePageExtractOrganization(modUser $user)
    {
        $extended = trainingCoursePageGetProfileExtended($user);
        $keys = array(
            'company',
            'organization',
            'organisation',
            'org',
            'company_name',
            'organisation_name',
            'employer',
            'workplace',
        );

        foreach ($keys as $key) {
            if (!empty($extended[$key])) {
                return trim((string)$extended[$key]);
            }
        }

        $profile = $user->getOne('Profile');
        if ($profile) {
            $fullname = trim((string)$profile->get('fullname'));
            if ($fullname !== '') {
                return $fullname;
            }
        }

        return trim((string)$user->get('username'));
    }
}

if (!function_exists('trainingCoursePageMakeViewUrl')) {
    function trainingCoursePageMakeViewUrl(modX $modx, $viewerResourceId, $moduleResourceId, $lessonId, $moduleParam, $lessonParam)
    {
        $viewerResourceId = (int)$viewerResourceId;
        $moduleResourceId = (int)$moduleResourceId;
        $lessonId = (int)$lessonId;

        if ($viewerResourceId <= 0 || $moduleResourceId <= 0 || $lessonId <= 0) {
            return '#';
        }

        $baseUrl = $modx->makeUrl($viewerResourceId);
        if (!$baseUrl) {
            return '#';
        }

        $params = array(
            $moduleParam => $moduleResourceId,
            $lessonParam => $lessonId,
        );

        return $baseUrl . (strpos($baseUrl, '?') === false ? '?' : '&') . http_build_query($params);
    }
}

$resourceId = (int)$modx->getOption('resource_id', $scriptProperties, $modx->resource ? $modx->resource->get('id') : 0);
$viewerResourceId = (int)$modx->getOption(
    'viewer_resource_id',
    $scriptProperties,
    (int)$modx->getOption('training.training_view_resource_id', null, 174)
);
$viewerModuleParam = trim((string)$modx->getOption('viewer_module_param', $scriptProperties, 'module'));
$viewerLessonParam = trim((string)$modx->getOption('viewer_lesson_param', $scriptProperties, 'lesson'));

$pageTpl = trim((string)$modx->getOption('pageTpl', $scriptProperties, 'training/course/page.tpl'));
$moduleTpl = trim((string)$modx->getOption('moduleTpl', $scriptProperties, 'training/course/module.tpl'));
$lessonTpl = trim((string)$modx->getOption('lessonTpl', $scriptProperties, 'training/course/lesson.tpl'));

if ($resourceId <= 0) {
    return '<div class="section-block"><div class="alert alert-warning mb-0">Курс не найден.</div></div>';
}

if (!$modx->user || !(int)$modx->user->get('id') || !$modx->user->isAuthenticated($modx->context->get('key'))) {
    return '';
}

$training = new Training($modx);
$progressService = new TrainingProgressService($modx, $training);
$userId = (int)$modx->user->get('id');

/** @var TrainingCourse|null $course */
$course = $modx->getObject('TrainingCourse', array(
    'resource_id' => $resourceId,
));

/** @var modResource|null $resource */
$resource = $modx->getObject('modResource', array(
    'id' => $resourceId,
    'deleted' => 0,
));

if (!$course || !$resource || !(int)$course->get('is_active')) {
    return '<div class="section-block"><div class="alert alert-warning mb-0">Курс недоступен.</div></div>';
}

$courseId = (int)$course->get('id');
if (!$progressService->hasCourseAccess($courseId, $userId)) {
    return '<div class="section-block"><div class="alert alert-warning mb-0">У вас нет доступа к этому курсу.</div></div>';
}

$progressService->syncUserCourseForUser($courseId, $userId);
$progressService->recalculateUserCourse($courseId, $userId);

/** @var TrainingUserCourse|null $userCourse */
$userCourse = $modx->getObject('TrainingUserCourse', array(
    'course_id' => $courseId,
    'user_id' => $userId,
));

if (!$userCourse || (string)$userCourse->get('status') === 'revoked') {
    return '<div class="section-block"><div class="alert alert-warning mb-0">У вас нет доступа к этому курсу.</div></div>';
}

$courseTitle = trim((string)$resource->get('pagetitle'));
$courseImage = trim((string)$resource->getTVValue('image_curse'));
if ($courseImage === '') {
    $courseImage = 'theme/images/training/curses/image_1.jpg';
}

$courseDescription = trim((string)$resource->getTVValue('desc'));
if ($courseDescription === '') {
    $fallbackDescription = trim((string)$resource->get('description'));
    $courseDescription = $fallbackDescription !== ''
        ? nl2br(trainingCoursePageEsc($fallbackDescription))
        : 'Описание курса пока не заполнено.';
}

$courseDurationText = trim((string)$resource->getTVValue('time_curse'));
$courseProgressPercent = (int)round((float)$userCourse->get('progress_percent'));
$completedModules = (int)$userCourse->get('completed_modules');
$totalModulesFromProgress = (int)$userCourse->get('total_modules');
$currentModuleId = (int)$userCourse->get('current_module_id');
$courseStatus = (string)$userCourse->get('status');
$isSequential = (int)$course->get('is_sequential') === 1;

$courseStatusText = 'Не начат';
$courseStatusClass = 'label-chip--blue';
if ($courseStatus === 'completed' || $courseProgressPercent >= 100) {
    $courseStatusText = 'Пройден';
    $courseStatusClass = 'label-chip--green';
} elseif ($courseStatus === 'in_progress' || $courseProgressPercent > 0 || $completedModules > 0) {
    $courseStatusText = 'В процессе';
    $courseStatusClass = 'label-chip--purple';
}

$courseUserLabel = trainingCoursePageExtractOrganization($modx->user);
$testsCount = (int)$modx->getCount('TrainingTestLink', array('course_id' => $courseId));
$modules = $progressService->getCourseModules($courseId, true, false);

$progressQuery = $modx->newQuery('TrainingUserModuleProgress');
$progressQuery->where(array(
    'course_id' => $courseId,
    'user_id' => $userId,
));
$progressRows = $modx->getCollection('TrainingUserModuleProgress', $progressQuery);

$progressMap = array();
foreach ($progressRows as $progressRow) {
    $progressMap[(int)$progressRow->get('module_id')] = $progressRow;
}

$modulesHtml = '';
$moduleCount = 0;
$lessonsTotal = 0;
$courseDurationSeconds = 0;
$sequenceLocked = false;
$openFirst = true;

foreach ($modules as $module) {
    $moduleCount++;
    $moduleId = (int)$module->get('id');

    /** @var modResource|null $moduleResource */
    $moduleResource = $module->getOne('Resource');
    $moduleResourceId = $moduleResource ? (int)$moduleResource->get('id') : 0;
    $moduleTitle = $moduleResource ? trim((string)$moduleResource->get('pagetitle')) : '';
    if ($moduleTitle === '') {
        $moduleTitle = 'Модуль ' . $moduleCount;
    }

    $lessonQuery = $modx->newQuery('TrainingModuleLesson');
    $lessonQuery->where(array(
        'module_id' => $moduleId,
        'is_active' => 1,
    ));
    $lessonQuery->sortby('sort_order', 'ASC');
    $lessonQuery->sortby('id', 'ASC');
    $allLessons = $modx->getCollection('TrainingModuleLesson', $lessonQuery);

    $visibleLessons = array();
    $firstLessonId = 0;
    $moduleDurationSeconds = (int)$module->get('duration_seconds');

    foreach ($allLessons as $lesson) {
        $lessonId = (int)$lesson->get('id');

        $videoQuery = $modx->newQuery('TrainingModuleVideo');
        $videoQuery->where(array(
            'lesson_id' => $lessonId,
            'is_active' => 1,
            'file_path:!=' => '',
        ));
        $hasVideo = (int)$modx->getCount('TrainingModuleVideo', $videoQuery) > 0;

        if (!$hasVideo) {
            continue;
        }

        if ($firstLessonId <= 0) {
            $firstLessonId = $lessonId;
        }

        $visibleLessons[] = $lesson;
    }

    $moduleLessonsCount = count($visibleLessons);
    $lessonsTotal += $moduleLessonsCount;

    if ($moduleDurationSeconds <= 0 && !empty($visibleLessons)) {
        $sumDuration = 0;
        foreach ($visibleLessons as $lesson) {
            $sumDuration += (int)$lesson->get('duration_seconds');
        }
        $moduleDurationSeconds = $sumDuration;
    }

    $courseDurationSeconds += max(0, $moduleDurationSeconds);
    $moduleDurationText = trainingCoursePageFormatDuration($moduleDurationSeconds);
    $moduleDurationClass = $moduleDurationText !== '' ? '' : 'd-none';

    $moduleProgress = isset($progressMap[$moduleId]) ? $progressMap[$moduleId] : null;
    $moduleProgressPercent = $moduleProgress ? (int)round((float)$moduleProgress->get('progress_percent')) : 0;
    $moduleCompleted = $moduleProgress
        ? ((int)$moduleProgress->get('completed') === 1 || $moduleProgressPercent >= 100)
        : false;
    $moduleInProgress = $moduleProgress
        ? ($moduleProgressPercent > 0 || (string)$moduleProgress->get('status') === 'in_progress' || (int)$moduleProgress->get('max_time') > 0)
        : false;

    if (!$moduleInProgress && $currentModuleId === $moduleId && !$moduleCompleted) {
        $moduleInProgress = true;
    }

    $moduleLocked = false;
    if ($isSequential && $sequenceLocked && !$moduleCompleted && !$moduleInProgress) {
        $moduleLocked = true;
    }

    $moduleState = 'available';
    $moduleStatusHtml = '<span class="label-chip label-chip--blue"><span>Доступен</span></span>';
    if ($moduleCompleted) {
        $moduleState = 'done';
        $moduleStatusHtml = '<span class="label-chip label-chip--green"><span>Пройден</span></span>';
    } elseif ($moduleLocked) {
        $moduleState = 'locked';
        $moduleStatusHtml = '<span class="cs-lock"><img src="theme/images/training/curses/lock-keyhole-ico.svg" class="img-svg" alt=""><span>Заблокировано</span></span>';
    } elseif ($moduleInProgress) {
        $moduleState = 'progress';
        $moduleStatusHtml = '<span class="label-chip label-chip--purple"><span>В процессе (' . $moduleProgressPercent . '%)</span></span>';
    }

    if (!$moduleCompleted) {
        $sequenceLocked = true;
    }

    $moduleLessonsCountText = $moduleLessonsCount . ' ' . trainingCoursePagePlural($moduleLessonsCount, array('материал', 'материала', 'материалов'));
    $lessonsHtml = '';

    foreach ($visibleLessons as $index => $lesson) {
        $lessonId = (int)$lesson->get('id');
        $lessonTitle = trim((string)$lesson->get('title'));
        if ($lessonTitle === '') {
            $lessonTitle = $moduleTitle . ' — урок ' . ($index + 1);
        }

        $lessonUrl = trainingCoursePageMakeViewUrl(
            $modx,
            $viewerResourceId,
            $moduleResourceId,
            $lessonId,
            $viewerModuleParam,
            $viewerLessonParam
        );
        $lessonUrlEsc = trainingCoursePageEsc($lessonUrl);

        $lessonStatusHtml = '<a class="label-chip label-chip--blue" href="' . $lessonUrlEsc . '" style="text-decoration:none;"><span>Начать</span></a>';
        $lessonStatusHtmlMobile = '<a class="label-chip" href="' . $lessonUrlEsc . '" style="text-decoration:none;"><span>→</span></a>';

        if ($moduleCompleted) {
            $lessonStatusHtml = '<a class="label-chip label-chip--green" href="' . $lessonUrlEsc . '" style="text-decoration:none;"><span>Открыть</span></a>';
            $lessonStatusHtmlMobile = '<a class="label-chip" href="' . $lessonUrlEsc . '" style="text-decoration:none;"><span>OK</span></a>';
        } elseif ($moduleInProgress) {
            $lessonStatusHtml = '<a class="label-chip label-chip--purple" href="' . $lessonUrlEsc . '" style="text-decoration:none;"><span>Продолжить</span></a>';
            $lessonStatusHtmlMobile = '<a class="label-chip" href="' . $lessonUrlEsc . '" style="text-decoration:none;"><span>' . $moduleProgressPercent . '%</span></a>';
        }

        $lessonIconHtml = '<a href="' . $lessonUrlEsc . '" class="cs-item__playlink" aria-label="Открыть урок"><span class="cs-item__ico" aria-hidden="true"><img src="theme/images/training/curses/play-ico.png" alt=""></span></a>';
        $lessonTitleHtml = '<a href="' . $lessonUrlEsc . '" class="cs-item__title-link">' . trainingCoursePageEsc($lessonTitle) . '</a>';

        if ($moduleLocked || $lessonUrl === '#') {
            $lessonStatusHtml = '<span class="cs-lock"><img src="theme/images/training/curses/lock-keyhole-ico.svg" class="img-svg" alt=""><span>Заблокировано</span></span>';
            $lessonStatusHtmlMobile = '<span class="label-chip"><img src="theme/images/training/curses/lock-keyhole-ico.svg" class="img-svg" alt=""></span>';
            $lessonIconHtml = '<span class="cs-item__ico" aria-hidden="true"><img src="theme/images/training/curses/play-ico.png" alt=""></span>';
            $lessonTitleHtml = '<span class="cs-item__title-text">' . trainingCoursePageEsc($lessonTitle) . '</span>';
        }

        $lessonsHtml .= trainingCoursePageRenderChunk($modx, $corePath, $lessonTpl, array(
            'lesson_locked_class' => $moduleLocked ? ' is-locked' : '',
            'lesson_icon_html' => $lessonIconHtml,
            'lesson_title_html' => $lessonTitleHtml,
            'lesson_type' => 'Учебный материал',
            'lesson_status_html' => $lessonStatusHtml,
            'lesson_status_mobile_html' => $lessonStatusHtmlMobile,
        ));
    }

    $modulesHtml .= trainingCoursePageRenderChunk($modx, $corePath, $moduleTpl, array(
        'module_open_class' => $openFirst ? ' is-open' : '',
        'module_aria_expanded' => $openFirst ? 'true' : 'false',
        'module_state' => $moduleState,
        'module_title' => trainingCoursePageEsc($moduleTitle),
        'module_lessons_count_text' => trainingCoursePageEsc($moduleLessonsCountText),
        'module_duration_text' => trainingCoursePageEsc($moduleDurationText),
        'module_duration_class' => $moduleDurationClass,
        'module_status_html' => $moduleStatusHtml,
        'module_lessons_html' => $lessonsHtml,
    ));

    $openFirst = false;
}

$totalModules = $moduleCount > 0 ? $moduleCount : $totalModulesFromProgress;
if ($courseDurationText === '') {
    $courseDurationText = trainingCoursePageFormatDuration($courseDurationSeconds);
}
$courseDurationClass = $courseDurationText !== '' ? '' : 'd-none';

return trainingCoursePageRenderChunk($modx, $corePath, $pageTpl, array(
    'course_title' => trainingCoursePageEsc($courseTitle),
    'course_image' => trainingCoursePageEsc($courseImage),
    'course_status_text' => trainingCoursePageEsc($courseStatusText),
    'course_status_class' => $courseStatusClass,
    'course_user_label' => trainingCoursePageEsc($courseUserLabel),
    'course_duration_text' => trainingCoursePageEsc($courseDurationText),
    'course_duration_class' => $courseDurationClass,
    'course_description' => $courseDescription,
    'course_progress_percent' => (string)$courseProgressPercent,
    'course_completed_modules' => (string)$completedModules,
    'course_total_modules' => (string)$totalModules,
    'course_total_lessons' => (string)$lessonsTotal,
    'course_total_tests' => (string)$testsCount,
    'course_modules_html' => $modulesHtml,
));
