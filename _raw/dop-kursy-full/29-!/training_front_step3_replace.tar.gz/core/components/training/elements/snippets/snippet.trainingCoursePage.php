<?php
/** @var modX $modx */
/** @var array $scriptProperties */

$corePath = $modx->getOption(
    'training.core_path',
    null,
    $modx->getOption('core_path') . 'components/training/'
);

require_once $corePath . 'model/training/training.class.php';
require_once $corePath . 'model/training/services/trainingprogress.class.php';

if (!function_exists('trainingCoursePageRenderChunk')) {
    function trainingCoursePageRenderChunk($corePath, $relativePath, array $placeholders = array())
    {
        $basePath = rtrim(str_replace('\\', '/', (string)$corePath), '/');
        $path = $basePath . '/elements/chunks/' . ltrim($relativePath, '/');
        if (!is_file($path)) {
            return '';
        }

        $content = (string)file_get_contents($path);
        if ($content === '') {
            return '';
        }

        $replace = array();
        foreach ($placeholders as $key => $value) {
            if (is_array($value) || is_object($value)) {
                $value = '';
            }
            $replace['{$' . $key . '}'] = (string)$value;
        }

        return strtr($content, $replace);
    }
}

if (!function_exists('trainingCoursePageEsc')) {
    function trainingCoursePageEsc($value)
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('trainingCoursePagePlural')) {
    function trainingCoursePagePlural($number, array $forms)
    {
        $number = abs((int)$number) % 100;
        $n1 = $number % 10;
        if ($number > 10 && $number < 20) {
            return $forms[2];
        }
        if ($n1 > 1 && $n1 < 5) {
            return $forms[1];
        }
        if ($n1 == 1) {
            return $forms[0];
        }
        return $forms[2];
    }
}

if (!function_exists('trainingCoursePageFormatDuration')) {
    function trainingCoursePageFormatDuration($seconds)
    {
        $seconds = (int)$seconds;
        if ($seconds <= 0) {
            return '';
        }

        $hours = (int)floor($seconds / 3600);
        $minutes = (int)floor(($seconds % 3600) / 60);
        if ($hours > 0) {
            return $hours . ' часов ' . $minutes . ' минут';
        }
        if ($minutes > 0) {
            return $minutes . ' минут';
        }
        return $seconds . ' сек';
    }
}

if (!function_exists('trainingCoursePageMakePlayerUrl')) {
    function trainingCoursePageMakePlayerUrl(modX $modx, $moduleResourceId, $lessonId)
    {
        $moduleResourceId = (int)$moduleResourceId;
        $lessonId = (int)$lessonId;
        $viewerResourceId = (int)$modx->getOption('training.training_view_resource_id', null, 174);
        if ($viewerResourceId <= 0 || $moduleResourceId <= 0 || $lessonId <= 0) {
            return '';
        }

        $baseUrl = $modx->makeUrl($viewerResourceId);
        if (!$baseUrl) {
            return '';
        }

        return $baseUrl . (strpos($baseUrl, '?') === false ? '?' : '&') . http_build_query(array(
            'module' => $moduleResourceId,
            'lesson' => $lessonId,
        ));
    }
}

if (!function_exists('trainingCoursePageGetUserLabel')) {
    function trainingCoursePageGetUserLabel(modUser $user)
    {
        $profile = $user->getOne('Profile');
        if ($profile) {
            $fullname = trim((string)$profile->get('fullname'));
            if ($fullname !== '') {
                return $fullname;
            }
        }
        return trim((string)$user->get('username'));
    }
}

$resourceId = (int)$modx->getOption('resource_id', $scriptProperties, $modx->resource ? $modx->resource->get('id') : 0);
$pageTpl = trim((string)$modx->getOption('pageTpl', $scriptProperties, 'training/course/page.tpl'));
$moduleTpl = trim((string)$modx->getOption('moduleTpl', $scriptProperties, 'training/course/module.tpl'));
$lessonTpl = trim((string)$modx->getOption('lessonTpl', $scriptProperties, 'training/course/lesson.tpl'));

if ($resourceId <= 0) {
    return '<div class="section-block"><div class="alert alert-warning mb-0">Курс не найден.</div></div>';
}

if (!$modx->user || !(int)$modx->user->get('id') || !$modx->user->isAuthenticated($modx->context->get('key'))) {
    return '';
}

$training = new Training($modx);
$service = new TrainingProgressService($modx, $training);
$userId = (int)$modx->user->get('id');

/** @var TrainingCourse $course */
$course = $modx->getObject('TrainingCourse', array('resource_id' => $resourceId, 'is_active' => 1));
/** @var modResource $resource */
$resource = $modx->getObject('modResource', array('id' => $resourceId, 'deleted' => 0));

if (!$course || !$resource) {
    return '<div class="section-block"><div class="alert alert-warning mb-0">Курс недоступен.</div></div>';
}

$courseId = (int)$course->get('id');
if (!$service->hasCourseAccess($courseId, $userId)) {
    return '<div class="section-block"><div class="alert alert-warning mb-0">У вас нет доступа к этому курсу.</div></div>';
}

$service->syncUserCourseForUser($courseId, $userId);
/** @var TrainingUserCourse $userCourse */
$userCourse = $service->recalculateUserCourse($courseId, $userId);
if (!$userCourse || (string)$userCourse->get('status') === 'revoked') {
    return '<div class="section-block"><div class="alert alert-warning mb-0">У вас нет доступа к этому курсу.</div></div>';
}

$courseTitle = trim((string)$resource->get('pagetitle'));
$courseImage = trim((string)$resource->getTVValue('image_curse'));
if ($courseImage === '') {
    $courseImage = 'theme/images/training/image_2.jpg';
}
$courseDescription = trim((string)$resource->getTVValue('desc'));
if ($courseDescription === '') {
    $courseDescription = trim((string)$resource->get('description'));
}
if ($courseDescription === '') {
    $courseDescription = 'Описание курса пока не заполнено.';
}
$courseDescription = nl2br($courseDescription);
$courseDurationText = trim((string)$resource->getTVValue('time_curse'));

$courseLessonStats = $service->getCourseLessonStats($courseId, $userId);
$courseTestStats = $service->getCourseTestStats($courseId, $userId);
$courseVideosCompleted = (int)$courseLessonStats['completed_lessons'];
$courseVideosTotal = (int)$courseLessonStats['total_lessons'];
$courseTestsPassed = (int)$courseTestStats['passed_tests'];
$courseTestsTotal = (int)$courseTestStats['total_tests'];
$coursePracticesCompleted = 0;
$coursePracticesTotal = 0;

$courseStatusText = 'Не начат';
$courseStatusClass = 'label-chip--blue';
$courseProgressPercent = round((float)$userCourse->get('progress_percent'));
if ((string)$userCourse->get('status') === 'completed' || $courseProgressPercent >= 100) {
    $courseStatusText = 'Курс завершен';
    $courseStatusClass = 'label-chip--green';
} elseif ((string)$userCourse->get('status') === 'in_progress' || $courseProgressPercent > 0) {
    $courseStatusText = 'В процессе';
    $courseStatusClass = 'label-chip--purple';
}

$modulesHtml = '';
$courseDurationSeconds = (int)$courseLessonStats['duration_seconds'];
$modules = $service->getCourseModules($courseId, true, false);
$moduleIds = array();
/** @var TrainingModule $module */
foreach ($modules as $module) {
    $moduleIds[] = (int)$module->get('id');
}
$openModuleId = (int)$userCourse->get('current_module_id');
if ($openModuleId <= 0 && !empty($moduleIds)) {
    $openModuleId = (int)reset($moduleIds);
}

/** @var TrainingModule $module */
foreach ($modules as $module) {
    $moduleId = (int)$module->get('id');
    $moduleResourceId = (int)$module->get('resource_id');
    /** @var modResource $moduleResource */
    $moduleResource = $module->getOne('Resource');
    $moduleTitle = $moduleResource ? trim((string)$moduleResource->get('pagetitle')) : ('Модуль ' . $moduleId);

    $lessonRows = $service->getModuleLessons($moduleId, true, true);
    $moduleLessonsCount = count($lessonRows);
    $moduleLessonStats = $service->getModuleLessonStats($courseId, $moduleId, $userId);

    /** @var TrainingUserModuleProgress $moduleProgress */
    $moduleProgress = $service->recalculateModuleProgressFromLessons($courseId, $moduleId, $userId);
    $moduleProgressPercent = $moduleProgress ? round((float)$moduleProgress->get('progress_percent')) : 0;
    $moduleCompleted = $moduleProgress ? ((int)$moduleProgress->get('completed') === 1) : false;
    $moduleLocked = !$service->canAccessModule($courseId, $moduleId, $userId);
    $moduleStarted = (int)$moduleLessonStats['started_lessons'] > 0 || $moduleProgressPercent > 0 || ((int)$userCourse->get('current_module_id') === $moduleId);

    $moduleDurationSeconds = $moduleProgress ? (int)$moduleProgress->get('duration_seconds') : 0;
    if ($moduleDurationSeconds <= 0) {
        $moduleDurationSeconds = (int)$moduleLessonStats['duration_seconds'];
    }
    $moduleDurationText = trainingCoursePageFormatDuration($moduleDurationSeconds);
    $moduleDurationClass = $moduleDurationText !== '' ? '' : 'd-none';

    if ($moduleLocked) {
        $moduleStatusHtml = '<span class="cs-lock"><img src="theme/images/training/curses/lock-keyhole-ico.svg" class="img-svg" alt=""><span>Заблокировано</span></span>';
        $moduleState = 'locked';
    } elseif ($moduleCompleted) {
        $moduleStatusHtml = '<span class="label-chip label-chip--green"><span>Курс завершен</span></span>';
        $moduleState = 'done';
    } elseif ($moduleStarted) {
        $moduleStatusHtml = '<span class="label-chip label-chip--purple"><span>В процессе (' . (int)$moduleLessonStats['completed_lessons'] . '/' . (int)$moduleLessonStats['total_lessons'] . ')</span></span>';
        $moduleState = 'progress';
    } else {
        $moduleStatusHtml = '<span class="label-chip label-chip--blue"><span>Не начат</span></span>';
        $moduleState = 'new';
    }

    $moduleLessonsHtml = '';
    /** @var TrainingModuleLesson $lesson */
    foreach ($lessonRows as $lesson) {
        $lessonId = (int)$lesson->get('id');
        $lessonTitle = trim((string)$lesson->get('title'));
        if ($lessonTitle === '') {
            $lessonTitle = 'Урок ' . ((int)$lesson->get('sort_order') + 1);
        }

        $lessonLocked = !$service->canAccessLesson($courseId, $moduleId, $lessonId, $userId);
        $lessonProgress = $service->getLessonProgress($courseId, $lessonId, $userId);
        $lessonCompleted = $lessonProgress && (int)$lessonProgress->get('completed') === 1;
        $lessonProgressPercent = $lessonProgress ? round((float)$lessonProgress->get('progress_percent')) : 0;
        $lessonUrl = !$lessonLocked ? trainingCoursePageMakePlayerUrl($modx, $moduleResourceId, $lessonId) : '';

        if ($lessonLocked) {
            $lessonStatusHtml = '<span class="cs-lock"><img src="theme/images/training/curses/lock-keyhole-ico.svg" class="img-svg" alt=""><span>Заблокировано</span></span>';
            $lessonStatusMobileHtml = '<span class="cs-lock"><img src="theme/images/training/curses/lock-keyhole-ico.svg" class="img-svg" alt=""></span>';
        } elseif ($lessonCompleted) {
            $lessonStatusHtml = '<a class="label-chip label-chip--green" href="' . trainingCoursePageEsc($lessonUrl) . '" style="text-decoration:none;"><span>100%</span></a>';
            $lessonStatusMobileHtml = '<a class="label-chip label-chip--green" href="' . trainingCoursePageEsc($lessonUrl) . '" style="text-decoration:none;"><span>100%</span></a>';
        } elseif ($lessonProgressPercent > 0) {
            $lessonStatusHtml = '<a class="label-chip label-chip--purple" href="' . trainingCoursePageEsc($lessonUrl) . '" style="text-decoration:none;"><span>Продолжить</span></a>';
            $lessonStatusMobileHtml = '<a class="label-chip label-chip--purple" href="' . trainingCoursePageEsc($lessonUrl) . '" style="text-decoration:none;"><span>' . $lessonProgressPercent . '%</span></a>';
        } else {
            $lessonStatusHtml = '<a class="label-chip label-chip--blue" href="' . trainingCoursePageEsc($lessonUrl) . '" style="text-decoration:none;"><span>Начать</span></a>';
            $lessonStatusMobileHtml = '<a class="label-chip label-chip--blue" href="' . trainingCoursePageEsc($lessonUrl) . '" style="text-decoration:none;"><span>→</span></a>';
        }

        $lessonIconHtml = '<span class="cs-item__ico" aria-hidden="true"><img src="theme/images/training/curses/play-ico.png" alt=""></span>';
        if (!$lessonLocked && $lessonUrl !== '') {
            $lessonIconHtml = '<a href="' . trainingCoursePageEsc($lessonUrl) . '" class="cs-item__playlink" aria-label="Открыть урок"><span class="cs-item__ico" aria-hidden="true"><img src="theme/images/training/curses/play-ico.png" alt=""></span></a>';
        }

        $moduleLessonsHtml .= trainingCoursePageRenderChunk($corePath, $lessonTpl, array(
            'lesson_locked_class' => $lessonLocked ? ' is-locked' : '',
            'lesson_icon_html' => $lessonIconHtml,
            'lesson_title_html' => trainingCoursePageEsc($lessonTitle),
            'lesson_type' => 'Учебный материал',
            'lesson_status_html' => $lessonStatusHtml,
            'lesson_status_mobile_html' => $lessonStatusMobileHtml,
        ));
    }

    $moduleLessonsCountText = $moduleLessonsCount . ' ' . trainingCoursePagePlural($moduleLessonsCount, array('материал', 'материала', 'материалов'));
    $modulesHtml .= trainingCoursePageRenderChunk($corePath, $moduleTpl, array(
        'module_open_class' => $openModuleId === $moduleId ? ' is-open' : '',
        'module_aria_expanded' => $openModuleId === $moduleId ? 'true' : 'false',
        'module_state' => $moduleState,
        'module_title' => trainingCoursePageEsc($moduleTitle),
        'module_lessons_count_text' => trainingCoursePageEsc($moduleLessonsCountText),
        'module_duration_text' => trainingCoursePageEsc($moduleDurationText),
        'module_duration_class' => $moduleDurationClass,
        'module_status_html' => $moduleStatusHtml,
        'module_lessons_html' => $moduleLessonsHtml,
    ));
}

if ($courseDurationText === '') {
    $courseDurationText = trainingCoursePageFormatDuration($courseDurationSeconds);
}

return trainingCoursePageRenderChunk($corePath, $pageTpl, array(
    'course_title' => trainingCoursePageEsc($courseTitle),
    'course_image' => trainingCoursePageEsc($courseImage),
    'course_status_text' => trainingCoursePageEsc($courseStatusText),
    'course_status_class' => $courseStatusClass,
    'course_user_label' => trainingCoursePageEsc(trainingCoursePageGetUserLabel($modx->user)),
    'course_duration_text' => trainingCoursePageEsc($courseDurationText),
    'course_duration_class' => $courseDurationText !== '' ? '' : 'd-none',
    'course_description' => $courseDescription,
    'course_progress_percent' => $courseProgressPercent,
    'course_completed_modules' => (int)$userCourse->get('completed_modules'),
    'course_total_modules' => (int)$userCourse->get('total_modules'),
    'course_videos_completed' => $courseVideosCompleted,
    'course_videos_total' => $courseVideosTotal,
    'course_practices_completed' => $coursePracticesCompleted,
    'course_practices_total' => $coursePracticesTotal,
    'course_tests_passed' => $courseTestsPassed,
    'course_tests_total' => $courseTestsTotal,
    'course_modules_html' => $modulesHtml,
));
