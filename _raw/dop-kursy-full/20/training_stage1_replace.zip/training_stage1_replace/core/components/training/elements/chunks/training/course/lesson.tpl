<div class="cs-item[[+lesson_locked_class]]">
    <span class="cs-item__ico" aria-hidden="true">
        <img src="theme/images/training/curses/play-ico.png" alt="">
    </span>
    <div class="cs-item__txt">
        <div class="cs-item__title">[[+lesson_title]]</div>
        <div class="cs-item__type">[[+lesson_type]]</div>
    </div>
    <div class="cs-item__status d-none d-xl-flex">[[+lesson_status_html]]</div>
    <div class="cs-item__status d-flex d-xl-none">[[+lesson_status_mobile_html]]</div>
</div>
