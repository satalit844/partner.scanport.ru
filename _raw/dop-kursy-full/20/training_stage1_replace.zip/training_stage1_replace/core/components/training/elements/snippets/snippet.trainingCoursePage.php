<?php
/** @var modX $modx */
/** @var array $scriptProperties */

$corePath = $modx->getOption(
    'training.core_path',
    null,
    $modx->getOption('core_path') . 'components/training/'
);

require_once $corePath . 'model/training/training.class.php';
require_once $corePath . 'model/training/services/trainingprogress.class.php';

if (!function_exists('trainingCoursePageRenderChunk')) {
    function trainingCoursePageRenderChunk(modX $modx, $corePath, $relativePath, array $placeholders = [])
    {
        $path = rtrim($corePath, '/\') . '/elements/chunks/' . ltrim($relativePath, '/\');
        if (!is_file($path)) {
            return '';
        }

        $content = file_get_contents($path);
        /** @var modChunk $chunk */
        $chunk = $modx->newObject('modChunk');
        $chunk->setCacheable(false);
        $chunk->setContent($content);

        return $chunk->process($placeholders);
    }
}

if (!function_exists('trainingCoursePageFormatDuration')) {
    function trainingCoursePageFormatDuration($seconds)
    {
        $seconds = (int)$seconds;
        if ($seconds <= 0) {
            return '';
        }

        $hours = (int)floor($seconds / 3600);
        $minutes = (int)floor(($seconds % 3600) / 60);

        if ($hours > 0) {
            if ($minutes > 0) {
                return $hours . ' ч ' . $minutes . ' мин';
            }
            return $hours . ' ч';
        }

        if ($minutes > 0) {
            return $minutes . ' мин';
        }

        return $seconds . ' сек';
    }
}

if (!function_exists('trainingCoursePagePlural')) {
    function trainingCoursePagePlural($number, array $forms)
    {
        $number = abs((int)$number) % 100;
        $n1 = $number % 10;

        if ($number > 10 && $number < 20) {
            return $forms[2];
        }
        if ($n1 > 1 && $n1 < 5) {
            return $forms[1];
        }
        if ($n1 == 1) {
            return $forms[0];
        }

        return $forms[2];
    }
}

if (!function_exists('trainingCoursePageGetProfileExtended')) {
    function trainingCoursePageGetProfileExtended(modUser $user)
    {
        $profile = $user->getOne('Profile');
        if (!$profile) {
            return [];
        }

        $extended = $profile->get('extended');
        if (is_array($extended)) {
            return $extended;
        }

        $extended = trim((string)$extended);
        if ($extended === '') {
            return [];
        }

        $decoded = json_decode($extended, true);
        return is_array($decoded) ? $decoded : [];
    }
}

if (!function_exists('trainingCoursePageExtractOrganization')) {
    function trainingCoursePageExtractOrganization(modUser $user)
    {
        $extended = trainingCoursePageGetProfileExtended($user);
        $keys = [
            'company',
            'organization',
            'organisation',
            'org',
            'company_name',
            'organisation_name',
            'employer',
            'workplace',
        ];

        foreach ($keys as $key) {
            if (!empty($extended[$key])) {
                return trim((string)$extended[$key]);
            }
        }

        $profile = $user->getOne('Profile');
        if ($profile) {
            $fullname = trim((string)$profile->get('fullname'));
            if ($fullname !== '') {
                return $fullname;
            }
        }

        return trim((string)$user->get('username'));
    }
}

if (!function_exists('trainingCoursePageMakeViewUrl')) {
    function trainingCoursePageMakeViewUrl(modX $modx, $viewerResourceId, $moduleResourceId, $lessonId = 0, $moduleParam = 'module', $lessonParam = 'lesson')
    {
        $viewerResourceId = (int)$viewerResourceId;
        $moduleResourceId = (int)$moduleResourceId;
        $lessonId = (int)$lessonId;

        if ($viewerResourceId <= 0 || $moduleResourceId <= 0) {
            return '#';
        }

        $baseUrl = $modx->makeUrl($viewerResourceId);
        if (!$baseUrl) {
            return '#';
        }

        $params = [$moduleParam => $moduleResourceId];
        if ($lessonId > 0) {
            $params[$lessonParam] = $lessonId;
        }

        return $baseUrl . (strpos($baseUrl, '?') === false ? '?' : '&') . http_build_query($params);
    }
}

$resourceId = (int)$modx->getOption('resource_id', $scriptProperties, $modx->resource ? $modx->resource->get('id') : 0);
$viewerResourceId = (int)$modx->getOption(
    'viewer_resource_id',
    $scriptProperties,
    (int)$modx->getOption('training.training_view_resource_id', null, 174)
);
$viewerModuleParam = trim((string)$modx->getOption('viewer_module_param', $scriptProperties, 'module'));
$viewerLessonParam = trim((string)$modx->getOption('viewer_lesson_param', $scriptProperties, 'lesson'));

$pageTpl = trim((string)$modx->getOption('pageTpl', $scriptProperties, 'training/course/page.tpl'));
$moduleTpl = trim((string)$modx->getOption('moduleTpl', $scriptProperties, 'training/course/module.tpl'));
$lessonTpl = trim((string)$modx->getOption('lessonTpl', $scriptProperties, 'training/course/lesson.tpl'));

if ($resourceId <= 0) {
    return '<div class="section-block"><div class="alert alert-warning mb-0">Курс не найден.</div></div>';
}

if (!$modx->user || !(int)$modx->user->get('id') || !$modx->user->isAuthenticated($modx->context->get('key'))) {
    return '';
}

$training = new Training($modx);
$progressService = new TrainingProgressService($modx, $training);
$userId = (int)$modx->user->get('id');

/** @var TrainingCourse|null $course */
$course = $modx->getObject('TrainingCourse', [
    'resource_id' => $resourceId,
]);

/** @var modResource|null $resource */
$resource = $modx->getObject('modResource', [
    'id' => $resourceId,
    'deleted' => 0,
]);

if (!$course || !$resource || !(int)$course->get('is_active')) {
    return '<div class="section-block"><div class="alert alert-warning mb-0">Курс недоступен.</div></div>';
}

$courseId = (int)$course->get('id');
$hasAccess = $progressService->hasCourseAccess($courseId, $userId);
if (!$hasAccess) {
    return '<div class="section-block"><div class="alert alert-warning mb-0">У вас нет доступа к этому курсу.</div></div>';
}

$progressService->syncUserCourseForUser($courseId, $userId);
$progressService->recalculateUserCourse($courseId, $userId);

/** @var TrainingUserCourse|null $userCourse */
$userCourse = $modx->getObject('TrainingUserCourse', [
    'course_id' => $courseId,
    'user_id' => $userId,
]);

if (!$userCourse || (string)$userCourse->get('status') === 'revoked') {
    return '<div class="section-block"><div class="alert alert-warning mb-0">У вас нет доступа к этому курсу.</div></div>';
}

$courseTitle = trim((string)$resource->get('pagetitle'));

$courseImage = trim((string)$resource->getTVValue('image_curse'));
if ($courseImage === '') {
    $courseImage = 'theme/images/training/curses/image_1.jpg';
}

$courseDescription = trim((string)$resource->getTVValue('desc'));
if ($courseDescription === '') {
    $fallbackDescription = trim((string)$resource->get('description'));
    $courseDescription = $fallbackDescription !== ''
        ? nl2br(htmlspecialchars($fallbackDescription, ENT_QUOTES, 'UTF-8'))
        : 'Описание курса пока не заполнено.';
}

$courseDurationText = trim((string)$resource->getTVValue('time_curse'));

$courseProgressPercent = (int)round((float)$userCourse->get('progress_percent'));
$completedModules = (int)$userCourse->get('completed_modules');
$totalModulesFromProgress = (int)$userCourse->get('total_modules');
$currentModuleId = (int)$userCourse->get('current_module_id');
$courseStatus = (string)$userCourse->get('status');
$isSequential = (int)$course->get('is_sequential') === 1;

$courseStatusText = 'Не начат';
$courseStatusClass = 'label-chip--blue';

if ($courseStatus === 'completed' || $courseProgressPercent >= 100) {
    $courseStatusText = 'Пройден';
    $courseStatusClass = 'label-chip--green';
} elseif ($courseStatus === 'in_progress' || $courseProgressPercent > 0 || $completedModules > 0) {
    $courseStatusText = 'В процессе';
    $courseStatusClass = 'label-chip--purple';
}

$courseUserLabel = trainingCoursePageExtractOrganization($modx->user);

$testsCount = (int)$modx->getCount('TrainingTestLink', [
    'course_id' => $courseId,
]);

$modules = $progressService->getCourseModules($courseId, true, false);

$progressQuery = $modx->newQuery('TrainingUserModuleProgress');
$progressQuery->where([
    'course_id' => $courseId,
    'user_id' => $userId,
]);
$progressRows = $modx->getCollection('TrainingUserModuleProgress', $progressQuery);

$progressMap = [];
/** @var TrainingUserModuleProgress $progressRow */
foreach ($progressRows as $progressRow) {
    $progressMap[(int)$progressRow->get('module_id')] = $progressRow;
}

$modulesHtml = '';
$moduleCount = 0;
$lessonsTotal = 0;
$courseDurationSeconds = 0;
$sequenceLocked = false;
$openFirst = true;

/** @var TrainingModule $module */
foreach ($modules as $module) {
    $moduleCount++;
    $moduleId = (int)$module->get('id');

    /** @var modResource|null $moduleResource */
    $moduleResource = $module->getOne('Resource');
    $moduleResourceId = $moduleResource ? (int)$moduleResource->get('id') : 0;
    $moduleTitle = $moduleResource ? trim((string)$moduleResource->get('pagetitle')) : '';
    if ($moduleTitle === '') {
        $moduleTitle = 'Модуль ' . $moduleCount;
    }

    $lessonQuery = $modx->newQuery('TrainingModuleLesson');
    $lessonQuery->where([
        'module_id' => $moduleId,
        'is_active' => 1,
    ]);
    $lessonQuery->sortby('sort_order', 'ASC');
    $lessonQuery->sortby('id', 'ASC');
    $lessons = $modx->getCollection('TrainingModuleLesson', $lessonQuery);

    $lessonRows = [];
    $firstLessonId = 0;
    $moduleLessonsCount = 0;
    $moduleDurationSeconds = (int)$module->get('duration_seconds');

    /** @var TrainingModuleLesson $lesson */
    foreach ($lessons as $lesson) {
        $moduleLessonsCount++;
        $lessonId = (int)$lesson->get('id');
        if ($firstLessonId <= 0) {
            $firstLessonId = $lessonId;
        }

        $lessonRows[] = $lesson;
    }

    if ($moduleLessonsCount <= 0) {
        $moduleLessonsCount = 1;
    }
    $lessonsTotal += $moduleLessonsCount;

    if ($moduleDurationSeconds <= 0 && !empty($lessonRows)) {
        $sumDuration = 0;
        foreach ($lessonRows as $lesson) {
            $sumDuration += (int)$lesson->get('duration_seconds');
        }
        $moduleDurationSeconds = $sumDuration;
    }

    $courseDurationSeconds += max(0, $moduleDurationSeconds);
    $moduleDurationText = trainingCoursePageFormatDuration($moduleDurationSeconds);
    $moduleDurationClass = $moduleDurationText !== '' ? '' : 'd-none';

    /** @var TrainingUserModuleProgress|null $moduleProgress */
    $moduleProgress = isset($progressMap[$moduleId]) ? $progressMap[$moduleId] : null;
    $moduleProgressPercent = $moduleProgress ? (int)round((float)$moduleProgress->get('progress_percent')) : 0;

    $moduleCompleted = $moduleProgress
        ? ((int)$moduleProgress->get('completed') === 1 || $moduleProgressPercent >= 100)
        : false;

    $moduleInProgress = $moduleProgress
        ? ($moduleProgressPercent > 0 || (string)$moduleProgress->get('status') === 'in_progress' || (int)$moduleProgress->get('max_time') > 0)
        : false;

    if (!$moduleInProgress && $currentModuleId === $moduleId && !$moduleCompleted) {
        $moduleInProgress = true;
    }

    $moduleLocked = false;
    if ($isSequential && $sequenceLocked && !$moduleCompleted && !$moduleInProgress) {
        $moduleLocked = true;
    }

    $moduleState = 'available';
    $moduleStatusHtml = '<span class="label-chip label-chip--blue"><span>Доступен</span></span>';

    if ($moduleCompleted) {
        $moduleState = 'done';
        $moduleStatusHtml = '<span class="label-chip label-chip--green"><span>Пройден</span></span>';
    } elseif ($moduleLocked) {
        $moduleState = 'locked';
        $moduleStatusHtml = '<span class="cs-lock"><img src="theme/images/training/curses/lock-keyhole-ico.svg" class="img-svg" alt=""><span>Заблокировано</span></span>';
    } elseif ($moduleInProgress) {
        $moduleState = 'progress';
        $moduleStatusHtml = '<span class="label-chip label-chip--purple"><span>В процессе (' . $moduleProgressPercent . '%)</span></span>';
    }

    if (!$moduleCompleted) {
        $sequenceLocked = true;
    }

    $moduleLessonsCountText = $moduleLessonsCount . ' ' . trainingCoursePagePlural($moduleLessonsCount, ['материал', 'материала', 'материалов']);

    $moduleViewUrl = trainingCoursePageMakeViewUrl(
        $modx,
        $viewerResourceId,
        $moduleResourceId,
        $firstLessonId,
        $viewerModuleParam,
        $viewerLessonParam
    );

    $lessonsHtml = '';

    if (!empty($lessonRows)) {
        $lessonIndex = 0;

        /** @var TrainingModuleLesson $lesson */
        foreach ($lessonRows as $lesson) {
            $lessonIndex++;
            $lessonId = (int)$lesson->get('id');
            $lessonTitle = trim((string)$lesson->get('title'));
            if ($lessonTitle === '') {
                $lessonTitle = $moduleTitle . ' — урок ' . $lessonIndex;
            }

            $lessonActionText = 'Начать';
            $lessonActionClass = 'label-chip label-chip--blue';

            if ($moduleCompleted) {
                $lessonActionText = 'Открыть';
                $lessonActionClass = 'label-chip label-chip--green';
            } elseif ($moduleInProgress) {
                $lessonActionText = 'Продолжить';
                $lessonActionClass = 'label-chip label-chip--purple';
            }

            $lessonUrl = trainingCoursePageMakeViewUrl(
                $modx,
                $viewerResourceId,
                $moduleResourceId,
                $lessonId,
                $viewerModuleParam,
                $viewerLessonParam
            );
            $lessonUrl = htmlspecialchars($lessonUrl, ENT_QUOTES, 'UTF-8');

            $lessonStatusHtml = '<a class="' . $lessonActionClass . '" href="' . $lessonUrl . '" style="text-decoration:none;"><span>' . $lessonActionText . '</span></a>';
            $lessonStatusHtmlMobile = '<a class="label-chip" href="' . $lessonUrl . '" style="text-decoration:none;"><span>' . ($moduleInProgress ? $moduleProgressPercent . '%' : ($moduleCompleted ? 'OK' : '→')) . '</span></a>';

            if ($moduleLocked) {
                $lessonStatusHtml = '<span class="cs-lock"><img src="theme/images/training/curses/lock-keyhole-ico.svg" class="img-svg" alt=""><span>Заблокировано</span></span>';
                $lessonStatusHtmlMobile = '<span class="label-chip"><img src="theme/images/training/curses/lock-keyhole-ico.svg" class="img-svg" alt=""></span>';
            }

            $lessonsHtml .= trainingCoursePageRenderChunk($modx, $corePath, $lessonTpl, [
                'lesson_title' => htmlspecialchars($lessonTitle, ENT_QUOTES, 'UTF-8'),
                'lesson_type' => 'Учебный материал',
                'lesson_locked_class' => $moduleLocked ? ' is-locked' : '',
                'lesson_status_html' => $lessonStatusHtml,
                'lesson_status_mobile_html' => $lessonStatusHtmlMobile,
            ]);
        }
    } else {
        $moduleViewUrlEsc = htmlspecialchars($moduleViewUrl, ENT_QUOTES, 'UTF-8');
        $lessonStatusHtml = '<a class="label-chip label-chip--blue" href="' . $moduleViewUrlEsc . '" style="text-decoration:none;"><span>Открыть</span></a>';
        $lessonStatusHtmlMobile = '<a class="label-chip" href="' . $moduleViewUrlEsc . '" style="text-decoration:none;"><span>→</span></a>';

        if ($moduleCompleted) {
            $lessonStatusHtml = '<a class="label-chip label-chip--green" href="' . $moduleViewUrlEsc . '" style="text-decoration:none;"><span>Открыть</span></a>';
            $lessonStatusHtmlMobile = '<a class="label-chip" href="' . $moduleViewUrlEsc . '" style="text-decoration:none;"><span>OK</span></a>';
        } elseif ($moduleInProgress) {
            $lessonStatusHtml = '<a class="label-chip label-chip--purple" href="' . $moduleViewUrlEsc . '" style="text-decoration:none;"><span>Продолжить</span></a>';
            $lessonStatusHtmlMobile = '<a class="label-chip" href="' . $moduleViewUrlEsc . '" style="text-decoration:none;"><span>' . $moduleProgressPercent . '%</span></a>';
        } elseif ($moduleLocked) {
            $lessonStatusHtml = '<span class="cs-lock"><img src="theme/images/training/curses/lock-keyhole-ico.svg" class="img-svg" alt=""><span>Заблокировано</span></span>';
            $lessonStatusHtmlMobile = '<span class="label-chip"><img src="theme/images/training/curses/lock-keyhole-ico.svg" class="img-svg" alt=""></span>';
        }

        $lessonsHtml .= trainingCoursePageRenderChunk($modx, $corePath, $lessonTpl, [
            'lesson_title' => 'Перейти к просмотру',
            'lesson_type' => 'Учебный материал',
            'lesson_locked_class' => $moduleLocked ? ' is-locked' : '',
            'lesson_status_html' => $lessonStatusHtml,
            'lesson_status_mobile_html' => $lessonStatusHtmlMobile,
        ]);
    }

    $modulesHtml .= trainingCoursePageRenderChunk($modx, $corePath, $moduleTpl, [
        'module_open_class' => $openFirst ? ' is-open' : '',
        'module_aria_expanded' => $openFirst ? 'true' : 'false',
        'module_state' => $moduleState,
        'module_title' => htmlspecialchars($moduleTitle, ENT_QUOTES, 'UTF-8'),
        'module_lessons_count_text' => htmlspecialchars($moduleLessonsCountText, ENT_QUOTES, 'UTF-8'),
        'module_duration_text' => htmlspecialchars($moduleDurationText, ENT_QUOTES, 'UTF-8'),
        'module_duration_class' => $moduleDurationClass,
        'module_status_html' => $moduleStatusHtml,
        'module_lessons_html' => $lessonsHtml,
    ]);

    $openFirst = false;
}

$totalModules = $moduleCount > 0 ? $moduleCount : $totalModulesFromProgress;

if ($courseDurationText === '') {
    $courseDurationText = trainingCoursePageFormatDuration($courseDurationSeconds);
}
$courseDurationClass = $courseDurationText !== '' ? '' : 'd-none';

return trainingCoursePageRenderChunk($modx, $corePath, $pageTpl, [
    'course_title' => htmlspecialchars($courseTitle, ENT_QUOTES, 'UTF-8'),
    'course_image' => htmlspecialchars($courseImage, ENT_QUOTES, 'UTF-8'),
    'course_status_text' => htmlspecialchars($courseStatusText, ENT_QUOTES, 'UTF-8'),
    'course_status_class' => $courseStatusClass,
    'course_user_label' => htmlspecialchars($courseUserLabel, ENT_QUOTES, 'UTF-8'),
    'course_duration_text' => htmlspecialchars($courseDurationText, ENT_QUOTES, 'UTF-8'),
    'course_duration_class' => $courseDurationClass,
    'course_description' => $courseDescription,
    'course_progress_percent' => $courseProgressPercent,
    'course_completed_modules' => $completedModules,
    'course_total_modules' => $totalModules,
    'course_total_lessons' => $lessonsTotal,
    'course_total_tests' => $testsCount,
    'course_modules_html' => $modulesHtml,
]);
