Файлы для замены, этап 1 (страница курса).

После замены:
1. Сниппет trainingCoursePage должен смотреть на файл core/components/training/elements/snippets/snippet.trainingCoursePage.php
2. Chunk-файлы грузятся сниппетом напрямую из core/components/training/elements/chunks/training/course/
