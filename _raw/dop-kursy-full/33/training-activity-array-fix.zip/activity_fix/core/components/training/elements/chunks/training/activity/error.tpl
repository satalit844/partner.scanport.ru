<div class="section-block tests-block results-block">
    <div class="page-content d-flex flex-column h-100">
        <div class="test-card position-relative w-100 d-flex flex-column">
            <div class="test-header d-flex align-items-center justify-content-between mb-4">
                <img src="theme/images/training/tests/logo-scanport.svg" alt="Сканпорт" class="img-svg">
            </div>
            <div class="test-content-list text-left mb-auto">
                <div class="test-question d-flex align-items-center gap-2 gap-lg-3 mb-4">
                    <img src="theme/images/training/tests/circle-x.svg" class="img-svg"><span>{$title}</span>
                </div>
                <div class="test-subtitle">{$message}</div>
            </div>
            <div class="test-footer d-flex flex-wrap align-items-center justify-content-end gap-2 gap-sm-4">
                {$back_button_html}
            </div>
        </div>
    </div>
</div>
