<div class="section-block tests-block">
    <div class="page-content d-flex flex-column h-100">
        <div class="test-card position-relative w-100 d-flex flex-column">
            <div class="test-header">
                <img src="theme/images/training/tests/logo-scanport.svg" alt="Сканпорт" class="img-svg">
            </div>
            <div class="test-content text-left text-md-center mb-auto my-md-auto">
                <div class="test-title">
                    Добро пожаловать к {$activity_type_title} по материалам {$module_title}
                </div>
                {$activity_description_html}
                {$activity_attempts_html}
            </div>
            <div class="test-footer d-flex flex-wrap align-items-center justify-content-between gap-2 gap-sm-4">
                {$back_button_html}
                <a href="{$instruction_url}" class="btn btn-test col-auto text-decoration-none">
                    <span>{$start_button_text}</span>
                    <img src="theme/images/training/tests/arrow-right-ico.svg" class="img-svg d-none d-sm-block">
                </a>
            </div>
        </div>
    </div>
</div>
