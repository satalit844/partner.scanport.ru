<div class="section-block tests-block">
    <div class="page-content d-flex flex-column h-100">
        <div class="test-card position-relative w-100 d-flex flex-column">
            <div class="test-header mb-4">
                <img src="theme/images/training/tests/logo-scanport.svg" alt="Сканпорт" class="img-svg">
            </div>
            <div class="test-content-list text-left mb-auto">
                <div class="test-title mb-4">
                    {if $activity_type_label == 'Практическое задание'}
                        Инструкция по выполнению задания
                    {else}
                        Инструкция по прохождению теста
                    {/if}
                </div>
                {if $activity_instruction_html}
                    <div class="test-subtitle mb-4">
                        {$activity_instruction_html}
                    </div>
                {else}
                    <ul class="test-list mb-5">
                        <li>Перед ответом внимательно прочитайте текст вопроса</li>
                        <li>Затем выберите правильный вариант ответа. В некоторых вопросах может быть несколько правильных ответов</li>
                        <li>Нажмите кнопку <span>«Ответить»</span> для подтверждения ответа</li>
                        <li>Для просмотра и выбора вопросов используйте <span>список</span> вопросов</li>
                    </ul>
                {/if}

                {if $activity_min_pass_percent}
                    <div class="text-info-test mt-3">
                        Проходной балл: {$activity_min_pass_percent}%
                    </div>
                {/if}
                {if $activity_attempts_text}
                    <div class="text-info-test mt-2">
                        Попытки: {$activity_attempts_text}
                    </div>
                {/if}
            </div>
            <div class="test-footer d-flex flex-wrap align-items-center justify-content-between gap-2 gap-sm-4">
                <a href="{$back_url}" class="btn btn-test btn-reload-test col-auto text-decoration-none">
                    <span>Назад к курсу</span>
                    <img src="theme/images/training/tests/arrow-rotate-ico.svg" class="img-svg d-none d-sm-block">
                </a>
                <a href="{$run_url}" class="btn btn-test col-auto text-decoration-none">
                    <span>{$continue_button_text}</span>
                    <img src="theme/images/training/tests/arrow-right-ico.svg" class="img-svg d-none d-sm-block">
                </a>
            </div>
        </div>
    </div>
</div>
