<?php
/** @var modX $modx */
/** @var array $scriptProperties */

$corePath = $modx->getOption(
    'training.core_path',
    null,
    $modx->getOption('core_path') . 'components/training/'
);

require_once $corePath . 'model/training/training.class.php';
require_once $corePath . 'model/training/services/trainingprogress.class.php';

if (!function_exists('trainingActivityGetRenderer')) {
    function trainingActivityGetRenderer(modX $modx)
    {
        static $pdoTools = null;
        static $checked = false;

        if (!$checked) {
            $checked = true;
            $pdoTools = $modx->getService('pdoTools');
        }

        return $pdoTools;
    }
}

if (!function_exists('trainingActivityRenderChunk')) {
    function trainingActivityRenderChunk(modX $modx, $corePath, $relativePath, array $placeholders = array())
    {
        $basePath = rtrim(str_replace('\\', '/', (string)$corePath), '/');
        $path = $basePath . '/elements/chunks/' . ltrim($relativePath, '/');
        if (!is_file($path)) {
            return '';
        }

        $pdoTools = trainingActivityGetRenderer($modx);
        if ($pdoTools) {
            return (string)$pdoTools->getChunk('@FILE ' . $path, $placeholders);
        }

        $content = (string)file_get_contents($path);
        if ($content === '') {
            return '';
        }

        $replace = array();
        foreach ($placeholders as $key => $value) {
            if (is_array($value) || is_object($value)) {
                $value = '';
            }
            $replace['{$' . $key . '}'] = (string)$value;
        }

        return strtr($content, $replace);
    }
}

if (!function_exists('trainingActivityEsc')) {
    function trainingActivityEsc($value)
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('trainingActivityMakeUrl')) {
    function trainingActivityMakeUrl(modX $modx, $resourceId, array $params = array())
    {
        $resourceId = (int)$resourceId;
        if ($resourceId <= 0) {
            return '';
        }

        return (string)$modx->makeUrl($resourceId, '', $params);
    }
}

if (!function_exists('trainingActivityFormatAttempts')) {
    function trainingActivityFormatAttempts($used, $max)
    {
        $used = max(0, (int)$used);
        $max = max(0, (int)$max);
        if ($max <= 0) {
            return '';
        }

        return $used . '/' . $max;
    }
}

$resourceId = (int)$modx->getOption('resource_id', $scriptProperties, $modx->resource ? $modx->resource->get('id') : 0);
$activityId = isset($_GET['activity']) ? (int)$_GET['activity'] : (int)$modx->getOption('activity', $scriptProperties, 0);
$screen = trim((string)(isset($_GET['screen']) ? $_GET['screen'] : $modx->getOption('screen', $scriptProperties, '')));
$backResourceId = isset($_GET['back']) ? (int)$_GET['back'] : (int)$modx->getOption('back', $scriptProperties, 0);
$testPageId = (int)$modx->getOption('training.training_test_resource_id', null, 170);
$practicePageId = (int)$modx->getOption('training.training_practice_resource_id', null, 176);

if ($resourceId <= 0) {
    return '';
}

if (!$modx->user || !(int)$modx->user->get('id') || !$modx->user->isAuthenticated($modx->context->get('key'))) {
    return '';
}

if ($activityId <= 0) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Активность не найдена',
        'message' => 'Не передан параметр активности.',
        'back_url' => $backResourceId > 0 ? trainingActivityMakeUrl($modx, $backResourceId) : '',
    ));
}

$training = new Training($modx);
$service = new TrainingProgressService($modx, $training);
$userId = (int)$modx->user->get('id');

/** @var TrainingTestLink|null $activity */
$activity = $modx->getObject('TrainingTestLink', array('id' => $activityId));
if (!$activity) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Активность не найдена',
        'message' => 'Запрашиваемая активность не существует.',
        'back_url' => $backResourceId > 0 ? trainingActivityMakeUrl($modx, $backResourceId) : '',
    ));
}

$courseId = (int)$activity->get('course_id');
$moduleId = (int)$activity->get('module_id');
$testId = (int)$activity->get('usertest_test_id');
$linkType = $service->normalizeActivityLinkType($activity->get('link_type'));
$targetResourceId = $linkType === 'practice' ? $practicePageId : $testPageId;
if ($targetResourceId > 0 && $resourceId !== $targetResourceId) {
    $params = array('activity' => $activityId);
    if ($backResourceId > 0) {
        $params['back'] = $backResourceId;
    }
    if ($screen !== '') {
        $params['screen'] = $screen;
    }
    if (isset($_GET['step'])) {
        $params['step'] = trim((string)$_GET['step']);
    }
    if (isset($_GET['result_id'])) {
        $params['result_id'] = (int)$_GET['result_id'];
    }
    if (isset($_GET['reset'])) {
        $params['reset'] = 1;
    }
    $modx->sendRedirect(trainingActivityMakeUrl($modx, $targetResourceId, $params));
    return '';
}

/** @var TrainingCourse|null $course */
$course = $modx->getObject('TrainingCourse', array('id' => $courseId, 'is_active' => 1));
/** @var TrainingModule|null $module */
$module = $modx->getObject('TrainingModule', array('id' => $moduleId, 'course_id' => $courseId, 'is_active' => 1));
/** @var modResource|null $courseResource */
$courseResource = $course ? $modx->getObject('modResource', array('id' => (int)$course->get('resource_id'), 'deleted' => 0)) : null;

if (!$course || !$module || !$courseResource) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Курс недоступен',
        'message' => 'Связанный курс или модуль не найдены.',
        'back_url' => $backResourceId > 0 ? trainingActivityMakeUrl($modx, $backResourceId) : '',
    ));
}

if ($backResourceId <= 0) {
    $backResourceId = (int)$courseResource->get('id');
}
$backUrl = trainingActivityMakeUrl($modx, $backResourceId > 0 ? $backResourceId : (int)$courseResource->get('id'));

$service->syncUserCourseForUser($courseId, $userId);
if (!$service->hasCourseAccess($courseId, $userId)) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Нет доступа',
        'message' => 'У вас нет доступа к этой активности.',
        'back_url' => $backUrl,
    ));
}

if (!$service->canAccessModule($courseId, $moduleId, $userId)) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Активность заблокирована',
        'message' => 'Сначала завершите предыдущие обязательные модули курса.',
        'back_url' => $backUrl,
    ));
}

$moduleLessons = $service->getModuleLessons($moduleId, true, true);
$allLessonsCompleted = true;
foreach ($moduleLessons as $lesson) {
    $lessonProgress = $service->getLessonProgress($courseId, (int)$lesson->get('id'), $userId);
    if (!$lessonProgress || (int)$lessonProgress->get('completed') !== 1) {
        $allLessonsCompleted = false;
        break;
    }
}

$activityRows = $service->getModuleActivityRows($courseId, $moduleId, $userId);
$currentRow = null;
$previousRequiredActivitiesCompleted = true;
foreach ($activityRows as $row) {
    if ((int)$row['id'] === $activityId) {
        $currentRow = $row;
        break;
    }
    if (!empty($row['is_required']) && empty($row['completed'])) {
        $previousRequiredActivitiesCompleted = false;
    }
}

if (!$currentRow) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Активность не найдена',
        'message' => 'Эта активность не привязана к модулю.',
        'back_url' => $backUrl,
    ));
}

if (!$allLessonsCompleted || !$previousRequiredActivitiesCompleted) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Активность заблокирована',
        'message' => 'Сначала завершите все видеоуроки и обязательные активности этого модуля.',
        'back_url' => $backUrl,
    ));
}

if ($testId <= 0) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Тест не найден',
        'message' => 'Для активности не выбран тест usertest.',
        'back_url' => $backUrl,
    ));
}

$usertestCorePath = $modx->getOption('usertest_core_path', null, $modx->getOption('core_path') . 'components/usertest/');
$usertestModelPath = rtrim($usertestCorePath, '/\\') . '/model/';
if (!is_dir($usertestModelPath)) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'UserTest недоступен',
        'message' => 'Не найден пакет usertest.',
        'back_url' => $backUrl,
    ));
}
$modx->addPackage('usertest', $usertestModelPath);

/** @var UserTestTests|null $test */
$test = $modx->getObject('UserTestTests', array('id' => $testId, 'active' => 1));
if (!$test) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Тест недоступен',
        'message' => 'Связанный тест не найден или выключен.',
        'back_url' => $backUrl,
    ));
}

$status = $service->syncUserTestStatus($courseId, $moduleId, $testId, $userId);
$currentStatus = $status ? trim((string)$status->get('status')) : 'not_started';
$currentAttempts = $status ? (int)$status->get('attempts') : 0;
$maxAttempts = (int)$activity->get('max_attempts');
$minPassPercent = (float)$activity->get('min_pass_percent');

$canRestart = true;
if ($maxAttempts > 0 && $currentAttempts >= $maxAttempts && !in_array($currentStatus, array('passed', 'accepted', 'in_progress', 'pending_review', 'checking'), true)) {
    $canRestart = false;
}

$title = trim((string)$currentRow['title']);
if ($title === '') {
    $title = trim((string)$test->get('name'));
}
if ($title === '') {
    $title = $linkType === 'practice' ? 'Практическое задание' : 'Тест';
}

$description = trim((string)$test->get('description'));
$instructionHtml = trim((string)$test->get('instruction'));
$moduleTitle = '';
$moduleResource = $modx->getObject('modResource', array('id' => (int)$module->get('resource_id')));
if ($moduleResource) {
    $moduleTitle = trim((string)$moduleResource->get('pagetitle'));
}
if ($moduleTitle === '') {
    $moduleTitle = 'Модуль';
}

$instructionUrl = trainingActivityMakeUrl($modx, $targetResourceId, array(
    'activity' => $activityId,
    'back' => $backResourceId,
    'screen' => 'instruction',
));
$runUrl = trainingActivityMakeUrl($modx, $targetResourceId, array(
    'activity' => $activityId,
    'back' => $backResourceId,
    'step' => 'start',
));
$restartUrl = trainingActivityMakeUrl($modx, $targetResourceId, array(
    'activity' => $activityId,
    'back' => $backResourceId,
    'step' => 'start',
    'reset' => 1,
));

$actionModeTitle = $linkType === 'practice' ? 'практическому заданию' : 'тесту';
$actionStartButton = $linkType === 'practice' ? 'Начать задание' : 'Начать тест';
$actionContinueButton = $linkType === 'practice' ? 'Перейти к заданию' : 'Перейти к тесту';

if (!$canRestart && !isset($_GET['result_id']) && !isset($_GET['step']) && !isset($_GET['reset'])) {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/error.tpl', array(
        'title' => 'Попытки закончились',
        'message' => 'Доступное количество попыток исчерпано.',
        'back_url' => $backUrl,
    ));
}

$shouldRunTestEngine = isset($_GET['step']) || isset($_GET['result_id']) || isset($_GET['reset']);
if ($shouldRunTestEngine) {
    return $modx->runSnippet('UserTest', array(
        'id' => $testId,
        'AjaxMode' => 0,
        'tpl' => '@FILE ' . rtrim($corePath, '/\\') . '/elements/chunks/training/activity/usertest.tpl',
        'tplError' => '@FILE ' . rtrim($corePath, '/\\') . '/elements/chunks/training/activity/usertest.error.tpl',
        'training_activity_id' => $activityId,
        'training_activity_type' => $linkType,
        'training_activity_title' => $title,
        'training_activity_back_id' => $backResourceId,
        'training_activity_min_pass_percent' => $minPassPercent,
        'training_activity_max_attempts' => $maxAttempts,
    ));
}

$commonPlaceholders = array(
    'activity_id' => $activityId,
    'activity_title' => trainingActivityEsc($title),
    'module_title' => trainingActivityEsc($moduleTitle),
    'activity_type_label' => $linkType === 'practice' ? 'Практическое задание' : 'Тест',
    'activity_type_title' => $actionModeTitle,
    'activity_description' => $description,
    'activity_instruction_html' => $instructionHtml,
    'activity_attempts_text' => trainingActivityFormatAttempts($currentAttempts, $maxAttempts),
    'activity_min_pass_percent' => $minPassPercent > 0 ? rtrim(rtrim(number_format($minPassPercent, 2, '.', ''), '0'), '.') : '',
    'start_url' => $instructionUrl,
    'instruction_url' => $instructionUrl,
    'run_url' => $runUrl,
    'restart_url' => $restartUrl,
    'back_url' => $backUrl,
    'start_button_text' => $actionStartButton,
    'continue_button_text' => $actionContinueButton,
);

if ($screen === 'instruction') {
    return trainingActivityRenderChunk($modx, $corePath, 'training/activity/instruction.tpl', $commonPlaceholders);
}

return trainingActivityRenderChunk($modx, $corePath, 'training/activity/start.tpl', $commonPlaceholders);
