<?php
/**
 * Запустить один раз в MODX Console, если не хочешь вручную править содержимое сниппетов в админке.
 */
$map = array(
    'trainingCertificatesPage' => "return include MODX_CORE_PATH . 'components/training/elements/snippets/trainingCertificatesPage.php';",
    'trainingManageCertificatesPage' => "return include MODX_CORE_PATH . 'components/training/elements/snippets/trainingManageCertificatesPage.php';",
);

foreach ($map as $name => $code) {
    /** @var modSnippet $snippet */
    $snippet = $modx->getObject('modSnippet', array('name' => $name));
    if (!$snippet) {
        echo 'NOT FOUND: ' . $name . "\n";
        continue;
    }

    $snippet->set('snippet', $code);
    if ($snippet->save()) {
        echo 'UPDATED: ' . $name . "\n";
    } else {
        echo 'ERROR: ' . $name . "\n";
    }
}

$modx->cacheManager->refresh();
echo "DONE\n";
