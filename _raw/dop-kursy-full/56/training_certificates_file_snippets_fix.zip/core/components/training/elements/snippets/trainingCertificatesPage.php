<?php
/** @var modX $modx */
/** @var array $scriptProperties */

$corePath = $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/');
require_once $corePath . 'elements/snippets/_certificateHelper.php';

$pageTpl = trim((string)$modx->getOption('pageTpl', $scriptProperties, 'training/certificates/page.tpl'));
$itemTpl = trim((string)$modx->getOption('itemTpl', $scriptProperties, 'training/certificates/item.tpl'));
$modalTpl = trim((string)$modx->getOption('modalTpl', $scriptProperties, 'training/certificates/modal.tpl'));

$contextKey = $modx->context ? (string)$modx->context->get('key') : '';
$userId = ($modx->user && (int)$modx->user->get('id')) ? (int)$modx->user->get('id') : 0;

$debug = array(
    'snippet' => 'trainingCertificatesPage.php',
    'corePath' => $corePath,
    'context' => $contextKey,
    'user_id' => $userId,
    'auth_context' => ($userId > 0 && $contextKey !== '' && $modx->user->isAuthenticated($contextKey)) ? 'yes' : 'no',
    'auth_web' => ($userId > 0 && $modx->user->isAuthenticated('web')) ? 'yes' : 'no',
    'auth_mgr' => ($userId > 0 && $modx->user->isAuthenticated('mgr')) ? 'yes' : 'no',
    'pageTpl_exists' => is_file(trainingCertificatesChunkPath($corePath, $pageTpl)) ? 'yes' : 'no',
    'itemTpl_exists' => is_file(trainingCertificatesChunkPath($corePath, $itemTpl)) ? 'yes' : 'no',
    'modalTpl_exists' => is_file(trainingCertificatesChunkPath($corePath, $modalTpl)) ? 'yes' : 'no',
);

if (!trainingCertificatesIsAuthenticated($modx)) {
    if (trainingCertificatesDebugEnabled()) {
        return trainingCertificatesDebugHtml('CERT DEBUG: auth failed', $debug);
    }
    return '';
}

$tables = array(
    'certificates' => trainingCertificatesTableName($modx, 'training_user_certificates'),
    'templates' => trainingCertificatesTableName($modx, 'training_certificate_templates'),
    'courses' => trainingCertificatesTableName($modx, 'training_courses'),
    'users' => $modx->getTableName('modUser'),
    'profiles' => $modx->getTableName('modUserProfile'),
    'resources' => $modx->getTableName('modResource'),
);

$debug['certificates_table'] = $tables['certificates'];
$debug['certificates_table_exists'] = trainingCertificatesTableExists($modx, $tables['certificates']) ? 'yes' : 'no';
$debug['certificates_count_for_user'] = trainingCertificatesCount($modx, $tables['certificates'], '`user_id` = :user_id', array(':user_id' => $userId));

if (class_exists('TrainingCertificateService') && class_exists('Training')) {
    try {
        $service = new TrainingCertificateService($modx, new Training($modx));
        $generated = $service->ensureCertificatesForUser($userId, false);
        $debug['ensure_count'] = is_array($generated) ? count($generated) : 0;
    } catch (Exception $e) {
        $debug['ensure_error'] = $e->getMessage();
        $modx->log(modX::LOG_LEVEL_ERROR, '[trainingCertificatesPage] ensure error: ' . $e->getMessage());
    }
} else {
    $debug['service_loaded'] = 'no';
}

$rows = array();
if (trainingCertificatesTableExists($modx, $tables['certificates'])) {
    $sql = trainingCertificatesCertificateRowsSql($tables)
        . 'WHERE cert.`user_id` = :user_id '
        . 'ORDER BY cert.`issuedon` DESC, cert.`id` DESC';
    $rows = trainingCertificatesFetchAll($modx, $sql, array(':user_id' => $userId), 'trainingCertificatesPage');
}
$debug['rows_count'] = count($rows);

$itemsHtml = '';
foreach ($rows as $row) {
    $itemsHtml .= trainingCertificatesBuildItemHtml($corePath, $itemTpl, $row, false);
}

if ($itemsHtml === '') {
    $itemsHtml = '<div class="w-100">Сертификатов пока нет</div>';
}

$debugHtml = trainingCertificatesDebugHtml('CERT DEBUG: personal page', $debug);

return trainingCertificatesRenderChunk($corePath, $pageTpl, array(
    'page_title' => 'Сертификаты',
    'page_subtitle' => 'Мои сертификаты',
    'toolbar_html' => '',
    'items_html' => $debugHtml . $itemsHtml,
    'modal_html' => trainingCertificatesRenderChunk($corePath, $modalTpl, array()),
));
