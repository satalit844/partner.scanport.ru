<?php
/** @var modX $modx */

$corePath = $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/');

$trainingClass = $corePath . 'model/training/training.class.php';
$certificateServiceClass = $corePath . 'model/training/services/trainingcertificate.class.php';

if (is_file($trainingClass)) {
    require_once $trainingClass;
}
if (is_file($certificateServiceClass)) {
    require_once $certificateServiceClass;
}

if (!function_exists('trainingCertificatesEsc')) {
    function trainingCertificatesEsc($value)
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('trainingCertificatesChunkPath')) {
    function trainingCertificatesChunkPath($corePath, $relativePath)
    {
        return rtrim(str_replace('\\', '/', (string)$corePath), '/') . '/elements/chunks/' . ltrim((string)$relativePath, '/');
    }
}

if (!function_exists('trainingCertificatesRenderChunk')) {
    function trainingCertificatesRenderChunk($corePath, $relativePath, array $placeholders = array())
    {
        $path = trainingCertificatesChunkPath($corePath, $relativePath);
        if (!is_file($path)) {
            return '';
        }

        $content = (string)file_get_contents($path);
        if ($content === '') {
            return '';
        }

        $replace = array();
        foreach ($placeholders as $key => $value) {
            if (is_array($value) || is_object($value)) {
                $value = '';
            }
            $replace['{$' . $key . '}'] = (string)$value;
            $replace['[[+' . $key . ']]'] = (string)$value;
        }

        return strtr($content, $replace);
    }
}

if (!function_exists('trainingCertificatesTableExists')) {
    function trainingCertificatesTableExists(modX $modx, $table)
    {
        $table = str_replace('`', '', (string)$table);
        if ($table === '') {
            return false;
        }
        $stmt = $modx->query('SHOW TABLES LIKE ' . $modx->quote($table));
        return $stmt && $stmt->fetch(PDO::FETCH_NUM);
    }
}

if (!function_exists('trainingCertificatesTableName')) {
    function trainingCertificatesTableName(modX $modx, $name)
    {
        $prefix = (string)$modx->getOption('table_prefix', null, '');
        $name = ltrim((string)$name, '_');

        $candidates = array();
        $candidates[] = $prefix . $name;

        $fixed = rtrim($prefix, '_') . '_' . $name;
        if ($fixed !== $candidates[0]) {
            $candidates[] = $fixed;
        }

        $candidates[] = $name;

        foreach ($candidates as $table) {
            if (trainingCertificatesTableExists($modx, $table)) {
                return str_replace('`', '', $table);
            }
        }

        return str_replace('`', '', $prefix . $name);
    }
}

if (!function_exists('trainingCertificatesFetchAll')) {
    function trainingCertificatesFetchAll(modX $modx, $sql, array $params = array(), $logPrefix = 'trainingCertificates')
    {
        $stmt = $modx->prepare($sql);
        if (!$stmt || !$stmt->execute($params)) {
            if ($stmt && method_exists($stmt, 'errorInfo')) {
                $modx->log(modX::LOG_LEVEL_ERROR, '[' . $logPrefix . '] SQL error: ' . print_r($stmt->errorInfo(), true) . "\n" . $sql);
            }
            return array();
        }

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return is_array($rows) ? $rows : array();
    }
}

if (!function_exists('trainingCertificatesFetchColumn')) {
    function trainingCertificatesFetchColumn(modX $modx, $sql, array $params = array(), $logPrefix = 'trainingCertificates')
    {
        $stmt = $modx->prepare($sql);
        if (!$stmt || !$stmt->execute($params)) {
            if ($stmt && method_exists($stmt, 'errorInfo')) {
                $modx->log(modX::LOG_LEVEL_ERROR, '[' . $logPrefix . '] SQL error: ' . print_r($stmt->errorInfo(), true) . "\n" . $sql);
            }
            return array();
        }

        $rows = $stmt->fetchAll(PDO::FETCH_COLUMN);
        return is_array($rows) ? $rows : array();
    }
}

if (!function_exists('trainingCertificatesCount')) {
    function trainingCertificatesCount(modX $modx, $table, $where = '', array $params = array())
    {
        $sql = 'SELECT COUNT(*) FROM `' . str_replace('`', '', $table) . '`';
        if (trim((string)$where) !== '') {
            $sql .= ' WHERE ' . $where;
        }

        $stmt = $modx->prepare($sql);
        if (!$stmt || !$stmt->execute($params)) {
            return 0;
        }

        return (int)$stmt->fetchColumn();
    }
}

if (!function_exists('trainingCertificatesIsAuthenticated')) {
    function trainingCertificatesIsAuthenticated(modX $modx)
    {
        if (!$modx->user || !(int)$modx->user->get('id')) {
            return false;
        }

        $contextKey = $modx->context ? (string)$modx->context->get('key') : '';
        if ($contextKey !== '' && $modx->user->isAuthenticated($contextKey)) {
            return true;
        }

        if ($modx->user->isAuthenticated('web')) {
            return true;
        }

        if ($modx->user->isAuthenticated('mgr')) {
            return true;
        }

        return false;
    }
}

if (!function_exists('trainingCertificatesIsAdmin')) {
    function trainingCertificatesIsAdmin(modX $modx)
    {
        if (!$modx->user || !(int)$modx->user->get('id')) {
            return false;
        }

        if ((int)$modx->user->get('sudo') === 1) {
            return true;
        }

        if (method_exists($modx->user, 'isMember')) {
            if ($modx->user->isMember('Administrator') || $modx->user->isMember('Администратор')) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('trainingCertificatesDebugEnabled')) {
    function trainingCertificatesDebugEnabled()
    {
        return isset($_GET['debug_cert']) && (string)$_GET['debug_cert'] === '1';
    }
}

if (!function_exists('trainingCertificatesDebugHtml')) {
    function trainingCertificatesDebugHtml($title, array $data)
    {
        if (!trainingCertificatesDebugEnabled()) {
            return '';
        }

        $html = '<pre class="training-cert-debug" style="white-space:pre-wrap;background:#f6f8fa;border:1px solid #d0d7de;border-radius:10px;padding:12px;margin:0 0 16px;font-size:13px;line-height:1.45;">';
        $html .= trainingCertificatesEsc($title) . "\n";
        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $value = implode(',', array_map('strval', $value));
            } elseif (is_bool($value)) {
                $value = $value ? 'yes' : 'no';
            }
            $html .= trainingCertificatesEsc($key . ': ' . (string)$value) . "\n";
        }
        $html .= '</pre>';

        return $html;
    }
}

if (!function_exists('trainingCertificatesCertificateRowsSql')) {
    function trainingCertificatesCertificateRowsSql(array $tables)
    {
        return 'SELECT cert.*, '
            . 't.`template_pdf`, '
            . 't.`template_preview`, '
            . 'r.`pagetitle` AS `course_pagetitle`, '
            . 'u.`username`, '
            . 'p.`email`, '
            . 'COALESCE(NULLIF(TRIM(cert.`fullname`), ""), NULLIF(TRIM(p.`fullname`), ""), NULLIF(TRIM(u.`username`), ""), CONCAT("Пользователь #", cert.`user_id`)) AS `display_user`, '
            . 'COALESCE(NULLIF(TRIM(cert.`course_title`), ""), NULLIF(TRIM(r.`pagetitle`), ""), CONCAT("Курс #", cert.`course_id`)) AS `display_course_title` '
            . 'FROM `' . $tables['certificates'] . '` cert '
            . 'LEFT JOIN `' . $tables['templates'] . '` t ON t.`id` = cert.`template_id` '
            . 'LEFT JOIN `' . $tables['courses'] . '` c ON c.`id` = cert.`course_id` '
            . 'LEFT JOIN `' . $tables['resources'] . '` r ON r.`id` = c.`resource_id` '
            . 'LEFT JOIN `' . $tables['users'] . '` u ON u.`id` = cert.`user_id` '
            . 'LEFT JOIN `' . $tables['profiles'] . '` p ON p.`internalKey` = cert.`user_id` ';
    }
}

if (!function_exists('trainingCertificatesBuildItemHtml')) {
    function trainingCertificatesBuildItemHtml($corePath, $itemTpl, array $row, $withUserName = false)
    {
        $file = trim((string)(isset($row['file_path']) ? $row['file_path'] : ''));
        $preview = trim((string)(isset($row['preview_image']) ? $row['preview_image'] : ''));
        if ($preview === '') {
            $preview = trim((string)(isset($row['template_preview']) ? $row['template_preview'] : ''));
        }
        if ($preview === '') {
            $preview = $file;
        }

        $courseTitle = trim((string)(isset($row['display_course_title']) ? $row['display_course_title'] : ''));
        if ($courseTitle === '') {
            $courseTitle = trim((string)(isset($row['course_title']) ? $row['course_title'] : ''));
        }
        if ($courseTitle === '') {
            $courseTitle = trim((string)(isset($row['course_pagetitle']) ? $row['course_pagetitle'] : ''));
        }
        if ($courseTitle === '') {
            $courseTitle = 'Курс #' . (int)(isset($row['course_id']) ? $row['course_id'] : 0);
        }

        $title = $courseTitle;
        if ($withUserName) {
            $userName = trim((string)(isset($row['display_user']) ? $row['display_user'] : ''));
            if ($userName === '') {
                $userName = 'Пользователь #' . (int)(isset($row['user_id']) ? $row['user_id'] : 0);
            }
            $title = $userName . ' — ' . $courseTitle;
        }

        $issuedon = trim((string)(isset($row['issuedon']) ? $row['issuedon'] : ''));
        $date = '—';
        if ($issuedon !== '' && $issuedon !== '0000-00-00 00:00:00') {
            $time = strtotime($issuedon);
            $date = $time ? date('d.m.Y', $time) : $issuedon;
        }

        return trainingCertificatesRenderChunk($corePath, $itemTpl, array(
            'certificate_title' => trainingCertificatesEsc($title),
            'certificate_status' => trainingCertificatesEsc($issuedon !== '' ? 'Сертификат выдан' : 'Сертификат готов'),
            'certificate_preview' => trainingCertificatesEsc($preview),
            'certificate_file' => trainingCertificatesEsc($file !== '' ? $file : $preview),
            'certificate_issuedon' => trainingCertificatesEsc($date),
        ));
    }
}
