<?php
$map = array(
    'trainingCertificatesPage' => "return include MODX_CORE_PATH . 'components/training/elements/snippets/trainingCertificatesPage.php';",
    'trainingManageCertificatesPage' => "return include MODX_CORE_PATH . 'components/training/elements/snippets/trainingManageCertificatesPage.php';",
);

foreach ($map as $name => $code) {
    $snippet = $modx->getObject('modSnippet', array('name' => $name));
    if (!$snippet) {
        echo 'NOT FOUND: ' . $name . "\n";
        continue;
    }

    $snippet->set('snippet', $code);
    echo ($snippet->save() ? 'UPDATED: ' : 'ERROR: ') . $name . "\n";
}

$modx->cacheManager->refresh();
echo "DONE\n";
