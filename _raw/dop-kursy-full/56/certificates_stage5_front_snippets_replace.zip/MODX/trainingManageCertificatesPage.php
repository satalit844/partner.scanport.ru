<?php
/** @var modX $modx */
/** @var array $scriptProperties */

$corePath = $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/');
require_once $corePath . 'elements/snippets/_certificateHelper.php';

if (!$modx->user || !(int)$modx->user->get('id') || !$modx->user->isAuthenticated($modx->context->get('key'))) {
    return '';
}

$pageTpl = trim((string)$modx->getOption('pageTpl', $scriptProperties, 'training/certificates/page.tpl'));
$itemTpl = trim((string)$modx->getOption('itemTpl', $scriptProperties, 'training/certificates/item.tpl'));
$modalTpl = trim((string)$modx->getOption('modalTpl', $scriptProperties, 'training/certificates/modal.tpl'));
$userSelectTpl = trim((string)$modx->getOption('userSelectTpl', $scriptProperties, 'training/certificates/user-select.tpl'));

$actorUserId = (int)$modx->user->get('id');
$selectedUserId = (int)$modx->getOption('certificate_user', $_GET, 0);
$prefix = (string)$modx->getOption('table_prefix', null, 'modx_');

$tables = array(
    'certificates' => $prefix . 'training_user_certificates',
    'templates' => $prefix . 'training_certificate_templates',
    'courses' => $prefix . 'training_courses',
    'course_access' => $prefix . 'training_course_access',
    'manager_link' => $prefix . 'training_user_manager_link',
    'users' => $modx->getTableName('modUser'),
    'profiles' => $modx->getTableName('modUserProfile'),
    'resources' => $modx->getTableName('modResource'),
);

$getColumn = function ($sql, array $params) use ($modx) {
    $stmt = $modx->prepare($sql);
    if (!$stmt || !$stmt->execute($params)) {
        if ($stmt && method_exists($stmt, 'errorInfo')) {
            $modx->log(modX::LOG_LEVEL_ERROR, '[trainingManageCertificatesPage] SQL: ' . print_r($stmt->errorInfo(), true));
        }
        return array();
    }
    return (array)$stmt->fetchAll(PDO::FETCH_COLUMN);
};

$directorCourseIds = $getColumn(
    'SELECT DISTINCT ca.`course_id` '
    . 'FROM `' . $tables['course_access'] . '` ca '
    . 'WHERE ca.`is_active` = 1 '
    . 'AND ca.`access_role` IN ("director", "manager") '
    . 'AND ((ca.`principal_type` = "user" AND ca.`principal_id` = :user_id) OR ca.`user_id` = :user_id2) '
    . 'AND (ca.`active_from` IS NULL OR ca.`active_from` = "0000-00-00 00:00:00" OR ca.`active_from` <= NOW()) '
    . 'AND (ca.`active_to` IS NULL OR ca.`active_to` = "0000-00-00 00:00:00" OR ca.`active_to` >= NOW())',
    array(':user_id' => $actorUserId, ':user_id2' => $actorUserId)
);
$directorCourseIds = array_values(array_unique(array_filter(array_map('intval', $directorCourseIds))));

$managedUserIds = $getColumn(
    'SELECT DISTINCT ml.`employee_user_id` '
    . 'FROM `' . $tables['manager_link'] . '` ml '
    . 'WHERE ml.`manager_user_id` = :user_id AND ml.`is_active` = 1',
    array(':user_id' => $actorUserId)
);
$managedUserIds = array_values(array_unique(array_filter(array_map('intval', $managedUserIds))));

$where = array('cert.`user_id` = :actor_user_id');
$params = array(':actor_user_id' => $actorUserId);

if (!empty($managedUserIds)) {
    $ph = array();
    foreach ($managedUserIds as $i => $id) {
        $key = ':managed_user_' . $i;
        $ph[] = $key;
        $params[$key] = (int)$id;
    }
    $where[] = 'cert.`user_id` IN (' . implode(',', $ph) . ')';
}

if (!empty($directorCourseIds)) {
    $ph = array();
    foreach ($directorCourseIds as $i => $id) {
        $key = ':director_course_' . $i;
        $ph[] = $key;
        $params[$key] = (int)$id;
    }
    $where[] = 'cert.`course_id` IN (' . implode(',', $ph) . ')';
}

$sql = 'SELECT cert.*, '
    . 't.`template_preview`, '
    . 'r.`pagetitle` AS `course_pagetitle`, '
    . 'u.`username`, p.`email`, '
    . 'COALESCE(NULLIF(TRIM(cert.`fullname`), ""), NULLIF(TRIM(p.`fullname`), ""), NULLIF(TRIM(u.`username`), ""), CONCAT("Пользователь #", cert.`user_id`)) AS `display_user`, '
    . 'COALESCE(NULLIF(TRIM(cert.`course_title`), ""), NULLIF(TRIM(r.`pagetitle`), ""), CONCAT("Курс #", cert.`course_id`)) AS `display_course_title` '
    . 'FROM `' . $tables['certificates'] . '` cert '
    . 'LEFT JOIN `' . $tables['templates'] . '` t ON t.`id` = cert.`template_id` '
    . 'LEFT JOIN `' . $tables['courses'] . '` c ON c.`id` = cert.`course_id` '
    . 'LEFT JOIN `' . $tables['resources'] . '` r ON r.`id` = c.`resource_id` '
    . 'LEFT JOIN `' . $tables['users'] . '` u ON u.`id` = cert.`user_id` '
    . 'LEFT JOIN `' . $tables['profiles'] . '` p ON p.`internalKey` = cert.`user_id` '
    . 'WHERE (' . implode(' OR ', $where) . ') '
    . 'ORDER BY cert.`issuedon` DESC, cert.`id` DESC';

$rows = array();
$stmt = $modx->prepare($sql);
if ($stmt && $stmt->execute($params)) {
    $rows = (array)$stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    if ($stmt && method_exists($stmt, 'errorInfo')) {
        $modx->log(modX::LOG_LEVEL_ERROR, '[trainingManageCertificatesPage] list certificates: ' . print_r($stmt->errorInfo(), true));
    }
}

$userMap = array();
foreach ($rows as $row) {
    $uid = (int)(isset($row['user_id']) ? $row['user_id'] : 0);
    if ($uid > 0) {
        $userMap[$uid] = isset($row['display_user']) ? (string)$row['display_user'] : ('Пользователь #' . $uid);
    }
}

if ($selectedUserId > 0 && isset($userMap[$selectedUserId])) {
    $filtered = array();
    foreach ($rows as $row) {
        if ((int)$row['user_id'] === $selectedUserId) {
            $filtered[] = $row;
        }
    }
    $rows = $filtered;
} else {
    $selectedUserId = 0;
}

$toolbarHtml = '';
if (count($userMap) > 1) {
    asort($userMap, SORT_NATURAL | SORT_FLAG_CASE);
    $optionsHtml = '<option value="0"' . ($selectedUserId === 0 ? ' selected="selected"' : '') . '>Все пользователи</option>';
    foreach ($userMap as $id => $name) {
        $id = (int)$id;
        $optionsHtml .= '<option value="' . $id . '"' . ($id === $selectedUserId ? ' selected="selected"' : '') . '>' . trainingCertificatesEsc($name) . '</option>';
    }
    $toolbarHtml = trainingCertificatesRenderChunk($corePath, $userSelectTpl, array(
        'select_name' => 'certificate_user',
        'select_options_html' => $optionsHtml,
    ));
}

$itemsHtml = '';
foreach ($rows as $row) {
    $file = trim((string)(isset($row['file_path']) ? $row['file_path'] : ''));
    $preview = trim((string)(isset($row['preview_image']) ? $row['preview_image'] : ''));
    if ($preview === '') {
        $preview = trim((string)(isset($row['template_preview']) ? $row['template_preview'] : ''));
    }
    if ($preview === '') {
        $preview = $file;
    }

    $title = trim((string)(isset($row['display_course_title']) ? $row['display_course_title'] : 'Сертификат'));
    $userName = trim((string)(isset($row['display_user']) ? $row['display_user'] : ''));
    if ($userName !== '') {
        $title = $userName . ' — ' . $title;
    }

    $itemsHtml .= trainingCertificatesRenderChunk($corePath, $itemTpl, array(
        'certificate_title' => trainingCertificatesEsc($title),
        'certificate_status' => trainingCertificatesEsc(!empty($row['issuedon']) ? 'Сертификат выдан' : 'Сертификат готов'),
        'certificate_preview' => trainingCertificatesEsc($preview),
        'certificate_file' => trainingCertificatesEsc($file !== '' ? $file : $preview),
        'certificate_issuedon' => !empty($row['issuedon']) ? trainingCertificatesEsc(date('d.m.Y', strtotime($row['issuedon']))) : '—',
    ));
}

if ($itemsHtml === '') {
    $itemsHtml = '<div class="w-100">Сертификатов пока нет</div>';
}

return trainingCertificatesRenderChunk($corePath, $pageTpl, array(
    'page_title' => 'Управление сертификатами',
    'page_subtitle' => 'Сертификаты',
    'toolbar_html' => $toolbarHtml,
    'items_html' => $itemsHtml,
    'modal_html' => trainingCertificatesRenderChunk($corePath, $modalTpl, array()),
));
