<?php
/** @var modX $modx */
/** @var array $scriptProperties */

$corePath = $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/');
require_once $corePath . 'elements/snippets/_certificateHelper.php';

if (!$modx->user || !(int)$modx->user->get('id') || !$modx->user->isAuthenticated($modx->context->get('key'))) {
    return '';
}

$pageTpl = trim((string)$modx->getOption('pageTpl', $scriptProperties, 'training/certificates/page.tpl'));
$itemTpl = trim((string)$modx->getOption('itemTpl', $scriptProperties, 'training/certificates/item.tpl'));
$modalTpl = trim((string)$modx->getOption('modalTpl', $scriptProperties, 'training/certificates/modal.tpl'));

$userId = (int)$modx->user->get('id');
$prefix = (string)$modx->getOption('table_prefix', null, 'modx_');

$tables = array(
    'certificates' => $prefix . 'training_user_certificates',
    'templates' => $prefix . 'training_certificate_templates',
    'courses' => $prefix . 'training_courses',
    'resources' => $modx->getTableName('modResource'),
);

try {
    $service = new TrainingCertificateService($modx, new Training($modx));
    $service->ensureCertificatesForUser($userId, false);
} catch (Exception $e) {
    $modx->log(modX::LOG_LEVEL_ERROR, '[trainingCertificatesPage] ensureCertificatesForUser: ' . $e->getMessage());
} catch (Throwable $e) {
    $modx->log(modX::LOG_LEVEL_ERROR, '[trainingCertificatesPage] ensureCertificatesForUser: ' . $e->getMessage());
}

$sql = 'SELECT cert.*, '
    . 't.`template_preview`, '
    . 'r.`pagetitle` AS `course_pagetitle`, '
    . 'COALESCE(NULLIF(TRIM(cert.`course_title`), ""), NULLIF(TRIM(r.`pagetitle`), ""), CONCAT("Курс #", cert.`course_id`)) AS `display_course_title` '
    . 'FROM `' . $tables['certificates'] . '` cert '
    . 'LEFT JOIN `' . $tables['templates'] . '` t ON t.`id` = cert.`template_id` '
    . 'LEFT JOIN `' . $tables['courses'] . '` c ON c.`id` = cert.`course_id` '
    . 'LEFT JOIN `' . $tables['resources'] . '` r ON r.`id` = c.`resource_id` '
    . 'WHERE cert.`user_id` = :user_id '
    . 'ORDER BY cert.`issuedon` DESC, cert.`id` DESC';

$rows = array();
$stmt = $modx->prepare($sql);
if ($stmt && $stmt->execute(array(':user_id' => $userId))) {
    $rows = (array)$stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    if ($stmt && method_exists($stmt, 'errorInfo')) {
        $modx->log(modX::LOG_LEVEL_ERROR, '[trainingCertificatesPage] list certificates: ' . print_r($stmt->errorInfo(), true));
    }
}

$itemsHtml = '';
foreach ($rows as $row) {
    $file = trim((string)(isset($row['file_path']) ? $row['file_path'] : ''));
    $preview = trim((string)(isset($row['preview_image']) ? $row['preview_image'] : ''));
    if ($preview === '') {
        $preview = trim((string)(isset($row['template_preview']) ? $row['template_preview'] : ''));
    }
    if ($preview === '') {
        $preview = $file;
    }

    $itemsHtml .= trainingCertificatesRenderChunk($corePath, $itemTpl, array(
        'certificate_title' => trainingCertificatesEsc(isset($row['display_course_title']) ? $row['display_course_title'] : 'Сертификат'),
        'certificate_status' => trainingCertificatesEsc(!empty($row['issuedon']) ? 'Сертификат выдан' : 'Сертификат готов'),
        'certificate_preview' => trainingCertificatesEsc($preview),
        'certificate_file' => trainingCertificatesEsc($file !== '' ? $file : $preview),
        'certificate_issuedon' => !empty($row['issuedon']) ? trainingCertificatesEsc(date('d.m.Y', strtotime($row['issuedon']))) : '—',
    ));
}

if ($itemsHtml === '') {
    $itemsHtml = '<div class="w-100">Сертификатов пока нет</div>';
}

return trainingCertificatesRenderChunk($corePath, $pageTpl, array(
    'page_title' => 'Сертификаты',
    'page_subtitle' => 'Мои сертификаты',
    'toolbar_html' => '',
    'items_html' => $itemsHtml,
    'modal_html' => trainingCertificatesRenderChunk($corePath, $modalTpl, array()),
));
