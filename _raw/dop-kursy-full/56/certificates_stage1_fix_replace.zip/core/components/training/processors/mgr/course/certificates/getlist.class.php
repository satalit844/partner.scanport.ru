<?php

$corePath = dirname(dirname(dirname(dirname(dirname(__FILE__))))) . '/';
require_once $corePath . 'model/training/training.class.php';
require_once $corePath . 'model/training/services/trainingcertificate.class.php';

class TrainingCourseCertificatesGetListProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    public function process()
    {
        $courseId = (int)$this->getProperty('course_id', 0);
        if ($courseId <= 0) {
            return $this->successJson(array(), 0);
        }

        $start = max(0, (int)$this->getProperty('start', 0));
        $limit = max(0, (int)$this->getProperty('limit', 20));

        $service = new TrainingCertificateService($this->modx, new Training($this->modx));
        $rows = $service->listIssuedCertificatesForCourse($courseId);
        $total = count($rows);

        if ($limit > 0) {
            $rows = array_slice($rows, $start, $limit);
        }

        $results = array();
        foreach ($rows as $row) {
            $certificateId = (int)(isset($row['certificate_id']) ? $row['certificate_id'] : 0);
            $filePath = trim((string)(isset($row['file_path']) ? $row['file_path'] : ''));

            $row['id'] = (int)$row['user_id'];
            $row['certificate_generated'] = $certificateId > 0 ? 1 : 0;
            $row['certificate_generated_label'] = $certificateId > 0 ? 'Да' : 'Нет';
            $row['completedon_formatted'] = (!empty($row['completedon']) && $row['completedon'] !== '0000-00-00 00:00:00') ? date('d.m.Y H:i', strtotime($row['completedon'])) : '—';
            $row['issuedon_formatted'] = (!empty($row['issuedon']) && $row['issuedon'] !== '0000-00-00 00:00:00') ? date('d.m.Y H:i', strtotime($row['issuedon'])) : '—';
            $row['file_path'] = $filePath !== '' ? $filePath : '';
            $results[] = $row;
        }

        return $this->successJson($results, $total);
    }

    protected function successJson(array $rows, $total)
    {
        return $this->modx->toJSON(array(
            'success' => true,
            'total' => (int)$total,
            'results' => array_values($rows),
        ));
    }
}
return 'TrainingCourseCertificatesGetListProcessor';
