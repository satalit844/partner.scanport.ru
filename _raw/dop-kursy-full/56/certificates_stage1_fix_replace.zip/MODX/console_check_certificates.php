<?php
/**
 * Проверка сертификатов training. Запускать в MODX Console при необходимости.
 */
$prefix = $modx->getOption('table_prefix');
$courseId = (int)($_GET['course_id'] ?? 1);
$tables = array(
    'user_courses' => $prefix . 'training_user_courses',
    'templates' => $prefix . 'training_certificate_templates',
    'certificates' => $prefix . 'training_user_certificates',
);
echo "COURSE ID: {$courseId}
";
foreach ($tables as $k => $t) {
    echo "TABLE {$k}: {$t} — " . ($modx->query("SHOW TABLES LIKE " . $modx->quote($t))->fetchColumn() ? 'OK' : 'NO') . "
";
}

$stmt = $modx->prepare("SELECT id, user_id, status, completedon FROM `{$tables['user_courses']}` WHERE course_id = :course_id ORDER BY id ASC");
$stmt->execute(array(':course_id' => $courseId));
echo "
USER COURSES:
";
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));

$stmt = $modx->prepare("SELECT * FROM `{$tables['templates']}` WHERE course_id = :course_id");
$stmt->execute(array(':course_id' => $courseId));
echo "
TEMPLATE:
";
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));

$stmt = $modx->prepare("SELECT id, user_id, status, issuedon, file_path FROM `{$tables['certificates']}` WHERE course_id = :course_id ORDER BY id ASC");
$stmt->execute(array(':course_id' => $courseId));
echo "
CERTIFICATES:
";
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
