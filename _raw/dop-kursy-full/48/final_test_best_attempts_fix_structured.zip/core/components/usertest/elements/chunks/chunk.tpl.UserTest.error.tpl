
{set $activityId = $.get.activity ?: 0}
{set $backId = $.get.back ?: 0}
{set $resourceId = $_modx->resource.id}
{set $backUrl = $back_url ?: $_modx->getPlaceholder('training_activity_back_url')}
{if !$backUrl && $backId}
    {set $backUrl = $_modx->makeUrl($backId)}
{/if}
{set $restartUrl = $reset_url ?: $_modx->getPlaceholder('training_activity_restart_url')}
{if !$restartUrl && $activityId}
    {set $restartUrl = $_modx->makeUrl($resourceId, '', ['activity' => $activityId, 'back' => $backId, 'screen' => 'test', 'step' => 'start', 'reset' => 1])}
{/if}

<div class="section-block tests-block">
    <div class="page-content d-flex flex-column h-100">
        <div class="test-card position-relative w-100 d-flex flex-column">
            <div class="test-header">
                <img src="theme/images/training/tests/logo-scanport.svg" alt="Сканпорт" class="img-svg">
            </div>
            <div class="test-content text-left mb-auto my-md-auto">
                <div class="test-question d-flex align-items-center gap-2 gap-lg-3 mb-4">
                    <img src="theme/images/training/tests/circle-x.svg" class="img-svg"><span>Ошибка</span>
                </div>
                <div class="test-subtitle mt-4">{$error}</div>
            </div>
            <div class="test-footer d-flex flex-wrap align-items-center justify-content-between gap-2 gap-sm-4 mt-auto">
                {if $backUrl}
                    <a href="{$backUrl}" class="btn btn-test col-auto text-decoration-none">
                        <span>Назад к курсу</span>
                        <img src="theme/images/training/tests/arrow-rotate-ico.svg" class="img-svg d-none d-sm-block">
                    </a>
                {/if}
                {if $restartUrl}
                    <a href="{$restartUrl}" class="btn btn-test btn-reload-test col-auto text-decoration-none">
                        <span>Пройти тест заново</span>
                        <img src="theme/images/training/tests/arrow-rotate-ico.svg" class="img-svg d-none d-sm-block">
                    </a>
                {/if}
            </div>
        </div>
    </div>
</div>
