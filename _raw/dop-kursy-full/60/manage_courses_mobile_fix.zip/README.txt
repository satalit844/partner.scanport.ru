Файлы:
- theme/css/training.css — полный файл на замену
- manage-courses-mobile-only.css — только добавленный мобильный блок, если нужно вставить руками

Правка ограничена media max-width: 767.98px и scoped по .training-manage-page.
ПК/планшет выше 768px не трогались.
