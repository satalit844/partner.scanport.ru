<?php
/** @var modX $modx */
$userId = 1342;

function trainingDebugResolveTable(modX $modx, $className, $plainName) {
    $prefix = (string)$modx->getOption('table_prefix');
    $candidates = [];

    if ($className !== '') {
        $table = trim((string)$modx->getTableName($className), '`');
        if ($table !== '') {
            $candidates[] = $table;
        }
    }

    $plainName = preg_replace('/[^a-zA-Z0-9_]/', '', (string)$plainName);
    if ($plainName !== '') {
        $candidates[] = $prefix . $plainName;
        $candidates[] = $prefix . '_' . $plainName;
        $candidates[] = 'modx_' . $plainName;
        $candidates[] = 'modx_partners' . $plainName;
    }

    $checked = [];
    foreach ($candidates as $table) {
        $table = trim((string)$table, '`');
        $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
        if ($table === '' || isset($checked[$table])) {
            continue;
        }
        $checked[$table] = true;
        $stmt = $modx->query('SHOW TABLES LIKE ' . $modx->quote($table));
        if ($stmt && $stmt->fetchColumn()) {
            return $table;
        }
    }

    return preg_replace('/[^a-zA-Z0-9_]/', '', $prefix . $plainName);
}

$tables = [
    'course_access' => trainingDebugResolveTable($modx, 'TrainingCourseAccess', 'training_course_access'),
    'manager_link' => trainingDebugResolveTable($modx, 'TrainingUserManagerLink', 'training_user_manager_link'),
    'courses' => trainingDebugResolveTable($modx, 'TrainingCourse', 'training_courses'),
];

echo "table_prefix: " . $modx->getOption('table_prefix') . "\n";
foreach ($tables as $name => $table) {
    $exists = $modx->query('SHOW TABLES LIKE ' . $modx->quote($table))->fetchColumn() ? 'YES' : 'NO';
    echo "TABLE {$name}: {$table} = {$exists}\n";
}

$sql = "
SELECT ca.id, ca.course_id, ca.principal_id, ca.access_role, ca.is_active, c.resource_id, r.pagetitle
FROM `{$tables['course_access']}` ca
LEFT JOIN `{$tables['courses']}` c ON c.id = ca.course_id
LEFT JOIN " . $modx->getTableName('modResource') . " r ON r.id = c.resource_id
WHERE ca.principal_type = 'user'
  AND ca.access_role = 'director'
  AND (ca.principal_id = :principal_id OR ca.user_id = :legacy_user_id)
";
$stmt = $modx->prepare($sql);
$stmt->bindValue(':principal_id', $userId, PDO::PARAM_INT);
$stmt->bindValue(':legacy_user_id', $userId, PDO::PARAM_INT);
$stmt->execute();
echo "DIRECTOR COURSES:\n";
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));

$sql = "SELECT * FROM `{$tables['manager_link']}` WHERE manager_user_id = :uid AND is_active = 1";
$stmt = $modx->prepare($sql);
$stmt->bindValue(':uid', $userId, PDO::PARAM_INT);
$stmt->execute();
echo "MANAGED USERS:\n";
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
