<?php
/** @var modX $modx */
$snippetName = 'trainingManageCoursesPage';
$code = "return include MODX_CORE_PATH . 'components/training/elements/snippets/trainingManageCoursesPage.php';";
$snippet = $modx->getObject('modSnippet', ['name' => $snippetName]);
if (!$snippet) {
    $snippet = $modx->newObject('modSnippet');
    $snippet->set('name', $snippetName);
}
$snippet->set('snippet', $code);
$snippet->set('cache_type', 0);
$snippet->save();
$modx->cacheManager->refresh();
echo "UPDATED {$snippetName}\n";
