<?php
/** @var modX $modx */

$name = 'trainingManageCoursesPage';
$content = "<?php\nreturn include MODX_CORE_PATH . 'components/training/elements/snippets/trainingManageCoursesPage.php';\n";

$snippet = $modx->getObject('modSnippet', ['name' => $name]);
if (!$snippet) {
    $snippet = $modx->newObject('modSnippet');
    $snippet->set('name', $name);
    $snippet->set('description', 'Training manage courses page');
}

$snippet->set('snippet', $content);
$snippet->set('cache_type', 0);
$snippet->save();

$modx->cacheManager->refresh();

echo "UPDATED: {$name}\n";
