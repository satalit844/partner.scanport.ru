<?php
/**
 * Запустить один раз в MODX Console.
 * Создаёт настройку получателя и чанки AjaxForm для модалки запроса курса.
 */

/** @var modX $modx */

$corePath = $modx->getOption('training.core_path', null, $modx->getOption('core_path') . 'components/training/');
$base = rtrim($corePath, '/\\') . '/elements/chunks/training/manage/';

$created = [];
$updated = [];
$errors = [];

function trainingCourseRequestUpsertChunk(modX $modx, $name, $filePath, array &$created, array &$updated, array &$errors) {
    if (!is_file($filePath)) {
        $errors[] = 'FILE NOT FOUND: ' . $filePath;
        return;
    }

    $content = file_get_contents($filePath);
    $chunk = $modx->getObject('modChunk', ['name' => $name]);

    if (!$chunk) {
        $chunk = $modx->newObject('modChunk');
        $chunk->set('name', $name);
        $chunk->set('description', 'Training course request AjaxForm chunk');
        $chunk->set('category', 0);
        $chunk->set('snippet', $content);
        if ($chunk->save()) {
            $created[] = 'CHUNK: ' . $name;
        } else {
            $errors[] = 'CHUNK CREATE FAILED: ' . $name;
        }
        return;
    }

    $chunk->set('snippet', $content);
    if ($chunk->save()) {
        $updated[] = 'CHUNK: ' . $name;
    } else {
        $errors[] = 'CHUNK UPDATE FAILED: ' . $name;
    }
}

$settingKey = 'training.course_request_email';
$setting = $modx->getObject('modSystemSetting', ['key' => $settingKey]);
if (!$setting) {
    $setting = $modx->newObject('modSystemSetting');
    $setting->fromArray([
        'key' => $settingKey,
        'value' => 'satalit844@mail.ru',
        'xtype' => 'textfield',
        'namespace' => 'training',
        'area' => 'course_request',
        'editedon' => time(),
    ], '', true, true);
    if ($setting->save()) {
        $created[] = 'SETTING: ' . $settingKey;
    } else {
        $errors[] = 'SETTING CREATE FAILED: ' . $settingKey;
    }
} else {
    if (trim((string)$setting->get('value')) === '') {
        $setting->set('value', 'satalit844@mail.ru');
    }
    $setting->set('xtype', 'textfield');
    $setting->set('namespace', 'training');
    $setting->set('area', 'course_request');
    $setting->set('editedon', time());
    if ($setting->save()) {
        $updated[] = 'SETTING: ' . $settingKey;
    } else {
        $errors[] = 'SETTING UPDATE FAILED: ' . $settingKey;
    }
}

trainingCourseRequestUpsertChunk($modx, 'training.manage.request-course.form', $base . 'request-course-form.tpl', $created, $updated, $errors);
trainingCourseRequestUpsertChunk($modx, 'training.manage.request-course.email', $base . 'request-course-email.tpl', $created, $updated, $errors);

$snippetName = 'trainingManageCoursesPage';
$snippet = $modx->getObject('modSnippet', ['name' => $snippetName]);
$snippetContent = "return include MODX_CORE_PATH . 'components/training/elements/snippets/trainingManageCoursesPage.php';";
if ($snippet) {
    $snippet->set('snippet', $snippetContent);
    if ($snippet->save()) {
        $updated[] = 'SNIPPET: ' . $snippetName;
    } else {
        $errors[] = 'SNIPPET UPDATE FAILED: ' . $snippetName;
    }
} else {
    $snippet = $modx->newObject('modSnippet');
    $snippet->fromArray([
        'name' => $snippetName,
        'description' => 'Training manage courses page',
        'snippet' => $snippetContent,
    ], '', true, true);
    if ($snippet->save()) {
        $created[] = 'SNIPPET: ' . $snippetName;
    } else {
        $errors[] = 'SNIPPET CREATE FAILED: ' . $snippetName;
    }
}

$modx->cacheManager->refresh();

echo "TRAINING COURSE REQUEST AJAXFORM SETUP\n";
echo "CREATED:\n" . (!empty($created) ? implode("\n", $created) : '-') . "\n";
echo "UPDATED:\n" . (!empty($updated) ? implode("\n", $updated) : '-') . "\n";
echo "ERRORS:\n" . (!empty($errors) ? implode("\n", $errors) : '-') . "\n";
echo "DONE\n";
