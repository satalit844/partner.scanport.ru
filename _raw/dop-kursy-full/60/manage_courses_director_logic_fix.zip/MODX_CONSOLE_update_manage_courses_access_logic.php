<?php
/** @var modX $modx */

$snippets = [
    'trainingManageCoursesPage' => "<?php\nreturn include MODX_CORE_PATH . 'components/training/elements/snippets/trainingManageCoursesPage.php';\n",
];

foreach ($snippets as $name => $content) {
    $snippet = $modx->getObject('modSnippet', ['name' => $name]);
    if (!$snippet) {
        $snippet = $modx->newObject('modSnippet');
        $snippet->set('name', $name);
        $snippet->set('description', 'Training manage courses page');
    }
    $snippet->set('snippet', $content);
    $snippet->set('cache_type', 0);
    $snippet->save();
    echo "UPDATED SNIPPET: {$name}\n";
}

$modx->cacheManager->refresh();
echo "DONE\n";
