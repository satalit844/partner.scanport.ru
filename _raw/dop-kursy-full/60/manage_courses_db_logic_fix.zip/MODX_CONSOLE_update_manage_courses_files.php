<?php
/** @var modX $modx */

$snippet = $modx->getObject('modSnippet', ['name' => 'trainingManageCoursesPage']);
if (!$snippet) {
    $snippet = $modx->newObject('modSnippet');
    $snippet->set('name', 'trainingManageCoursesPage');
    $snippet->set('description', 'Training manage courses page');
}
$snippet->set('snippet', "return include MODX_CORE_PATH . 'components/training/elements/snippets/trainingManageCoursesPage.php';");
$snippet->set('cache_type', 0);
$snippet->save();

echo "UPDATED SNIPPET: trainingManageCoursesPage\n";
$modx->cacheManager->refresh();
echo "DONE\n";
