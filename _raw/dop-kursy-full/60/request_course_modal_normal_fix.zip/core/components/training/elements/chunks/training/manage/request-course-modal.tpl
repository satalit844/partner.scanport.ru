<div class="modal fade training-request-modal" id="trainingCourseRequestModal" tabindex="-1" aria-labelledby="trainingCourseRequestModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <button type="button" class="training-request-modal__close" data-bs-dismiss="modal" aria-label="Закрыть">×</button>

            <form method="post" class="ajax_form" id="training-course-request-form" action="[[~[[*id]]]]" novalidate data-request-course-form>
                <input type="hidden" name="form_id" value="training_course_request">
                <input type="hidden" name="request_user_id" value="[[+request_user_id]]">
                <input type="hidden" name="request_context" value="[[+context_key]]">
                <input type="hidden" name="requested_course_id" value="" data-request-course-id>
                <input type="hidden" name="requested_course_resource_id" value="" data-request-course-resource-id>
                <input type="hidden" name="requested_course_title" value="" data-request-course-title>

                <div class="training-request-modal__head">
                    <div class="training-request-modal__title" id="trainingCourseRequestModalLabel">Запросить курс</div>
                    <div class="training-request-modal__text">
                        Заполните информацию и ваша заявка отправится на рассмотрение. С вами обязательно свяжется наш оператор.
                    </div>
                </div>

                <div class="training-request-modal__fields">
                    <label class="training-request-modal__field d-none" data-request-course-selected-wrap>
                        <span class="training-request-modal__label">Запрашиваемый курс</span>
                        <input type="text" class="training-request-modal__input" value="" data-request-course-selected-title readonly>
                        <span class="training-request-modal__error"></span>
                    </label>

                    <label class="training-request-modal__field">
                        <span class="training-request-modal__label">ФИО</span>
                        <input type="text" name="fullname" class="training-request-modal__input" value="[[+fullname]]" placeholder="Иван Иванов" autocomplete="name" required>
                        <span class="training-request-modal__error">[[+fi.fullname.error]]</span>
                    </label>

                    <div class="training-request-modal__row">
                        <label class="training-request-modal__field">
                            <span class="training-request-modal__label">Email</span>
                            <input type="email" name="email" class="training-request-modal__input" value="[[+email]]" placeholder="customer123@gmail.com" autocomplete="email" required>
                            <span class="training-request-modal__error">[[+fi.email.error]]</span>
                        </label>

                        <label class="training-request-modal__field">
                            <span class="training-request-modal__label">Номер телефона</span>
                            <input type="text" name="phone" class="training-request-modal__input" value="[[+phone]]" placeholder="+7 (000) 000-00-00" autocomplete="tel">
                            <span class="training-request-modal__error">[[+fi.phone.error]]</span>
                        </label>
                    </div>

                    <label class="training-request-modal__field training-request-modal__field--message">
                        <span class="training-request-modal__label">Дополнительная информация</span>
                        <textarea name="message" class="training-request-modal__textarea" placeholder="Описание">[[+message]]</textarea>
                        <span class="training-request-modal__error">[[+fi.message.error]]</span>
                    </label>

                    <label class="training-request-modal__agree">
                        <input type="checkbox" name="personal_data_agree" value="1" class="training-request-modal__agree-check" required>
                        <span>Я даю согласие на обработку своих персональных данных</span>
                    </label>
                    <span class="training-request-modal__error">[[+fi.personal_data_agree.error]]</span>
                </div>

                <div class="training-request-modal__actions">
                    <button type="submit" name="training_course_request_submit" value="1" class="training-request-modal__submit">Отправить</button>
                </div>
            </form>
        </div>
    </div>
</div>
