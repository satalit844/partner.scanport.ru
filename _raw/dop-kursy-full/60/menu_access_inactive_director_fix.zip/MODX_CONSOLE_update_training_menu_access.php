<?php
/**
 * Один раз выполнить в MODX Console, если сниппет trainingMenuAccess не файловый.
 */
if (!isset($modx) || !$modx instanceof modX) {
    return 'MODX is not initialized';
}

$name = 'trainingMenuAccess';
$content = "<?php\nreturn include MODX_CORE_PATH . 'components/training/elements/snippets/trainingMenuAccess.php';\n";

/** @var modSnippet $snippet */
$snippet = $modx->getObject('modSnippet', ['name' => $name]);
if (!$snippet) {
    $snippet = $modx->newObject('modSnippet');
    $snippet->set('name', $name);
}

$snippet->set('snippet', $content);
$snippet->set('static', 0);
$snippet->set('source', 0);
$snippet->save();

$modx->cacheManager->refresh();

return 'UPDATED: ' . $name;
