<?php
/**
 * Run once in MODX Console.
 * Updates the MODX snippet wrapper only; file logic is loaded from core/components/training/elements/snippets/trainingManageCoursesPage.php
 */
/** @var modX $modx */
$snippet = $modx->getObject('modSnippet', ['name' => 'trainingManageCoursesPage']);
if (!$snippet) {
    $snippet = $modx->newObject('modSnippet');
    $snippet->set('name', 'trainingManageCoursesPage');
}
$snippet->set('snippet', "return include MODX_CORE_PATH . 'components/training/elements/snippets/trainingManageCoursesPage.php';");
$snippet->set('static', 0);
$snippet->set('source', 0);
$snippet->save();

$modx->cacheManager->refresh();
echo "UPDATED: trainingManageCoursesPage snippet wrapper\n";
