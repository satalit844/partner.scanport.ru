<?php
/** @var modX $modx */
$userId = 1342;
$prefix = $modx->getOption('table_prefix');
$tables = [
    'course_access' => $prefix . 'partnerstraining_course_access',
    'manager_link' => $prefix . 'partnerstraining_user_manager_link',
    'courses' => $prefix . 'partnerstraining_courses',
];

foreach ($tables as $name => $table) {
    echo "TABLE {$name}: {$table} = " . ($modx->query("SHOW TABLES LIKE " . $modx->quote($table))->fetchColumn() ? 'YES' : 'NO') . "\n";
}

$sql = "
SELECT ca.id, ca.course_id, ca.principal_id, ca.access_role, ca.is_active, c.resource_id, r.pagetitle
FROM `{$tables['course_access']}` ca
LEFT JOIN `{$tables['courses']}` c ON c.id = ca.course_id
LEFT JOIN " . $modx->getTableName('modResource') . " r ON r.id = c.resource_id
WHERE ca.principal_type = 'user'
  AND ca.access_role = 'director'
  AND (ca.principal_id = :principal_id OR ca.user_id = :legacy_user_id)
";
$stmt = $modx->prepare($sql);
$stmt->bindValue(':principal_id', $userId, PDO::PARAM_INT);
$stmt->bindValue(':legacy_user_id', $userId, PDO::PARAM_INT);
$stmt->execute();
echo "DIRECTOR COURSES:\n";
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));

$sql = "SELECT * FROM `{$tables['manager_link']}` WHERE manager_user_id = :uid AND is_active = 1";
$stmt = $modx->prepare($sql);
$stmt->bindValue(':uid', $userId, PDO::PARAM_INT);
$stmt->execute();
echo "MANAGED USERS:\n";
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
