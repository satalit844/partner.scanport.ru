<?php
/**
 * Returns JSON with training menu mode for current web user.
 * Modes:
 * - none: no dropdown, only plain "Обучение" link
 * - employee: Все курсы / Мои курсы / Сертификаты / История
 * - manager: Все курсы / Управление курсами / Управление сертификатами / Управление историей
 * - director: all training menu sections
 */
if (!isset($modx) || !$modx instanceof modX) {
    return json_encode(['mode' => 'none']);
}

$userId = $modx->user ? (int)$modx->user->get('id') : 0;
if ($userId <= 0) {
    return json_encode(['mode' => 'none']);
}

$prefix = $modx->getOption('table_prefix');
$courseAccessTable = $prefix . 'training_course_access';
$userCoursesTable = $prefix . 'training_user_courses';
$managerLinkTable = $prefix . 'training_user_manager_link';

$hasDirectorCourse = false;
$hasEmployeeCourse = false;
$hasManagerLink = false;
$hasEmployeeLink = false;

$now = date('Y-m-d H:i:s');

try {
    $sql = "
        SELECT access_role
        FROM {$courseAccessTable}
        WHERE is_active = 1
          AND principal_type = 'user'
          AND principal_id = :user_id
          AND (active_from IS NULL OR active_from = '0000-00-00 00:00:00' OR active_from <= :now_from)
          AND (active_to IS NULL OR active_to = '0000-00-00 00:00:00' OR active_to >= :now_to)
    ";
    $stmt = $modx->prepare($sql);
    if ($stmt && $stmt->execute([
        ':user_id' => $userId,
        ':now_from' => $now,
        ':now_to' => $now,
    ])) {
        while ($role = $stmt->fetchColumn()) {
            $role = strtolower(trim((string)$role));
            if ($role === 'director') {
                $hasDirectorCourse = true;
            }
            if ($role === 'employee') {
                $hasEmployeeCourse = true;
            }
        }
    }
} catch (Throwable $e) {
    $modx->log(modX::LOG_LEVEL_ERROR, '[trainingMenuAccess] course_access: ' . $e->getMessage());
}

try {
    $sql = "
        SELECT access_role
        FROM {$userCoursesTable}
        WHERE user_id = :user_id
          AND status <> 'revoked'
    ";
    $stmt = $modx->prepare($sql);
    if ($stmt && $stmt->execute([':user_id' => $userId])) {
        while ($role = $stmt->fetchColumn()) {
            $role = strtolower(trim((string)$role));
            if ($role === 'director') {
                $hasDirectorCourse = true;
            }
            if ($role === 'employee') {
                $hasEmployeeCourse = true;
            }
        }
    }
} catch (Throwable $e) {
    $modx->log(modX::LOG_LEVEL_ERROR, '[trainingMenuAccess] user_courses: ' . $e->getMessage());
}

try {
    $sql = "
        SELECT
            SUM(CASE WHEN manager_user_id = :manager_id THEN 1 ELSE 0 END) AS manager_count,
            SUM(CASE WHEN employee_user_id = :employee_id THEN 1 ELSE 0 END) AS employee_count
        FROM {$managerLinkTable}
        WHERE is_active = 1
          AND (manager_user_id = :manager_id2 OR employee_user_id = :employee_id2)
    ";
    $stmt = $modx->prepare($sql);
    if ($stmt && $stmt->execute([
        ':manager_id' => $userId,
        ':employee_id' => $userId,
        ':manager_id2' => $userId,
        ':employee_id2' => $userId,
    ])) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $hasManagerLink = !empty($row['manager_count']);
        $hasEmployeeLink = !empty($row['employee_count']);
    }
} catch (Throwable $e) {
    $modx->log(modX::LOG_LEVEL_ERROR, '[trainingMenuAccess] manager_link: ' . $e->getMessage());
}

$isAdmin = false;
try {
    $isAdmin = $modx->user && ($modx->user->sudo || $modx->user->isMember('Administrator'));
} catch (Throwable $e) {
    $isAdmin = false;
}

if ($isAdmin || $hasDirectorCourse) {
    $mode = 'director';
} elseif ($hasEmployeeCourse || $hasEmployeeLink) {
    $mode = 'employee';
} elseif ($hasManagerLink) {
    $mode = 'manager';
} else {
    $mode = 'none';
}

return json_encode([
    'mode' => $mode,
    'is_admin' => $isAdmin ? 1 : 0,
    'has_director_course' => $hasDirectorCourse ? 1 : 0,
    'has_employee_course' => $hasEmployeeCourse ? 1 : 0,
    'has_manager_link' => $hasManagerLink ? 1 : 0,
    'has_employee_link' => $hasEmployeeLink ? 1 : 0,
], JSON_UNESCAPED_UNICODE);
