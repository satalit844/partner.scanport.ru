<?php
$snippets = [
    'trainingMenuAccess' => "<?php\nreturn include MODX_CORE_PATH . 'components/training/elements/snippets/trainingMenuAccess.php';\n",
    'trainingMenuRender' => "<?php\nreturn include MODX_CORE_PATH . 'components/training/elements/snippets/trainingMenuRender.php';\n",
];

foreach ($snippets as $name => $content) {
    /** @var modSnippet $snippet */
    $snippet = $modx->getObject('modSnippet', ['name' => $name]);
    if (!$snippet) {
        $snippet = $modx->newObject('modSnippet');
        $snippet->set('name', $name);
        $snippet->set('description', 'Training menu access/render helper');
        echo "CREATED: {$name}\n";
    } else {
        echo "UPDATED: {$name}\n";
    }

    $snippet->set('snippet', $content);
    $snippet->set('static', 0);
    $snippet->save();
}

$modx->cacheManager->refresh();
echo "DONE\n";
