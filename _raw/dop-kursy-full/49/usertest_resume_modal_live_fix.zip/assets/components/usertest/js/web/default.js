$(document).ready(function() {
    $("body").on('submit',"#UserTestForm",function(){
        if(validate_question() && validate_ask()){
            var form = $(this);
            var data = form.serialize();
            
            $.ajax({
               type: 'POST',
               url: UserTestActionUrl,
               dataType: 'json',
               data: data,
               beforeSend: function(data) {
                    form.find('input[type="submit"]').attr('disabled', 'disabled');
                  },
               success: function(data){
                    if(data.success){
                        var parsed = $.parseHTML(data.html, document, true);
                        var $doc = $('<div>').append(parsed);
                        var $newMain = $doc.find('#testuser-main').first();
                        var $newModal = $doc.find('#testListModal').first();

                        if ($newMain.length) {
                            $('#testuser-main').replaceWith($newMain);
                        } else {
                            $("#testuser-main").replaceWith(data.html);
                        }

                        if ($newModal.length) {
                            var $currentModal = $('#testListModal');
                            if ($currentModal.length) {
                                $currentModal.replaceWith($newModal);
                            } else {
                                $('body').append($newModal);
                            }
                        }

                        var $testMain = $('#testuser-main');
                        if ($testMain.length && $testMain.offset()) {
                            $('html, body').animate({ scrollTop: $testMain.offset().top }, 500);
                        }

                        document.dispatchEvent(new CustomEvent('usertest:updated', {
                            detail: {
                                html: data.html
                            }
                        }));

                        var ctx = document.getElementById("chart-area");
                        if(ctx){
                            window.myPie = new Chart(ctx.getContext("2d"), config);
                        }
                    }
                 },
               error: function (xhr, ajaxOptions, thrownError) {
                    alert(xhr.status);
                    alert(thrownError);
                 },
               complete: function(data) { // сoбытиe пoслe любoгo исхoдa
                    form.find('input[type="submit"]').prop('disabled', false);
                 }	  
            });
            
        }
        return false;
    });
});

function validate_question(){
    validate = true;
    $(".error").remove();
    $('.question.validate').each(function (index, value) { 
        //console.log('div' + index + ':' + $(this).attr('id')); 
        //$("input:radio:checked")
        switch($(this).data('type_id')){
            case 1: //Одиночный выбор
            case 12: //Опросник САН
                if($(this).find("input:radio:checked").length == 0){
                    validate = false;
                    $(this).append('<div class="w-100 m-0 p-0"></div><p class="error mt-2"><span class="text-danger py-2 px-3 badge rounded-pill text-bg-danger fw-normal">На этот вопрос требуется ответ!</span></p>');
                }
                break;
            case 2: //Множественный выбор
                if($(this).find("input:checkbox:checked").length == 0){
                    validate = false;
                    $(this).append('<div class="w-100 m-0 p-0"></div><p class="error mt-2"><span class="text-danger py-2 px-3 badge rounded-pill text-bg-danger fw-normal">На этот вопрос требуется ответ!</span></p>');
                }
                break;
            case 3: //Простой текст
                if($(this).find("input").val() == ""){
                    validate = false;
                    $(this).append('<div class="w-100 m-0 p-0"></div><p class="error mt-2"><span class="text-danger py-2 px-3 badge rounded-pill text-bg-danger fw-normal">На этот вопрос требуется ответ!</span></p>');
                }
                break;
            case 4: //Открытый вопрос
                if($(this).find("input").val() == ""){
                    validate = false;
                    $(this).append('<div class="w-100 m-0 p-0"></div><p class="error mt-2"><span class="text-danger py-2 px-3 badge rounded-pill text-bg-danger fw-normal">На этот вопрос требуется ответ!</span></p>');
                }
                break;
            case 9: //Селекты в тексте
                check = true;
                $(this).find("select").each(function (index, value) {
                    if($(this).val() == 0){
                        validate = false;
                        check = false;
                    }
                });
                if(!check){
                    $(this).append('<div class="w-100 m-0 p-0"></div><p class="error mt-2"><span class="text-danger py-2 px-3 badge rounded-pill text-bg-danger fw-normal">На этот вопрос требуется ответ!</span></p>');
                }
                break;
        }
        
    });
    return validate;
}

function validate_ask(){
    validate = true;
    $(".error").remove();
    $('.ask.validate').each(function (index, value) { 
        if($(this).find("input").val() == ""){
            validate = false;
            $(this).append('<span class="text-danger py-2 px-3 badge rounded-pill text-bg-danger fw-normal">Это поле требуется!</span>');
        } 
    });
    return validate;
}