$templateContent = <<<'FENOM'
{extends 'template:01.base'}
{block 'css'}
    <link href="theme/css/swiper-bundle.min.css" rel="stylesheet">
    <link href="{'!fileCashFix' | snippet : ['input' => 'theme/css/training.css']}" rel="stylesheet">
{/block}
{block 'content'}
    {if !$_modx->isAuthenticated('web')}
        {$_modx->sendRedirect(12 | url)}
    {/if}

    {set $practicePageId = ('training.training_practice_resource_id' | config) ?: 176}
    {set $activityId = $.get.activity ?: 0}
    {set $activityType = $.get.type ?: $.get.link_type ?: ''}

    {if $activityId && ($activityType == 'practice' || $_modx->resource.id == $practicePageId)}
        {'!trainingPracticePage' | snippet : [
            'resource_id' => $_modx->resource.id,
            'activity' => $.get.activity,
            'link' => $.get.link
        ]}
    {elseif $activityId}
        {'!trainingActivityPage' | snippet : [
            'resource_id' => $_modx->resource.id
        ]}
    {else}
        {$_modx->resource.content}
    {/if}
{/block}
{block 'js'}
    <script src="theme/js/swiper-bundle.min.js"></script>
    <script src="{'!fileCashFix' | snippet : ['input' => 'theme/js/app-training.js']}"></script>
{/block}
FENOM;

$updates = array();

$template = $modx->getObject('modTemplate', array('templatename' => '14.Обучение'));
if ($template) {
    $template->set('content', $templateContent);
    $template->save();
    $updates[] = 'template:14.Обучение OK';
} else {
    $updates[] = 'template:14.Обучение NOT FOUND';
}

$snippets = array(
    'trainingActivityPage' => "return include MODX_CORE_PATH . 'components/training/elements/snippets/snippet.trainingActivityPage.php';",
    'UserTest' => "return include MODX_CORE_PATH . 'components/usertest/elements/snippets/snippet.usertest.php';",
    'UserTestAnswerResult' => "return include MODX_CORE_PATH . 'components/usertest/elements/snippets/snippet.UserTestAnswerResult.php';",
);

foreach ($snippets as $name => $content) {
    $snippet = $modx->getObject('modSnippet', array('name' => $name));
    if ($snippet) {
        $snippet->set('snippet', $content);
        $snippet->save();
        $updates[] = 'snippet:' . $name . ' OK';
    } else {
        $updates[] = 'snippet:' . $name . ' NOT FOUND';
    }
}

if ($modx->cacheManager) {
    $modx->cacheManager->refresh(array(
        'db' => array(),
        'auto_publish' => array('contexts' => array()),
        'context_settings' => array('contexts' => array()),
        'resource' => array('contexts' => array()),
    ));
}

return '<pre>' . htmlentities('Updated:' . PHP_EOL . implode(PHP_EOL, $updates), ENT_QUOTES, 'UTF-8') . '</pre>';
