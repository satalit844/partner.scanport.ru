<?php
/**
 * Восстановить подключение тестовых сниппетов через файлы.
 * Нужен только если MODX продолжает исполнять старый код из БД, а не файлы на диске.
 */
$items = array(
    'UserTest' => "return include MODX_CORE_PATH . 'components/usertest/elements/snippets/snippet.usertest.php';",
    'UserTestAnswerResult' => "return include MODX_CORE_PATH . 'components/usertest/elements/snippets/snippet.UserTestAnswerResult.php';",
    'trainingActivityPage' => "return include MODX_CORE_PATH . 'components/training/elements/snippets/snippet.trainingActivityPage.php';",
);

$out = array();
foreach ($items as $name => $code) {
    $snippet = $modx->getObject('modSnippet', array('name' => $name));
    if (!$snippet) {
        $out[] = $name . ': NOT FOUND';
        continue;
    }
    $snippet->set('snippet', $code);
    $snippet->save();
    $out[] = $name . ': OK';
}

if ($modx->cacheManager) {
    $modx->cacheManager->refresh(array(
        'db' => array(),
        'auto_publish' => array('contexts' => array()),
        'context_settings' => array('contexts' => array()),
        'resource' => array('contexts' => array()),
    ));
}

return '<pre>' . htmlentities(implode(PHP_EOL, $out), ENT_QUOTES, 'UTF-8') . '</pre>';
