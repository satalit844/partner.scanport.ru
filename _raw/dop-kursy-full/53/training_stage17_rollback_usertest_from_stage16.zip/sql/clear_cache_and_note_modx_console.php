<?php
$modx->cacheManager->refresh(array(
    'resource' => array(),
    'scripts' => array(),
    'system_settings' => array(),
));

$coreCache = MODX_CORE_PATH . 'cache/';
$paths = array(
    $coreCache . 'resource/',
    $coreCache . 'scripts/',
    $coreCache . 'includes/',
);
foreach ($paths as $path) {
    if (is_dir($path)) {
        $modx->cacheManager->deleteTree($path, array('deleteTop' => false, 'skipDirs' => false));
    }
}

echo '<pre>OK: rollback stage16, restored working UserTest template from stage15. Clear browser cache: Ctrl+F5.</pre>';
