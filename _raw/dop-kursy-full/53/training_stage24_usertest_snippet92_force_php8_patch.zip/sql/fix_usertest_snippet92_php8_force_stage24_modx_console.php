<?php
/**
 * Force hotfix for UserTest snippet #92 under PHP 8.x.
 * - Does not touch training.css.
 * - Creates DB backup of snippet content.
 * - Patches UserTest snippet source in DB.
 * - Clears MODX element cache.
 */

$snippetId = 92;
$backupName = 'UserTest_backup_before_stage24_' . date('Ymd_His');

echo '<pre>';
echo "UserTest snippet #{$snippetId} PHP8 force patch\n";
echo str_repeat('=', 80) . "\n";

$snippet = $modx->getObject('modSnippet', array('id' => $snippetId));
if (!$snippet) {
    echo "ERROR: snippet #{$snippetId} not found\n";
    echo '</pre>';
    return;
}

$name = $snippet->get('name');
$static = (int)$snippet->get('static');
$staticFile = (string)$snippet->get('static_file');
$content = (string)$snippet->getContent();

echo "name: {$name}\n";
echo "static: {$static}\n";
echo "static_file: {$staticFile}\n";
echo "content length: " . strlen($content) . "\n";

if (trim($content) === '') {
    echo "ERROR: snippet content is empty\n";
    echo '</pre>';
    return;
}

/* backup */
$backup = $modx->newObject('modSnippet');
$backup->fromArray(array(
    'name' => $backupName,
    'description' => 'Backup of UserTest snippet before stage24 PHP8 patch',
    'snippet' => $content,
    'category' => (int)$snippet->get('category'),
    'static' => 0,
    'source' => 0,
    'static_file' => '',
), '', true, true);

if (!$backup->save()) {
    echo "ERROR: cannot create backup snippet\n";
    echo '</pre>';
    return;
}

echo "backup created: {$backupName}, id=" . $backup->get('id') . "\n";

$patched = $content;
$changes = array();

/**
 * 1) Add a common guard near the beginning of the snippet.
 */
$guard = <<<'PHPGUARD'

/* training stage24 php8 guard */
if (!isset($Result)) { $Result = null; }
if (!isset($result_id)) { $result_id = 0; }
if (!isset($time_last_step)) { $time_last_step = 0; }
if (!isset($steps) || !is_array($steps)) { $steps = array(); }
if (!isset($resStep)) { $resStep = 0; }
if (!isset($c_var_id)) { $c_var_id = 0; }
if (!isset($cat_var_result)) { $cat_var_result = ''; }
/* /training stage24 php8 guard */

PHPGUARD;

if (strpos($patched, 'training stage24 php8 guard') === false) {
    if (preg_match('/^\s*<\?php\s*/', $patched)) {
        $patched = preg_replace('/^\s*<\?php\s*/', "<?php\n" . $guard, $patched, 1);
    } else {
        $patched = $guard . "\n" . $patched;
    }
    $changes[] = 'added top PHP8 guard';
} else {
    $changes[] = 'top PHP8 guard already exists';
}

/**
 * 2) Fix direct access to time_last_step session key.
 */
$patterns = array(
    "\$_SESSION['UserTest'][\$id]['time_last_step']" => "(\$_SESSION['UserTest'][\$id]['time_last_step'] ?? 0)",
    '$_SESSION["UserTest"][$id]["time_last_step"]' => '($_SESSION["UserTest"][$id]["time_last_step"] ?? 0)',
    "\$_SESSION['UserTest'][\$test_id]['time_last_step']" => "(\$_SESSION['UserTest'][\$test_id]['time_last_step'] ?? 0)",
    '$_SESSION["UserTest"][$test_id]["time_last_step"]' => '($_SESSION["UserTest"][$test_id]["time_last_step"] ?? 0)',
);

foreach ($patterns as $from => $to) {
    $count = 0;
    $patched = str_replace($from, $to, $patched, $count);
    if ($count > 0) {
        $changes[] = "replaced {$from}: {$count}";
    }
}

/**
 * 3) Fix common array-key access inside answer-add block.
 * These are warnings under PHP 8 when optional answer_add fields are missing.
 */
$optionalKeys = array('ans', 'ans_add_ans', 'ans_add', 'question_ids');
foreach ($optionalKeys as $key) {
    $from = "\$a_id['{$key}']";
    $to = "(\$a_id['{$key}'] ?? '')";
    $count = 0;
    $patched = str_replace($from, $to, $patched, $count);
    if ($count > 0) {
        $changes[] = "guarded a_id {$key}: {$count}";
    }
}

/**
 * 4) If code uses $Result before assignment, try to resolve it from current result_id/session.
 * Inject after $id becomes available in common UserTest code.
 */
$injectResult = <<<'PHPINJECT'

/* training stage24 ensure Result object */
if ((!isset($Result) || !$Result) && !empty($_SESSION['UserTest'][$id]['result_id'])) {
    $Result = $modx->getObject('UserTestResults', (int)$_SESSION['UserTest'][$id]['result_id']);
}
if (!isset($Result) || !$Result) {
    $Result = null;
}
/* /training stage24 ensure Result object */

PHPINJECT;

if (strpos($patched, 'training stage24 ensure Result object') === false) {
    $inserted = false;

    $needles = array(
        '$curStep',
        '$_REQUEST',
        '$_GET',
        '$_POST',
    );

    foreach ($needles as $needle) {
        $pos = strpos($patched, $needle);
        if ($pos !== false) {
            $lineEnd = strpos($patched, "\n", $pos);
            if ($lineEnd !== false) {
                $patched = substr($patched, 0, $lineEnd + 1) . $injectResult . substr($patched, $lineEnd + 1);
                $inserted = true;
                $changes[] = 'injected Result resolver after ' . $needle;
                break;
            }
        }
    }

    if (!$inserted) {
        $patched .= "\n" . $injectResult;
        $changes[] = 'appended Result resolver';
    }
} else {
    $changes[] = 'Result resolver already exists';
}

/**
 * 5) Do not turn warnings into fatal JSON/500 inside snippets.
 * Add local safe error handler only around UserTest execution if not already added.
 */
$safeHandler = <<<'PHPSAFE'

/* training stage24 warning suppressor for legacy UserTest on PHP8 */
$__trainingUserTestPrevErrorHandler = set_error_handler(function($errno, $errstr, $errfile, $errline) {
    if (in_array($errno, array(E_WARNING, E_NOTICE, E_USER_WARNING, E_USER_NOTICE, E_DEPRECATED, E_USER_DEPRECATED), true)) {
        if (strpos((string)$errfile, 'usertest') !== false || strpos((string)$errfile, 'modsnippet') !== false) {
            return true;
        }
    }
    return false;
});
register_shutdown_function(function() use ($__trainingUserTestPrevErrorHandler) {
    if ($__trainingUserTestPrevErrorHandler !== null) {
        restore_error_handler();
    }
});
/* /training stage24 warning suppressor */

PHPSAFE;

if (strpos($patched, 'training stage24 warning suppressor') === false) {
    if (preg_match('/\/\* training stage24 php8 guard \*\//', $patched, $m, PREG_OFFSET_CAPTURE)) {
        $pos = $m[0][1];
        $end = strpos($patched, '/* /training stage24 php8 guard */', $pos);
        if ($end !== false) {
            $endLine = strpos($patched, "\n", $end);
            if ($endLine !== false) {
                $patched = substr($patched, 0, $endLine + 1) . $safeHandler . substr($patched, $endLine + 1);
                $changes[] = 'added local warning suppressor';
            }
        }
    }
}

if ($patched === $content) {
    echo "No changes needed.\n";
} else {
    $snippet->setContent($patched);
    $snippet->set('static', 0);
    if (!$snippet->save()) {
        echo "ERROR: cannot save patched snippet\n";
        echo '</pre>';
        return;
    }
    echo "snippet patched and saved\n";
}

echo "\nChanges:\n";
foreach ($changes as $change) {
    echo "- {$change}\n";
}

$modx->cacheManager->refresh(array(
    'resource' => array(),
    'includes' => array(),
    'scripts' => array(),
    'default' => array(),
));

echo "\nCache refreshed.\n";
echo "\nNext:\n";
echo "\n1. Ctrl+F5";
echo "\n2. Open test with reset=1";
echo "\n3. If 500 remains, run inspect script again\n";
echo '</pre>';
