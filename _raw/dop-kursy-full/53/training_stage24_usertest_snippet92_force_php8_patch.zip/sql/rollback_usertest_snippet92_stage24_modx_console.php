<?php
/**
 * Rollback UserTest snippet #92 from latest stage24 backup.
 */
$snippetId = 92;

echo '<pre>';
echo "Rollback UserTest snippet #{$snippetId} from latest stage24 backup\n";
echo str_repeat('=', 80) . "\n";

$snippet = $modx->getObject('modSnippet', array('id' => $snippetId));
if (!$snippet) {
    echo "ERROR: snippet #{$snippetId} not found\n";
    echo '</pre>';
    return;
}

$c = $modx->newQuery('modSnippet');
$c->where(array('name:LIKE' => 'UserTest_backup_before_stage24_%'));
$c->sortby('id', 'DESC');
$c->limit(1);
$backup = $modx->getObject('modSnippet', $c);

if (!$backup) {
    echo "ERROR: backup not found\n";
    echo '</pre>';
    return;
}

$snippet->setContent($backup->getContent());
$snippet->set('static', 0);
$snippet->save();

$modx->cacheManager->refresh(array(
    'resource' => array(),
    'includes' => array(),
    'scripts' => array(),
    'default' => array(),
));

echo "OK rollback from backup: " . $backup->get('name') . ", id=" . $backup->get('id') . "\n";
echo '</pre>';
