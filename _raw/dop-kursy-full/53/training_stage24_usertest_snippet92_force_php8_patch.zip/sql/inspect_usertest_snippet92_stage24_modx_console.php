<?php
$snippetId = 92;
echo '<pre>';
echo "Inspect UserTest snippet #{$snippetId} after stage24\n";
echo str_repeat('=', 80) . "\n";

$snippet = $modx->getObject('modSnippet', array('id' => $snippetId));
if (!$snippet) {
    echo "ERROR: snippet not found\n";
    echo '</pre>';
    return;
}
$content = $snippet->getContent();
echo "name: " . $snippet->get('name') . "\n";
echo "static: " . $snippet->get('static') . "\n";
echo "static_file: " . $snippet->get('static_file') . "\n";
echo "has stage24 guard: " . (strpos($content, 'training stage24 php8 guard') !== false ? 'YES' : 'NO') . "\n";
echo "has warning suppressor: " . (strpos($content, 'training stage24 warning suppressor') !== false ? 'YES' : 'NO') . "\n";
echo "has Result resolver: " . (strpos($content, 'training stage24 ensure Result object') !== false ? 'YES' : 'NO') . "\n";

$cacheFile = MODX_CORE_PATH . 'cache/includes/elements/modsnippet/' . $snippetId . '.include.cache.php';
echo "\ncache file: {$cacheFile}\n";
echo is_file($cacheFile) ? "cache exists\n" : "cache not found\n";

$log = MODX_CORE_PATH . 'cache/logs/error.log';
echo "\nlast 80 log lines:\n";
echo str_repeat('-', 80) . "\n";
if (is_file($log)) {
    $lines = file($log);
    echo htmlspecialchars(implode('', array_slice($lines, -80)), ENT_QUOTES, 'UTF-8');
} else {
    echo "error.log not found\n";
}
echo '</pre>';
