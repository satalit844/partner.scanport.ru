<?php
$cachePath = MODX_CORE_PATH . 'cache/';
$paths = array(
    $cachePath . 'resource/',
    $cachePath . 'includes/',
    $cachePath . 'scripts/',
    $cachePath . 'default/',
    $cachePath . 'web/',
);
foreach ($paths as $path) {
    if (is_dir($path)) {
        $modx->cacheManager->deleteTree($path, array('deleteTop' => false, 'skipDirs' => false));
        echo 'CACHE CLEANED: ' . $path . "<br>";
    }
}
$modx->cacheManager->refresh(array(
    'resource' => array(),
    'scripts' => array(),
    'system_settings' => array(),
    'context_settings' => array(),
));

$tpl = MODX_CORE_PATH . 'components/training/elements/chunks/training/activity/usertest.tpl';
echo '<pre>';
echo "OK: restored stable original usertest.tpl\n";
echo "file: {$tpl}\n";
echo "mtime: " . (is_file($tpl) ? date('Y-m-d H:i:s', filemtime($tpl)) : 'not found') . "\n";
echo '</pre>';
