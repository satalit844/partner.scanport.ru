<?php
$actionFile = MODX_BASE_PATH . 'assets/components/usertest/action.php';
$backupFile = MODX_BASE_PATH . 'assets/components/usertest/action.training-original.php';
$debugFile = MODX_BASE_PATH . 'assets/components/usertest/action.training-debug.log';

print '<pre>';
print "Restore original UserTest action.php\n";
print str_repeat('=', 80) . "\n";

if (!is_file($actionFile)) {
    print "ERROR: action.php not found: {$actionFile}\n</pre>";
    return;
}

$current = (string)file_get_contents($actionFile);
$hasWrapper = strpos($current, 'TRAINING_USERTEST_ACTION_SAFE_WRAPPER') !== false;

if ($hasWrapper) {
    if (!is_file($backupFile)) {
        print "ERROR: wrapper installed, but backup not found: {$backupFile}\n";
        print "Need original /assets/components/usertest/action.php from archive.\n</pre>";
        return;
    }
    copy($backupFile, $actionFile);
    @chmod($actionFile, 0644);
    print "OK: wrapper removed, original restored\n";
    print "from: {$backupFile}\n";
    print "to:   {$actionFile}\n";
} else {
    print "OK: action.php is not wrapper, nothing to restore\n";
    print "file: {$actionFile}\n";
}

if (is_file($debugFile)) {
    print "debug log exists: {$debugFile}\n";
}

$modx->cacheManager->refresh(array(
    'resource' => array(),
    'scripts' => array(),
    'system_settings' => array(),
));
print "\nNext: Ctrl+F5 and test again.\n";
print '</pre>';
