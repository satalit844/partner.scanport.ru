<?php
$cachePath = MODX_CORE_PATH . 'cache/';
$paths = array(
    $cachePath . 'resource/',
    $cachePath . 'includes/',
    $cachePath . 'scripts/',
    $cachePath . 'default/',
);
print '<pre>';
foreach ($paths as $path) {
    if (is_dir($path)) {
        $modx->cacheManager->deleteTree($path, array(
            'deleteTop' => false,
            'skipDirs' => false,
            'extensions' => array(),
        ));
        print "CACHE CLEANED: {$path}\n";
    }
}
$modx->cacheManager->refresh(array(
    'resource' => array(),
    'scripts' => array(),
    'system_settings' => array(),
));
print "OK: training cache cleared\n";
print '</pre>';
