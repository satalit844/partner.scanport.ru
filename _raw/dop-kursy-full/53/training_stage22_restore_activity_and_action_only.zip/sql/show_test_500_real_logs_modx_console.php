<?php
$base = MODX_BASE_PATH;
$core = MODX_CORE_PATH;
$candidates = array(
    $core . 'cache/logs/error.log',
    $base . 'error_log',
    $base . 'assets/components/usertest/error_log',
    dirname($base) . '/logs/error.log',
    dirname($base) . '/logs/php_errors.log',
    dirname($base) . '/logs/' . parse_url($modx->getOption('site_url'), PHP_URL_HOST) . '.error.log',
    '/var/log/php8.3-fpm.log',
    '/var/log/php-fpm/error.log',
    '/var/log/nginx/error.log',
    '/var/log/apache2/error.log',
);

print '<pre>';
print "Real 500 logs candidates\n";
print str_repeat('=', 80) . "\n";
foreach (array_unique($candidates) as $file) {
    print "\n" . str_repeat('=', 80) . "\n";
    print $file . "\n";
    print str_repeat('-', 80) . "\n";
    if (!is_file($file) || !is_readable($file)) {
        print "not found or not readable\n";
        continue;
    }
    $lines = file($file);
    print htmlspecialchars(implode('', array_slice($lines, -160)), ENT_QUOTES, 'UTF-8');
}
print '</pre>';
