<?php
$snippet = $modx->getObject('modSnippet', array('name' => 'UserTest'));
echo '<pre>';
echo "Check stage27 UserTest\n";
echo str_repeat('=', 80) . "\n";
if (!$snippet) {
    echo "snippet found: NO\n</pre>";
    return;
}
$db = (string)$snippet->get('snippet');
$file = MODX_BASE_PATH . 'core/components/usertest/elements/snippets/snippet.usertest.php';
echo "snippet found: YES\n";
echo "snippetId: " . (int)$snippet->get('id') . "\n";
echo "static: " . $snippet->get('static') . "\n";
echo "static_file: " . $snippet->get('static_file') . "\n";
echo "file exists: " . (is_file($file) ? 'YES' : 'NO') . "\n";
echo "DB starts with php tag: " . (preg_match('/^\s*<\?php/', $db) ? 'YES - ERROR' : 'NO - OK') . "\n";
echo "stage27 marker: " . (strpos($db, 'TRAINING_STAGE27_USERTEST_NO_EMPTY_POST_SAVE') !== false ? 'YES' : 'NO') . "\n";
echo "old bad hotfix: " . (strpos($db, 'TRAINING_USERTEST_SNIPPET92_PHP8_HOTFIX') !== false ? 'YES - ERROR' : 'NO - OK') . "\n";
echo "empty POST guard: " . (strpos($db, 'if($hasPostedQuestion and $answer_step != "start" and !$skip_save){') !== false ? 'YES' : 'NO - ERROR') . "\n";
echo "unsafe save condition remains: " . (strpos($db, 'if($answer_step != "start" and !$skip_save){') !== false ? 'YES - ERROR' : 'NO - OK') . "\n";
echo "safe time_last_step: " . (strpos($db, '!empty($_SESSION[\'UserTest\'][$id][\'time_last_step\'])') !== false ? 'YES' : 'NO - ERROR') . "\n";
echo '</pre>';
