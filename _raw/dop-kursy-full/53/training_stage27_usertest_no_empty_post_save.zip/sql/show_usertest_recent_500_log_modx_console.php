<?php
$files = array(
    MODX_CORE_PATH . 'cache/logs/error.log',
    MODX_BASE_PATH . 'error_log',
    MODX_BASE_PATH . 'assets/components/usertest/error_log',
);

echo '<pre>';
echo "Recent UserTest 500 logs\n";
echo str_repeat('=', 80) . "\n";
foreach ($files as $file) {
    echo "\n" . str_repeat('=', 80) . "\n";
    echo $file . "\n";
    echo str_repeat('-', 80) . "\n";
    if (!is_file($file) || !is_readable($file)) {
        echo "not found or not readable\n";
        continue;
    }
    $lines = file($file);
    $tail = array_slice($lines, -180);
    echo htmlspecialchars(implode('', $tail), ENT_QUOTES, 'UTF-8');
}
echo '</pre>';
