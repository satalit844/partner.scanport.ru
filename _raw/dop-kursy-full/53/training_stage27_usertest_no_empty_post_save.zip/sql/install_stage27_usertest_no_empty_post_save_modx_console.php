<?php
/**
 * Stage27 UserTest fix:
 * - updates non-static snippet UserTest from file
 * - removes bad PHP8 error suppressor hotfix
 * - skips answer save when POST has no question[]
 * - keeps CSS untouched
 */

$snippetName = 'UserTest';
$file = MODX_BASE_PATH . 'core/components/usertest/elements/snippets/snippet.usertest.php';

if (!is_file($file)) {
    echo '<pre>ERROR: file not found: ' . htmlspecialchars($file, ENT_QUOTES, 'UTF-8') . '</pre>';
    return;
}

$content = file_get_contents($file);
if ($content === false || trim($content) === '') {
    echo '<pre>ERROR: empty snippet file</pre>';
    return;
}

// MODX snippet content in DB must not start with <?php
$contentForDb = preg_replace('/^\xEF\xBB\xBF/', '', $content);
$contentForDb = preg_replace('/^\s*<\?php\s*/', '', $contentForDb, 1);

$snippet = $modx->getObject('modSnippet', array('name' => $snippetName));
if (!$snippet) {
    echo '<pre>ERROR: snippet UserTest not found</pre>';
    return;
}

$backupName = 'UserTest_backup_before_stage27_' . date('Ymd_His');
$backup = $modx->newObject('modSnippet');
$backup->fromArray(array(
    'name' => $backupName,
    'description' => 'Backup before Training stage27 UserTest no empty POST save fix',
    'snippet' => $snippet->get('snippet'),
    'static' => 0,
), '', true, true);
$backup->save();

$snippet->set('snippet', $contentForDb);
$snippet->set('static', 0);
$snippet->set('static_file', 'core/components/usertest/elements/snippets/snippet.usertest.php');
$snippet->save();

if ($modx->cacheManager) {
    $modx->cacheManager->refresh(array(
        'resource' => array(),
        'includes' => array(),
        'scripts' => array(),
        'system_settings' => array(),
        'default' => array(),
    ));
}

$db = (string)$snippet->get('snippet');

echo '<pre>';
echo "OK: stage27 UserTest installed\n";
echo "snippet: {$snippetName}\n";
echo "snippetId: " . (int)$snippet->get('id') . "\n";
echo "backup: {$backupName}\n";
echo "file: {$file}\n";
echo "DB starts with php tag: " . (preg_match('/^\s*<\?php/', $db) ? 'YES - ERROR' : 'NO - OK') . "\n";
echo "stage27 marker: " . (strpos($db, 'TRAINING_STAGE27_USERTEST_NO_EMPTY_POST_SAVE') !== false ? 'YES' : 'NO') . "\n";
echo "old bad hotfix: " . (strpos($db, 'TRAINING_USERTEST_SNIPPET92_PHP8_HOTFIX') !== false ? 'YES - ERROR' : 'NO - OK') . "\n";
echo "empty POST guard: " . (strpos($db, 'if($hasPostedQuestion and $answer_step != "start" and !$skip_save){') !== false ? 'YES' : 'NO - ERROR') . "\n";
echo "safe time_last_step: " . (strpos($db, '!empty($_SESSION[\'UserTest\'][$id][\'time_last_step\'])') !== false ? 'YES' : 'NO - ERROR') . "\n";
echo "\nNext: Ctrl+F5 and open test with reset=1\n";
echo '</pre>';
