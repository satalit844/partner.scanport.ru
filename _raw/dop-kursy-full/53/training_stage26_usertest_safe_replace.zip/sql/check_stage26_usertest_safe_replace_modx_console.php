<?php
$snippetId = 92;
$file = MODX_CORE_PATH . 'components/usertest/elements/snippets/snippet.usertest.php';
$snippet = $modx->getObject('modSnippet', $snippetId);
$content = $snippet ? (string)$snippet->getContent() : '';
$fileContent = is_file($file) ? (string)file_get_contents($file) : '';

$out = array();
$out[] = 'Check stage26 UserTest';
$out[] = str_repeat('=', 80);
$out[] = 'snippet found: ' . ($snippet ? 'YES' : 'NO');
$out[] = 'file exists: ' . (is_file($file) ? 'YES' : 'NO');
$out[] = 'DB starts with php tag: ' . (preg_match('/^\s*<\?php/', $content) ? 'YES - BAD' : 'NO - OK');
$out[] = 'file has stage26 marker: ' . (strpos($fileContent, 'TRAINING_USERTEST_STAGE26_PATCH') !== false ? 'YES' : 'NO');
$out[] = 'DB has stage26 marker: ' . (strpos($content, 'TRAINING_USERTEST_STAGE26_PATCH') !== false ? 'YES' : 'NO');
$out[] = 'old bad hotfix in DB: ' . (strpos($content, 'TRAINING_USERTEST_SNIPPET92_PHP8_HOTFIX_START') !== false ? 'YES - BAD' : 'NO - OK');
$out[] = 'guard in DB: ' . (strpos($content, 'and !$skip_save and $hasPostedQuestion') !== false ? 'YES' : 'NO');
$out[] = 'safe time_last_step in DB: ' . (strpos($content, "!empty(\$_SESSION['UserTest'][\$id]['time_last_step'])") !== false ? 'YES' : 'NO');

if ($snippet) {
    $out[] = 'static: ' . (string)$snippet->get('static');
    $out[] = 'static_file: ' . (string)$snippet->get('static_file');
}

echo '<pre>' . htmlspecialchars(implode("\n", $out), ENT_QUOTES, 'UTF-8') . '</pre>';
