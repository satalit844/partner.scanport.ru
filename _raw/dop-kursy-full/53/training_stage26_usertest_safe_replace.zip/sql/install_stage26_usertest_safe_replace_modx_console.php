<?php
$snippetId = 92;
$file = MODX_CORE_PATH . 'components/usertest/elements/snippets/snippet.usertest.php';

$out = array();
$out[] = 'Install stage26 UserTest safe replace';
$out[] = str_repeat('=', 80);
$out[] = 'file: ' . $file;

if (!is_file($file)) {
    echo '<pre>ERROR: snippet file not found: ' . htmlspecialchars($file, ENT_QUOTES, 'UTF-8') . '</pre>';
    return;
}

$content = file_get_contents($file);
if ($content === false || trim($content) === '') {
    echo '<pre>ERROR: snippet file is empty or unreadable</pre>';
    return;
}

if (strpos($content, 'TRAINING_USERTEST_STAGE26_PATCH') === false) {
    echo '<pre>ERROR: stage26 marker not found in file. File was not replaced.</pre>';
    return;
}

if (strpos($content, 'TRAINING_USERTEST_SNIPPET92_PHP8_HOTFIX_START') !== false) {
    echo '<pre>ERROR: old bad hotfix is still in file. Stop.</pre>';
    return;
}

$dbContent = preg_replace('/^\xEF\xBB\xBF?\s*<\?php\s*/', '', $content, 1);
$dbContent = preg_replace('/^\s*<\?php\s*/', '', $dbContent, 1);

$snippet = $modx->getObject('modSnippet', $snippetId);
if (!$snippet) {
    echo '<pre>ERROR: modSnippet #92 not found</pre>';
    return;
}

$oldContent = (string)$snippet->getContent();
$backupName = 'UT_backup_before_stage26_' . date('Ymd_His');
$backup = $modx->newObject('modSnippet');
if ($backup) {
    $backup->set('name', $backupName);
    $backup->set('description', 'Backup before stage26 UserTest fix');
    $backup->set('category', $snippet->get('category'));
    $backup->set('static', 0);
    $backup->set('static_file', '');
    $backup->setContent($oldContent);
    if ($backup->save()) {
        $out[] = 'backup created: ' . $backupName;
    } else {
        $out[] = 'WARN: backup snippet was not saved';
    }
}

$snippet->setContent($dbContent);
$snippet->set('static', 0);
$snippet->set('static_file', 'core/components/usertest/elements/snippets/snippet.usertest.php');

if (!$snippet->save()) {
    echo '<pre>ERROR: UserTest snippet was not saved</pre>';
    return;
}

$cachePath = MODX_CORE_PATH . 'cache/';
$paths = array(
    $cachePath . 'includes/',
    $cachePath . 'resource/',
    $cachePath . 'scripts/',
    $cachePath . 'default/',
);

foreach ($paths as $path) {
    if (is_dir($path)) {
        $modx->cacheManager->deleteTree($path, array(
            'deleteTop' => false,
            'skipDirs' => false,
            'extensions' => array(),
        ));
        $out[] = 'CACHE CLEANED: ' . $path;
    }
}

$modx->cacheManager->refresh(array(
    'scripts' => array(),
    'resource' => array(),
    'system_settings' => array(),
));

$out[] = 'OK: UserTest snippet #92 replaced';
$out[] = 'static: ' . (string)$snippet->get('static');
$out[] = 'static_file: ' . (string)$snippet->get('static_file');
$out[] = 'bad hotfix removed: YES';
$out[] = 'has posted question guard: YES';
$out[] = 'safe time_last_step: YES';

echo '<pre>' . htmlspecialchars(implode("\n", $out), ENT_QUOTES, 'UTF-8') . '</pre>';
