<?php
$name = 'TrainingUserTestCKEditorSafe';
$coreFile = MODX_CORE_PATH . 'components/training/elements/plugins/plugin.usertest_ckeditor_safe.php';
$assetsFile = MODX_ASSETS_PATH . 'components/training/js/mgr/usertest-ckeditor-safe.js';

if (!is_file($coreFile)) {
    echo '<pre>FAIL plugin file: ' . htmlspecialchars($coreFile, ENT_QUOTES, 'UTF-8') . '</pre>';
    return;
}

if (!is_file($assetsFile)) {
    echo '<pre>FAIL js file: ' . htmlspecialchars($assetsFile, ENT_QUOTES, 'UTF-8') . '</pre>';
    return;
}

$plugin = $modx->getObject('modPlugin', array('name' => $name));
if (!$plugin) {
    $plugin = $modx->newObject('modPlugin');
    $plugin->set('name', $name);
}

$plugin->fromArray(array(
    'description' => 'Защита CKEditor от повторной инициализации в окнах UserTest/MODX manager.',
    'category' => 0,
    'static' => 1,
    'static_file' => 'core/components/training/elements/plugins/plugin.usertest_ckeditor_safe.php',
    'source' => 1,
    'disabled' => 0,
    'plugincode' => "return include MODX_CORE_PATH . 'components/training/elements/plugins/plugin.usertest_ckeditor_safe.php';",
), '', true, true);
$plugin->save();

$pluginId = (int)$plugin->get('id');

$event = $modx->getObject('modPluginEvent', array(
    'pluginid' => $pluginId,
    'event' => 'OnManagerPageBeforeRender',
));

if (!$event) {
    $event = $modx->newObject('modPluginEvent');
    $event->fromArray(array(
        'pluginid' => $pluginId,
        'event' => 'OnManagerPageBeforeRender',
        'propertyset' => 0,
    ));
}

$event->set('priority', -1000);
$event->save();

$modx->cacheManager->refresh(array(
    'db' => array(),
    'system_settings' => array(),
    'scripts' => array(),
));

$cachePath = MODX_CORE_PATH . 'cache/';
foreach (array('includes/', 'mgr/', 'scripts/') as $dir) {
    $path = $cachePath . $dir;
    if (is_dir($path)) {
        $modx->cacheManager->deleteTree($path, array(
            'deleteTop' => false,
            'skipDirs' => false,
            'extensions' => array(),
        ));
    }
}

echo '<pre>';
echo "OK: {$name} v2\n";
echo "pluginId: {$pluginId}\n";
echo "priority: -1000\n";
echo "core file: {$coreFile}\n";
echo "js file: {$assetsFile}\n";
echo "js mtime: " . date('Y-m-d H:i:s', filemtime($assetsFile)) . "\n";
echo "\nДальше: закрыть окно вопроса, Ctrl+F5 в админке, открыть вопрос заново.\n";
echo '</pre>';
