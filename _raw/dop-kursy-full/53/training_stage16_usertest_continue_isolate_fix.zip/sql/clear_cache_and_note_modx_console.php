<?php
$modx->cacheManager->refresh(array(
    'db' => array(),
    'auto_publish' => array(),
    'context_settings' => array(),
    'resource' => array(),
    'system_settings' => array(),
    'scripts' => array(),
));

echo '<pre>';
echo "OK: UserTest continue button isolated from /assets/components/usertest/action.php.\n";
echo "Answered question screen now has no UserTestForm and no .btn-test on Continue.\n";
echo "Next step opens by GET only.\n";
echo '</pre>';
