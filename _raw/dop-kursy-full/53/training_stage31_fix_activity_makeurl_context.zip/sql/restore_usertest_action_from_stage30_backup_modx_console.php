<?php
echo '<pre>';
$action = MODX_BASE_PATH . 'assets/components/usertest/action.php';
$backup = MODX_BASE_PATH . 'assets/components/usertest/action.stage30.original.php';

if (!is_file($backup)) {
    echo "SKIP: backup not found: {$backup}\n";
    echo '</pre>';
    return;
}

if (!copy($backup, $action)) {
    echo "ERROR: cannot restore {$action}\n";
    echo '</pre>';
    return;
}

echo "OK: restored UserTest action.php from stage30 backup\n";
echo "action: {$action}\n";
echo "backup: {$backup}\n";
echo '</pre>';
