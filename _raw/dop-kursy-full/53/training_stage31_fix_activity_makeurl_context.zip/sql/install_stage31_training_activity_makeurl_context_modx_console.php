<?php
/**
 * Stage31: fix trainingActivityPage URL generation on PHP 8.3 / MODX 2.8.
 * Updates snippet trainingActivityPage from file and clears caches.
 */
echo '<pre>';

$file = MODX_CORE_PATH . 'components/training/elements/snippets/snippet.trainingActivityPage.php';
$snippetName = 'trainingActivityPage';

if (!is_file($file)) {
    echo "ERROR: file not found: {$file}\n";
    echo '</pre>';
    return;
}

$content = file_get_contents($file);
if ($content === false || trim($content) === '') {
    echo "ERROR: file is empty: {$file}\n";
    echo '</pre>';
    return;
}

if (substr($content, 0, 5) === '<?php') {
    $contentForDb = preg_replace('/^<\?php\s*/', '', $content, 1);
} else {
    $contentForDb = $content;
}

$snippet = $modx->getObject('modSnippet', array('name' => $snippetName));
if (!$snippet) {
    echo "ERROR: snippet not found: {$snippetName}\n";
    echo '</pre>';
    return;
}

$backupName = $snippetName . '_backup_stage31_' . date('Ymd_His');
$backup = $modx->newObject('modSnippet');
$backup->fromArray(array(
    'name' => $backupName,
    'description' => 'Backup before stage31 trainingActivityPage URL context fix',
    'snippet' => $snippet->get('snippet'),
    'static' => 0,
    'static_file' => '',
), '', true, true);
$backup->save();

$snippet->set('snippet', $contentForDb);
$snippet->set('static', 0);
$snippet->set('static_file', '');
$snippet->save();

$paths = array(
    MODX_CORE_PATH . 'cache/includes/',
    MODX_CORE_PATH . 'cache/resource/',
    MODX_CORE_PATH . 'cache/default/',
    MODX_CORE_PATH . 'cache/scripts/',
);

$remove = function ($path) use (&$remove) {
    if (!file_exists($path)) {
        return;
    }
    if (is_file($path) || is_link($path)) {
        @unlink($path);
        return;
    }
    $items = scandir($path);
    if (is_array($items)) {
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $remove(rtrim($path, '/') . '/' . $item);
        }
    }
    @rmdir($path);
};

foreach ($paths as $path) {
    $remove($path);
    echo "CACHE CLEANED: {$path}\n";
}

$modx->cacheManager->refresh(array(
    'resource' => array(),
    'scripts' => array(),
    'system_settings' => array(),
));

echo "\nOK: stage31 installed\n";
echo "snippet id: " . $snippet->get('id') . "\n";
echo "backup snippet: {$backupName}\n";
echo "file: {$file}\n";
echo '</pre>';
