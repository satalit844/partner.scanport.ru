<?php
echo '<pre>';

$snippet = $modx->getObject('modSnippet', array('name' => 'trainingActivityPage'));
if (!$snippet) {
    echo "ERROR: snippet trainingActivityPage not found\n";
    echo '</pre>';
    return;
}

$content = (string)$snippet->get('snippet');
$cachePath = MODX_CORE_PATH . 'cache/includes/elements/modsnippet/' . (int)$snippet->get('id') . '.include.cache.php';
$cache = is_file($cachePath) ? (string)file_get_contents($cachePath) : '';

echo "Check stage31 trainingActivityPage\n";
echo str_repeat('=', 80) . "\n";
echo "snippet id: " . $snippet->get('id') . "\n";
echo "static: " . $snippet->get('static') . "\n";
echo "static_file: " . $snippet->get('static_file') . "\n";
echo "DB has stage31 marker: " . (strpos($content, 'TRAINING_STAGE31_FIX_ACTIVITY_MAKEURL_CONTEXT') !== false ? 'YES' : 'NO') . "\n";
echo "DB uses resource context_key: " . (strpos($content, "get('context_key')") !== false ? 'YES' : 'NO') . "\n";
echo "DB has raw makeUrl empty context: " . (strpos($content, "makeUrl((int)\$resourceId, '',") !== false ? 'YES - BAD' : 'NO - OK') . "\n";
echo "DB AjaxMode 1: " . (strpos($content, "'AjaxMode' => 1") !== false ? 'YES' : 'NO') . "\n";
echo "DB AjaxMode 0: " . (strpos($content, "'AjaxMode' => 0") !== false ? 'YES - BAD' : 'NO - OK') . "\n";
echo "cache exists: " . (is_file($cachePath) ? 'YES' : 'NO') . "\n";
if ($cache !== '') {
    echo "cache has stage31 marker: " . (strpos($cache, 'TRAINING_STAGE31_FIX_ACTIVITY_MAKEURL_CONTEXT') !== false ? 'YES' : 'NO') . "\n";
    echo "cache uses resource context_key: " . (strpos($cache, "get('context_key')") !== false ? 'YES' : 'NO') . "\n";
    echo "cache AjaxMode 1: " . (strpos($cache, "'AjaxMode' => 1") !== false ? 'YES' : 'NO') . "\n";
}

echo "\nTest helper by running snippet GET start reset\n";
echo str_repeat('-', 80) . "\n";

$_GET = array(
    'activity' => 3,
    'back' => 159,
    'screen' => 'test',
    'step' => 'start',
    'reset' => 1,
);
$_REQUEST = $_GET;
$_SERVER['REQUEST_METHOD'] = 'GET';
$_SERVER['REQUEST_URI'] = '/obuchenie/obuchenie-glavnaya/stranitsa-testa/?activity=3&back=159&screen=test&step=start&reset=1';

$oldHandler = set_error_handler(function ($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) {
        return false;
    }
    throw new ErrorException($message, 0, $severity, $file, $line);
});

try {
    $out = $modx->runSnippet('trainingActivityPage', array('resource_id' => 176));
    echo "OK: rendered\n";
    echo "output length: " . strlen((string)$out) . "\n";
} catch (Throwable $e) {
    echo "FATAL CAUGHT\n";
    echo "message: " . $e->getMessage() . "\n";
    echo "file: " . $e->getFile() . "\n";
    echo "line: " . $e->getLine() . "\n";
    echo $e->getTraceAsString() . "\n";
}
restore_error_handler();

echo '</pre>';
