<?php
$modx->cacheManager->refresh(array(
    'db' => array(),
    'auto_publish' => array(),
    'context_settings' => array(),
    'resource' => array(),
    'system_settings' => array(),
    'scripts' => array(),
));

echo '<pre>';
echo "OK: cache cleared\n";
echo "UserTest AJAX mode restored by snippet file replacement.\n\n";

$log = MODX_CORE_PATH . 'cache/logs/error.log';
if (is_file($log)) {
    echo "Last error.log lines:\n";
    echo str_repeat('-', 80) . "\n";
    $lines = file($log);
    echo htmlspecialchars(implode('', array_slice($lines, -80)), ENT_QUOTES, 'UTF-8');
} else {
    echo "error.log not found: {$log}\n";
}
echo '</pre>';
