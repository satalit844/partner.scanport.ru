<?php
/**
 * Diagnose UserTest 500 on action.php for all training users.
 * Run in MODX Console.
 */
set_time_limit(0);

function tp10_table_exists(modX $modx, $table) {
    $stmt = $modx->prepare('SHOW TABLES LIKE :t');
    $stmt->execute(array(':t' => $table));
    return (bool)$stmt->fetchColumn();
}
function tp10_cols(modX $modx, $table) {
    static $cache = array();
    if (isset($cache[$table])) return $cache[$table];
    $cols = array();
    if (tp10_table_exists($modx, $table)) {
        $stmt = $modx->query('SHOW COLUMNS FROM `' . str_replace('`', '', $table) . '`');
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $cols[$row['Field']] = true;
        }
    }
    return $cache[$table] = $cols;
}
function tp10_has_col(modX $modx, $table, $col) {
    $cols = tp10_cols($modx, $table);
    return isset($cols[$col]);
}
function tp10_fetch_all(modX $modx, $sql, array $params = array()) {
    $stmt = $modx->prepare($sql);
    if (!$stmt || !$stmt->execute($params)) {
        echo "SQL ERROR:\n" . $sql . "\n";
        print_r($stmt ? $stmt->errorInfo() : array('prepare failed'));
        return array();
    }
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return is_array($rows) ? $rows : array();
}
function tp10_find_table_with_cols(modX $modx, array $needles, $like = '%usertest%') {
    $db = $modx->getOption('dbname');
    if (!$db) {
        $db = $modx->query('SELECT DATABASE()')->fetchColumn();
    }
    $sql = "SELECT TABLE_NAME, GROUP_CONCAT(COLUMN_NAME) AS cols
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = :db AND TABLE_NAME LIKE :like
            GROUP BY TABLE_NAME";
    $rows = tp10_fetch_all($modx, $sql, array(':db' => $db, ':like' => $like));
    foreach ($rows as $row) {
        $cols = array_flip(explode(',', $row['cols']));
        $ok = true;
        foreach ($needles as $col) {
            if (!isset($cols[$col])) {
                $ok = false;
                break;
            }
        }
        if ($ok) return $row['TABLE_NAME'];
    }
    return '';
}
function tp10_decode_session($value) {
    $value = (string)$value;
    $out = array('raw_len' => strlen($value), 'AjaxMode' => null, 'curStep' => null, 'question_step' => null, 'decode' => 'none');
    if ($value === '') return $out;

    $json = json_decode($value, true);
    if (is_array($json)) {
        $out['decode'] = 'json';
        foreach (array('AjaxMode','curStep','question_step','step') as $k) {
            if (array_key_exists($k, $json)) $out[$k === 'step' ? 'curStep' : $k] = $json[$k];
        }
        return $out;
    }

    $un = @unserialize($value);
    if (is_array($un)) {
        $out['decode'] = 'serialize';
        foreach (array('AjaxMode','curStep','question_step','step') as $k) {
            if (array_key_exists($k, $un)) $out[$k === 'step' ? 'curStep' : $k] = $un[$k];
        }
        return $out;
    }

    if (preg_match('/AjaxMode[^;]*;[bi]:([0-9]+)/', $value, $m)) {
        $out['AjaxMode'] = $m[1];
        $out['decode'] = 'regex';
    }
    if (preg_match('/curStep[^;]*;[is]:?"?([0-9a-zA-Z_\-]+)/', $value, $m)) {
        $out['curStep'] = $m[1];
        $out['decode'] = $out['decode'] === 'none' ? 'regex' : $out['decode'];
    }
    return $out;
}

$corePath = $modx->getOption('training.core_path', null, MODX_CORE_PATH . 'components/training/');
if (is_dir($corePath . 'model/')) {
    $modx->addPackage('training', $corePath . 'model/');
}
$utCore = $modx->getOption('usertest_core_path', null, MODX_CORE_PATH . 'components/usertest/');
if (is_dir($utCore . 'model/')) {
    $modx->addPackage('usertest', $utCore . 'model/');
}

$prefix = $modx->getOption('table_prefix');
$tables = array(
    'training_links' => class_exists('TrainingTestLink') ? trim($modx->getTableName('TrainingTestLink'), '`') : $prefix . 'training_test_links',
    'training_status' => class_exists('TrainingUserTestStatus') ? trim($modx->getTableName('TrainingUserTestStatus'), '`') : $prefix . 'training_user_test_status',
    'users' => $prefix . 'users',
    'profiles' => $prefix . 'user_attributes',
    'ut_tests' => class_exists('UserTestTests') ? trim($modx->getTableName('UserTestTests'), '`') : '',
    'ut_results' => class_exists('UserTestResults') ? trim($modx->getTableName('UserTestResults'), '`') : '',
);
if (!$tables['ut_tests'] || !tp10_table_exists($modx, $tables['ut_tests'])) {
    $tables['ut_tests'] = tp10_find_table_with_cols($modx, array('id', 'count_questions'), '%usertest%');
}
if (!$tables['ut_results'] || !tp10_table_exists($modx, $tables['ut_results'])) {
    $tables['ut_results'] = tp10_find_table_with_cols($modx, array('test_id', 'user_id', 'status_id'), '%usertest%');
}
$tables['ut_question_link'] = tp10_find_table_with_cols($modx, array('test_id', 'question_id'), '%usertest%');
$tables['ut_answers'] = tp10_find_table_with_cols($modx, array('question_id'), '%usertest%');

header('Content-Type: text/html; charset=utf-8');
echo '<pre>';
echo "UserTest 500 diagnose\n" . str_repeat('=', 80) . "\n";
echo "PHP: " . PHP_VERSION . "\n";
echo "training core: {$corePath}\n";
echo "usertest core: {$utCore}\n\n";
echo "Tables:\n";
print_r($tables);

foreach ($tables as $name => $table) {
    if (!$table) continue;
    echo (tp10_table_exists($modx, $table) ? 'OK   ' : 'FAIL ') . $name . ': ' . $table . "\n";
}

if (!tp10_table_exists($modx, $tables['training_links']) || !tp10_table_exists($modx, $tables['ut_results']) || !tp10_table_exists($modx, $tables['ut_tests'])) {
    echo "\nНе найдены нужные таблицы. Проверь, что пакет usertest установлен и addPackage видит model.\n";
    echo '</pre>';
    return;
}

$linked = tp10_fetch_all($modx, "
    SELECT l.*,
           t.`name` AS test_name,
           t.`count_questions`,
           t.`active`
    FROM `{$tables['training_links']}` l
    LEFT JOIN `{$tables['ut_tests']}` t ON t.`id` = l.`usertest_test_id`
    WHERE l.`link_type` = 'test'
    ORDER BY l.`course_id`, l.`module_id`, l.`sort_order`, l.`id`
");

echo "\nLinked module tests:\n";
foreach ($linked as $row) {
    echo "link #{$row['id']} course={$row['course_id']} module={$row['module_id']} test={$row['usertest_test_id']} active={$row['active']} count={$row['count_questions']} title={$row['test_name']}\n";
}

$testIds = array();
foreach ($linked as $row) {
    $testIds[] = (int)$row['usertest_test_id'];
}
$testIds = array_values(array_unique(array_filter($testIds)));
$testIdsSql = $testIds ? implode(',', $testIds) : '0';

if ($tables['ut_question_link'] && tp10_table_exists($modx, $tables['ut_question_link'])) {
    echo "\nQuestion counts by real link table:\n";
    $counts = tp10_fetch_all($modx, "
        SELECT `test_id`, COUNT(*) AS real_count
        FROM `{$tables['ut_question_link']}`
        WHERE `test_id` IN ({$testIdsSql})
        GROUP BY `test_id`
        ORDER BY `test_id`
    ");
    print_r($counts);
}

$resCols = tp10_cols($modx, $tables['ut_results']);
$select = array('r.`id`', 'r.`test_id`', 'r.`user_id`', 'r.`status_id`');
foreach (array('max_point','test_point','point','createdon','updatedon','date','session') as $col) {
    if (isset($resCols[$col])) $select[] = 'r.`' . $col . '`';
}
$joinStatus = tp10_table_exists($modx, $tables['training_status']);
$statusSelect = $joinStatus ? ", s.`id` AS training_status_id, s.`course_id`, s.`module_id`, s.`status` AS training_status, s.`last_result_id`, s.`attempts`, s.`passed`, s.`last_score`" : '';
$statusJoin = $joinStatus ? "LEFT JOIN `{$tables['training_status']}` s ON s.`last_result_id` = r.`id`" : '';
$usersJoin = tp10_table_exists($modx, $tables['users']) ? "LEFT JOIN `{$tables['users']}` u ON u.`id` = r.`user_id`" : '';
$profilesJoin = tp10_table_exists($modx, $tables['profiles']) ? "LEFT JOIN `{$tables['profiles']}` ua ON ua.`internalKey` = r.`user_id`" : '';
$userSelect = tp10_table_exists($modx, $tables['users']) ? ", u.`username`" : '';
$userSelect .= tp10_table_exists($modx, $tables['profiles']) ? ", ua.`fullname`" : '';

$activeRows = tp10_fetch_all($modx, "
    SELECT " . implode(', ', $select) . $statusSelect . $userSelect . "
    FROM `{$tables['ut_results']}` r
    {$statusJoin}
    {$usersJoin}
    {$profilesJoin}
    WHERE r.`test_id` IN ({$testIdsSql})
      AND r.`status_id` = 1
    ORDER BY r.`test_id`, r.`user_id`, r.`id`
");

echo "\nActive unfinished UserTestResults for linked tests (status_id=1):\n";
foreach ($activeRows as $row) {
    $sessionInfo = isset($row['session']) ? tp10_decode_session($row['session']) : array();
    unset($row['session']);
    echo "\n--- active result ---\n";
    print_r($row);
    if ($sessionInfo) {
        echo "session: ";
        print_r($sessionInfo);
    }
}

if ($joinStatus) {
    $badStatus = tp10_fetch_all($modx, "
        SELECT s.*, u.`username`, ua.`fullname`
        FROM `{$tables['training_status']}` s
        LEFT JOIN `{$tables['ut_results']}` r ON r.`id` = s.`last_result_id`
        LEFT JOIN `{$tables['users']}` u ON u.`id` = s.`user_id`
        LEFT JOIN `{$tables['profiles']}` ua ON ua.`internalKey` = s.`user_id`
        WHERE s.`usertest_test_id` IN ({$testIdsSql})
          AND (
              s.`status` = 'in_progress'
              OR (s.`last_result_id` > 0 AND r.`id` IS NULL)
              OR (s.`last_result_id` > 0 AND r.`status_id` = 1 AND s.`attempts` = 0)
          )
        ORDER BY s.`usertest_test_id`, s.`user_id`
    ");
    echo "\nTraining statuses that can force broken resume:\n";
    print_r($badStatus);
}

$zeroMaxWhere = isset($resCols['max_point']) ? " OR COALESCE(r.`max_point`,0) = 0" : '';
$badResults = tp10_fetch_all($modx, "
    SELECT " . implode(', ', $select) . $userSelect . "
    FROM `{$tables['ut_results']}` r
    {$usersJoin}
    {$profilesJoin}
    WHERE r.`test_id` IN ({$testIdsSql})
      AND (r.`status_id` = 1 {$zeroMaxWhere})
    ORDER BY r.`test_id`, r.`user_id`, r.`id`
    LIMIT 200
");
echo "\nPotentially bad results (active or max_point=0):\n";
foreach ($badResults as $row) {
    unset($row['session']);
    print_r($row);
}

$log = MODX_CORE_PATH . 'cache/logs/error.log';
echo "\nLatest relevant error.log lines:\n";
if (is_file($log)) {
    $lines = file($log);
    $relevant = array();
    foreach (array_slice($lines, -500) as $line) {
        if (stripos($line, 'usertest') !== false || stripos($line, 'action.php') !== false || stripos($line, 'UserTest') !== false || stripos($line, 'trainingActivity') !== false) {
            $relevant[] = $line;
        }
    }
    echo htmlspecialchars(implode('', array_slice($relevant, -120)), ENT_QUOTES, 'UTF-8');
} else {
    echo "error.log not found\n";
}

echo "\n" . str_repeat('=', 80) . "\nDone\n";
echo '</pre>';
