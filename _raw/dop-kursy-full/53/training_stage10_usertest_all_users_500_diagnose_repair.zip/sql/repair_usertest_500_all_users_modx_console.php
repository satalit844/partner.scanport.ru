<?php
/**
 * Repair common UserTest 500 causes for training module tests:
 * - recount UserTest tests by question links;
 * - repair max_point=0 for unfinished/zero results;
 * - reset stale active attempts that training resumes for users after test DB changed.
 * Run in MODX Console.
 */
set_time_limit(0);

function tr10_table_exists(modX $modx, $table) {
    $stmt = $modx->prepare('SHOW TABLES LIKE :t');
    $stmt->execute(array(':t' => $table));
    return (bool)$stmt->fetchColumn();
}
function tr10_cols(modX $modx, $table) {
    static $cache = array();
    if (isset($cache[$table])) return $cache[$table];
    $cols = array();
    if (tr10_table_exists($modx, $table)) {
        $stmt = $modx->query('SHOW COLUMNS FROM `' . str_replace('`', '', $table) . '`');
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $cols[$row['Field']] = true;
        }
    }
    return $cache[$table] = $cols;
}
function tr10_find_table_with_cols(modX $modx, array $needles, $like = '%usertest%') {
    $db = $modx->getOption('dbname');
    if (!$db) $db = $modx->query('SELECT DATABASE()')->fetchColumn();
    $stmt = $modx->prepare("SELECT TABLE_NAME, GROUP_CONCAT(COLUMN_NAME) AS cols
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = :db AND TABLE_NAME LIKE :like
        GROUP BY TABLE_NAME");
    $stmt->execute(array(':db' => $db, ':like' => $like));
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $cols = array_flip(explode(',', $row['cols']));
        $ok = true;
        foreach ($needles as $col) {
            if (!isset($cols[$col])) { $ok = false; break; }
        }
        if ($ok) return $row['TABLE_NAME'];
    }
    return '';
}
function tr10_fetch_all(modX $modx, $sql, array $params = array()) {
    $stmt = $modx->prepare($sql);
    if (!$stmt || !$stmt->execute($params)) {
        echo "SQL ERROR:\n" . $sql . "\n";
        print_r($stmt ? $stmt->errorInfo() : array('prepare failed'));
        return array();
    }
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return is_array($rows) ? $rows : array();
}
function tr10_exec(modX $modx, $sql, array $params = array()) {
    $stmt = $modx->prepare($sql);
    if (!$stmt || !$stmt->execute($params)) {
        echo "SQL ERROR:\n" . $sql . "\n";
        print_r($stmt ? $stmt->errorInfo() : array('prepare failed'));
        return 0;
    }
    return $stmt->rowCount();
}

$corePath = $modx->getOption('training.core_path', null, MODX_CORE_PATH . 'components/training/');
if (is_dir($corePath . 'model/')) $modx->addPackage('training', $corePath . 'model/');
$utCore = $modx->getOption('usertest_core_path', null, MODX_CORE_PATH . 'components/usertest/');
if (is_dir($utCore . 'model/')) $modx->addPackage('usertest', $utCore . 'model/');

$prefix = $modx->getOption('table_prefix');
$links = class_exists('TrainingTestLink') ? trim($modx->getTableName('TrainingTestLink'), '`') : $prefix . 'training_test_links';
$status = class_exists('TrainingUserTestStatus') ? trim($modx->getTableName('TrainingUserTestStatus'), '`') : $prefix . 'training_user_test_status';
$tests = class_exists('UserTestTests') ? trim($modx->getTableName('UserTestTests'), '`') : '';
$results = class_exists('UserTestResults') ? trim($modx->getTableName('UserTestResults'), '`') : '';
if (!$tests || !tr10_table_exists($modx, $tests)) $tests = tr10_find_table_with_cols($modx, array('id', 'count_questions'), '%usertest%');
if (!$results || !tr10_table_exists($modx, $results)) $results = tr10_find_table_with_cols($modx, array('test_id', 'user_id', 'status_id'), '%usertest%');
$qLink = tr10_find_table_with_cols($modx, array('test_id', 'question_id'), '%usertest%');

header('Content-Type: text/html; charset=utf-8');
echo '<pre>';
echo "UserTest 500 repair\n" . str_repeat('=', 80) . "\n";
echo "links={$links}\nstatus={$status}\ntests={$tests}\nresults={$results}\nqLink={$qLink}\n\n";

foreach (array($links, $tests, $results) as $t) {
    if (!$t || !tr10_table_exists($modx, $t)) {
        echo "FAIL: required table not found: {$t}\n";
        echo '</pre>';
        return;
    }
}

$linkedRows = tr10_fetch_all($modx, "
    SELECT `id`, `course_id`, `module_id`, `usertest_test_id`
    FROM `{$links}`
    WHERE `link_type` = 'test' AND `usertest_test_id` > 0
    ORDER BY `id`
");
$testIds = array();
foreach ($linkedRows as $row) $testIds[] = (int)$row['usertest_test_id'];
$testIds = array_values(array_unique(array_filter($testIds)));
$testIdsSql = $testIds ? implode(',', $testIds) : '0';
echo "Linked UserTest IDs: {$testIdsSql}\n\n";

if ($qLink && tr10_table_exists($modx, $qLink) && tr10_table_exists($modx, $tests)) {
    $counts = tr10_fetch_all($modx, "
        SELECT `test_id`, COUNT(*) AS real_count
        FROM `{$qLink}`
        WHERE `test_id` IN ({$testIdsSql})
        GROUP BY `test_id`
    ");
    foreach ($counts as $row) {
        $count = (int)$row['real_count'];
        $testId = (int)$row['test_id'];
        $affected = tr10_exec($modx, "
            UPDATE `{$tests}`
            SET `count_questions` = :cnt
            WHERE `id` = :id AND (COALESCE(`count_questions`,0) = 0 OR `count_questions` <> :cnt)
        ", array(':cnt' => $count, ':id' => $testId));
        echo "test {$testId}: count_questions => {$count}; updated={$affected}\n";
    }
}

$resCols = tr10_cols($modx, $results);
$hasMax = isset($resCols['max_point']);
if ($hasMax) {
    $affected = tr10_exec($modx, "
        UPDATE `{$results}` r
        INNER JOIN `{$tests}` t ON t.`id` = r.`test_id`
        SET r.`max_point` = GREATEST(1, COALESCE(t.`count_questions`,0) * 10)
        WHERE r.`test_id` IN ({$testIdsSql})
          AND COALESCE(r.`max_point`,0) = 0
          AND COALESCE(t.`count_questions`,0) > 0
    ");
    echo "\nresults max_point repaired: {$affected}\n";
}

$badIds = array();
if (tr10_table_exists($modx, $status)) {
    $rows = tr10_fetch_all($modx, "
        SELECT DISTINCT r.`id`
        FROM `{$status}` s
        INNER JOIN `{$results}` r ON r.`id` = s.`last_result_id`
        WHERE s.`usertest_test_id` IN ({$testIdsSql})
          AND s.`status` = 'in_progress'
          AND s.`attempts` = 0
          AND r.`status_id` = 1
    ");
    foreach ($rows as $r) $badIds[] = (int)$r['id'];
}
if ($hasMax) {
    $rows = tr10_fetch_all($modx, "
        SELECT `id`
        FROM `{$results}`
        WHERE `test_id` IN ({$testIdsSql})
          AND `status_id` = 1
          AND COALESCE(`max_point`,0) = 0
    ");
    foreach ($rows as $r) $badIds[] = (int)$r['id'];
}
$badIds = array_values(array_unique(array_filter($badIds)));

if ($badIds) {
    $badSql = implode(',', $badIds);
    echo "\nStale active results to reset: {$badSql}\n";

    $backup = $prefix . 'training_usertest_bad_results_backup';
    $modx->exec("CREATE TABLE IF NOT EXISTS `{$backup}` LIKE `{$results}`");
    $copied = $modx->exec("INSERT IGNORE INTO `{$backup}` SELECT * FROM `{$results}` WHERE `id` IN ({$badSql})");
    echo "backup copied rows: " . (int)$copied . " into {$backup}\n";

    // status_id=0 removes result from active resume, but does not count as completed/passed.
    $affected = tr10_exec($modx, "
        UPDATE `{$results}`
        SET `status_id` = 0
        WHERE `id` IN ({$badSql}) AND `status_id` = 1
    ");
    echo "active results disabled: {$affected}\n";

    if (tr10_table_exists($modx, $status)) {
        $affected = tr10_exec($modx, "
            UPDATE `{$status}`
            SET `last_result_id` = 0,
                `attempts` = 0,
                `passed` = 0,
                `status` = 'not_started',
                `last_score` = 0,
                `last_passedon` = NULL,
                `updatedon` = NOW()
            WHERE `last_result_id` IN ({$badSql})
               OR (`usertest_test_id` IN ({$testIdsSql}) AND `status` = 'in_progress' AND `attempts` = 0)
        ");
        echo "training_user_test_status reset: {$affected}\n";
    }
} else {
    echo "\nNo stale active results matched reset rules.\n";
}

$modx->cacheManager->refresh(array(
    'db' => array(),
    'auto_publish' => array(),
    'context_settings' => array(),
    'resource' => array(),
    'system_settings' => array(),
    'scripts' => array(),
));

echo "\nCache refreshed.\n";
echo "\nOpen test again from course page. If user was inside test, start it again.\n";
echo str_repeat('=', 80) . "\nDone\n";
echo '</pre>';
