<?php
$prefix = $modx->getOption('table_prefix');
$testId = isset($_GET['test_id']) ? (int)$_GET['test_id'] : 4;
$questionNumber = isset($_GET['question']) ? (int)$_GET['question'] : 3;

$testsTable = $prefix . 'usertest_tests';
$linksTable = $prefix . 'usertest_test_question_link';
$questionsTable = $prefix . 'usertest_questions';
$answersTable = $prefix . 'usertest_answers';

function tpStage9TableExists(modX $modx, $table) {
    $stmt = $modx->prepare('SHOW TABLES LIKE :table');
    $stmt->execute(array(':table' => $table));
    return (bool)$stmt->fetchColumn();
}

foreach (array($testsTable, $linksTable, $questionsTable, $answersTable) as $table) {
    if (!tpStage9TableExists($modx, $table)) {
        echo '<pre>FAIL table not found: ' . htmlspecialchars($table, ENT_QUOTES, 'UTF-8') . '</pre>';
        return;
    }
}

$stmt = $modx->prepare("SELECT id, name, count_questions, count_test_answer FROM `{$testsTable}` WHERE id = :test_id LIMIT 1");
$stmt->execute(array(':test_id' => $testId));
$test = $stmt->fetch(PDO::FETCH_ASSOC);

$stmt = $modx->prepare("
    SELECT
        l.id AS link_id,
        l.menuindex,
        q.id AS question_id,
        q.question,
        q.type,
        q.max_point,
        COUNT(a.id) AS answers_total
    FROM `{$linksTable}` l
    INNER JOIN `{$questionsTable}` q ON q.id = l.question_id
    LEFT JOIN `{$answersTable}` a ON a.question_id = q.id
    WHERE l.test_id = :test_id
    GROUP BY l.id, q.id
    ORDER BY l.menuindex, l.id
");
$stmt->execute(array(':test_id' => $testId));
$questions = $stmt->fetchAll(PDO::FETCH_ASSOC);

$target = null;
foreach ($questions as $i => $row) {
    if (($i + 1) === $questionNumber) {
        $target = $row;
        break;
    }
}

$answers = array();
if ($target) {
    $stmt = $modx->prepare("SELECT id, question_id, answer, `right`, menuindex FROM `{$answersTable}` WHERE question_id = :question_id ORDER BY menuindex, id");
    $stmt->execute(array(':question_id' => (int)$target['question_id']));
    $answers = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

echo '<pre>';
echo "UserTest answers diagnose\n";
echo str_repeat('=', 80) . "\n";
echo "test_id: {$testId}\n";
echo "question number: {$questionNumber}\n\n";
echo "TEST:\n";
print_r($test);
echo "\nQUESTIONS SUMMARY:\n";
foreach ($questions as $i => $row) {
    echo '#' . ($i + 1) . ' | question_id=' . $row['question_id'] . ' | type=' . $row['type'] . ' | answers=' . $row['answers_total'] . ' | ' . strip_tags($row['question']) . "\n";
}
echo "\nTARGET QUESTION:\n";
print_r($target);
echo "\nTARGET ANSWERS:\n";
print_r($answers);
echo "\nNOTE:\n";
if (!$target) {
    echo "Question not found.\n";
} elseif (!$answers) {
    echo "У вопроса нет записей в usertest_answers — нужно заполнить ответы в админке UserTest.\n";
} elseif (!in_array((int)$target['type'], array(1,2,3,4,12), true)) {
    echo "У вопроса нестандартный тип. Новый чанк training/activity/usertest.tpl отрисует его как сортируемый список.\n";
} else {
    echo "Тип вопроса стандартный, ответы есть. Если они не видны, проблема в чанке/кэше.\n";
}
echo '</pre>';
