<?php
$prefix = $modx->getOption('table_prefix');
$testsTable = $prefix . 'usertest_tests';
$linksTable = $prefix . 'usertest_test_question_link';
$questionsTable = $prefix . 'usertest_questions';
$answersTable = $prefix . 'usertest_answers';
$resultsTable = $prefix . 'usertest_results';

$testId = isset($_GET['test_id']) ? (int)$_GET['test_id'] : 4;

$sql = "
SELECT
    t.id,
    t.name,
    t.count_questions,
    t.count_test_answer,
    COUNT(DISTINCT l.question_id) AS linked_questions,
    COALESCE(SUM(DISTINCT q.max_point), 0) AS max_by_questions
FROM `{$testsTable}` t
LEFT JOIN `{$linksTable}` l ON l.test_id = t.id
LEFT JOIN `{$questionsTable}` q ON q.id = l.question_id
WHERE t.id = :test_id
GROUP BY t.id
";
$stmt = $modx->prepare($sql);
$stmt->execute(array(':test_id' => $testId));
$test = $stmt->fetch(PDO::FETCH_ASSOC);

$qsql = "
SELECT
    l.menuindex,
    q.id AS question_id,
    q.question,
    q.type,
    q.max_point,
    COUNT(a.id) AS answers_total,
    SUM(CASE WHEN a.right = 1 THEN 1 ELSE 0 END) AS answers_right
FROM `{$linksTable}` l
LEFT JOIN `{$questionsTable}` q ON q.id = l.question_id
LEFT JOIN `{$answersTable}` a ON a.question_id = q.id
WHERE l.test_id = :test_id
GROUP BY l.id
ORDER BY l.menuindex, l.id
";
$stmt = $modx->prepare($qsql);
$stmt->execute(array(':test_id' => $testId));
$questions = $stmt->fetchAll(PDO::FETCH_ASSOC);

$rsql = "
SELECT id, test_id, user_id, date, test_point, max_point, status_id, variant_id,
       CASE WHEN `session` IS NULL OR `session` = '' THEN 0 ELSE 1 END AS has_session,
       LEFT(`session`, 200) AS session_head
FROM `{$resultsTable}`
WHERE test_id = :test_id
ORDER BY id DESC
LIMIT 20
";
$stmt = $modx->prepare($rsql);
$stmt->execute(array(':test_id' => $testId));
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo '<pre>';
echo "TEST\n";
print_r($test);
echo "\nQUESTIONS\n";
print_r($questions);
echo "\nLATEST RESULTS\n";
print_r($results);
echo '</pre>';
