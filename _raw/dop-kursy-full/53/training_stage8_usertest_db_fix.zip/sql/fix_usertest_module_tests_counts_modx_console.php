<?php
/**
 * MODX Console script.
 * Fixes UserTest module-test counters that can cause /assets/components/usertest/action.php 500
 * when count_questions/max_point stay 0 for tests with linked questions.
 */
$prefix = $modx->getOption('table_prefix');

$testsTable = $prefix . 'usertest_tests';
$linksTable = $prefix . 'usertest_test_question_link';
$questionsTable = $prefix . 'usertest_questions';
$resultsTable = $prefix . 'usertest_results';
$trainingStatusTable = $prefix . 'training_user_test_status';

function trainingStage8TableExists(modX $modx, $table) {
    $stmt = $modx->prepare('SHOW TABLES LIKE :table');
    $stmt->execute(array(':table' => $table));
    return (bool)$stmt->fetchColumn();
}

$required = array($testsTable, $linksTable, $questionsTable, $resultsTable);
foreach ($required as $table) {
    if (!trainingStage8TableExists($modx, $table)) {
        echo '<pre>FAIL: table not found: ' . htmlspecialchars($table, ENT_QUOTES, 'UTF-8') . '</pre>';
        return;
    }
}

$sql = "
    SELECT
        t.id,
        t.name,
        t.count_questions,
        t.count_test_answer,
        COUNT(l.question_id) AS linked_questions,
        COALESCE(SUM(q.max_point), 0) AS linked_max_point
    FROM `{$testsTable}` t
    LEFT JOIN `{$linksTable}` l ON l.test_id = t.id
    LEFT JOIN `{$questionsTable}` q ON q.id = l.question_id
    WHERE t.active = 1
    GROUP BY t.id
    ORDER BY t.id
";
$stmt = $modx->query($sql);
$rows = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : array();

$updatedTests = 0;
$updatedResults = 0;
$fixedSessions = 0;

$out = array();
$out[] = 'UserTest module tests DB fix';
$out[] = str_repeat('=', 80);

foreach ($rows as $row) {
    $testId = (int)$row['id'];
    $linkedQuestions = (int)$row['linked_questions'];
    $countQuestions = (int)$row['count_questions'];
    $countTestAnswer = (int)$row['count_test_answer'];
    $linkedMaxPoint = (float)$row['linked_max_point'];

    if ($linkedQuestions <= 0) {
        $out[] = 'SKIP test #' . $testId . ' — no linked questions: ' . $row['name'];
        continue;
    }

    if ($countTestAnswer <= 0) {
        $countTestAnswer = 10;
    }

    $maxPoint = $linkedMaxPoint > 0 ? $linkedMaxPoint : ($linkedQuestions * $countTestAnswer);
    if ($maxPoint <= 0) {
        $maxPoint = $linkedQuestions * 10;
    }

    $needUpdateTest = ($countQuestions !== $linkedQuestions) || ((int)$row['count_test_answer'] <= 0);

    if ($needUpdateTest) {
        $upd = $modx->prepare("UPDATE `{$testsTable}` SET `count_questions` = :count_questions, `count_test_answer` = :count_test_answer WHERE `id` = :id");
        $upd->execute(array(
            ':count_questions' => $linkedQuestions,
            ':count_test_answer' => $countTestAnswer,
            ':id' => $testId,
        ));
        $updatedTests++;
    }

    $updRes = $modx->prepare("UPDATE `{$resultsTable}` SET `max_point` = :max_point WHERE `test_id` = :test_id AND (`max_point` IS NULL OR `max_point` = 0)");
    $updRes->execute(array(
        ':max_point' => $maxPoint,
        ':test_id' => $testId,
    ));
    $updatedResults += $updRes->rowCount();

    $out[] = ($needUpdateTest ? 'FIX  ' : 'OK   ') . 'test #' . $testId . ' | questions: ' . $countQuestions . ' => ' . $linkedQuestions . ' | max_point: ' . $maxPoint . ' | ' . $row['name'];
}

// If a previous hotfix started an attempt with AjaxMode=0, restore it in saved UserTest sessions.
$sessionFix = $modx->prepare("UPDATE `{$resultsTable}` SET `session` = REPLACE(`session`, '\"AjaxMode\":0', '\"AjaxMode\":1') WHERE `session` LIKE '%\"AjaxMode\":0%'");
$sessionFix->execute();
$fixedSessions += $sessionFix->rowCount();

$sessionFix2 = $modx->prepare("UPDATE `{$resultsTable}` SET `session` = REPLACE(`session`, '\"AjaxMode\":\"0\"', '\"AjaxMode\":1') WHERE `session` LIKE '%\"AjaxMode\":\"0\"%'");
$sessionFix2->execute();
$fixedSessions += $sessionFix2->rowCount();

if (trainingStage8TableExists($modx, $trainingStatusTable)) {
    // Recalculate status rows that point to active results with max_point previously equal 0.
    $modx->exec("UPDATE `{$trainingStatusTable}` SET `updatedon` = NOW() WHERE `status` = 'in_progress'");
}

$modx->cacheManager->refresh(array(
    'db' => array(),
    'system_settings' => array(),
    'resource' => array(),
    'scripts' => array(),
));

$out[] = str_repeat('-', 80);
$out[] = 'updated tests: ' . $updatedTests;
$out[] = 'updated result max_point rows: ' . $updatedResults;
$out[] = 'fixed saved AjaxMode sessions: ' . $fixedSessions;
$out[] = 'DONE';

echo '<pre>' . htmlspecialchars(implode("\n", $out), ENT_QUOTES, 'UTF-8') . '</pre>';
