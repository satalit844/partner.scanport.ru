<?php
$name = 'TrainingUserTestCKEditorSafe';
$coreFile = MODX_CORE_PATH . 'components/training/elements/plugins/plugin.usertest_ckeditor_safe.php';
$assetsFile = MODX_ASSETS_PATH . 'components/training/js/mgr/usertest-ckeditor-safe.js';

if (!is_file($coreFile)) {
    echo '<pre>FAIL plugin file: ' . htmlspecialchars($coreFile, ENT_QUOTES, 'UTF-8') . '</pre>';
    return;
}

if (!is_file($assetsFile)) {
    echo '<pre>FAIL js file: ' . htmlspecialchars($assetsFile, ENT_QUOTES, 'UTF-8') . '</pre>';
    return;
}

$plugin = $modx->getObject('modPlugin', array('name' => $name));
if (!$plugin) {
    $plugin = $modx->newObject('modPlugin');
    $plugin->set('name', $name);
    $plugin->set('description', 'Защита CKEditor от повторной инициализации в окнах UserTest/MODX manager.');
}

$plugin->set('category', 0);
$plugin->set('static', 1);
$plugin->set('static_file', 'core/components/training/elements/plugins/plugin.usertest_ckeditor_safe.php');
$plugin->set('source', 1);
$plugin->set('disabled', 0);
$plugin->set('plugincode', "return include MODX_CORE_PATH . 'components/training/elements/plugins/plugin.usertest_ckeditor_safe.php';");
$plugin->save();

$pluginId = (int)$plugin->get('id');

$event = $modx->getObject('modPluginEvent', array(
    'pluginid' => $pluginId,
    'event' => 'OnManagerPageBeforeRender',
));

if (!$event) {
    $event = $modx->newObject('modPluginEvent');
    $event->fromArray(array(
        'pluginid' => $pluginId,
        'event' => 'OnManagerPageBeforeRender',
        'priority' => 0,
        'propertyset' => 0,
    ));
    $event->save();
}

$modx->cacheManager->refresh(array(
    'db' => array(),
    'system_settings' => array(),
    'scripts' => array(),
));

$cachePath = MODX_CORE_PATH . 'cache/';
$modx->cacheManager->deleteTree($cachePath . 'includes/', array('deleteTop' => false, 'skipDirs' => false));
$modx->cacheManager->deleteTree($cachePath . 'mgr/', array('deleteTop' => false, 'skipDirs' => false));

echo '<pre>';
echo "OK: {$name}\n";
echo "pluginId: {$pluginId}\n";
echo "event: OnManagerPageBeforeRender\n";
echo "core file: {$coreFile}\n";
echo "js file: {$assetsFile}\n";
echo "\nДальше: Ctrl+F5 в админке и заново открыть окно редактирования вопроса.\n";
echo '</pre>';
