(function (w) {
    'use strict';

    if (w.__trainingUserTestCkeditorSafe) {
        return;
    }

    w.__trainingUserTestCkeditorSafe = true;

    function destroySameInstance(ckeditor, element) {
        var id = '';

        if (typeof element === 'string') {
            id = element;
        } else if (element && element.id) {
            id = element.id;
        }

        if (!id || !ckeditor.instances || !ckeditor.instances[id]) {
            return;
        }

        try {
            ckeditor.instances[id].destroy(true);
        } catch (e) {}

        try {
            delete ckeditor.instances[id];
        } catch (e) {}
    }

    function install(ckeditor) {
        if (!ckeditor || ckeditor.__trainingSafeReplaceInstalled) {
            return;
        }

        if (typeof ckeditor.replace !== 'function') {
            w.setTimeout(function () {
                install(ckeditor);
            }, 50);
            return;
        }

        var originalReplace = ckeditor.replace;

        ckeditor.replace = function (element, config) {
            destroySameInstance(ckeditor, element);
            return originalReplace.apply(this, arguments);
        };

        ckeditor.__trainingSafeReplaceInstalled = true;
    }

    var currentCkeditor = w.CKEDITOR;

    if (currentCkeditor) {
        install(currentCkeditor);
    } else {
        try {
            Object.defineProperty(w, 'CKEDITOR', {
                configurable: true,
                enumerable: true,
                get: function () {
                    return currentCkeditor;
                },
                set: function (value) {
                    currentCkeditor = value;
                    w.setTimeout(function () {
                        install(value);
                    }, 0);
                }
            });
        } catch (e) {}
    }

    w.setInterval(function () {
        install(w.CKEDITOR);
    }, 250);
})(window);
