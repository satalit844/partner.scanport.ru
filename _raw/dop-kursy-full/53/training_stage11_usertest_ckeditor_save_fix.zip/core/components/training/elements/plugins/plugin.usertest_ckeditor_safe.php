<?php
/** @var modX $modx */

if (!$modx || !$modx->event || $modx->event->name !== 'OnManagerPageBeforeRender') {
    return;
}

if (!$modx->controller || !method_exists($modx->controller, 'addJavascript')) {
    return;
}

$assetsPath = rtrim($modx->getOption('assets_path'), '/') . '/components/training/';
$assetsUrl = rtrim($modx->getOption('assets_url'), '/') . '/components/training/';
$file = $assetsPath . 'js/mgr/usertest-ckeditor-safe.js';

if (!is_file($file)) {
    return;
}

$version = filemtime($file);
$modx->controller->addJavascript($assetsUrl . 'js/mgr/usertest-ckeditor-safe.js?v=' . $version);
