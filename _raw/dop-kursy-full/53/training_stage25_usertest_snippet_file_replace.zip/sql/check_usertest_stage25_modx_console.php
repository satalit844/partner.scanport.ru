<?php
$snippet = $modx->getObject('modSnippet', 92);
if (!$snippet) {
    $snippet = $modx->getObject('modSnippet', array('name' => 'UserTest'));
}

echo '<pre>';
echo "Check UserTest stage25\n";
echo str_repeat('=', 80) . "\n";

if (!$snippet) {
    echo "ERROR: snippet UserTest not found\n</pre>";
    return;
}

$content = $snippet->getContent();

echo "id: " . $snippet->get('id') . "\n";
echo "name: " . $snippet->get('name') . "\n";
echo "static: " . $snippet->get('static') . "\n";
echo "static_file: " . $snippet->get('static_file') . "\n";
echo "old bad hotfix removed: " . (strpos($content, 'TRAINING_USERTEST_SNIPPET92_PHP8_HOTFIX') === false ? 'YES' : 'NO') . "\n";
echo "hasPostedQuestion guard: " . (strpos($content, '&& $hasPostedQuestion') !== false ? 'YES' : 'NO') . "\n";
echo "safe time_last_step: " . (strpos($content, '!empty($_SESSION[\\'UserTest\\'][$id][\\'time_last_step\\'])') !== false ? 'YES' : 'NO') . "\n";
echo '</pre>';
