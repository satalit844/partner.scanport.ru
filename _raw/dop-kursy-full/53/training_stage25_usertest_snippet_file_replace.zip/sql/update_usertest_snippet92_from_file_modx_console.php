<?php
$snippetId = 92;
$file = MODX_CORE_PATH . 'components/usertest/elements/snippets/snippet.usertest.php';

echo '<pre>';
echo "Update UserTest snippet #{$snippetId} from file\n";
echo str_repeat('=', 80) . "\n";
echo "file: {$file}\n";

if (!is_file($file)) {
    echo "ERROR: file not found\n";
    echo '</pre>';
    return;
}

$content = file_get_contents($file);
if ($content === false || trim($content) === '') {
    echo "ERROR: file is empty or unreadable\n";
    echo '</pre>';
    return;
}

$snippet = $modx->getObject('modSnippet', $snippetId);
if (!$snippet) {
    $snippet = $modx->getObject('modSnippet', array('name' => 'UserTest'));
}

if (!$snippet) {
    echo "ERROR: snippet UserTest not found\n";
    echo '</pre>';
    return;
}

$snippetId = (int)$snippet->get('id');
$backupName = 'UserTest_backup_before_stage25_' . date('Ymd_His');

$backup = $modx->newObject('modSnippet');
$backup->fromArray(array(
    'name' => $backupName,
    'description' => 'Backup before stage25 UserTest fix',
    'snippet' => $snippet->getContent(),
    'category' => $snippet->get('category'),
    'static' => 0,
    'static_file' => '',
), '', true, true);

if ($backup->save()) {
    echo "backup: {$backupName}\n";
} else {
    echo "WARN: backup was not saved\n";
}

$snippet->setContent($content);
$snippet->set('static', 0);
$snippet->set('static_file', 'core/components/usertest/elements/snippets/snippet.usertest.php');

if (!$snippet->save()) {
    echo "ERROR: snippet was not saved\n";
    echo '</pre>';
    return;
}

if ($modx->cacheManager) {
    $modx->cacheManager->refresh(array(
        'resource' => array(),
        'scripts' => array(),
        'system_settings' => array(),
    ));
}

$coreCache = MODX_CORE_PATH . 'cache/';
$paths = array(
    $coreCache . 'includes/',
    $coreCache . 'resource/',
    $coreCache . 'scripts/',
    $coreCache . 'default/',
);

foreach ($paths as $path) {
    if (is_dir($path)) {
        $modx->cacheManager->deleteTree($path, array(
            'deleteTop' => false,
            'skipDirs' => false,
            'extensions' => array(),
        ));
        echo "CACHE CLEANED: {$path}\n";
    }
}

echo "OK\n";
echo "snippetId: {$snippetId}\n";
echo "snippet static: " . (int)$snippet->get('static') . "\n";
echo "snippet static_file: " . $snippet->get('static_file') . "\n";
echo "file mtime: " . date('Y-m-d H:i:s', filemtime($file)) . "\n";
echo '</pre>';
