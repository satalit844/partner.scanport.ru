<?php
$modx->cacheManager->refresh(array(
    'resource' => array(),
    'scripts' => array(),
    'system_settings' => array(),
));

echo '<pre>';
echo "OK: cache refreshed\n";
echo "Fixed UserTest answered-step continue: button now opens next step by GET, without POST to /assets/components/usertest/action.php.\n";
echo "Next: Ctrl+F5, reopen test with reset=1, answer question, then click Continue.\n";
echo '</pre>';
