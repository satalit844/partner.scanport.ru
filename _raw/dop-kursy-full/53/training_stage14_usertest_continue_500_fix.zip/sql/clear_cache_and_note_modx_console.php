<?php
$modx->cacheManager->refresh(array(
    'resource' => array(),
    'scripts' => array(),
    'system_settings' => array(),
));

echo '<pre>';
echo "OK: cache refresh requested\n";
echo "Replace chunk file and reload test page with Ctrl+F5.\n";
echo '</pre>';
