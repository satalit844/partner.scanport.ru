<?php
$cachePath = MODX_CORE_PATH . 'cache/';

$paths = array(
    $cachePath . 'resource/',
    $cachePath . 'scripts/',
    $cachePath . 'includes/',
    $cachePath . 'system_settings/',
    $cachePath . 'context_settings/',
    $cachePath . 'default/',
);

foreach ($paths as $path) {
    if (is_dir($path)) {
        $modx->cacheManager->deleteTree($path, array(
            'deleteTop' => false,
            'skipDirs' => false,
            'extensions' => array(),
        ));
        echo 'CLEANED: ' . $path . "<br>";
    }
}

$modx->cacheManager->refresh(array(
    'db' => array(),
    'auto_publish' => array(),
    'context_settings' => array(),
    'resource' => array(),
    'scripts' => array(),
    'system_settings' => array(),
));

echo '<pre>OK: restored stable usertest.tpl/training.css cache cleared. Open test with reset=1.</pre>';
