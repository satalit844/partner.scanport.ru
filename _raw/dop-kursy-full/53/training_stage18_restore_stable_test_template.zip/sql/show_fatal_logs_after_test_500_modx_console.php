<?php
$logs = array(
    MODX_CORE_PATH . 'cache/logs/error.log',
    dirname(MODX_BASE_PATH) . '/logs/error.log',
    MODX_BASE_PATH . 'error_log',
    MODX_BASE_PATH . 'assets/components/usertest/error_log',
);

echo '<pre>';
foreach ($logs as $log) {
    echo "\n================================================================================\n";
    echo $log . "\n";
    echo "--------------------------------------------------------------------------------\n";
    if (is_file($log)) {
        $lines = file($log);
        echo htmlspecialchars(implode('', array_slice($lines, -160)), ENT_QUOTES, 'UTF-8');
    } else {
        echo "not found\n";
    }
}
echo '</pre>';
