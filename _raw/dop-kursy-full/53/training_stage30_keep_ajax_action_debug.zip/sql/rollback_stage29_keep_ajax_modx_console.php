<?php
/**
 * Rollback only the bad idea of disabling UserTest AjaxMode.
 * Does not touch CSS, templates, UserTest snippet, or data.
 */

echo '<pre>';

echo "Stage30 rollback AjaxMode disable\n";
echo str_repeat('=', 80) . "\n";

$targets = array();
$file = MODX_CORE_PATH . 'components/training/elements/snippets/snippet.trainingActivityPage.php';
if (is_file($file)) {
    $targets['file:' . $file] = $file;
}

$replacements = 0;
foreach ($targets as $label => $path) {
    $content = file_get_contents($path);
    $old = $content;

    $content = str_replace("'AjaxMode' => 0", "'AjaxMode' => 1", $content);
    $content = str_replace('"AjaxMode" => 0', '"AjaxMode" => 1', $content);
    $content = str_replace("'AjaxMode'=>0", "'AjaxMode'=>1", $content);
    $content = str_replace('"AjaxMode"=>0', '"AjaxMode"=>1', $content);
    $content = str_replace('&AjaxMode=`0`', '&AjaxMode=`1`', $content);
    $content = str_replace('&AjaxMode=0', '&AjaxMode=1', $content);

    if ($content !== $old) {
        file_put_contents($path, $content);
        $replacements++;
        echo "UPDATED {$label}\n";
    } else {
        echo "NO CHANGE {$label}\n";
    }
}

$snippets = array('trainingActivityPage', 'TrainingActivityPage');
foreach ($snippets as $snippetName) {
    $snippet = $modx->getObject('modSnippet', array('name' => $snippetName));
    if (!$snippet) {
        continue;
    }
    $content = (string)$snippet->get('snippet');
    $old = $content;
    $content = str_replace("'AjaxMode' => 0", "'AjaxMode' => 1", $content);
    $content = str_replace('"AjaxMode" => 0', '"AjaxMode" => 1', $content);
    $content = str_replace("'AjaxMode'=>0", "'AjaxMode'=>1", $content);
    $content = str_replace('"AjaxMode"=>0', '"AjaxMode"=>1', $content);
    $content = str_replace('&AjaxMode=`0`', '&AjaxMode=`1`', $content);
    $content = str_replace('&AjaxMode=0', '&AjaxMode=1', $content);
    if ($content !== $old) {
        $snippet->set('snippet', $content);
        $snippet->save();
        $replacements++;
        echo "UPDATED DB snippet {$snippetName}\n";
    }
}

if ($modx->cacheManager) {
    $modx->cacheManager->refresh(array(
        'resource' => array(),
        'includes' => array(),
        'scripts' => array(),
        'default' => array(),
    ));
}

echo "\nAjaxMode disabled rollback replacements: {$replacements}\n";
echo "OK: Ajax stays enabled. CSS untouched.\n";
echo '</pre>';
