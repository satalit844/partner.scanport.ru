<?php
/**
 * Installs a debug wrapper around assets/components/usertest/action.php.
 * AJAX stays enabled. The original action.php is preserved and included.
 * Purpose: capture real PHP fatal/warning/Throwable for the 500.
 */

echo '<pre>';

echo "Stage30 UserTest action.php ajax debug wrapper\n";
echo str_repeat('=', 80) . "\n";

$action = MODX_BASE_PATH . 'assets/components/usertest/action.php';
$dir = dirname($action);
$original = $dir . '/action.stage30.original.php';
$log = $dir . '/action_stage30_debug.log';

if (!is_file($action)) {
    echo "ERROR: action.php not found: {$action}\n";
    echo '</pre>';
    return;
}

$current = file_get_contents($action);

if (strpos($current, 'TRAINING_STAGE30_USERTEST_ACTION_DEBUG_WRAPPER') !== false) {
    echo "Already installed: {$action}\n";
    echo "Original: {$original}\n";
    echo "Log: {$log}\n";
    echo '</pre>';
    return;
}

// If an older wrapper is detected, try to restore from common backup names before wrapping.
if (strpos($current, 'TRAINING_STAGE21') !== false || strpos($current, 'action-safe-wrapper') !== false || strpos($current, 'TRAINING_STAGE') !== false) {
    $candidates = glob($dir . '/action*.{bak,backup,original,orig,php.bak,php.backup,php.original}', GLOB_BRACE);
    $candidates[] = $dir . '/action.original.php';
    $candidates[] = $dir . '/action.php.original';
    $candidates[] = $dir . '/action.stage21.original.php';
    $candidates = array_values(array_filter(array_unique($candidates), 'is_file'));
    usort($candidates, function($a, $b) { return filemtime($b) <=> filemtime($a); });
    foreach ($candidates as $candidate) {
        $candidateContent = file_get_contents($candidate);
        if ($candidateContent && strpos($candidateContent, 'TRAINING_STAGE') === false && strpos($candidateContent, 'action-safe-wrapper') === false) {
            file_put_contents($action, $candidateContent);
            $current = $candidateContent;
            echo "Restored probable original before wrapping: {$candidate}\n";
            break;
        }
    }
}

if (!is_file($original)) {
    if (!copy($action, $original)) {
        echo "ERROR: cannot create backup: {$original}\n";
        echo '</pre>';
        return;
    }
    echo "Backup created: {$original}\n";
} else {
    echo "Backup already exists: {$original}\n";
}

$wrapper = <<<'PHPWRAP'
<?php
/* TRAINING_STAGE30_USERTEST_ACTION_DEBUG_WRAPPER */
$__stage30Log = __DIR__ . '/action_stage30_debug.log';
$__stage30Start = microtime(true);

if (!function_exists('trainingStage30Clean')) {
    function trainingStage30Clean($value, $depth = 0) {
        if ($depth > 5) {
            return '...depth...';
        }
        if (is_array($value)) {
            $out = array();
            foreach ($value as $k => $v) {
                $key = (string)$k;
                if (preg_match('/pass|password|token|secret|key/i', $key)) {
                    $out[$key] = '***';
                } else {
                    $out[$key] = trainingStage30Clean($v, $depth + 1);
                }
            }
            return $out;
        }
        if (is_object($value)) {
            return get_class($value);
        }
        if (is_string($value) && strlen($value) > 2000) {
            return substr($value, 0, 2000) . '...truncated...';
        }
        return $value;
    }
}

if (!function_exists('trainingStage30Log')) {
    function trainingStage30Log($title, $data = null) {
        global $__stage30Log;
        $line = "\n" . date('Y-m-d H:i:s') . ' ' . $title . "\n";
        if ($data !== null) {
            $line .= print_r(trainingStage30Clean($data), true) . "\n";
        }
        @file_put_contents($__stage30Log, $line, FILE_APPEND);
    }
}

trainingStage30Log('REQUEST', array(
    'method' => isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '',
    'uri' => isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '',
    'http_status_before' => function_exists('http_response_code') ? http_response_code() : null,
    'get' => isset($_GET) ? $_GET : array(),
    'post' => isset($_POST) ? $_POST : array(),
));

set_error_handler(function($severity, $message, $file, $line) {
    trainingStage30Log('PHP_ERROR', array(
        'severity' => $severity,
        'message' => $message,
        'file' => $file,
        'line' => $line,
    ));
    return false;
});

register_shutdown_function(function() use ($__stage30Start) {
    $err = error_get_last();
    if ($err) {
        trainingStage30Log('SHUTDOWN_ERROR', $err);
    }
    trainingStage30Log('END', array(
        'http_status' => function_exists('http_response_code') ? http_response_code() : null,
        'duration' => round(microtime(true) - $__stage30Start, 4),
    ));
});

try {
    require __DIR__ . '/action.stage30.original.php';
} catch (Throwable $e) {
    trainingStage30Log('THROWABLE', array(
        'class' => get_class($e),
        'message' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine(),
        'trace' => $e->getTraceAsString(),
    ));
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
    }
    echo json_encode(array(
        'success' => false,
        'message' => 'UserTest action error logged',
    ), JSON_UNESCAPED_UNICODE);
}
PHPWRAP;

file_put_contents($action, $wrapper);
@chmod($action, 0644);

if (!is_file($log)) {
    @file_put_contents($log, "");
    @chmod($log, 0664);
}

echo "Wrapper installed: {$action}\n";
echo "Original: {$original}\n";
echo "Log: {$log}\n";
echo "\nAJAX remains enabled. Reproduce the 500, then run show_usertest_action_stage30_debug_log_modx_console.php\n";
echo '</pre>';
