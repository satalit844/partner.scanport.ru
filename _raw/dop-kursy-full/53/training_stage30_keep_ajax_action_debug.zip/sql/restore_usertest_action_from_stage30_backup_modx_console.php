<?php

echo '<pre>';

echo "Restore UserTest action.php from stage30 backup\n";
echo str_repeat('=', 80) . "\n";

$action = MODX_BASE_PATH . 'assets/components/usertest/action.php';
$original = MODX_BASE_PATH . 'assets/components/usertest/action.stage30.original.php';

if (!is_file($original)) {
    echo "ERROR: backup not found: {$original}\n";
    echo '</pre>';
    return;
}

if (!copy($original, $action)) {
    echo "ERROR: cannot restore {$action}\n";
    echo '</pre>';
    return;
}

@chmod($action, 0644);
echo "OK restored\n";
echo "action: {$action}\n";
echo '</pre>';
