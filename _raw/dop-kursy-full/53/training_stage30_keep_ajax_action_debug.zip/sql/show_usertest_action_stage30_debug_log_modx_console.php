<?php

echo '<pre>';

echo "Stage30 UserTest action.php debug log\n";
echo str_repeat('=', 80) . "\n";

$log = MODX_BASE_PATH . 'assets/components/usertest/action_stage30_debug.log';
$action = MODX_BASE_PATH . 'assets/components/usertest/action.php';
$original = MODX_BASE_PATH . 'assets/components/usertest/action.stage30.original.php';

echo "action: {$action} " . (is_file($action) ? 'OK' : 'NOT FOUND') . "\n";
echo "original: {$original} " . (is_file($original) ? 'OK' : 'NOT FOUND') . "\n";
echo "log: {$log} " . (is_file($log) ? 'OK' : 'NOT FOUND') . "\n";

if (is_file($action)) {
    $content = file_get_contents($action);
    echo "wrapper installed: " . (strpos($content, 'TRAINING_STAGE30_USERTEST_ACTION_DEBUG_WRAPPER') !== false ? 'YES' : 'NO') . "\n";
}

echo str_repeat('-', 80) . "\n";

if (!is_file($log)) {
    echo "Log not found. Reproduce 500 after installing wrapper.\n";
    echo '</pre>';
    return;
}

$lines = file($log);
echo htmlspecialchars(implode('', array_slice($lines, -260)), ENT_QUOTES, 'UTF-8');
echo '</pre>';
