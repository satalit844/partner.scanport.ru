<?php
/**
 * Hotfix UserTest snippet #92 for PHP 8.x warnings that break test page.
 * Does not touch CSS.
 */

$snippetId = 92;
$markerStart = '/* TRAINING_USERTEST_SNIPPET92_PHP8_HOTFIX_START */';
$markerEnd   = '/* TRAINING_USERTEST_SNIPPET92_PHP8_HOTFIX_END */';

$snippet = $modx->getObject('modSnippet', $snippetId);

echo '<pre>';
echo "UserTest snippet #{$snippetId} PHP8 hotfix\n";
echo str_repeat('=', 80) . "\n";

if (!$snippet) {
    echo "ERROR: modSnippet #{$snippetId} not found\n</pre>";
    return;
}

echo "snippet id: " . $snippet->get('id') . "\n";
echo "snippet name: " . $snippet->get('name') . "\n";
echo "static: " . (int)$snippet->get('static') . "\n";
echo "static_file: " . $snippet->get('static_file') . "\n";

$corePath = $modx->getOption('core_path');
$basePath = $modx->getOption('base_path');

$targetFile = '';
$isStatic = (int)$snippet->get('static') === 1;
$staticFile = trim((string)$snippet->get('static_file'));

if ($isStatic && $staticFile !== '') {
    $candidates = array();

    if (strpos($staticFile, '[[++core_path]]') !== false) {
        $candidates[] = str_replace('[[++core_path]]', $corePath, $staticFile);
    }
    if (strpos($staticFile, '[[++base_path]]') !== false) {
        $candidates[] = str_replace('[[++base_path]]', $basePath, $staticFile);
    }

    $candidates[] = $staticFile;
    $candidates[] = $basePath . ltrim($staticFile, '/');
    $candidates[] = $corePath . ltrim($staticFile, '/');

    foreach ($candidates as $candidate) {
        $candidate = str_replace('//', '/', $candidate);
        if (is_file($candidate) && is_writable($candidate)) {
            $targetFile = $candidate;
            break;
        }
    }
}

$hotfixCode = <<<'PHP'

/* TRAINING_USERTEST_SNIPPET92_PHP8_HOTFIX_START */
if (!isset($Result) || !is_array($Result)) {
    $Result = array();
}
if (!isset($Result['time_last_step'])) {
    $Result['time_last_step'] = 0;
}
if (!isset($Result['time_start'])) {
    $Result['time_start'] = time();
}
if (!isset($Result['time_end'])) {
    $Result['time_end'] = 0;
}
if (!isset($Result['id'])) {
    $Result['id'] = 0;
}

$__trainingUserTestPrevErrorHandler = set_error_handler(function ($severity, $message, $file, $line) use (&$__trainingUserTestPrevErrorHandler) {
    $msg = (string)$message;

    if (
        strpos($msg, 'Undefined variable $Result') !== false ||
        strpos($msg, 'Undefined array key "time_last_step"') !== false ||
        strpos($msg, "Undefined array key 'time_last_step'") !== false ||
        strpos($msg, 'Trying to access array offset on null') !== false
    ) {
        return true;
    }

    if (is_callable($__trainingUserTestPrevErrorHandler)) {
        return call_user_func($__trainingUserTestPrevErrorHandler, $severity, $message, $file, $line);
    }

    return false;
});
register_shutdown_function(function () {
    restore_error_handler();
});
/* TRAINING_USERTEST_SNIPPET92_PHP8_HOTFIX_END */

PHP;

$backupDir = $corePath . 'components/training/backups/';
if (!is_dir($backupDir)) {
    @mkdir($backupDir, 0755, true);
}

$stamp = date('Ymd_His');

if ($targetFile !== '') {
    $source = file_get_contents($targetFile);

    if ($source === false) {
        echo "ERROR: cannot read target file: {$targetFile}\n</pre>";
        return;
    }

    $backup = $backupDir . 'snippet92_' . basename($targetFile) . '_' . $stamp . '.bak.php';
    file_put_contents($backup, $source);

    $source = preg_replace(
        '#' . preg_quote($markerStart, '#') . '.*?' . preg_quote($markerEnd, '#') . '\s*#s',
        '',
        $source
    );

    if (strpos($source, '<?php') !== false) {
        $source = preg_replace('/<\?php\s*/', "<?php\n" . $hotfixCode . "\n", $source, 1);
    } else {
        $source = $hotfixCode . "\n" . $source;
    }

    file_put_contents($targetFile, $source);

    echo "patched static file: {$targetFile}\n";
    echo "backup: {$backup}\n";
} else {
    $content = (string)$snippet->get('snippet');
    $backup = $backupDir . 'snippet92_db_' . $stamp . '.bak.php';
    file_put_contents($backup, $content);

    $content = preg_replace(
        '#' . preg_quote($markerStart, '#') . '.*?' . preg_quote($markerEnd, '#') . '\s*#s',
        '',
        $content
    );

    if (strpos($content, '<?php') !== false) {
        $content = preg_replace('/<\?php\s*/', "<?php\n" . $hotfixCode . "\n", $content, 1);
    } else {
        $content = $hotfixCode . "\n" . $content;
    }

    $snippet->set('snippet', $content);
    $snippet->save();

    echo "patched snippet content in DB\n";
    echo "backup: {$backup}\n";
}

$cacheTargets = array(
    'resource' => array(),
    'includes' => array(),
    'scripts' => array(),
    'system_settings' => array(),
);
$modx->cacheManager->refresh($cacheTargets);

$includeCache = $corePath . 'cache/includes/elements/modsnippet/' . $snippetId . '.include.cache.php';
if (is_file($includeCache)) {
    @unlink($includeCache);
    echo "removed include cache: {$includeCache}\n";
}

echo "OK\n";
echo "Next: open test with &reset=1\n";
echo '</pre>';
