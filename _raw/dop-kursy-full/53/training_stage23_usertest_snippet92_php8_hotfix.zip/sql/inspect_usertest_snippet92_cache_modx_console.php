<?php
$snippetId = 92;
$corePath = $modx->getOption('core_path');
$snippet = $modx->getObject('modSnippet', $snippetId);
$cacheFile = $corePath . 'cache/includes/elements/modsnippet/' . $snippetId . '.include.cache.php';

echo '<pre>';
echo "Inspect snippet {$snippetId}\n";
echo str_repeat('=', 80) . "\n";

if ($snippet) {
    echo "name: " . $snippet->get('name') . "\n";
    echo "static: " . (int)$snippet->get('static') . "\n";
    echo "static_file: " . $snippet->get('static_file') . "\n";
}

echo "\ncache file: {$cacheFile}\n";
if (is_file($cacheFile)) {
    $lines = file($cacheFile);
    foreach (array(1537, 1702, 1770) as $center) {
        echo "\n--- around line {$center} ---\n";
        $start = max(1, $center - 8);
        $end = min(count($lines), $center + 8);
        for ($i = $start; $i <= $end; $i++) {
            echo str_pad($i, 5, ' ', STR_PAD_LEFT) . ': ' . htmlspecialchars($lines[$i - 1], ENT_QUOTES, 'UTF-8');
        }
    }
} else {
    echo "cache not found\n";
}
echo '</pre>';
