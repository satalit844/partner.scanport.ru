<?php
/**
 * Rollback helper: shows available snippet #92 backups.
 * Manual rollback: copy the needed backup content back to the static file or snippet content.
 */

$snippetId = 92;
$snippet = $modx->getObject('modSnippet', $snippetId);
$corePath = $modx->getOption('core_path');
$backupDir = $corePath . 'components/training/backups/';

echo '<pre>';
echo "Snippet #{$snippetId} rollback info\n";
echo str_repeat('=', 80) . "\n";

if ($snippet) {
    echo "snippet name: " . $snippet->get('name') . "\n";
    echo "static: " . (int)$snippet->get('static') . "\n";
    echo "static_file: " . $snippet->get('static_file') . "\n";
}

echo "\nBackups:\n";
if (is_dir($backupDir)) {
    $files = glob($backupDir . 'snippet92_*.bak.php');
    rsort($files);
    foreach ($files as $file) {
        echo $file . " | " . date('Y-m-d H:i:s', filemtime($file)) . "\n";
    }
} else {
    echo "backup dir not found\n";
}

echo '</pre>';
