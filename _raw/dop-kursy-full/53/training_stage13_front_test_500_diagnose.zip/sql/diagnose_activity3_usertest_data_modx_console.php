<?php
$prefix = $modx->getOption('table_prefix');
$activityId = 3;

echo '<pre>';
echo "Diagnose training activity/UserTest data\n";
echo str_repeat('=', 80) . "\n";
echo "activityId: {$activityId}\n\n";

function tp_table_exists(modX $modx, $table) {
    $stmt = $modx->prepare('SHOW TABLES LIKE :t');
    $stmt->execute(array(':t' => $table));
    return (bool)$stmt->fetchColumn();
}
function tp_cols(modX $modx, $table) {
    $stmt = $modx->query('SHOW COLUMNS FROM `' . str_replace('`', '', $table) . '`');
    $rows = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : array();
    $cols = array();
    foreach ($rows as $r) { $cols[] = $r['Field']; }
    return $cols;
}
function tp_fetch_all(modX $modx, $sql, $params = array()) {
    $stmt = $modx->prepare($sql);
    if (!$stmt || !$stmt->execute($params)) { return array(); }
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$linksTable = $prefix . 'training_test_links';
$link = null;
if (tp_table_exists($modx, $linksTable)) {
    $rows = tp_fetch_all($modx, "SELECT * FROM `{$linksTable}` WHERE `id` = :id", array(':id' => $activityId));
    $link = $rows ? $rows[0] : null;
}

echo "training_test_links row:\n";
print_r($link);
$testId = $link && isset($link['usertest_test_id']) ? (int)$link['usertest_test_id'] : 0;
echo "\nresolved usertest_test_id: {$testId}\n\n";

echo "UserTest-like tables:\n";
$tables = tp_fetch_all($modx, "SHOW TABLES LIKE :like", array(':like' => $prefix . '%usertest%'));
foreach ($tables as $row) {
    $table = array_values($row)[0];
    $count = 0;
    try { $count = (int)$modx->query("SELECT COUNT(*) FROM `{$table}`")->fetchColumn(); } catch (Exception $e) {}
    echo "- {$table} ({$count})\n";
}
echo "\n";

$candidateTests = array($prefix.'usertest_tests', $prefix.'user_test_tests', $prefix.'UserTestTests');
foreach ($candidateTests as $table) {
    if (!tp_table_exists($modx, $table)) { continue; }
    echo "TEST TABLE {$table}\n";
    $cols = tp_cols($modx, $table);
    echo 'columns: ' . implode(', ', $cols) . "\n";
    if ($testId > 0 && in_array('id', $cols, true)) {
        $rows = tp_fetch_all($modx, "SELECT * FROM `{$table}` WHERE `id` = :id", array(':id' => $testId));
        print_r($rows);
    }
    echo "\n";
}

foreach ($tables as $row) {
    $table = array_values($row)[0];
    $cols = tp_cols($modx, $table);
    $hasTest = in_array('test_id', $cols, true) || in_array('id_test', $cols, true) || in_array('test', $cols, true);
    if (!$hasTest || $testId <= 0) { continue; }

    $field = in_array('test_id', $cols, true) ? 'test_id' : (in_array('id_test', $cols, true) ? 'id_test' : 'test');
    echo "ROWS BY {$field} in {$table}\n";
    echo 'columns: ' . implode(', ', $cols) . "\n";
    $rows2 = tp_fetch_all($modx, "SELECT * FROM `{$table}` WHERE `{$field}` = :test_id LIMIT 30", array(':test_id' => $testId));
    print_r($rows2);
    echo "\n";
}

$statusTable = $prefix . 'training_user_test_status';
if (tp_table_exists($modx, $statusTable) && $testId > 0 && $link) {
    echo "training_user_test_status for this test/module:\n";
    $rows = tp_fetch_all($modx, "SELECT * FROM `{$statusTable}` WHERE `usertest_test_id` = :test_id AND `module_id` = :module_id ORDER BY `updatedon` DESC LIMIT 50", array(':test_id' => $testId, ':module_id' => (int)$link['module_id']));
    print_r($rows);
}

echo '</pre>';
