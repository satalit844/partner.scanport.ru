<?php
$log = MODX_CORE_PATH . 'cache/logs/error.log';
$needle = array(
    'UserTest',
    'usertest',
    'trainingActivityPage',
    'snippet.trainingActivityPage',
    'action.php',
    'Fatal error',
    'PHP Fatal',
    'Uncaught',
);

echo '<pre>';
echo "Training frontend 500 latest log\n";
echo str_repeat('=', 80) . "\n";

if (!is_file($log)) {
    echo "error.log not found: {$log}\n";
    echo '</pre>';
    return;
}

$lines = file($log, FILE_IGNORE_NEW_LINES);
$last = array_slice($lines, -300);
$out = array();
foreach ($last as $line) {
    $matched = false;
    foreach ($needle as $n) {
        if (stripos($line, $n) !== false) {
            $matched = true;
            break;
        }
    }
    if ($matched) {
        $out[] = $line;
    }
}

if (!$out) {
    $out = array_slice($last, -120);
    echo "No direct UserTest/training matches found, showing last 120 lines.\n";
    echo str_repeat('-', 80) . "\n";
} else {
    echo "Matched lines from last 300 log lines.\n";
    echo str_repeat('-', 80) . "\n";
}

echo htmlspecialchars(implode("\n", $out), ENT_QUOTES, 'UTF-8');
echo "\n" . str_repeat('=', 80) . "\n";
echo "Now reproduce 500 once, then run this script again if needed.\n";
echo '</pre>';
