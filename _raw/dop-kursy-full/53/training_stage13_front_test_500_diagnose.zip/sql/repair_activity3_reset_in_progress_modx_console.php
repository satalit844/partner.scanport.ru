<?php
$prefix = $modx->getOption('table_prefix');
$activityId = 3;

echo '<pre>';
echo "Soft reset in-progress attempts for activity {$activityId}\n";
echo str_repeat('=', 80) . "\n";

$linksTable = $prefix . 'training_test_links';
$statusTable = $prefix . 'training_user_test_status';

$stmt = $modx->prepare("SELECT * FROM `{$linksTable}` WHERE `id` = :id");
$stmt->execute(array(':id' => $activityId));
$link = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$link) {
    echo "ERROR: training_test_links id={$activityId} not found\n</pre>";
    return;
}

$testId = (int)$link['usertest_test_id'];
$moduleId = (int)$link['module_id'];
$courseId = (int)$link['course_id'];

echo "courseId={$courseId}, moduleId={$moduleId}, testId={$testId}\n\n";

$tables = array();
$stmt = $modx->prepare("SHOW TABLES LIKE :like");
$stmt->execute(array(':like' => $prefix . '%usertest%result%'));
foreach ($stmt->fetchAll(PDO::FETCH_NUM) as $row) { $tables[] = $row[0]; }
$stmt = $modx->prepare("SHOW TABLES LIKE :like");
$stmt->execute(array(':like' => $prefix . '%UserTest%Result%'));
foreach ($stmt->fetchAll(PDO::FETCH_NUM) as $row) { $tables[] = $row[0]; }
$tables = array_unique($tables);

foreach ($tables as $table) {
    $colsStmt = $modx->query("SHOW COLUMNS FROM `{$table}`");
    $colsRows = $colsStmt ? $colsStmt->fetchAll(PDO::FETCH_ASSOC) : array();
    $cols = array();
    foreach ($colsRows as $c) { $cols[] = $c['Field']; }
    if (!in_array('test_id', $cols, true) || !in_array('status_id', $cols, true)) { continue; }

    echo "Candidate results table: {$table}\n";
    $before = (int)$modx->query("SELECT COUNT(*) FROM `{$table}` WHERE `test_id` = {$testId} AND `status_id` = 1")->fetchColumn();
    echo "active before: {$before}\n";

    $backup = $prefix . 'training_usertest_activity3_results_backup_' . date('Ymd_His');
    $modx->exec("CREATE TABLE `{$backup}` AS SELECT * FROM `{$table}` WHERE `test_id` = {$testId} AND `status_id` = 1");
    echo "backup: {$backup}\n";

    $modx->exec("UPDATE `{$table}` SET `status_id` = 0 WHERE `test_id` = {$testId} AND `status_id` = 1");
    $after = (int)$modx->query("SELECT COUNT(*) FROM `{$table}` WHERE `test_id` = {$testId} AND `status_id` = 1")->fetchColumn();
    echo "active after: {$after}\n\n";
}

if ($modx->query("SHOW TABLES LIKE '{$statusTable}'")->fetchColumn()) {
    $stmt = $modx->prepare("UPDATE `{$statusTable}` SET `last_result_id` = 0, `status` = 'not_started', `updatedon` = NOW() WHERE `course_id` = :course_id AND `module_id` = :module_id AND `usertest_test_id` = :test_id AND `status` = 'in_progress'");
    $stmt->execute(array(':course_id' => $courseId, ':module_id' => $moduleId, ':test_id' => $testId));
    echo "training_user_test_status reset rows: " . $stmt->rowCount() . "\n";
}

$modx->cacheManager->refresh(array('resource' => array(), 'scripts' => array(), 'system_settings' => array()));
echo "\nOK. Reopen the course page and start the test again.\n";
echo '</pre>';
