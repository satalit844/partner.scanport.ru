<?php
$files = array(
    MODX_BASE_PATH . 'assets/components/usertest/action.training-debug.log',
    MODX_CORE_PATH . 'cache/logs/error.log',
);

print '<pre>';
foreach ($files as $file) {
    print "\n" . str_repeat('=', 80) . "\n";
    print $file . "\n";
    print str_repeat('-', 80) . "\n";
    if (!is_file($file)) {
        print "not found\n";
        continue;
    }
    $lines = file($file);
    print htmlspecialchars(implode('', array_slice($lines, -160)), ENT_QUOTES, 'UTF-8');
}
print '</pre>';
