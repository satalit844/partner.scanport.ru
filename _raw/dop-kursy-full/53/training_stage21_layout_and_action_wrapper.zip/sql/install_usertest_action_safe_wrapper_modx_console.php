<?php
$actionFile = MODX_BASE_PATH . 'assets/components/usertest/action.php';
$originalFile = MODX_BASE_PATH . 'assets/components/usertest/action.training-original.php';
$debugFile = MODX_BASE_PATH . 'assets/components/usertest/action.training-debug.log';
$stubFile = MODX_BASE_PATH . 'assets/components/training/usertest/action-safe-wrapper.stub.php';

print '<pre>';
print "Install UserTest action safe wrapper\n";
print str_repeat('=', 80) . "\n";

if (!is_file($actionFile)) {
    print "ERROR: action.php not found: {$actionFile}\n</pre>";
    return;
}
if (!is_file($stubFile)) {
    print "ERROR: wrapper stub not found: {$stubFile}\n</pre>";
    return;
}

$current = (string)file_get_contents($actionFile);
if (strpos($current, 'TRAINING_USERTEST_ACTION_SAFE_WRAPPER') === false) {
    if (!is_file($originalFile)) {
        copy($actionFile, $originalFile);
        print "BACKUP CREATED: {$originalFile}\n";
    } else {
        print "BACKUP EXISTS: {$originalFile}\n";
    }
} else {
    print "WRAPPER ALREADY INSTALLED, updating wrapper only\n";
    if (!is_file($originalFile)) {
        print "ERROR: wrapper installed but original file missing: {$originalFile}\n</pre>";
        return;
    }
}

$stub = (string)file_get_contents($stubFile);
file_put_contents($actionFile, $stub);
@chmod($actionFile, 0644);
@touch($debugFile);
@chmod($debugFile, 0664);

$modx->cacheManager->refresh(array(
    'resource' => array(),
    'scripts' => array(),
));

print "OK: wrapper installed\n";
print "action: {$actionFile}\n";
print "original: {$originalFile}\n";
print "debug: {$debugFile}\n";
print "\nNext: Ctrl+F5, reproduce answer/continue once. If error remains, open debug log script.\n";
print '</pre>';
