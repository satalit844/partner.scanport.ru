<?php
$cachePath = MODX_CORE_PATH . 'cache/';
$paths = array(
    $cachePath . 'resource/',
    $cachePath . 'includes/',
    $cachePath . 'scripts/',
    $cachePath . 'default/',
);
foreach ($paths as $path) {
    if (is_dir($path)) {
        $modx->cacheManager->deleteTree($path, array('deleteTop' => false, 'skipDirs' => false));
        print "CACHE CLEANED: {$path}<br>";
    }
}
$modx->cacheManager->refresh(array(
    'resource' => array(),
    'scripts' => array(),
    'system_settings' => array(),
));
print '<pre>OK: training test cache cleared</pre>';
