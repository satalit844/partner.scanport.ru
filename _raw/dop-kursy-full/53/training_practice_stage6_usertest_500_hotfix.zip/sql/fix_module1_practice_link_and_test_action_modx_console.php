<?php
$prefix = $modx->getOption('table_prefix');

function tpFixTable(modX $modx, $name) {
    $prefix = (string)$modx->getOption('table_prefix');
    $candidates = array($prefix . $name, $prefix . '_' . $name, 'modx_' . $name);
    foreach ($candidates as $table) {
        $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
        if ($table === '') { continue; }
        $stmt = $modx->query('SHOW TABLES LIKE ' . $modx->quote($table));
        if ($stmt && $stmt->fetchColumn()) { return $table; }
    }
    return preg_replace('/[^a-zA-Z0-9_]/', '', $prefix . $name);
}

$practices = tpFixTable($modx, 'training_practices');
$links = tpFixTable($modx, 'training_test_links');
$settings = tpFixTable($modx, 'system_settings');

// 1. Fix UserTest mode for training activity page: disable UserTest action.php AJAX by default.
$key = 'training_activity_ajax_mode';
$stmt = $modx->prepare("SELECT COUNT(*) FROM `{$settings}` WHERE `key` = :key");
$stmt->execute(array(':key' => $key));
if ((int)$stmt->fetchColumn() > 0) {
    $stmt = $modx->prepare("UPDATE `{$settings}` SET `value` = '0', `xtype` = 'combo-boolean', `namespace` = 'training', `area` = 'training' WHERE `key` = :key");
    $stmt->execute(array(':key' => $key));
} else {
    $stmt = $modx->prepare("INSERT INTO `{$settings}` (`key`, `value`, `xtype`, `namespace`, `area`) VALUES (:key, '0', 'combo-boolean', 'training', 'training')");
    $stmt->execute(array(':key' => $key));
}

// 2. Guarantee practice exists for module 1 and the module link points to real training_practices.id.
$stmt = $modx->prepare("SELECT `id` FROM `{$practices}` WHERE `course_id` = 1 AND `module_id` = 1 AND `active` = 1 ORDER BY `rank`, `id` LIMIT 1");
$stmt->execute();
$practiceId = (int)$stmt->fetchColumn();

if ($practiceId <= 0) {
    $stmt = $modx->prepare("INSERT INTO `{$practices}` (`course_id`, `module_id`, `title`, `description`, `template_file`, `template_file_name`, `image`, `deadline_days`, `allowed_extensions`, `max_file_size`, `active`, `rank`, `createdon`, `editedon`) VALUES (1, 1, 'Практическое задание 1 к Модулю 1', 'Загрузите выполненное задание PDF, DOCX или XLSX и отправьте сообщение ментору.', '', '', 'theme/images/training/tests/logo-scanport.svg', 0, 'pdf,doc,docx,xls,xlsx,png,jpg,jpeg,zip', 52428800, 1, 2, NOW(), NOW())");
    $stmt->execute();
    $practiceId = (int)$modx->lastInsertId();
}

$stmt = $modx->prepare("SELECT `id` FROM `{$links}` WHERE `course_id` = 1 AND `module_id` = 1 AND `link_type` = 'practice' ORDER BY `sort_order`, `id` LIMIT 1");
$stmt->execute();
$linkId = (int)$stmt->fetchColumn();

if ($linkId > 0) {
    $stmt = $modx->prepare("UPDATE `{$links}` SET `usertest_test_id` = :practice_id, `sort_order` = 2, `is_required` = 1, `max_attempts` = 5, `min_pass_percent` = 0, `block_next_module_until_passed` = 1 WHERE `id` = :id");
    $stmt->execute(array(':practice_id' => $practiceId, ':id' => $linkId));
} else {
    $stmt = $modx->prepare("INSERT INTO `{$links}` (`course_id`, `module_id`, `usertest_test_id`, `link_type`, `sort_order`, `is_required`, `max_attempts`, `min_pass_percent`, `block_next_module_until_passed`, `createdon`) VALUES (1, 1, :practice_id, 'practice', 2, 1, 5, 0, 1, NOW())");
    $stmt->execute(array(':practice_id' => $practiceId));
    $linkId = (int)$modx->lastInsertId();
}

$modx->cacheManager->refresh(array(
    'db' => array(),
    'system_settings' => array(),
    'scripts' => array(),
));

echo '<pre>';
echo "OK: UserTest AjaxMode disabled for training activity\n";
echo "practices table: {$practices}\n";
echo "links table: {$links}\n";
echo "module 1 practice_id: {$practiceId}\n";
echo "module 1 practice link_id: {$linkId}\n";
echo "practice URL: /obuchenie/obuchenie-glavnaya/stranitsa-prakticheskoe-zadanie/?activity={$practiceId}\n";
echo '</pre>';
