<?php
$log = MODX_CORE_PATH . 'cache/logs/error.log';
echo '<pre>';
if (!is_file($log)) {
    echo 'error.log not found';
} else {
    $lines = file($log);
    echo htmlspecialchars(implode('', array_slice($lines, -120)), ENT_QUOTES, 'UTF-8');
}
echo '</pre>';
