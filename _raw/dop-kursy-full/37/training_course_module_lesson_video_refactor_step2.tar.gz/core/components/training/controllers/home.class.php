<?php

class TrainingHomeManagerController extends modExtraManagerController
{
    /** @var Training $training */
    public $training;

    public function initialize()
    {
        $corePath = $this->modx->getOption(
            'training_core_path',
            null,
            $this->modx->getOption('core_path') . 'components/training/'
        );

        $this->training = $this->modx->getService(
            'training',
            'Training',
            $corePath . 'model/training/'
        );

        parent::initialize();
    }

    public function getLanguageTopics()
    {
        return ['training:default'];
    }

    public function checkPermissions()
    {
        return true;
    }

    public function getPageTitle()
    {
        $lessonId = (int)$this->modx->getOption('lesson_id', $_GET, 0);
        $moduleId = (int)$this->modx->getOption('module_id', $_GET, 0);
        $courseId = (int)$this->modx->getOption('course_id', $_GET, 0);

        if ($lessonId > 0) {
            return 'Урок';
        }
        if ($moduleId > 0) {
            return 'Модуль';
        }
        if ($courseId > 0) {
            return 'Курс';
        }

        return 'Курсы';
    }

    public function loadCustomCssJs()
    {
        $assetsUrl = $this->training->config['assetsUrl'] . 'js/mgr/';
        $courseId = (int)$this->modx->getOption('course_id', $_GET, 0);
        $moduleId = (int)$this->modx->getOption('module_id', $_GET, 0);
        $lessonId = (int)$this->modx->getOption('lesson_id', $_GET, 0);
        $xtype = 'training-page-home';

        if ($lessonId > 0) {
            $xtype = 'training-page-lesson';
        } elseif ($moduleId > 0) {
            $xtype = 'training-page-module';
        } elseif ($courseId > 0) {
            $xtype = 'training-page-course';
        }

        $this->addJavascript($assetsUrl . 'training.js');
        $this->addJavascript($assetsUrl . 'widgets/course.grid.js');
        $this->addJavascript($assetsUrl . 'widgets/home.panel.js');
        $this->addJavascript($assetsUrl . 'widgets/course.panel.js');
        $this->addJavascript($assetsUrl . 'widgets/course.tabs.js');
        $this->addJavascript($assetsUrl . 'widgets/module.grid.js');
        $this->addJavascript($assetsUrl . 'widgets/course.access.grid.js');
        $this->addJavascript($assetsUrl . 'widgets/manager.link.grid.js');
        $this->addJavascript($assetsUrl . 'widgets/module.panel.js');
        $this->addJavascript($assetsUrl . 'widgets/module.tabs.js');
        $this->addJavascript($assetsUrl . 'widgets/module.lesson.grid.js');
        $this->addJavascript($assetsUrl . 'widgets/module.testlink.grid.js');
        $this->addJavascript($assetsUrl . 'widgets/lesson.panel.js');
        $this->addJavascript($assetsUrl . 'widgets/lesson.tabs.js');
        $this->addJavascript($assetsUrl . 'widgets/lesson.video.grid.js');
        $this->addJavascript($assetsUrl . 'widgets/module.video.grid.js');
        $this->addJavascript($assetsUrl . 'widgets/module.slide.grid.js');

        $this->addJavascript($assetsUrl . 'sections/home.js');
        $this->addJavascript($assetsUrl . 'sections/course.js');
        $this->addJavascript($assetsUrl . 'sections/module.js');
        $this->addJavascript($assetsUrl . 'sections/lesson.js');

        $this->addHtml(
            '<script type="text/javascript">'
            . 'Ext.onReady(function() {'
            . 'Training.config = ' . $this->modx->toJSON([
                'connector_url' => $this->training->config['connectorUrl'],
                'course_id' => $courseId,
                'module_id' => $moduleId,
                'lesson_id' => $lessonId,
                'courses_parent_id' => (int)$this->modx->getOption('training_courses_parent_id', null, 150),
                'media_source' => (int)$this->modx->getOption('training.training_media_source', null, 3),
            ]) . ';'
            . 'MODx.load({xtype:"' . $xtype . '"});'
            . '});'
            . '</script>'
        );
    }

    public function getTemplateFile()
    {
        return $this->training->config['templatesPath'] . 'home.tpl';
    }
}
