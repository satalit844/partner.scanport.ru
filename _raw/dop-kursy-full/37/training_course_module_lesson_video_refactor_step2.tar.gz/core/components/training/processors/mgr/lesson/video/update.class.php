<?php

require_once dirname(__DIR__) . '/_video_helper.php';

class TrainingLessonVideoUpdateProcessor extends modProcessor
{
    public function checkPermissions(){return true;}

    protected function boolValue($value){return in_array((string)$value,['1','true','yes','on'],true)||$value===true||$value===1?1:0;}

    public function process()
    {
        $id = (int)$this->getProperty('id');
        $row = TrainingLessonVideoHelper::fetchVideo($this->modx, $id);
        if (!$row) { return $this->failure('Видео урока не найдено'); }
        $lesson = TrainingLessonVideoHelper::getLesson($this->modx, (int)$row['lesson_id']);
        if (!$lesson) { return $this->failure('Урок не найден'); }

        $title = trim((string)$this->getProperty('title'));
        if ($title === '') { return $this->failure('Укажи название'); }
        $sort = (int)$this->getProperty('sort_order');
        if ($sort <= 0) { $sort = 1; }

        $table = TrainingLessonVideoHelper::lessonVideosTable($this->modx);
        $sql = 'UPDATE `' . $table . '` SET `title`=:title, `description`=:description, `sort_order`=:sort_order, `source_video`=:source_video, `is_default`=:is_default, `is_active`=:is_active, `updatedon`=:updatedon WHERE `id`=:id';
        $sourceVideo = trim((string)$this->getProperty('source_video', $row['source_video']));
        $stmt = $this->modx->prepare($sql);
        if (!$stmt || !$stmt->execute([
            ':title' => $title,
            ':description' => trim((string)$this->getProperty('description', $row['description'])),
            ':sort_order' => $sort,
            ':source_video' => $sourceVideo,
            ':is_default' => $this->boolValue($this->getProperty('is_default', $row['is_default'])),
            ':is_active' => $this->boolValue($this->getProperty('is_active', $row['is_active'])),
            ':updatedon' => date('Y-m-d H:i:s'),
            ':id' => $id,
        ])) {
            return $this->failure('Не удалось сохранить видео урока');
        }

        if ($this->boolValue($this->getProperty('is_default', $row['is_default']))) {
            TrainingLessonVideoHelper::clearDefaultLessonVideo($this->modx, (int)$row['lesson_id'], $id);
        }

        TrainingLessonVideoHelper::recalcLesson($this->modx, $lesson);
        return $this->success('Видео урока сохранено');
    }
}
return 'TrainingLessonVideoUpdateProcessor';
