<?php

require_once dirname(__DIR__) . '/_video_helper.php';

class TrainingLessonVideoCreateProcessor extends modProcessor
{
    public function checkPermissions(){return true;}

    protected function boolValue($value){return in_array((string)$value,['1','true','yes','on'],true)||$value===true||$value===1?1:0;}

    public function process()
    {
        $lessonId = (int)$this->getProperty('lesson_id');
        $title = trim((string)$this->getProperty('title'));
        if ($lessonId <= 0) { return $this->failure('Не указан урок'); }
        $lesson = TrainingLessonVideoHelper::getLesson($this->modx, $lessonId);
        if (!$lesson) { return $this->failure('Урок не найден'); }

        if ($title === '') { $title = 'Новое видео'; }
        $sort = (int)$this->getProperty('sort_order');
        if ($sort <= 0) { $sort = TrainingLessonVideoHelper::nextSortOrder($this->modx, $lessonId); }

        $table = TrainingLessonVideoHelper::lessonVideosTable($this->modx);
        $sql = 'INSERT INTO `' . $table . '` (`lesson_id`,`title`,`description`,`sort_order`,`source_video`,`duration_seconds`,`video_status`,`is_default`,`is_active`,`createdon`,`updatedon`)'
             . ' VALUES (:lesson_id,:title,:description,:sort_order,:source_video,0,:video_status,:is_default,:is_active,:createdon,:updatedon)';
        $now = date('Y-m-d H:i:s');
        $sourceVideo = trim((string)$this->getProperty('source_video', ''));
        $videoStatus = $sourceVideo !== '' ? 'available' : 'none';
        $stmt = $this->modx->prepare($sql);
        if (!$stmt || !$stmt->execute([
            ':lesson_id' => $lessonId,
            ':title' => $title,
            ':description' => trim((string)$this->getProperty('description', '')),
            ':sort_order' => $sort,
            ':source_video' => $sourceVideo,
            ':video_status' => $videoStatus,
            ':is_default' => $this->boolValue($this->getProperty('is_default', 0)),
            ':is_active' => $this->boolValue($this->getProperty('is_active', 1)),
            ':createdon' => $now,
            ':updatedon' => $now,
        ])) {
            return $this->failure('Не удалось создать видео урока');
        }

        $id = (int)$this->modx->lastInsertId();
        if ($this->boolValue($this->getProperty('is_default', 0))) {
            TrainingLessonVideoHelper::clearDefaultLessonVideo($this->modx, $lessonId, $id);
        }
        TrainingLessonVideoHelper::recalcLesson($this->modx, $lesson);

        return $this->success('Видео урока создано', ['id' => $id]);
    }
}
return 'TrainingLessonVideoCreateProcessor';
