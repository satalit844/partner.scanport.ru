Training.grid.LessonSlides = function(config) {
    config = config || {};
    this.lessonId = config.lessonId || Training.config.lesson_id;
    this.lessonVideoId = config.lessonVideoId || 0;
    this.sm = new Ext.grid.CheckboxSelectionModel();

    Ext.applyIf(config, {
        id: 'training-grid-lesson-slides',
        url: Training.config.connector_url,
        baseParams: {action: 'mgr/lesson/slides/getlist', lesson_video_id: this.lessonVideoId},
        sm: this.sm,
        fields: ['id','lesson_video_id','slide_no','image','timecode_ms','timecode_human','is_active'],
        paging: true,
        remoteSort: false,
        autoHeight: true,
        anchor: '100%',
        columns: [
            this.sm,
            {header: 'ID', dataIndex: 'id', width: 50},
            {header: 'Слайд', dataIndex: 'slide_no', width: 70},
            {header: 'Изображение', dataIndex: 'image', width: 300, renderer: Training.utils.renderFileLink},
            {header: 'Превью', dataIndex: 'image', width: 100, renderer: Training.utils.renderSlidePreview},
            {header: 'Таймкод', dataIndex: 'timecode_human', width: 80},
            {header: 'Активен', dataIndex: 'is_active', width: 80, renderer: Training.utils.renderBoolean}
        ],
        tbar: [{
            text: 'Импортировать из презентации',
            handler: this.importSlides,
            scope: this
        },{
            text: 'Расставить таймкоды',
            handler: this.autoTimecodes,
            scope: this
        },'-',{
            text: 'Добавить слайд',
            handler: this.createSlide,
            scope: this
        },{
            text: 'Изменить',
            handler: this.updateSlide,
            scope: this
        },{
            text: 'Удалить',
            handler: this.removeSlide,
            scope: this
        },'->',{
            text: 'Обновить',
            handler: function(){ this.refresh(); },
            scope: this
        }]
    });

    Training.grid.LessonSlides.superclass.constructor.call(this, config);
};
Ext.extend(Training.grid.LessonSlides, MODx.grid.Grid, {
    setVideoContext: function(videoId) {
        this.lessonVideoId = parseInt(videoId, 10) || 0;
        this.baseParams.lesson_video_id = this.lessonVideoId;
        var store = this.getStore();
        store.baseParams.lesson_video_id = this.lessonVideoId;
        store.removeAll();
        if (this.lessonVideoId > 0) {
            store.load({params: {start: 0, limit: this.pageSize || 20}});
        }
    },

    ensureSelectedVideo: function() {
        if (this.lessonVideoId > 0) { return true; }
        MODx.msg.alert('Внимание', 'Сначала выбери видео урока в верхней таблице');
        return false;
    },

    getSelectedRecord: function() {
        var sm = this.getSelectionModel(), selections = sm ? sm.getSelections() : [];
        return selections && selections.length ? selections[0] : (this.menu && this.menu.record ? this.menu.record : null);
    },

    importSlides: function() {
        if (!this.ensureSelectedVideo()) { return false; }
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {action: 'mgr/lesson/slide/import', lesson_id: this.lessonId, lesson_video_id: this.lessonVideoId},
            listeners: {success: {fn: function(){ this.refresh(); var videos = Ext.getCmp('training-grid-lesson-videos'); if (videos) { videos.refresh(); } }, scope: this}}
        });
    },

    autoTimecodes: function() {
        if (!this.ensureSelectedVideo()) { return false; }
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {action: 'mgr/lesson/slide/autotimecodes', lesson_video_id: this.lessonVideoId},
            listeners: {success: {fn: function(){ this.refresh(); }, scope: this}}
        });
    },

    createSlide: function() {
        if (!this.ensureSelectedVideo()) { return false; }
        var w = MODx.load({
            xtype: 'training-window-lesson-slide',
            title: 'Добавить слайд',
            baseParams: {action: 'mgr/lesson/slide/create'},
            lessonVideoId: this.lessonVideoId,
            listeners: {success: {fn: function(){ this.refresh(); }, scope: this}}
        });
        w.setValues({lesson_video_id: this.lessonVideoId, is_active: 1});
        w.show();
    },

    updateSlide: function(rec) {
        rec = rec || this.getSelectedRecord();
        if (!rec) { MODx.msg.alert('Внимание', 'Выбери слайд'); return false; }
        var w = MODx.load({
            xtype: 'training-window-lesson-slide',
            title: 'Изменить слайд',
            baseParams: {action: 'mgr/lesson/slide/update'},
            lessonVideoId: this.lessonVideoId,
            listeners: {success: {fn: function(){ this.refresh(); }, scope: this}}
        });
        w.setValues(rec.data || rec);
        w.show();
    },

    removeSlide: function(rec) {
        rec = rec || this.getSelectedRecord();
        if (!rec) { MODx.msg.alert('Внимание', 'Выбери слайд'); return false; }
        MODx.msg.confirm({
            title: 'Удаление',
            text: 'Удалить слайд?',
            url: Training.config.connector_url,
            params: {action: 'mgr/lesson/slide/remove', id: Training.utils.getRecordValue(rec, 'id')},
            listeners: {success: {fn: function(){ this.refresh(); var videos = Ext.getCmp('training-grid-lesson-videos'); if (videos) { videos.refresh(); } }, scope: this}}
        });
    }
});
Ext.reg('training-grid-lesson-slides', Training.grid.LessonSlides);

Training.window.LessonSlide = function(config) {
    config = config || {};
    this.lessonVideoId = config.lessonVideoId || 0;
    Ext.applyIf(config, {
        width: 760,
        autoHeight: true,
        url: Training.config.connector_url,
        fields: [
            {xtype:'hidden',name:'id'},
            {xtype:'hidden',name:'lesson_video_id',value:this.lessonVideoId},
            {xtype:'numberfield',fieldLabel:'Номер слайда',name:'slide_no',anchor:'100%',allowBlank:false},
            {xtype:'button',text:'Выбрать изображение',style:'margin-bottom:10px;',handler:function(btn){var win=btn.findParentByType('modx-window')||btn.findParentByType('window');var form=win&&win.fp?win.fp.getForm():null;var field=form?form.findField('image'):null;Training.utils.openPathBrowser(field,{source:Training.config.media_source||3,allowedFileTypes:'jpg,jpeg,png,webp,gif'});}},
            {xtype:'textfield',fieldLabel:'Изображение',name:'image',anchor:'100%',allowBlank:false},
            {xtype:'numberfield',fieldLabel:'Таймкод (мс)',name:'timecode_ms',anchor:'100%'},
            {xtype:'xcheckbox',boxLabel:'Активен',hideLabel:true,name:'is_active',inputValue:1,checked:true}
        ]
    });
    Training.window.LessonSlide.superclass.constructor.call(this, config);
};
Ext.extend(Training.window.LessonSlide, MODx.Window);
Ext.reg('training-window-lesson-slide', Training.window.LessonSlide);
