Training.grid.LessonQualities = function(config) {
    config = config || {};
    this.lessonId = config.lessonId || Training.config.lesson_id;
    this.lessonVideoId = config.lessonVideoId || 0;
    this.sm = new Ext.grid.CheckboxSelectionModel();

    Ext.applyIf(config, {
        id: 'training-grid-lesson-qualities',
        url: Training.config.connector_url,
        baseParams: {action: 'mgr/lesson/qualities/getlist', lesson_video_id: this.lessonVideoId},
        sm: this.sm,
        fields: ['id','lesson_video_id','quality','mime','file_path','width','height','bitrate','filesize','is_default','is_active'],
        paging: true,
        remoteSort: false,
        autoHeight: true,
        anchor: '100%',
        columns: [
            this.sm,
            {header: 'ID', dataIndex: 'id', width: 50},
            {header: 'Качество', dataIndex: 'quality', width: 80},
            {header: 'MIME', dataIndex: 'mime', width: 120},
            {header: 'Файл', dataIndex: 'file_path', width: 320, renderer: Training.utils.renderFileLink},
            {header: 'Размер', dataIndex: 'filesize', width: 100, renderer: Training.utils.renderBytes},
            {header: 'Разрешение', dataIndex: 'width', width: 100, renderer: function(v,m,rec){ return (rec.data.width||0) + '×' + (rec.data.height||0); }},
            {header: 'Битрейт', dataIndex: 'bitrate', width: 80},
            {header: 'По умолчанию', dataIndex: 'is_default', width: 90, renderer: Training.utils.renderBoolean},
            {header: 'Активен', dataIndex: 'is_active', width: 80, renderer: Training.utils.renderBoolean}
        ],
        tbar: [{
            text: 'Сгенерировать из исходника',
            handler: this.transcodeFromSource,
            scope: this
        },'-',{
            text: 'Добавить качество',
            handler: this.createQuality,
            scope: this
        },{
            text: 'Изменить',
            handler: this.updateQuality,
            scope: this
        },{
            text: 'Удалить',
            handler: this.removeQuality,
            scope: this
        },'->',{
            text: 'Обновить',
            handler: function(){ this.refresh(); },
            scope: this
        }]
    });

    Training.grid.LessonQualities.superclass.constructor.call(this, config);
};
Ext.extend(Training.grid.LessonQualities, MODx.grid.Grid, {
    setVideoContext: function(videoId) {
        this.lessonVideoId = parseInt(videoId, 10) || 0;
        this.baseParams.lesson_video_id = this.lessonVideoId;
        var store = this.getStore();
        store.baseParams.lesson_video_id = this.lessonVideoId;
        store.removeAll();
        if (this.lessonVideoId > 0) {
            store.load({params: {start: 0, limit: this.pageSize || 20}});
        }
    },

    ensureSelectedVideo: function() {
        if (this.lessonVideoId > 0) { return true; }
        MODx.msg.alert('Внимание', 'Сначала выбери видео урока в верхней таблице');
        return false;
    },

    getSelectedRecord: function() {
        var sm = this.getSelectionModel(), selections = sm ? sm.getSelections() : [];
        return selections && selections.length ? selections[0] : (this.menu && this.menu.record ? this.menu.record : null);
    },

    transcodeFromSource: function() {
        if (!this.ensureSelectedVideo()) { return false; }
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {action: 'mgr/lesson/video/transcode', lesson_video_id: this.lessonVideoId},
            listeners: {success: {fn: function(){ this.refresh(); var videos = Ext.getCmp('training-grid-lesson-videos'); if (videos) { videos.refresh(); } }, scope: this}}
        });
    },

    createQuality: function() {
        if (!this.ensureSelectedVideo()) { return false; }
        var w = MODx.load({
            xtype: 'training-window-lesson-quality',
            title: 'Добавить качество',
            baseParams: {action: 'mgr/lesson/quality/create'},
            lessonVideoId: this.lessonVideoId,
            listeners: {success: {fn: function(){ this.refresh(); }, scope: this}}
        });
        w.setValues({lesson_video_id: this.lessonVideoId, mime: 'video/mp4', is_active: 1, is_default: 0});
        w.show();
    },

    updateQuality: function(rec) {
        rec = rec || this.getSelectedRecord();
        if (!rec) { MODx.msg.alert('Внимание', 'Выбери качество'); return false; }
        var w = MODx.load({
            xtype: 'training-window-lesson-quality',
            title: 'Изменить качество',
            baseParams: {action: 'mgr/lesson/quality/update'},
            lessonVideoId: this.lessonVideoId,
            listeners: {success: {fn: function(){ this.refresh(); }, scope: this}}
        });
        w.setValues(rec.data || rec);
        w.show();
    },

    removeQuality: function(rec) {
        rec = rec || this.getSelectedRecord();
        if (!rec) { MODx.msg.alert('Внимание', 'Выбери качество'); return false; }
        MODx.msg.confirm({
            title: 'Удаление',
            text: 'Удалить качество видео?',
            url: Training.config.connector_url,
            params: {action: 'mgr/lesson/quality/remove', id: Training.utils.getRecordValue(rec, 'id')},
            listeners: {success: {fn: function(){ this.refresh(); }, scope: this}}
        });
    }
});
Ext.reg('training-grid-lesson-qualities', Training.grid.LessonQualities);

Training.window.LessonQuality = function(config) {
    config = config || {};
    this.lessonVideoId = config.lessonVideoId || 0;
    Ext.applyIf(config, {
        width: 760,
        autoHeight: true,
        url: Training.config.connector_url,
        fields: [
            {xtype:'hidden',name:'id'},
            {xtype:'hidden',name:'lesson_video_id',value:this.lessonVideoId},
            {xtype:'textfield',fieldLabel:'Качество',name:'quality',anchor:'100%',allowBlank:false},
            {xtype:'textfield',fieldLabel:'MIME',name:'mime',anchor:'100%'},
            {xtype:'button',text:'Выбрать файл качества',style:'margin-bottom:10px;',handler:function(btn){var win=btn.findParentByType('modx-window')||btn.findParentByType('window');var form=win&&win.fp?win.fp.getForm():null;var field=form?form.findField('file_path'):null;Training.utils.openPathBrowser(field,{source:Training.config.media_source||3,allowedFileTypes:'mp4,m3u8,webm,mov'});}},
            {xtype:'textfield',fieldLabel:'Файл',name:'file_path',anchor:'100%',allowBlank:false},
            {xtype:'numberfield',fieldLabel:'Ширина',name:'width',anchor:'100%'},
            {xtype:'numberfield',fieldLabel:'Высота',name:'height',anchor:'100%'},
            {xtype:'numberfield',fieldLabel:'Битрейт',name:'bitrate',anchor:'100%'},
            {xtype:'numberfield',fieldLabel:'Размер файла',name:'filesize',anchor:'100%'},
            {xtype:'xcheckbox',boxLabel:'По умолчанию',hideLabel:true,name:'is_default',inputValue:1},
            {xtype:'xcheckbox',boxLabel:'Активно',hideLabel:true,name:'is_active',inputValue:1,checked:true}
        ]
    });
    Training.window.LessonQuality.superclass.constructor.call(this, config);
};
Ext.extend(Training.window.LessonQuality, MODx.Window);
Ext.reg('training-window-lesson-quality', Training.window.LessonQuality);
