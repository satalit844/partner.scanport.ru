<?php

$helperPath = dirname(__DIR__) . '/_media_helper.php';
if (!file_exists($helperPath)) {
    $helperPath = dirname(dirname(__DIR__)) . '/mgr/_media_helper.php';
}
require_once $helperPath;

class TrainingLessonVideoHelper
{
    public static function table(modX $modx, $name)
    {
        $prefix = (string)$modx->getOption('table_prefix', null, 'modx_');
        return $prefix . 'partnerstraining_' . ltrim((string)$name, '_');
    }

    public static function lessonVideosTable(modX $modx)
    {
        return self::table($modx, 'lesson_videos');
    }

    public static function qualitiesTable(modX $modx)
    {
        return self::table($modx, 'module_videos');
    }

    public static function slidesTable(modX $modx)
    {
        return self::table($modx, 'module_slides');
    }

    public static function countLessonQualities(modX $modx, $lessonVideoId)
    {
        $sql = 'SELECT COUNT(*) FROM `' . self::qualitiesTable($modx) . '` WHERE `lesson_video_id` = :lesson_video_id';
        $stmt = $modx->prepare($sql);
        if (!$stmt || !$stmt->execute([':lesson_video_id' => (int)$lessonVideoId])) {
            return 0;
        }
        return (int)$stmt->fetchColumn();
    }

    public static function countVideoSlides(modX $modx, $lessonVideoId)
    {
        $sql = 'SELECT COUNT(*) FROM `' . self::slidesTable($modx) . '` WHERE `lesson_video_id` = :lesson_video_id';
        $stmt = $modx->prepare($sql);
        if (!$stmt || !$stmt->execute([':lesson_video_id' => (int)$lessonVideoId])) {
            return 0;
        }
        return (int)$stmt->fetchColumn();
    }
}
