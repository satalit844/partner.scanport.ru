<div class="col-12 col-md-6">
    <div class="lesson-card history-card js-history-item" data-history-id="{$history_id}">
        <div class="lesson-card__top">
            <div class="lesson-date">
                <span class="history-card__date">{$history_date}</span>
                <span class="history-card__time ms-1">{$history_time}</span>
            </div>
            <div class="label-chip {$history_status_class} label-chip--sm history-card__status"><span>{$history_status_text}</span></div>
        </div>

        <div class="lesson-title">
            <span class="lesson-ico">
                <img src="{$history_icon}" alt="" class="img-svg">
            </span>
            <div class="lesson-name history-card__title">{$history_material}</div>
        </div>

        <div class="history-card__meta d-flex flex-column gap-2">
            <div class="history-card__kv d-flex justify-content-between gap-3">
                <div class="course-meta__label">Просмотрено</div>
                <div class="history-card__v">{$history_viewed_plain}</div>
            </div>
            <div class="history-card__kv d-flex justify-content-between gap-3">
                <div class="course-meta__label">Баллы</div>
                <div class="history-card__v">{$history_score_plain}</div>
            </div>
            <div class="history-card__kv d-flex justify-content-between gap-3">
                <div class="course-meta__label">Продолж.</div>
                <div class="history-card__v">{$history_duration}</div>
            </div>
        </div>
    </div>
</div>
