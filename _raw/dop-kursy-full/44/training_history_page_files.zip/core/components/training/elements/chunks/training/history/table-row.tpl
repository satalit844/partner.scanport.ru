<div class="history-table__row js-history-item" data-history-id="{$history_id}">
    <div class="history-col history-col--date">
        <div class="history-date">{$history_date}</div>
        <div class="history-time">{$history_time}</div>
    </div>

    <div class="history-col history-col--mat">
        <div class="history-mat">
            <span class="history-mat__ico">
                <img src="{$history_icon}" class="img-svg" alt="">
            </span>
            <div class="history-mat__title">{$history_material}</div>
        </div>
    </div>

    <div class="history-col history-col--status">
        <div class="label-chip {$history_status_class}"><span>{$history_status_text}</span></div>
    </div>

    <div class="history-col history-col--viewed">{$history_viewed_html}</div>
    <div class="history-col history-col--score">{$history_score_html}</div>
    <div class="history-col history-col--dur">{$history_duration}</div>
</div>
