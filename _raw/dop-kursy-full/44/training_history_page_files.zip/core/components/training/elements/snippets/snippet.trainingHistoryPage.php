<?php
/** @var modX $modx */
/** @var array $scriptProperties */

$corePath = $modx->getOption(
    'training.core_path',
    null,
    $modx->getOption('core_path') . 'components/training/'
);
$corePath = rtrim(str_replace('\\', '/', (string)$corePath), '/') . '/';

require_once $corePath . 'model/training/training.class.php';
require_once $corePath . 'model/training/services/trainingprogress.class.php';
require_once $corePath . 'processors/web/_helpers.php';

if (!function_exists('trainingHistoryPageRenderChunk')) {
    function trainingHistoryPageRenderChunk($corePath, $relativePath, array $placeholders = array())
    {
        $path = rtrim(str_replace('\\', '/', (string)$corePath), '/') . '/elements/chunks/' . ltrim($relativePath, '/');
        if (!is_file($path)) {
            return '';
        }

        $content = (string)file_get_contents($path);
        if ($content === '') {
            return '';
        }

        $replace = array();
        foreach ($placeholders as $key => $value) {
            if (is_array($value) || is_object($value)) {
                $value = '';
            }
            $replace['{$' . $key . '}'] = (string)$value;
        }

        return strtr($content, $replace);
    }
}

if (!function_exists('trainingHistoryPageEsc')) {
    function trainingHistoryPageEsc($value)
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('trainingHistoryPageFormatSeconds')) {
    function trainingHistoryPageFormatSeconds($seconds)
    {
        $seconds = max(0, (int)$seconds);
        $hours = (int)floor($seconds / 3600);
        $minutes = (int)floor(($seconds % 3600) / 60);
        $secs = (int)($seconds % 60);
        return sprintf('%02d:%02d:%02d', $hours, $minutes, $secs);
    }
}

if (!function_exists('trainingHistoryPageFormatDateParts')) {
    function trainingHistoryPageFormatDateParts($value)
    {
        if (!$value || $value === '0000-00-00 00:00:00') {
            return array('date' => '—', 'time' => '—', 'timestamp' => 0);
        }

        $ts = is_numeric($value) ? (int)$value : strtotime((string)$value);
        if (!$ts) {
            return array('date' => '—', 'time' => '—', 'timestamp' => 0);
        }

        $months = array(
            1 => 'янв.', 2 => 'февр.', 3 => 'мар.', 4 => 'апр.', 5 => 'мая', 6 => 'июн.',
            7 => 'июл.', 8 => 'авг.', 9 => 'сент.', 10 => 'окт.', 11 => 'нояб.', 12 => 'дек.',
        );

        $month = isset($months[(int)date('n', $ts)]) ? $months[(int)date('n', $ts)] : date('m', $ts);
        return array(
            'date' => (int)date('j', $ts) . ' ' . $month . ' ' . date('Y', $ts),
            'time' => date('G:i', $ts),
            'timestamp' => $ts,
        );
    }
}

if (!function_exists('trainingHistoryPageGetUserLabel')) {
    function trainingHistoryPageGetUserLabel(array $row)
    {
        $fullname = trim((string)(isset($row['fullname']) ? $row['fullname'] : ''));
        $username = trim((string)(isset($row['username']) ? $row['username'] : ''));
        if ($fullname !== '') {
            return $fullname;
        }
        return $username !== '' ? $username : ('Пользователь #' . (int)$row['id']);
    }
}

if (!function_exists('trainingHistoryPageFetchUsers')) {
    function trainingHistoryPageFetchUsers(modX $modx, array $ids)
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
        if (empty($ids)) {
            return array();
        }

        $query = $modx->newQuery('modUser');
        $query->leftJoin('modUserProfile', 'Profile', 'Profile.internalKey = modUser.id');
        $query->where(array('modUser.id:IN' => $ids));
        $query->select(array(
            'modUser.id AS id',
            'modUser.username AS username',
            'Profile.fullname AS fullname',
            'Profile.email AS email',
            'Profile.extended AS extended',
        ));

        $rows = array();
        if ($query->prepare() && $query->stmt->execute()) {
            while ($row = $query->stmt->fetch(PDO::FETCH_ASSOC)) {
                $extended = array();
                if (!empty($row['extended'])) {
                    $decoded = json_decode((string)$row['extended'], true);
                    if (is_array($decoded)) {
                        $extended = $decoded;
                    }
                }

                $organization = '';
                foreach (array('company', 'organization', 'organisation', 'org', 'company_name', 'organisation_name', 'employer', 'workplace') as $key) {
                    if (!empty($extended[$key])) {
                        $organization = trim((string)$extended[$key]);
                        break;
                    }
                }

                $rows[(int)$row['id']] = array(
                    'id' => (int)$row['id'],
                    'username' => trim((string)$row['username']),
                    'fullname' => trim((string)$row['fullname']),
                    'email' => trim((string)$row['email']),
                    'organization' => $organization,
                );
            }
        }

        return $rows;
    }
}

if (!function_exists('trainingHistoryPageFetchManagedIds')) {
    function trainingHistoryPageFetchManagedIds(modX $modx, $managerUserId)
    {
        $managerUserId = (int)$managerUserId;
        if ($managerUserId <= 0) {
            return array();
        }

        $table = $modx->getOption('table_prefix', null, 'modx_') . 'partnerstraining_user_manager_link';
        $stmt = $modx->prepare('SELECT employee_user_id FROM `' . $table . '` WHERE manager_user_id = :manager AND is_active = 1 ORDER BY employee_user_id ASC');
        if (!$stmt) {
            return array();
        }
        if (!$stmt->execute(array(':manager' => $managerUserId))) {
            return array();
        }

        $ids = array();
        while (($id = $stmt->fetchColumn()) !== false) {
            $id = (int)$id;
            if ($id > 0 && $id !== $managerUserId) {
                $ids[$id] = $id;
            }
        }

        return array_values($ids);
    }
}

if (!function_exists('trainingHistoryPageBuildUrl')) {
    function trainingHistoryPageBuildUrl(modX $modx, array $params = array())
    {
        $resourceId = $modx->resource ? (int)$modx->resource->get('id') : 0;
        $url = $resourceId > 0 ? $modx->makeUrl($resourceId, $modx->context ? $modx->context->get('key') : '') : '';
        if ($url === '') {
            $url = $_SERVER['REQUEST_URI'];
        }

        $clean = array();
        foreach ($params as $key => $value) {
            if ($value === null || $value === '') {
                continue;
            }
            $clean[$key] = $value;
        }

        if (empty($clean)) {
            return $url;
        }

        $glue = strpos($url, '?') === false ? '?' : '&';
        return $url . $glue . http_build_query($clean);
    }
}

if (!function_exists('trainingHistoryPageStatusMeta')) {
    function trainingHistoryPageStatusMeta($type, $statusKey, $progressPercent)
    {
        $statusKey = trim((string)$statusKey);
        $progressPercent = (float)$progressPercent;

        if ($type === 'practice') {
            if (in_array($statusKey, array('accepted', 'completed', 'passed'), true)) {
                return array('text' => 'Завершен', 'class' => 'label-chip--green');
            }
            if (in_array($statusKey, array('pending_review', 'checking', 'submitted'), true)) {
                return array('text' => 'На проверке', 'class' => 'label-chip--orange');
            }
            if (in_array($statusKey, array('rejected', 'failed', 'revision_requested'), true)) {
                return array('text' => 'Не принято', 'class' => 'label-chip--red');
            }
            if ($progressPercent > 0 || in_array($statusKey, array('draft', 'in_progress'), true)) {
                return array('text' => 'В процессе', 'class' => 'label-chip--purple');
            }
            return array('text' => 'Не начат', 'class' => 'label-chip--blue');
        }

        if ($type === 'test') {
            if (in_array($statusKey, array('passed', 'accepted', 'completed'), true)) {
                return array('text' => 'Завершен', 'class' => 'label-chip--green');
            }
            if (in_array($statusKey, array('checking', 'pending_review'), true)) {
                return array('text' => 'На проверке', 'class' => 'label-chip--orange');
            }
            if (in_array($statusKey, array('failed', 'rejected'), true)) {
                return array('text' => 'Не пройден', 'class' => 'label-chip--red');
            }
            if ($progressPercent > 0 || in_array($statusKey, array('in_progress'), true)) {
                return array('text' => 'В процессе', 'class' => 'label-chip--purple');
            }
            return array('text' => 'Не начат', 'class' => 'label-chip--blue');
        }

        if (in_array($statusKey, array('completed', 'passed', 'accepted'), true) || $progressPercent >= 100) {
            return array('text' => 'Завершен', 'class' => 'label-chip--green');
        }
        if ($progressPercent > 0 || in_array($statusKey, array('in_progress'), true)) {
            return array('text' => 'В процессе', 'class' => 'label-chip--purple');
        }
        return array('text' => 'Не начат', 'class' => 'label-chip--blue');
    }
}

if (!$modx->user || !(int)$modx->user->get('id') || !$modx->user->isAuthenticated($modx->context->get('key'))) {
    return '';
}

$pageTpl = trim((string)$modx->getOption('pageTpl', $scriptProperties, 'training/history/page.tpl'));
$rowTpl = trim((string)$modx->getOption('rowTpl', $scriptProperties, 'training/history/table-row.tpl'));
$cardTpl = trim((string)$modx->getOption('cardTpl', $scriptProperties, 'training/history/card.tpl'));

$actorUserId = (int)$modx->user->get('id');
$managedIds = trainingHistoryPageFetchManagedIds($modx, $actorUserId);
$allowedIds = array_merge(array($actorUserId), $managedIds);
$allowedIds = array_values(array_unique(array_filter(array_map('intval', $allowedIds))));

$requestedUserId = isset($_GET['history_user']) ? (int)$_GET['history_user'] : $actorUserId;
if (!in_array($requestedUserId, $allowedIds, true)) {
    $requestedUserId = $actorUserId;
}

$sort = isset($_GET['history_sort']) ? trim((string)$_GET['history_sort']) : 'desc';
$sort = $sort === 'asc' ? 'asc' : 'desc';
$sortToggle = $sort === 'asc' ? 'desc' : 'asc';

$userMap = trainingHistoryPageFetchUsers($modx, $allowedIds);
if (!isset($userMap[$actorUserId])) {
    $currentUser = $modx->user;
    $profile = $currentUser ? $currentUser->getOne('Profile') : null;
    $userMap[$actorUserId] = array(
        'id' => $actorUserId,
        'username' => $currentUser ? (string)$currentUser->get('username') : ('user' . $actorUserId),
        'fullname' => $profile ? trim((string)$profile->get('fullname')) : '',
        'email' => $profile ? trim((string)$profile->get('email')) : '',
        'organization' => '',
    );
}

$selectedUser = isset($userMap[$requestedUserId]) ? $userMap[$requestedUserId] : $userMap[$actorUserId];
$showUserSelect = count($managedIds) > 0;
$subtitle = $requestedUserId === $actorUserId ? 'Моя история' : trainingHistoryPageGetUserLabel($selectedUser);

$userOptionsHtml = '';
if ($showUserSelect) {
    foreach ($allowedIds as $id) {
        if (!isset($userMap[$id])) {
            continue;
        }
        $label = $id === $actorUserId ? 'Моя история' : trainingHistoryPageGetUserLabel($userMap[$id]);
        $userOptionsHtml .= '<option value="' . (int)$id . '"' . ($id === $requestedUserId ? ' selected="selected"' : '') . '>' . trainingHistoryPageEsc($label) . '</option>';
    }
}

$prefix = (string)$modx->getOption('table_prefix', null, 'modx_');
$lessonProgressTable = $prefix . 'partnerstraining_user_lesson_progress';
$userVideoProgressTable = TrainingWebHelper::userVideoProgressTable($modx);
$lessonVideosTable = TrainingWebHelper::lessonVideosTable($modx);
$lessonsTable = $prefix . 'partnerstraining_module_lessons';
$modulesTable = $prefix . 'partnerstraining_modules';
$testStatusTable = $prefix . 'partnerstraining_user_test_status';
$testLinksTable = $prefix . 'partnerstraining_test_links';
$practiceAttemptsTable = $prefix . 'partnerstraining_practice_attempts';
$resourceTable = $modx->getTableName('modResource');

$events = array();
$historyId = 1;

// Уроки / видео
$lessonIds = array();
$lessonRows = array();
$sqlLessons = "
    SELECT lp.*, l.title AS lesson_title, l.module_id AS lesson_module_id, m.resource_id AS module_resource_id, mr.pagetitle AS module_title
    FROM `{$lessonProgressTable}` lp
    INNER JOIN `{$lessonsTable}` l ON l.id = lp.lesson_id
    LEFT JOIN `{$modulesTable}` m ON m.id = l.module_id
    LEFT JOIN `{$resourceTable}` mr ON mr.id = m.resource_id AND mr.deleted = 0
    WHERE lp.user_id = :user_id
      AND (
        lp.progress_percent > 0
        OR lp.watched_seconds > 0
        OR (lp.last_watch IS NOT NULL AND lp.last_watch <> '0000-00-00 00:00:00')
        OR (lp.completedon IS NOT NULL AND lp.completedon <> '0000-00-00 00:00:00')
      )
    ORDER BY COALESCE(lp.last_watch, lp.completedon) DESC, lp.id DESC
";
$stmtLessons = $modx->prepare($sqlLessons);
if ($stmtLessons && $stmtLessons->execute(array(':user_id' => $requestedUserId))) {
    $lessonRows = (array)$stmtLessons->fetchAll(PDO::FETCH_ASSOC);
    foreach ($lessonRows as $row) {
        $lessonId = (int)$row['lesson_id'];
        if ($lessonId > 0) {
            $lessonIds[$lessonId] = $lessonId;
        }
    }
}

$lessonVideoTotals = array();
$lessonVideoCompleted = array();
if (!empty($lessonIds)) {
    $lessonIdList = implode(',', array_values($lessonIds));

    $sqlTotals = "
        SELECT lesson_id, COUNT(*) AS total_videos
        FROM `{$lessonVideosTable}`
        WHERE lesson_id IN ({$lessonIdList})
          AND is_active = 1
          AND TRIM(COALESCE(source_video, '')) <> ''
        GROUP BY lesson_id
    ";
    $stmtTotals = $modx->query($sqlTotals);
    if ($stmtTotals) {
        while ($row = $stmtTotals->fetch(PDO::FETCH_ASSOC)) {
            $lessonVideoTotals[(int)$row['lesson_id']] = (int)$row['total_videos'];
        }
    }

    $sqlCompleted = "
        SELECT lesson_id, COUNT(*) AS completed_videos
        FROM `{$userVideoProgressTable}`
        WHERE user_id = :user_id
          AND lesson_id IN ({$lessonIdList})
          AND completed = 1
        GROUP BY lesson_id
    ";
    $stmtCompleted = $modx->prepare($sqlCompleted);
    if ($stmtCompleted && $stmtCompleted->execute(array(':user_id' => $requestedUserId))) {
        while ($row = $stmtCompleted->fetch(PDO::FETCH_ASSOC)) {
            $lessonVideoCompleted[(int)$row['lesson_id']] = (int)$row['completed_videos'];
        }
    }
}

foreach ($lessonRows as $row) {
    $lessonId = (int)$row['lesson_id'];
    $dateValue = !empty($row['last_watch']) && $row['last_watch'] !== '0000-00-00 00:00:00'
        ? $row['last_watch']
        : $row['completedon'];
    $parts = trainingHistoryPageFormatDateParts($dateValue);
    $progressPercent = round((float)$row['progress_percent']);
    $statusMeta = trainingHistoryPageStatusMeta('lesson', (string)$row['status'], $progressPercent);
    $totalVideos = isset($lessonVideoTotals[$lessonId]) ? (int)$lessonVideoTotals[$lessonId] : 0;
    $completedVideos = isset($lessonVideoCompleted[$lessonId]) ? (int)$lessonVideoCompleted[$lessonId] : 0;
    $viewedText = $progressPercent . '%';
    if ($totalVideos > 0) {
        $viewedText .= ' <span class="history-muted">(' . $completedVideos . '/' . $totalVideos . ')</span>';
    }

    $watchedSeconds = max((int)$row['watched_seconds'], (int)$row['max_time'], (int)$row['current_time']);

    $events[] = array(
        'history_id' => $historyId++,
        'timestamp' => (int)$parts['timestamp'],
        'date' => $parts['date'],
        'time' => $parts['time'],
        'material' => trim((string)$row['lesson_title']) !== '' ? trim((string)$row['lesson_title']) : ('Урок #' . $lessonId),
        'icon' => 'theme/images/training/lesson-ico.svg',
        'status_text' => $statusMeta['text'],
        'status_class' => $statusMeta['class'],
        'viewed_html' => $viewedText,
        'score_html' => '- <span class="history-muted">(0%)</span>',
        'duration' => trainingHistoryPageFormatSeconds($watchedSeconds),
    );
}

// Тесты
$sqlTests = "
    SELECT uts.*, tl.min_pass_percent, tl.link_type, mr.pagetitle AS module_title
    FROM `{$testStatusTable}` uts
    INNER JOIN `{$testLinksTable}` tl
        ON tl.course_id = uts.course_id
       AND tl.module_id = uts.module_id
       AND tl.usertest_test_id = uts.usertest_test_id
       AND tl.link_type = 'test'
    LEFT JOIN `{$modulesTable}` m ON m.id = uts.module_id
    LEFT JOIN `{$resourceTable}` mr ON mr.id = m.resource_id AND mr.deleted = 0
    WHERE uts.user_id = :user_id
      AND (
        uts.status <> 'not_started'
        OR uts.attempts > 0
        OR (uts.updatedon IS NOT NULL AND uts.updatedon <> '0000-00-00 00:00:00')
        OR (uts.last_passedon IS NOT NULL AND uts.last_passedon <> '0000-00-00 00:00:00')
      )
    ORDER BY COALESCE(uts.updatedon, uts.last_passedon) DESC, uts.id DESC
";
$stmtTests = $modx->prepare($sqlTests);
if ($stmtTests && $stmtTests->execute(array(':user_id' => $requestedUserId))) {
    while ($row = $stmtTests->fetch(PDO::FETCH_ASSOC)) {
        $dateValue = !empty($row['updatedon']) && $row['updatedon'] !== '0000-00-00 00:00:00'
            ? $row['updatedon']
            : $row['last_passedon'];
        $parts = trainingHistoryPageFormatDateParts($dateValue);
        $score = (float)$row['last_score'];
        $minPass = (float)$row['min_pass_percent'];
        $statusMeta = trainingHistoryPageStatusMeta('test', (string)$row['status'], $score);
        $moduleTitle = trim((string)$row['module_title']);
        $material = 'Тест';
        if ($moduleTitle !== '') {
            $material .= ' — ' . $moduleTitle;
        }

        $scoreHtml = ($score > 0 ? rtrim(rtrim(number_format($score, 2, '.', ''), '0'), '.') : '-')
            . ' <span class="history-muted">(' . (int)round($minPass) . '%)</span>';

        $events[] = array(
            'history_id' => $historyId++,
            'timestamp' => (int)$parts['timestamp'],
            'date' => $parts['date'],
            'time' => $parts['time'],
            'material' => $material,
            'icon' => 'theme/images/training/lesson-ico.svg',
            'status_text' => $statusMeta['text'],
            'status_class' => $statusMeta['class'],
            'viewed_html' => '-',
            'score_html' => $scoreHtml,
            'duration' => '—',
        );
    }
}

// Практические работы (последние статусы)
$sqlPractice = "
    SELECT pa.*, mr.pagetitle AS module_title
    FROM `{$practiceAttemptsTable}` pa
    LEFT JOIN `{$modulesTable}` m ON m.id = pa.module_id
    LEFT JOIN `{$resourceTable}` mr ON mr.id = m.resource_id AND mr.deleted = 0
    WHERE pa.user_id = :user_id
    ORDER BY COALESCE(pa.reviewedon, pa.submittedon, pa.updatedon, pa.createdon) DESC, pa.id DESC
";
$stmtPractice = $modx->prepare($sqlPractice);
if ($stmtPractice && $stmtPractice->execute(array(':user_id' => $requestedUserId))) {
    while ($row = $stmtPractice->fetch(PDO::FETCH_ASSOC)) {
        $dateValue = null;
        foreach (array('reviewedon', 'submittedon', 'updatedon', 'createdon') as $key) {
            if (!empty($row[$key]) && $row[$key] !== '0000-00-00 00:00:00') {
                $dateValue = $row[$key];
                break;
            }
        }
        $parts = trainingHistoryPageFormatDateParts($dateValue);
        $score = (float)$row['score'];
        $maxScore = (float)$row['max_score'];
        $percent = $maxScore > 0 ? round(($score / $maxScore) * 100) : 0;
        $statusMeta = trainingHistoryPageStatusMeta('practice', (string)$row['status'], $percent);
        $material = trim((string)$row['title']);
        if ($material === '') {
            $material = 'Практическая работа';
            if (!empty($row['module_title'])) {
                $material .= ' — ' . trim((string)$row['module_title']);
            }
        }

        $scoreText = ($score > 0 ? rtrim(rtrim(number_format($score, 2, '.', ''), '0'), '.') : '-');
        $scoreHtml = $scoreText . ' <span class="history-muted">(' . (int)$percent . '%)</span>';

        $events[] = array(
            'history_id' => $historyId++,
            'timestamp' => (int)$parts['timestamp'],
            'date' => $parts['date'],
            'time' => $parts['time'],
            'material' => $material,
            'icon' => 'theme/images/training/lesson-ico.svg',
            'status_text' => $statusMeta['text'],
            'status_class' => $statusMeta['class'],
            'viewed_html' => '-',
            'score_html' => $scoreHtml,
            'duration' => '—',
        );
    }
}

usort($events, function ($a, $b) use ($sort) {
    $left = isset($a['timestamp']) ? (int)$a['timestamp'] : 0;
    $right = isset($b['timestamp']) ? (int)$b['timestamp'] : 0;
    if ($left === $right) {
        return 0;
    }
    if ($sort === 'asc') {
        return $left < $right ? -1 : 1;
    }
    return $left > $right ? -1 : 1;
});

$tableRowsHtml = '';
$cardsHtml = '';
foreach ($events as $event) {
    $tableRowsHtml .= trainingHistoryPageRenderChunk($corePath, $rowTpl, array(
        'history_id' => (int)$event['history_id'],
        'history_date' => trainingHistoryPageEsc($event['date']),
        'history_time' => trainingHistoryPageEsc($event['time']),
        'history_material' => trainingHistoryPageEsc($event['material']),
        'history_icon' => trainingHistoryPageEsc($event['icon']),
        'history_status_text' => trainingHistoryPageEsc($event['status_text']),
        'history_status_class' => trainingHistoryPageEsc($event['status_class']),
        'history_viewed_html' => $event['viewed_html'],
        'history_score_html' => $event['score_html'],
        'history_duration' => trainingHistoryPageEsc($event['duration']),
    ));

    $cardsHtml .= trainingHistoryPageRenderChunk($corePath, $cardTpl, array(
        'history_id' => (int)$event['history_id'],
        'history_date' => trainingHistoryPageEsc($event['date']),
        'history_time' => trainingHistoryPageEsc($event['time']),
        'history_datetime' => trainingHistoryPageEsc(trim($event['date'] . ' ' . $event['time'])),
        'history_material' => trainingHistoryPageEsc($event['material']),
        'history_icon' => trainingHistoryPageEsc($event['icon']),
        'history_status_text' => trainingHistoryPageEsc($event['status_text']),
        'history_status_class' => trainingHistoryPageEsc($event['status_class']),
        'history_viewed_plain' => trim(strip_tags(str_replace('&nbsp;', ' ', $event['viewed_html']))),
        'history_score_plain' => trim(strip_tags(str_replace('&nbsp;', ' ', $event['score_html']))),
        'history_duration' => trainingHistoryPageEsc($event['duration']),
    ));
}

if ($tableRowsHtml === '') {
    $tableRowsHtml = '<div class="history-table__row"><div class="history-col" style="grid-column: 1 / -1;">История пока пуста</div></div>';
    $cardsHtml = '<div class="col-12"><div class="lesson-card">История пока пуста</div></div>';
}

$sortUrl = trainingHistoryPageBuildUrl($modx, array(
    'history_user' => $requestedUserId,
    'history_sort' => $sortToggle,
));

return trainingHistoryPageRenderChunk($corePath, $pageTpl, array(
    'history_title' => trainingHistoryPageEsc($modx->resource ? $modx->resource->get('pagetitle') : 'История'),
    'history_subtitle' => trainingHistoryPageEsc($subtitle),
    'history_user_select_html' => $showUserSelect ? ('
        <form class="history-user-form" method="get" action="">
            <input type="hidden" name="history_sort" value="' . trainingHistoryPageEsc($sort) . '">
            <select class="form-select history-user-select" name="history_user" onchange="this.form.submit()">' . $userOptionsHtml . '</select>
        </form>
    ') : '',
    'history_sort_url' => trainingHistoryPageEsc($sortUrl),
    'history_sort_class' => $sort === 'asc' ? ' is-asc' : ' is-desc',
    'history_table_rows_html' => $tableRowsHtml,
    'history_cards_html' => $cardsHtml,
));
