{'!trainingManageHistoryPage' | snippet}
