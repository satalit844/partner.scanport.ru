{'!trainingHistoryPage' | snippet}
