<?php
/** @var modX $modx */

require_once dirname(__FILE__) . '/_historyHelper.php';

return trainingHistoryRenderPage($modx, array(
    'manage' => false,
    'title' => $modx->resource ? (string)$modx->resource->get('pagetitle') : 'История',
    'subtitle' => 'Моя история',
));
