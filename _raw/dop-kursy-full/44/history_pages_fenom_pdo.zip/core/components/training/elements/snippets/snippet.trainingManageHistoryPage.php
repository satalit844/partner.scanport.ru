<?php
/** @var modX $modx */

require_once dirname(__FILE__) . '/_historyHelper.php';

return trainingHistoryRenderPage($modx, array(
    'manage' => true,
    'title' => $modx->resource ? (string)$modx->resource->get('pagetitle') : 'Управление историей',
    'subtitle' => 'Моя история',
));
