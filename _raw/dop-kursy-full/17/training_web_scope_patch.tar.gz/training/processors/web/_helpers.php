<?php

require_once dirname(dirname(__DIR__)) . '/model/training/training.class.php';
require_once dirname(dirname(__DIR__)) . '/model/training/services/trainingprogress.class.php';

class TrainingWebHelper
{
    public static function getTraining(modX $modx)
    {
        return new Training($modx);
    }

    public static function getProgressService(modX $modx)
    {
        return new TrainingProgressService($modx, self::getTraining($modx));
    }

    public static function requireAuth(modProcessor $processor)
    {
        if (!$processor->modx->user || !(int)$processor->modx->user->get('id')) {
            return $processor->failure('Нужно авторизоваться');
        }
        return null;
    }
}
