<?php

require_once dirname(dirname(__FILE__)) . '/_helpers.php';

class TrainingWebCourseMyCoursesProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    public function process()
    {
        if ($failure = TrainingWebHelper::requireAuth($this)) {
            return $failure;
        }

        $userId = (int)$this->modx->user->get('id');
        $limit = max(0, (int)$this->getProperty('limit', 0));
        $start = max(0, (int)$this->getProperty('start', 0));
        $includeRevoked = (int)$this->getProperty('include_revoked', 0) === 1;
        $recalculate = (int)$this->getProperty('recalculate', 1) === 1;

        $service = TrainingWebHelper::getProgressService($this->modx);
        $rows = $service->getMyCourses($userId, [
            'limit' => $limit,
            'start' => $start,
            'include_revoked' => $includeRevoked,
            'recalculate' => $recalculate,
        ]);

        return $this->success('', [
            'total' => count($rows),
            'results' => $rows,
        ]);
    }
}

return 'TrainingWebCourseMyCoursesProcessor';
