<?php

require_once dirname(dirname(__FILE__)) . '/_helpers.php';

class TrainingWebCourseAssignableUsersProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    public function process()
    {
        if ($failure = TrainingWebHelper::requireAuth($this)) {
            return $failure;
        }

        $actorUserId = (int)$this->modx->user->get('id');
        $courseId = (int)$this->getProperty('course_id', 0);
        $includeSelf = (int)$this->getProperty('include_self', 1) === 1;
        $query = trim((string)$this->getProperty('query', ''));

        $service = TrainingWebHelper::getProgressService($this->modx);
        $ids = $service->getAssignableUserIds($actorUserId, $includeSelf);
        if (empty($ids)) {
            return $this->success('', []);
        }

        $c = $this->modx->newQuery('modUser');
        $c->leftJoin('modUserProfile', 'Profile', 'Profile.internalKey = modUser.id');
        $c->where([
            'modUser.id:IN' => $ids,
        ]);
        if ($query !== '') {
            $c->where([
                'modUser.username:LIKE' => '%' . $query . '%',
                'OR:Profile.fullname:LIKE' => '%' . $query . '%',
                'OR:Profile.email:LIKE' => '%' . $query . '%',
            ]);
        }
        $c->select([
            'modUser.id AS id',
            'modUser.username AS username',
            'Profile.fullname AS fullname',
            'Profile.email AS email',
        ]);
        $c->sortby('Profile.fullname', 'ASC');
        $c->sortby('modUser.username', 'ASC');

        $rows = [];
        if ($c->prepare() && $c->stmt->execute()) {
            while ($row = $c->stmt->fetch(PDO::FETCH_ASSOC)) {
                $userId = (int)$row['id'];
                $fullname = trim((string)$row['fullname']);
                $email = trim((string)$row['email']);
                $username = trim((string)$row['username']);
                $label = '#' . $userId . ' ' . $username;
                if ($fullname !== '') {
                    $label .= ' (' . $fullname . ')';
                }
                if ($email !== '') {
                    $label .= ' [' . $email . ']';
                }

                $item = [
                    'id' => $userId,
                    'name' => $label,
                    'display' => $label,
                    'username' => $username,
                    'fullname' => $fullname,
                    'email' => $email,
                    'scope' => $userId === $actorUserId ? 'self' : 'managed',
                ];

                if ($courseId > 0) {
                    $directAccess = $service->getDirectUserAccess($courseId, $userId);
                    $item['has_access'] = $service->hasCourseAccess($courseId, $userId) ? 1 : 0;
                    $item['direct_access_id'] = $directAccess ? (int)$directAccess->get('id') : 0;
                    $item['direct_access_role'] = $directAccess ? (string)$directAccess->get('access_role') : '';
                    $item['resolved_access_role'] = $service->resolveUserAccessRoleForCourse($courseId, $userId, 'employee');
                }

                $rows[] = $item;
            }
        }

        return $this->success('', $rows);
    }
}

return 'TrainingWebCourseAssignableUsersProcessor';
