<?php

class TrainingProgressService
{
    /** @var modX */
    protected $modx;

    /** @var Training */
    protected $training;

    public function __construct(modX $modx, Training $training)
    {
        $this->modx = $modx;
        $this->training = $training;
    }

    protected function getNow()
    {
        return date('Y-m-d H:i:s');
    }

    protected function normalizeRole($role)
    {
        $role = trim((string)$role);
        return $role === 'director' ? 'director' : 'employee';
    }

    protected function mergeRole($currentRole, $newRole)
    {
        $currentRole = $this->normalizeRole($currentRole);
        $newRole = $this->normalizeRole($newRole);
        return $currentRole === 'director' || $newRole === 'director' ? 'director' : 'employee';
    }

    public function normalizeDateTimeValue($value)
    {
        $value = trim((string)$value);
        if ($value === '' || $value === '0000-00-00 00:00:00') {
            return null;
        }

        $value = str_replace('T', ' ', $value);
        if (preg_match('#^\d{4}-\d{2}-\d{2}$#', $value)) {
            return $value . ' 00:00:00';
        }

        if (preg_match('#^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}$#', $value)) {
            return $value . ':00';
        }

        return $value;
    }

    public function isAccessCurrentlyActive($access, $now = null)
    {
        $now = $now ?: $this->getNow();
        $activeFrom = null;
        $activeTo = null;

        if ($access instanceof TrainingCourseAccess) {
            if (!(int)$access->get('is_active')) {
                return false;
            }
            $activeFrom = $access->get('active_from');
            $activeTo = $access->get('active_to');
        } elseif (is_array($access)) {
            if (isset($access['is_active']) && !(int)$access['is_active']) {
                return false;
            }
            $activeFrom = isset($access['active_from']) ? $access['active_from'] : null;
            $activeTo = isset($access['active_to']) ? $access['active_to'] : null;
        }

        if (!empty($activeFrom) && $now < $activeFrom) {
            return false;
        }
        if (!empty($activeTo) && $now > $activeTo) {
            return false;
        }

        return true;
    }

    public function getUserGroupIds($userId)
    {
        $userId = (int)$userId;
        if ($userId <= 0) {
            return [];
        }

        $ids = [];
        $members = $this->modx->getIterator('modUserGroupMember', [
            'member' => $userId,
        ]);

        /** @var modUserGroupMember $member */
        foreach ($members as $member) {
            $groupId = (int)$member->get('user_group');
            if ($groupId > 0) {
                $ids[$groupId] = $groupId;
            }
        }

        return array_values($ids);
    }

    public function hasCourseAccess($courseId, $userId)
    {
        $courseId = (int)$courseId;
        $userId = (int)$userId;
        if ($courseId <= 0 || $userId <= 0) {
            return false;
        }

        $groupIds = $this->getUserGroupIds($userId);
        $items = $this->modx->getIterator('TrainingCourseAccess', [
            'course_id' => $courseId,
            'is_active' => 1,
        ]);

        $now = $this->getNow();
        /** @var TrainingCourseAccess $item */
        foreach ($items as $item) {
            if (!$this->isAccessCurrentlyActive($item, $now)) {
                continue;
            }

            $principalType = (string)$item->get('principal_type');
            $principalId = (int)$item->get('principal_id');
            if ($principalType === 'user' && $principalId === $userId) {
                return true;
            }
            if ($principalType === 'group' && in_array($principalId, $groupIds, true)) {
                return true;
            }
        }

        return false;
    }

    public function collectAccessibleUserMap($courseId)
    {
        $courseId = (int)$courseId;
        if ($courseId <= 0) {
            return [];
        }

        $result = [];
        $now = $this->getNow();
        $items = $this->modx->getIterator('TrainingCourseAccess', [
            'course_id' => $courseId,
            'is_active' => 1,
        ]);

        /** @var TrainingCourseAccess $item */
        foreach ($items as $item) {
            if (!$this->isAccessCurrentlyActive($item, $now)) {
                continue;
            }

            $principalType = (string)$item->get('principal_type');
            $principalId = (int)$item->get('principal_id');
            $accessRole = $this->normalizeRole($item->get('access_role'));
            if ($principalId <= 0) {
                continue;
            }

            if ($principalType === 'user') {
                if (!isset($result[$principalId])) {
                    $result[$principalId] = [
                        'user_id' => $principalId,
                        'access_role' => $accessRole,
                    ];
                } else {
                    $result[$principalId]['access_role'] = $this->mergeRole($result[$principalId]['access_role'], $accessRole);
                }
                continue;
            }

            if ($principalType === 'group') {
                $members = $this->modx->getIterator('modUserGroupMember', [
                    'user_group' => $principalId,
                ]);
                /** @var modUserGroupMember $member */
                foreach ($members as $member) {
                    $memberId = (int)$member->get('member');
                    if ($memberId <= 0) {
                        continue;
                    }
                    if (!isset($result[$memberId])) {
                        $result[$memberId] = [
                            'user_id' => $memberId,
                            'access_role' => $accessRole,
                        ];
                    } else {
                        $result[$memberId]['access_role'] = $this->mergeRole($result[$memberId]['access_role'], $accessRole);
                    }
                }
            }
        }

        ksort($result);
        return $result;
    }

    public function collectAccessibleUserIds($courseId)
    {
        return array_keys($this->collectAccessibleUserMap($courseId));
    }

    public function resolveUserAccessRoleForCourse($courseId, $userId, $default = 'employee')
    {
        $courseId = (int)$courseId;
        $userId = (int)$userId;
        if ($courseId <= 0 || $userId <= 0) {
            return $this->normalizeRole($default);
        }

        $map = $this->collectAccessibleUserMap($courseId);
        if (isset($map[$userId]['access_role'])) {
            return $this->normalizeRole($map[$userId]['access_role']);
        }

        /** @var TrainingUserCourse $userCourse */
        $userCourse = $this->modx->getObject('TrainingUserCourse', [
            'course_id' => $courseId,
            'user_id' => $userId,
        ]);
        if ($userCourse) {
            return $this->normalizeRole($userCourse->get('access_role'));
        }

        return $this->normalizeRole($default);
    }

    public function ensureUserCourse($courseId, $userId, $accessRole = 'employee')
    {
        $courseId = (int)$courseId;
        $userId = (int)$userId;
        $accessRole = $this->normalizeRole($accessRole);

        /** @var TrainingUserCourse $userCourse */
        $userCourse = $this->modx->getObject('TrainingUserCourse', [
            'course_id' => $courseId,
            'user_id' => $userId,
        ]);

        if (!$userCourse) {
            $userCourse = $this->modx->newObject('TrainingUserCourse');
            $userCourse->fromArray([
                'course_id' => $courseId,
                'user_id' => $userId,
                'access_role' => $accessRole,
                'status' => 'assigned',
                'current_module_id' => 0,
                'progress_percent' => 0,
                'completed_modules' => 0,
                'total_modules' => 0,
                'startedon' => null,
                'completedon' => null,
                'last_activity' => $this->getNow(),
            ], '', true, true);
            $userCourse->save();
        }

        return $userCourse;
    }

    public function syncUserCourseForUser($courseId, $userId)
    {
        $courseId = (int)$courseId;
        $userId = (int)$userId;
        if ($courseId <= 0 || $userId <= 0) {
            return false;
        }

        $hasAccess = $this->hasCourseAccess($courseId, $userId);
        $now = $this->getNow();

        /** @var TrainingUserCourse $userCourse */
        $userCourse = $this->modx->getObject('TrainingUserCourse', [
            'course_id' => $courseId,
            'user_id' => $userId,
        ]);

        if ($hasAccess) {
            $role = $this->resolveUserAccessRoleForCourse($courseId, $userId, 'employee');
            if (!$userCourse) {
                $userCourse = $this->ensureUserCourse($courseId, $userId, $role);
            }
            $userCourse->set('access_role', $role);
            if ((string)$userCourse->get('status') === 'revoked') {
                $userCourse->set('status', 'assigned');
            }
            $userCourse->set('last_activity', $now);
            $userCourse->save();
            return $this->recalculateUserCourse($courseId, $userId);
        }

        if ($userCourse) {
            if ((string)$userCourse->get('status') !== 'completed') {
                $userCourse->set('status', 'revoked');
            }
            $userCourse->set('last_activity', $now);
            $userCourse->save();
        }

        return $userCourse;
    }

    public function syncUserCourses($courseId)
    {
        $courseId = (int)$courseId;
        if ($courseId <= 0) {
            return [
                'created' => 0,
                'updated' => 0,
                'deactivated' => 0,
                'users' => [],
            ];
        }

        $accessibleUserMap = $this->collectAccessibleUserMap($courseId);
        $accessibleUserIds = array_keys($accessibleUserMap);
        $existing = $this->modx->getIterator('TrainingUserCourse', [
            'course_id' => $courseId,
        ]);

        $existingMap = [];
        /** @var TrainingUserCourse $userCourse */
        foreach ($existing as $userCourse) {
            $existingMap[(int)$userCourse->get('user_id')] = $userCourse;
        }

        $created = 0;
        $updated = 0;
        $deactivated = 0;
        $activeMap = array_fill_keys($accessibleUserIds, true);
        $now = $this->getNow();

        foreach ($accessibleUserMap as $userId => $row) {
            $userId = (int)$userId;
            $accessRole = $this->normalizeRole($row['access_role']);
            $userCourse = isset($existingMap[$userId]) ? $existingMap[$userId] : null;
            if (!$userCourse) {
                $userCourse = $this->ensureUserCourse($courseId, $userId, $accessRole);
                $created++;
            } else {
                if ((string)$userCourse->get('status') === 'revoked') {
                    $userCourse->set('status', 'assigned');
                }
                $userCourse->set('access_role', $accessRole);
                $userCourse->set('last_activity', $now);
                $userCourse->save();
                $updated++;
            }

            $this->recalculateUserCourse($courseId, $userId);
        }

        foreach ($existingMap as $userId => $userCourse) {
            if (isset($activeMap[$userId])) {
                continue;
            }
            if ((string)$userCourse->get('status') !== 'completed') {
                $userCourse->set('status', 'revoked');
            }
            $userCourse->set('last_activity', $now);
            $userCourse->save();
            $deactivated++;
        }

        return [
            'created' => $created,
            'updated' => $updated,
            'deactivated' => $deactivated,
            'users' => $accessibleUserIds,
        ];
    }

    public function getCourseModules($courseId, $onlyActive = true, $requiredOnly = false)
    {
        $courseId = (int)$courseId;
        $c = $this->modx->newQuery('TrainingModule');
        $c->where(['course_id' => $courseId]);
        if ($onlyActive) {
            $c->where(['is_active' => 1]);
        }
        if ($requiredOnly) {
            $c->where(['is_required' => 1]);
        }
        $c->leftJoin('modResource', 'Resource', 'Resource.id = TrainingModule.resource_id');
        $c->sortby('Resource.menuindex', 'ASC');
        $c->sortby('TrainingModule.id', 'ASC');
        return $this->modx->getCollection('TrainingModule', $c);
    }

    public function saveModuleProgress($courseId, $moduleId, $userId, array $data = [])
    {
        $courseId = (int)$courseId;
        $moduleId = (int)$moduleId;
        $userId = (int)$userId;

        if ($courseId <= 0 || $moduleId <= 0 || $userId <= 0) {
            return false;
        }

        /** @var TrainingModule $module */
        $module = $this->modx->getObject('TrainingModule', [
            'id' => $moduleId,
            'course_id' => $courseId,
        ]);
        if (!$module) {
            return false;
        }

        /** @var TrainingUserModuleProgress $progress */
        $progress = $this->modx->getObject('TrainingUserModuleProgress', [
            'module_id' => $moduleId,
            'user_id' => $userId,
        ]);

        if (!$progress) {
            $progress = $this->modx->newObject('TrainingUserModuleProgress');
            $progress->fromArray([
                'course_id' => $courseId,
                'module_id' => $moduleId,
                'user_id' => $userId,
                'status' => 'not_started',
                'current_time' => 0,
                'max_time' => 0,
                'watched_seconds' => 0,
                'duration_seconds' => max(0, (int)$module->get('duration_seconds')),
                'progress_percent' => 0,
                'completed' => 0,
                'completedon' => null,
                'last_watch' => null,
            ], '', true, true);
        }

        $duration = max(0, (int)$module->get('duration_seconds'));
        $currentTime = isset($data['current_time']) ? max(0, (int)$data['current_time']) : (int)$progress->get('current_time');
        if ($duration > 0 && $currentTime > $duration) {
            $currentTime = $duration;
        }

        $maxTime = max((int)$progress->get('max_time'), $currentTime, isset($data['max_time']) ? (int)$data['max_time'] : 0);
        if ($duration > 0 && $maxTime > $duration) {
            $maxTime = $duration;
        }

        $completed = !empty($data['completed']) ? 1 : 0;
        $progressPercent = 0;
        if ($duration > 0) {
            $progressPercent = round(($maxTime / $duration) * 100, 2);
            if ($progressPercent >= 90) {
                $completed = 1;
            }
        } elseif ($maxTime > 0) {
            $progressPercent = 100;
            $completed = 1;
        }

        $now = $this->getNow();
        $status = $completed ? 'completed' : ($maxTime > 0 ? 'in_progress' : 'not_started');

        $progress->set('course_id', $courseId);
        $progress->set('module_id', $moduleId);
        $progress->set('user_id', $userId);
        $progress->set('status', $status);
        $progress->set('current_time', $currentTime);
        $progress->set('max_time', $maxTime);
        $progress->set('watched_seconds', max((int)$progress->get('watched_seconds'), $maxTime));
        $progress->set('duration_seconds', $duration);
        $progress->set('progress_percent', $progressPercent);
        $progress->set('completed', $completed);
        $progress->set('completedon', $completed ? ($progress->get('completedon') ?: $now) : null);
        $progress->set('last_watch', $now);
        $progress->save();

        $this->recalculateUserCourse($courseId, $userId);
        return $progress;
    }

    public function recalculateUserCourse($courseId, $userId)
    {
        $courseId = (int)$courseId;
        $userId = (int)$userId;
        if ($courseId <= 0 || $userId <= 0) {
            return false;
        }

        /** @var TrainingUserCourse $userCourse */
        $userCourse = $this->ensureUserCourse($courseId, $userId, $this->resolveUserAccessRoleForCourse($courseId, $userId, 'employee'));
        if (!$userCourse) {
            return false;
        }

        $requiredModules = $this->getCourseModules($courseId, true, true);
        $requiredIds = [];
        /** @var TrainingModule $module */
        foreach ($requiredModules as $module) {
            $requiredIds[] = (int)$module->get('id');
        }

        if (empty($requiredIds)) {
            $allActiveModules = $this->getCourseModules($courseId, true, false);
            foreach ($allActiveModules as $module) {
                $requiredIds[] = (int)$module->get('id');
            }
        }

        $totalModules = count($requiredIds);
        $completedModules = 0;
        $currentModuleId = 0;
        $started = false;

        if ($totalModules > 0) {
            $progressItems = $this->modx->getCollection('TrainingUserModuleProgress', [
                'course_id' => $courseId,
                'user_id' => $userId,
            ]);

            $progressMap = [];
            /** @var TrainingUserModuleProgress $item */
            foreach ($progressItems as $item) {
                $progressMap[(int)$item->get('module_id')] = $item;
            }

            foreach ($requiredIds as $moduleId) {
                /** @var TrainingUserModuleProgress|null $item */
                $item = isset($progressMap[$moduleId]) ? $progressMap[$moduleId] : null;
                if ($item && (int)$item->get('completed') === 1) {
                    $completedModules++;
                }
                if ($item && ((int)$item->get('max_time') > 0 || (string)$item->get('status') !== 'not_started')) {
                    $started = true;
                }
                if ($currentModuleId <= 0 && (!$item || (int)$item->get('completed') !== 1)) {
                    $currentModuleId = $moduleId;
                }
            }
        }

        $progressPercent = $totalModules > 0 ? round(($completedModules / $totalModules) * 100, 2) : 0;
        $status = 'assigned';
        $completedOn = null;
        $startedOn = $userCourse->get('startedon');

        if ($completedModules > 0 || $started) {
            $status = 'in_progress';
            if (!$startedOn) {
                $startedOn = $this->getNow();
            }
        }

        if ($totalModules > 0 && $completedModules >= $totalModules) {
            $status = 'completed';
            $completedOn = $userCourse->get('completedon') ?: $this->getNow();
            $currentModuleId = 0;
        }

        $userCourse->set('access_role', $this->resolveUserAccessRoleForCourse($courseId, $userId, $userCourse->get('access_role')));
        $userCourse->set('status', $status);
        $userCourse->set('current_module_id', $currentModuleId);
        $userCourse->set('progress_percent', $progressPercent);
        $userCourse->set('completed_modules', $completedModules);
        $userCourse->set('total_modules', $totalModules);
        $userCourse->set('startedon', $startedOn ?: null);
        $userCourse->set('completedon', $completedOn);
        $userCourse->set('last_activity', $this->getNow());
        $userCourse->save();

        return $userCourse;
    }

    public function getUserObject($userId)
    {
        $userId = (int)$userId;
        if ($userId <= 0) {
            return null;
        }

        if ($this->modx->user && (int)$this->modx->user->get('id') === $userId) {
            return $this->modx->user;
        }

        return $this->modx->getObject('modUser', ['id' => $userId]);
    }

    public function getUserLabel($userId)
    {
        $userId = (int)$userId;
        if ($userId <= 0) {
            return '—';
        }

        $user = $this->getUserObject($userId);
        if (!$user) {
            return '—';
        }

        $profile = $user->getOne('Profile');
        $fullname = $profile ? trim((string)$profile->get('fullname')) : '';
        $email = $profile ? trim((string)$profile->get('email')) : '';
        $username = trim((string)$user->get('username'));

        $label = '#' . $userId . ' ' . $username;
        if ($fullname !== '') {
            $label .= ' (' . $fullname . ')';
        }
        if ($email !== '') {
            $label .= ' [' . $email . ']';
        }

        return $label;
    }

    public function isAdminUser($userId = 0)
    {
        $userId = (int)$userId;
        if ($userId <= 0 && $this->modx->user) {
            $userId = (int)$this->modx->user->get('id');
        }
        if ($userId <= 0) {
            return false;
        }

        if ($this->modx->user && (int)$this->modx->user->get('id') === $userId) {
            if ($this->modx->hasPermission('sudo') || $this->modx->hasPermission('settings')) {
                return true;
            }
        }

        $user = $this->getUserObject($userId);
        if (!$user) {
            return false;
        }

        if (method_exists($user, 'isMember')) {
            if ($user->isMember('Administrator') || $user->isMember('Администратор')) {
                return true;
            }
        }

        return false;
    }

    public function getManagedUserIds($managerUserId, $onlyActive = true)
    {
        $managerUserId = (int)$managerUserId;
        if ($managerUserId <= 0) {
            return [];
        }

        $criteria = [
            'manager_user_id' => $managerUserId,
        ];
        if ($onlyActive) {
            $criteria['is_active'] = 1;
        }

        $ids = [];
        $items = $this->modx->getIterator('TrainingUserManagerLink', $criteria);
        foreach ($items as $item) {
            $employeeId = (int)$item->get('employee_user_id');
            if ($employeeId > 0) {
                $ids[$employeeId] = $employeeId;
            }
        }

        ksort($ids);
        return array_values($ids);
    }

    public function isManagerOfUser($managerUserId, $employeeUserId, $onlyActive = true)
    {
        $managerUserId = (int)$managerUserId;
        $employeeUserId = (int)$employeeUserId;
        if ($managerUserId <= 0 || $employeeUserId <= 0 || $managerUserId === $employeeUserId) {
            return false;
        }

        $criteria = [
            'manager_user_id' => $managerUserId,
            'employee_user_id' => $employeeUserId,
        ];
        if ($onlyActive) {
            $criteria['is_active'] = 1;
        }

        return $this->modx->getCount('TrainingUserManagerLink', $criteria) > 0;
    }

    public function canAssignCourseToUser($actorUserId, $targetUserId)
    {
        $actorUserId = (int)$actorUserId;
        $targetUserId = (int)$targetUserId;
        if ($actorUserId <= 0 || $targetUserId <= 0) {
            return false;
        }

        if ($this->isAdminUser($actorUserId)) {
            return true;
        }

        if ($actorUserId === $targetUserId) {
            return true;
        }

        return $this->isManagerOfUser($actorUserId, $targetUserId, true);
    }

    public function getAssignableUserIds($actorUserId, $includeSelf = true)
    {
        $actorUserId = (int)$actorUserId;
        if ($actorUserId <= 0) {
            return [];
        }

        if ($this->isAdminUser($actorUserId)) {
            $ids = [];
            $users = $this->modx->getIterator('modUser');
            foreach ($users as $user) {
                $uid = (int)$user->get('id');
                if ($uid > 0) {
                    $ids[$uid] = $uid;
                }
            }
            ksort($ids);
            return array_values($ids);
        }

        $ids = array_fill_keys($this->getManagedUserIds($actorUserId, true), true);
        if ($includeSelf) {
            $ids[$actorUserId] = true;
        }

        $result = array_keys($ids);
        sort($result, SORT_NUMERIC);
        return $result;
    }

    public function getDirectUserAccess($courseId, $userId)
    {
        $courseId = (int)$courseId;
        $userId = (int)$userId;
        if ($courseId <= 0 || $userId <= 0) {
            return null;
        }

        return $this->modx->getObject('TrainingCourseAccess', [
            'course_id' => $courseId,
            'principal_type' => 'user',
            'principal_id' => $userId,
        ]);
    }

    public function assignCourseAccessToUser($courseId, $targetUserId, $actorUserId, array $options = [])
    {
        $courseId = (int)$courseId;
        $targetUserId = (int)$targetUserId;
        $actorUserId = (int)$actorUserId;
        if ($courseId <= 0 || $targetUserId <= 0 || $actorUserId <= 0) {
            return [
                'success' => false,
                'message' => 'Некорректные параметры назначения',
            ];
        }

        if (!$this->canAssignCourseToUser($actorUserId, $targetUserId)) {
            return [
                'success' => false,
                'message' => 'Недостаточно прав для назначения курса этому пользователю',
            ];
        }

        $accessRole = isset($options['access_role']) ? $this->normalizeRole($options['access_role']) : 'employee';
        if (!$this->isAdminUser($actorUserId) && $actorUserId !== $targetUserId) {
            $accessRole = 'employee';
        }

        $activeFrom = isset($options['active_from']) ? $this->normalizeDateTimeValue($options['active_from']) : null;
        $activeTo = isset($options['active_to']) ? $this->normalizeDateTimeValue($options['active_to']) : null;
        $isActive = isset($options['is_active']) ? (int)((string)$options['is_active'] === '0' ? 0 : 1) : 1;

        /** @var TrainingCourseAccess $access */
        $access = $this->getDirectUserAccess($courseId, $targetUserId);
        $created = false;
        if (!$access) {
            $access = $this->modx->newObject('TrainingCourseAccess');
            $created = true;
        }

        $access->fromArray([
            'course_id' => $courseId,
            'principal_type' => 'user',
            'principal_id' => $targetUserId,
            'access_role' => $accessRole,
            'is_active' => $isActive,
            'active_from' => $activeFrom,
            'active_to' => $activeTo,
            'assigned_by' => $actorUserId,
        ], '', true, true);

        if ($created && !$access->get('createdon')) {
            $access->set('createdon', $this->getNow());
        }

        if (!$access->save()) {
            return [
                'success' => false,
                'message' => 'Не удалось сохранить назначение курса',
            ];
        }

        $this->syncUserCourseForUser($courseId, $targetUserId);

        return [
            'success' => true,
            'created' => $created,
            'access' => $access,
            'user_course' => $this->modx->getObject('TrainingUserCourse', [
                'course_id' => $courseId,
                'user_id' => $targetUserId,
            ]),
        ];
    }

    public function revokeCourseAccessForUser($courseId, $targetUserId, $actorUserId)
    {
        $courseId = (int)$courseId;
        $targetUserId = (int)$targetUserId;
        $actorUserId = (int)$actorUserId;
        if ($courseId <= 0 || $targetUserId <= 0 || $actorUserId <= 0) {
            return [
                'success' => false,
                'message' => 'Некорректные параметры снятия доступа',
            ];
        }

        if (!$this->canAssignCourseToUser($actorUserId, $targetUserId)) {
            return [
                'success' => false,
                'message' => 'Недостаточно прав для снятия доступа у этого пользователя',
            ];
        }

        /** @var TrainingCourseAccess $access */
        $access = $this->getDirectUserAccess($courseId, $targetUserId);
        if ($access) {
            $access->remove();
        }

        $userCourse = $this->syncUserCourseForUser($courseId, $targetUserId);

        return [
            'success' => true,
            'removed' => (bool)$access,
            'has_access_now' => $this->hasCourseAccess($courseId, $targetUserId),
            'user_course' => $userCourse,
        ];
    }

    public function getMyCourses($userId, array $options = [])
    {
        $userId = (int)$userId;
        if ($userId <= 0) {
            return [];
        }

        $includeRevoked = !empty($options['include_revoked']);
        $recalculate = !empty($options['recalculate']);
        $limit = isset($options['limit']) ? max(0, (int)$options['limit']) : 0;
        $start = isset($options['start']) ? max(0, (int)$options['start']) : 0;

        $c = $this->modx->newQuery('TrainingUserCourse');
        $c->where([
            'TrainingUserCourse.user_id' => $userId,
        ]);
        if (!$includeRevoked) {
            $c->where([
                'TrainingUserCourse.status:!=' => 'revoked',
            ]);
        }

        $c->leftJoin('TrainingCourse', 'Course', 'Course.id = TrainingUserCourse.course_id');
        $c->leftJoin('modResource', 'Resource', 'Resource.id = Course.resource_id');
        $c->select([
            $this->modx->getSelectColumns('TrainingUserCourse', 'TrainingUserCourse'),
            'Course.resource_id AS resource_id',
            'Course.is_active AS course_is_active',
            'Course.is_sequential AS is_sequential',
            'Resource.pagetitle AS pagetitle',
            'Resource.longtitle AS longtitle',
            'Resource.description AS description',
            'Resource.uri AS uri',
            'Resource.published AS published',
            'Resource.menuindex AS menuindex',
        ]);
        $c->sortby('Resource.menuindex', 'ASC');
        $c->sortby('TrainingUserCourse.course_id', 'ASC');
        if ($limit > 0) {
            $c->limit($limit, $start);
        }

        $rows = [];
        if ($c->prepare() && $c->stmt->execute()) {
            while ($row = $c->stmt->fetch(PDO::FETCH_ASSOC)) {
                $courseId = (int)$row['course_id'];
                if ($recalculate && $courseId > 0) {
                    $this->recalculateUserCourse($courseId, $userId);
                    $userCourse = $this->modx->getObject('TrainingUserCourse', [
                        'course_id' => $courseId,
                        'user_id' => $userId,
                    ]);
                    if ($userCourse) {
                        $row = array_merge($row, $userCourse->toArray());
                    }
                }

                $rows[] = [
                    'course_id' => $courseId,
                    'resource_id' => (int)$row['resource_id'],
                    'pagetitle' => (string)$row['pagetitle'],
                    'longtitle' => (string)$row['longtitle'],
                    'description' => (string)$row['description'],
                    'uri' => (string)$row['uri'],
                    'published' => (int)$row['published'],
                    'course_is_active' => (int)$row['course_is_active'],
                    'is_sequential' => (int)$row['is_sequential'],
                    'access_role' => $this->normalizeRole($row['access_role']),
                    'status' => (string)$row['status'],
                    'current_module_id' => (int)$row['current_module_id'],
                    'progress_percent' => (float)$row['progress_percent'],
                    'completed_modules' => (int)$row['completed_modules'],
                    'total_modules' => (int)$row['total_modules'],
                    'startedon' => $row['startedon'],
                    'completedon' => $row['completedon'],
                    'last_activity' => $row['last_activity'],
                ];
            }
        }

        return $rows;
    }
}
