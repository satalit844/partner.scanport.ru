Fix for manager links getlist 500.

Replace file:
training/processors/mgr/managerlink/_helpers.php

Then clear MODX cache and hard refresh manager.
