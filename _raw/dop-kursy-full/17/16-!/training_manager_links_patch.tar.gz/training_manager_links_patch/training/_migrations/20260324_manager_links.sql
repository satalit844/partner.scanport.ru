-- Замени имя таблицы на своё полное имя по аналогии с существующей training_course_access.
-- Например, если у тебя сейчас таблица называется modx_partnerstraining_course_access,
-- то новую таблицу создай как modx_partnerstraining_user_manager_link.

CREATE TABLE `modx_partnerstraining_user_manager_link` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `manager_user_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `employee_user_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `createdon` DATETIME NULL,
  `createdby` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `manager_employee` (`manager_user_id`,`employee_user_id`),
  KEY `manager_user_id` (`manager_user_id`),
  KEY `employee_user_id` (`employee_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
