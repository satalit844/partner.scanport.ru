Замена для этапа: Управление курсами

Файлы:
- theme/js/app-training.js
- theme/css/training.css
- core/components/training/elements/snippets/snippet.trainingManageCoursesPage.php
- core/components/training/elements/chunks/training/manage/courses.tpl
- core/components/training/elements/chunks/training/manage/request-course-modal.tpl
- resource-content/Управление курсами.tpl

Что делает:
- выводит список доступных директору курсов в слайдере
- поиск идет по сотрудникам директора
- bulk-кнопки Активировать / Заблокировать работают через текущий web.connector.php
- добавлена bootstrap-модалка-заглушка Запросить курс
- swiper инициализируется на странице управления курсами
