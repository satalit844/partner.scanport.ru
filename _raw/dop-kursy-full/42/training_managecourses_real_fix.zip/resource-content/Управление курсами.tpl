[[!trainingManageCoursesPage]]
