<?php
/** @var modX $modx */

if (!function_exists('trainingManageCoursesPageRenderFile')) {
    function trainingManageCoursesPageRenderFile(modX $modx, $path, array $placeholders = [])
    {
        if (!is_file($path)) {
            return '';
        }

        /** @var modChunk $chunk */
        $chunk = $modx->newObject('modChunk');
        $chunk->setCacheable(false);
        $chunk->setContent(file_get_contents($path));

        return $chunk->process($placeholders);
    }
}

$userId = (int)$modx->user->get('id');
if ($userId <= 0) {
    return '';
}

$corePath = $modx->getOption(
    'training.core_path',
    null,
    $modx->getOption('core_path') . 'components/training/'
);
$corePath = rtrim($corePath, '/\\') . '/';

$trainingClassPath = $corePath . 'model/training/training.class.php';
$progressServicePath = $corePath . 'model/training/services/trainingprogress.class.php';
if (is_file($trainingClassPath)) {
    require_once $trainingClassPath;
}
if (is_file($progressServicePath)) {
    require_once $progressServicePath;
}

$chunkBase = $corePath . 'elements/chunks/training/manage/';
$pageChunkPath = $chunkBase . 'courses.tpl';
$modalChunkPath = $chunkBase . 'request-course-modal.tpl';
$accessModalChunkPath = $chunkBase . 'course-access-modal.tpl';

$courses = [];
$coursesMap = [];

$addCourse = function ($courseId, $resourceId, $title = '') use (&$courses, &$coursesMap) {
    $courseId = (int)$courseId;
    $resourceId = (int)$resourceId;
    $title = trim((string)$title);

    if ($courseId <= 0 || $resourceId <= 0 || isset($coursesMap[$courseId])) {
        return;
    }

    $coursesMap[$courseId] = true;
    $courses[] = [
        'course_id' => $courseId,
        'resource_id' => $resourceId,
        'title' => $title !== '' ? $title : ('Курс #' . $courseId),
    ];
};

// 1. Пытаемся взять курсы через сервис компонента.
if (class_exists('TrainingProgressService') && class_exists('Training')) {
    try {
        $service = new TrainingProgressService($modx, new Training($modx));
        $manageableCourseIds = (array)$service->getManageableCourseIds($userId);

        if (!empty($manageableCourseIds)) {
            $query = $modx->newQuery('TrainingCourse');
            $query->leftJoin('modResource', 'Resource', 'Resource.id = TrainingCourse.resource_id');
            $query->where([
                'TrainingCourse.id:IN' => array_values(array_unique(array_map('intval', $manageableCourseIds))),
                'TrainingCourse.is_active' => 1,
            ]);
            $query->select([
                'TrainingCourse.id AS course_id',
                'TrainingCourse.resource_id AS resource_id',
                'Resource.pagetitle AS title',
            ]);
            $query->sortby('TrainingCourse.id', 'ASC');

            if ($query->prepare() && $query->stmt->execute()) {
                while ($row = $query->stmt->fetch(PDO::FETCH_ASSOC)) {
                    $addCourse($row['course_id'], $row['resource_id'], $row['title']);
                }
            }
        }
    } catch (Exception $e) {
        // fallback ниже
    }
}

// 2. Fallback по прямым правам директора на курс.
if (empty($courses)) {
    $courseAccessTable = $modx->getOption('table_prefix') . 'partnerstraining_course_access';
    $coursesTable = $modx->getOption('table_prefix') . 'partnerstraining_courses';
    $userCoursesTable = $modx->getOption('table_prefix') . 'partnerstraining_user_courses';
    $resourceTable = $modx->getTableName('modResource');
    $now = date('Y-m-d H:i:s');

    $sqlAccess = "
        SELECT DISTINCT
            ca.course_id AS course_id,
            c.resource_id AS resource_id,
            COALESCE(NULLIF(TRIM(r.pagetitle), ''), CONCAT('Курс #', ca.course_id)) AS title
        FROM {$courseAccessTable} ca
        INNER JOIN {$coursesTable} c ON c.id = ca.course_id AND c.is_active = 1
        LEFT JOIN {$resourceTable} r ON r.id = c.resource_id AND r.deleted = 0
        WHERE ca.principal_type = 'user'
          AND ca.principal_id = :user_id
          AND ca.access_role = 'director'
          AND ca.is_active = 1
          AND (ca.active_from IS NULL OR ca.active_from = '0000-00-00 00:00:00' OR ca.active_from <= :now)
          AND (ca.active_to IS NULL OR ca.active_to = '0000-00-00 00:00:00' OR ca.active_to >= :now)
        ORDER BY ca.course_id ASC
    ";

    $stmt = $modx->prepare($sqlAccess);
    if ($stmt) {
        $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindValue(':now', $now, PDO::PARAM_STR);
        if ($stmt->execute()) {
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $addCourse($row['course_id'], $row['resource_id'], $row['title']);
            }
        }
    }

    // 3. Дополнительный fallback по user_courses для директора.
    if (empty($courses)) {
        $sqlUserCourses = "
            SELECT DISTINCT
                uc.course_id AS course_id,
                c.resource_id AS resource_id,
                COALESCE(NULLIF(TRIM(r.pagetitle), ''), CONCAT('Курс #', uc.course_id)) AS title
            FROM {$userCoursesTable} uc
            INNER JOIN {$coursesTable} c ON c.id = uc.course_id AND c.is_active = 1
            LEFT JOIN {$resourceTable} r ON r.id = c.resource_id AND r.deleted = 0
            WHERE uc.user_id = :user_id
              AND uc.access_role = 'director'
              AND uc.status <> 'revoked'
            ORDER BY uc.course_id ASC
        ";
        $stmt = $modx->prepare($sqlUserCourses);
        if ($stmt) {
            $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
            if ($stmt->execute()) {
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $addCourse($row['course_id'], $row['resource_id'], $row['title']);
                }
            }
        }
    }
}

$coursesButtons = '';
if (!empty($courses)) {
    foreach ($courses as $index => $course) {
        $coursesButtons .= '<div class="swiper-slide w-auto">';
        $coursesButtons .= '<button type="button" class="course-filter__chip' . ($index === 0 ? ' is-active' : '') . '"';
        $coursesButtons .= ' data-course-id="' . (int)$course['course_id'] . '"';
        $coursesButtons .= ' data-resource-id="' . (int)$course['resource_id'] . '"';
        $coursesButtons .= ' data-filter="course_' . (int)$course['course_id'] . '"';
        $coursesButtons .= ' aria-selected="' . ($index === 0 ? 'true' : 'false') . '">';
        $coursesButtons .= htmlspecialchars($course['title'], ENT_QUOTES, 'UTF-8');
        $coursesButtons .= '</button>';
        $coursesButtons .= '</div>';
    }
} else {
    $coursesButtons = '<div class="manage-courses-empty">Доступных курсов пока нет</div>';
}

return trainingManageCoursesPageRenderFile($modx, $pageChunkPath, [
    'context_key' => $modx->context->get('key'),
    'available_count' => count($courses),
    'courses_buttons' => $coursesButtons,
    'controls_disabled' => empty($courses) ? ' disabled="disabled"' : '',
    'request_modal' => trainingManageCoursesPageRenderFile($modx, $modalChunkPath, []),
    'course_access_modal' => trainingManageCoursesPageRenderFile($modx, $accessModalChunkPath, []),
]);
