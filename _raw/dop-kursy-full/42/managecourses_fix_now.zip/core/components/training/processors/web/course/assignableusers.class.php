<?php

require_once dirname(dirname(__FILE__)) . '/_helpers.php';

class TrainingWebCourseAssignableUsersProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    protected function formatDateValue($value)
    {
        if ($value === null || $value === '' || $value === '0000-00-00 00:00:00' || $value === 0 || $value === '0') {
            return '—';
        }

        $ts = is_numeric($value) ? (int)$value : strtotime((string)$value);
        if (!$ts) {
            return '—';
        }

        return date('d.m.Y H:i', $ts);
    }

    protected function decodeExtended($value)
    {
        if (is_array($value)) {
            return $value;
        }

        $value = trim((string)$value);
        if ($value === '') {
            return [];
        }

        $decoded = json_decode($value, true);
        return is_array($decoded) ? $decoded : [];
    }

    protected function extractOrganization($extended)
    {
        $extended = $this->decodeExtended($extended);
        $keys = [
            'company',
            'organization',
            'organisation',
            'org',
            'company_name',
            'organisation_name',
            'employer',
            'workplace',
        ];

        foreach ($keys as $key) {
            if (!empty($extended[$key])) {
                return trim((string)$extended[$key]);
            }
        }

        return '';
    }

    protected function actorCanManageCourse($actorUserId, $courseId)
    {
        $actorUserId = (int)$actorUserId;
        $courseId = (int)$courseId;
        if ($actorUserId <= 0 || $courseId <= 0) {
            return false;
        }

        $prefix = $this->modx->getOption('table_prefix', null, 'modx_');
        $courseAccessTable = $prefix . 'partnerstraining_course_access';
        $userCoursesTable = $prefix . 'partnerstraining_user_courses';

        $now = date('Y-m-d H:i:s');

        $sql = "
            SELECT 1
            FROM {$courseAccessTable}
            WHERE course_id = :course_id
              AND principal_type = 'user'
              AND principal_id = :user_id
              AND access_role = 'director'
              AND is_active = 1
              AND (active_from IS NULL OR active_from = '0000-00-00 00:00:00' OR active_from <= :now)
              AND (active_to IS NULL OR active_to = '0000-00-00 00:00:00' OR active_to >= :now)
            LIMIT 1
        ";

        $stmt = $this->modx->prepare($sql);
        if ($stmt) {
            $stmt->bindValue(':course_id', $courseId, PDO::PARAM_INT);
            $stmt->bindValue(':user_id', $actorUserId, PDO::PARAM_INT);
            $stmt->bindValue(':now', $now, PDO::PARAM_STR);
            if ($stmt->execute() && $stmt->fetchColumn()) {
                return true;
            }
        }

        $sql = "
            SELECT 1
            FROM {$userCoursesTable}
            WHERE course_id = :course_id
              AND user_id = :user_id
              AND access_role = 'director'
              AND status <> 'revoked'
            LIMIT 1
        ";
        $stmt = $this->modx->prepare($sql);
        if ($stmt) {
            $stmt->bindValue(':course_id', $courseId, PDO::PARAM_INT);
            $stmt->bindValue(':user_id', $actorUserId, PDO::PARAM_INT);
            if ($stmt->execute() && $stmt->fetchColumn()) {
                return true;
            }
        }

        return false;
    }

    protected function buildState($hasAccess, array $userCourseRow = [], $directAccessId = 0)
    {
        $progressPercent = isset($userCourseRow['progress_percent']) ? (float)$userCourseRow['progress_percent'] : 0;
        $status = isset($userCourseRow['status']) ? (string)$userCourseRow['status'] : '';

        if (!$hasAccess) {
            return [
                'state' => 'new',
                'status_text' => 'Не начат',
                'status_class' => 'label-chip--blue',
                'can_unassign' => 0,
            ];
        }

        if ($status === 'completed' || $progressPercent >= 100) {
            return [
                'state' => 'done',
                'status_text' => 'Завершено',
                'status_class' => 'label-chip--green',
                'can_unassign' => $directAccessId > 0 ? 1 : 0,
            ];
        }

        if ($status === 'in_progress' || $progressPercent > 0) {
            return [
                'state' => 'progress',
                'status_text' => 'В процессе - ' . round($progressPercent) . '%',
                'status_class' => 'label-chip--purple',
                'can_unassign' => $directAccessId > 0 ? 1 : 0,
            ];
        }

        return [
            'state' => 'new',
            'status_text' => 'Не начат',
            'status_class' => 'label-chip--blue',
            'can_unassign' => $directAccessId > 0 ? 1 : 0,
        ];
    }

    public function process()
    {
        if ($failure = TrainingWebHelper::requireAuth($this)) {
            return $failure;
        }

        $actorUserId = (int)$this->modx->user->get('id');
        $courseId = TrainingWebHelper::resolveCourseId(
            $this->modx,
            (int)$this->getProperty('course_id', 0),
            (int)$this->getProperty('resource_id', 0)
        );
        $query = trim((string)$this->getProperty('query', ''));

        if ($courseId <= 0 || !$this->actorCanManageCourse($actorUserId, $courseId)) {
            return $this->success('', [
                'course_id' => $courseId,
                'total' => 0,
                'results' => [],
            ]);
        }

        $managerLinks = $this->modx->getIterator('TrainingUserManagerLink', [
            'manager_user_id' => $actorUserId,
            'is_active' => 1,
        ]);

        $employeeIds = [];
        /** @var TrainingUserManagerLink $link */
        foreach ($managerLinks as $link) {
            $employeeId = (int)$link->get('employee_user_id');
            if ($employeeId > 0 && $employeeId !== $actorUserId) {
                $employeeIds[$employeeId] = $employeeId;
            }
        }

        $employeeIds = array_values($employeeIds);
        sort($employeeIds, SORT_NUMERIC);

        if (empty($employeeIds)) {
            return $this->success('', [
                'course_id' => $courseId,
                'total' => 0,
                'results' => [],
            ]);
        }

        $prefix = $this->modx->getOption('table_prefix', null, 'modx_');
        $courseAccessTable = $prefix . 'partnerstraining_course_access';
        $userCoursesTable = $prefix . 'partnerstraining_user_courses';

        $now = date('Y-m-d H:i:s');
        $directAccessMap = [];
        $userCourseMap = [];

        $placeholders = implode(',', array_fill(0, count($employeeIds), '?'));

        $sqlAccess = "
            SELECT id, principal_id
            FROM {$courseAccessTable}
            WHERE course_id = ?
              AND principal_type = 'user'
              AND principal_id IN ({$placeholders})
              AND is_active = 1
              AND (active_from IS NULL OR active_from = '0000-00-00 00:00:00' OR active_from <= ?)
              AND (active_to IS NULL OR active_to = '0000-00-00 00:00:00' OR active_to >= ?)
        ";
        $stmtAccess = $this->modx->prepare($sqlAccess);
        if ($stmtAccess) {
            $params = array_merge([$courseId], $employeeIds, [$now, $now]);
            if ($stmtAccess->execute($params)) {
                while ($row = $stmtAccess->fetch(PDO::FETCH_ASSOC)) {
                    $directAccessMap[(int)$row['principal_id']] = (int)$row['id'];
                }
            }
        }

        $sqlUserCourses = "
            SELECT user_id, status, progress_percent, startedon, last_activity
            FROM {$userCoursesTable}
            WHERE course_id = ?
              AND user_id IN ({$placeholders})
        ";
        $stmtUserCourses = $this->modx->prepare($sqlUserCourses);
        if ($stmtUserCourses) {
            $params = array_merge([$courseId], $employeeIds);
            if ($stmtUserCourses->execute($params)) {
                while ($row = $stmtUserCourses->fetch(PDO::FETCH_ASSOC)) {
                    $userCourseMap[(int)$row['user_id']] = $row;
                }
            }
        }

        $c = $this->modx->newQuery('modUser');
        $c->leftJoin('modUserProfile', 'Profile', 'Profile.internalKey = modUser.id');
        $c->where([
            'modUser.id:IN' => $employeeIds,
        ]);

        if ($query !== '') {
            $c->where([
                'modUser.username:LIKE' => '%' . $query . '%',
                'OR:Profile.fullname:LIKE' => '%' . $query . '%',
                'OR:Profile.email:LIKE' => '%' . $query . '%',
            ]);
        }

        $c->select([
            'modUser.id AS id',
            'modUser.username AS username',
            'Profile.fullname AS fullname',
            'Profile.email AS email',
            'Profile.extended AS extended',
            'Profile.lastlogin AS lastlogin',
        ]);
        $c->sortby('Profile.fullname', 'ASC');
        $c->sortby('modUser.username', 'ASC');

        $rows = [];
        if ($c->prepare() && $c->stmt->execute()) {
            while ($row = $c->stmt->fetch(PDO::FETCH_ASSOC)) {
                $userId = (int)$row['id'];
                $fullname = trim((string)$row['fullname']);
                $email = trim((string)$row['email']);
                $username = trim((string)$row['username']);
                $organization = $this->extractOrganization($row['extended']);

                $displayName = $fullname !== '' ? $fullname : $username;
                $label = '#' . $userId . ' ' . $username;
                if ($fullname !== '') {
                    $label .= ' (' . $fullname . ')';
                }
                if ($email !== '') {
                    $label .= ' [' . $email . ']';
                }

                $userCourseRow = isset($userCourseMap[$userId]) ? $userCourseMap[$userId] : [];
                $directAccessId = isset($directAccessMap[$userId]) ? (int)$directAccessMap[$userId] : 0;
                $hasAccess = $directAccessId > 0;
                $state = $this->buildState($hasAccess, $userCourseRow, $directAccessId);

                $progressPercent = isset($userCourseRow['progress_percent']) ? round((float)$userCourseRow['progress_percent']) : 0;
                $startedOn = isset($userCourseRow['startedon']) ? $userCourseRow['startedon'] : null;

                $rows[] = [
                    'id' => $userId,
                    'name' => $label,
                    'display' => $label,
                    'display_name' => $displayName,
                    'username' => $username,
                    'fullname' => $fullname,
                    'email' => $email,
                    'organization' => $organization !== '' ? $organization : '—',
                    'scope' => 'managed',

                    'course_id' => $courseId,
                    'has_access' => $hasAccess ? 1 : 0,
                    'direct_access_id' => $directAccessId,
                    'direct_access_role' => $hasAccess ? 'employee' : '',
                    'resolved_access_role' => 'employee',

                    'user_course_status' => isset($userCourseRow['status']) ? (string)$userCourseRow['status'] : '',
                    'progress_percent' => $progressPercent,
                    'startedon' => $startedOn,
                    'startedon_formatted' => $this->formatDateValue($startedOn),
                    'last_login' => $row['lastlogin'],
                    'last_login_formatted' => $this->formatDateValue($row['lastlogin']),

                    'state' => $state['state'],
                    'status_text' => $state['status_text'],
                    'status_class' => $state['status_class'],
                    'show_assign_button' => 0,
                    'show_status_chip' => 1,
                    'button_text' => '',
                    'button_class' => '',

                    'can_assign' => $hasAccess ? 0 : 1,
                    'can_unassign' => $state['can_unassign'],
                ];
            }
        }

        return $this->success('', [
            'course_id' => $courseId,
            'total' => count($rows),
            'results' => $rows,
        ]);
    }
}

return 'TrainingWebCourseAssignableUsersProcessor';
