<?php
/** @var modX $modx */

if (!function_exists('trainingManageCoursesPageRenderFile')) {
    function trainingManageCoursesPageRenderFile(modX $modx, $path, array $placeholders = [])
    {
        if (!is_file($path)) {
            return '';
        }

        $chunk = $modx->newObject('modChunk');
        $chunk->setCacheable(false);
        $chunk->setContent(file_get_contents($path));

        return $chunk->process($placeholders);
    }
}

$userId = (int)$modx->user->get('id');
if ($userId <= 0) {
    return '';
}

$corePath = $modx->getOption(
    'training.core_path',
    null,
    $modx->getOption('core_path') . 'components/training/'
);

$chunkBase = rtrim($corePath, '/\\') . '/elements/chunks/training/manage/';
$pageChunkPath = $chunkBase . 'courses.tpl';
$modalChunkPath = $chunkBase . 'request-course-modal.tpl';
$accessModalChunkPath = $chunkBase . 'course-access-modal.tpl';

$userCoursesTable = $modx->getOption('table_prefix') . 'partnerstraining_user_courses';
$coursesTable = $modx->getOption('table_prefix') . 'partnerstraining_courses';
$resourceTable = $modx->getTableName('modResource');

$sql = "
    SELECT DISTINCT
        uc.course_id,
        c.resource_id,
        COALESCE(NULLIF(TRIM(r.pagetitle), ''), CONCAT('Курс #', uc.course_id)) AS title
    FROM {$userCoursesTable} AS uc
    INNER JOIN {$coursesTable} AS c
        ON c.id = uc.course_id
       AND c.is_active = 1
    LEFT JOIN {$resourceTable} AS r
        ON r.id = c.resource_id
       AND r.deleted = 0
       AND r.published = 1
    WHERE uc.user_id = :user_id
      AND uc.access_role = 'director'
      AND uc.status <> 'revoked'
    ORDER BY uc.course_id ASC
";

$stmt = $modx->prepare($sql);
$stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);

$courses = [];
if ($stmt->execute()) {
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $courseId = (int)$row['course_id'];
        $resourceId = (int)$row['resource_id'];
        if ($courseId <= 0 || $resourceId <= 0) {
            continue;
        }

        $courses[] = [
            'course_id' => $courseId,
            'resource_id' => $resourceId,
            'title' => trim((string)$row['title']) !== '' ? trim((string)$row['title']) : ('Курс #' . $courseId),
        ];
    }
}

$coursesButtons = '';
if (!empty($courses)) {
    foreach ($courses as $index => $course) {
        $coursesButtons .= '<div class="swiper-slide w-auto">';
        $coursesButtons .= '<button type="button" class="course-filter__chip' . ($index === 0 ? ' is-active' : '') . '"';
        $coursesButtons .= ' data-course-id="' . (int)$course['course_id'] . '"';
        $coursesButtons .= ' data-resource-id="' . (int)$course['resource_id'] . '"';
        $coursesButtons .= ' data-filter="course_' . (int)$course['course_id'] . '"';
        $coursesButtons .= ' aria-selected="' . ($index === 0 ? 'true' : 'false') . '">';
        $coursesButtons .= htmlspecialchars($course['title'], ENT_QUOTES, 'UTF-8');
        $coursesButtons .= '</button>';
        $coursesButtons .= '</div>';
    }
} else {
    $coursesButtons = '<div class="manage-courses-empty">Доступных курсов пока нет</div>';
}

$hasCourses = !empty($courses);

return trainingManageCoursesPageRenderFile($modx, $pageChunkPath, [
    'context_key' => $modx->context->get('key'),
    'available_count' => count($courses),
    'courses_buttons' => $coursesButtons,
    'controls_disabled' => $hasCourses ? '' : ' disabled="disabled"',
    'request_modal' => trainingManageCoursesPageRenderFile($modx, $modalChunkPath, []),
    'course_access_modal' => trainingManageCoursesPageRenderFile($modx, $accessModalChunkPath, []),
]);
