<?php

require_once __DIR__ . '/_helpers.php';

class TrainingModuleTestLinkUpdateProcessor extends modObjectUpdateProcessor
{
    public $classKey = 'TrainingTestLink';
    public $objectType = 'training.module.testlink';

    public function checkPermissions()
    {
        return true;
    }

    public function initialize()
    {
        if (!TrainingModuleTestLinkHelper::ensureUserTestPackage($this->modx)) {
            return 'Не удалось подключить компонент usertest';
        }

        return parent::initialize();
    }

    public function beforeSet()
    {
        $id = (int)$this->getProperty('id');
        if ($id <= 0) {
            return 'Не указана привязка';
        }

        $moduleId = (int)$this->getProperty('module_id', $this->object ? $this->object->get('module_id') : 0);
        $courseId = (int)$this->getProperty('course_id', $this->object ? $this->object->get('course_id') : 0);
        $testId = (int)$this->getProperty('usertest_test_id', $this->object ? $this->object->get('usertest_test_id') : 0);
        $linkType = TrainingModuleTestLinkHelper::normalizeLinkType($this->getProperty('link_type', $this->object ? $this->object->get('link_type') : 'test'));
        $sortOrder = (int)$this->getProperty('sort_order', $this->object ? $this->object->get('sort_order') : 0);

        if ($moduleId <= 0) {
            return 'Не указан модуль';
        }

        /** @var TrainingModule $module */
        $module = TrainingModuleTestLinkHelper::getModule($this->modx, $moduleId);
        if (!$module) {
            return 'Модуль не найден';
        }

        $resolvedCourseId = (int)$module->get('course_id');
        if ($resolvedCourseId <= 0) {
            return 'У модуля не найден курс';
        }
        if ($courseId > 0 && $courseId !== $resolvedCourseId) {
            return 'Модуль не принадлежит указанному курсу';
        }

        if ($testId <= 0) {
            return 'Не выбран тест';
        }

        $test = TrainingModuleTestLinkHelper::getUserTestObject($this->modx, $testId);
        if (!$test) {
            return 'Выбранный тест не найден';
        }

        if (TrainingModuleTestLinkHelper::findDuplicate($this->modx, $resolvedCourseId, $moduleId, $testId, $linkType, $id)) {
            return 'Такая привязка уже существует';
        }

        if ($sortOrder <= 0) {
            $sortOrder = 1;
        }

        $this->setProperty('course_id', $resolvedCourseId);
        $this->setProperty('module_id', $moduleId);
        $this->setProperty('usertest_test_id', $testId);
        $this->setProperty('link_type', $linkType);
        $this->setProperty('sort_order', $sortOrder);
        $this->setProperty('is_required', TrainingModuleTestLinkHelper::boolValue($this->getProperty('is_required', 1), 1));
        $this->setProperty('max_attempts', max(0, (int)$this->getProperty('max_attempts', 0)));
        $this->setProperty('min_pass_percent', max(0, min(100, (float)$this->getProperty('min_pass_percent', 0))));
        $this->setProperty(
            'block_next_module_until_passed',
            TrainingModuleTestLinkHelper::boolValue($this->getProperty('block_next_module_until_passed', 0), 0)
        );

        return parent::beforeSet();
    }
}

return 'TrainingModuleTestLinkUpdateProcessor';
