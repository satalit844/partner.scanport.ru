<div class="modal fade training-request-modal" id="trainingCourseRequestModal" tabindex="-1" aria-labelledby="trainingCourseRequestModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <div class="modal-title" id="trainingCourseRequestModalLabel">Запросить курс</div>
                    <div class="training-request-modal__text">
                        Заполните информацию и ваша заявка отправится на рассмотрение.
                        С вами обязательно свяжется наш оператор.
                    </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Закрыть"></button>
            </div>

            <div class="modal-body">
                <form class="training-request-modal__form" action="#" onsubmit="return false;">
                    <label class="training-request-modal__field">
                        <span class="training-request-modal__label">ФИО</span>
                        <input type="text" class="training-request-modal__input" placeholder="Иван Иванов">
                    </label>

                    <div class="training-request-modal__row">
                        <label class="training-request-modal__field">
                            <span class="training-request-modal__label">Email</span>
                            <input type="email" class="training-request-modal__input" placeholder="customer123@gmail.com">
                        </label>

                        <label class="training-request-modal__field">
                            <span class="training-request-modal__label">Номер телефона</span>
                            <input type="text" class="training-request-modal__input" placeholder="+7 (000) 000-00-00">
                        </label>
                    </div>

                    <label class="training-request-modal__field">
                        <span class="training-request-modal__label">Дополнительная информация</span>
                        <textarea class="training-request-modal__textarea" placeholder="Описание"></textarea>
                    </label>

                    <label class="training-request-modal__agree">
                        <input type="checkbox">
                        <span>Я даю согласие на обработку своих персональных данных</span>
                    </label>

                    <div class="training-request-modal__actions">
                        <button type="submit" class="training-request-modal__submit">Отправить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
