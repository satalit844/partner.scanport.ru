<?php
class TrainingModuleLessonRemoveProcessor extends modProcessor
{
    public function checkPermissions(){return true;}
    public function process()
    {
        $ids = trim((string)$this->getProperty('ids'));
        if ($ids === '') return $this->failure('Не выбраны уроки');
        $ids = array_filter(array_map('intval', explode(',', $ids)));
        if (!$ids) return $this->failure('Не выбраны уроки');
        foreach ($ids as $id) {
            $lesson = $this->modx->getObject('TrainingModuleLesson', ['id' => $id]);
            if (!$lesson) continue;
            foreach ($this->modx->getCollection('TrainingModuleVideo', ['lesson_id' => $id]) as $video) {$video->remove();}
            foreach ($this->modx->getCollection('TrainingModuleSlide', ['lesson_id' => $id]) as $slide) {$slide->remove();}
            $lesson->remove();
        }
        return $this->success();
    }
}
return 'TrainingModuleLessonRemoveProcessor';
