<?php
class TrainingModuleLessonUpdateProcessor extends modObjectUpdateProcessor
{
    public $classKey = 'TrainingModuleLesson';
    public $objectType = 'training.module.lesson';
    public function checkPermissions(){return true;}
    public function beforeSet()
    {
        $id = (int)$this->getProperty('id');
        if ($id <= 0) return 'Не указан урок';
        $title = trim((string)$this->getProperty('title'));
        if ($title === '') return 'Укажи название';
        $this->setProperty('is_default', !empty($this->getProperty('is_default')) ? 1 : 0);
        $this->setProperty('is_active', $this->getProperty('is_active', 1) ? 1 : 0);
        $this->setProperty('updatedon', date('Y-m-d H:i:s'));
        return parent::beforeSet();
    }
}
return 'TrainingModuleLessonUpdateProcessor';
