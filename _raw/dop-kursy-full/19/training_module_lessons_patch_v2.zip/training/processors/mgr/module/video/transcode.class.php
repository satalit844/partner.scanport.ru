<?php

require_once dirname(dirname(__DIR__)) . '/_media_helper.php';

class TrainingModuleVideoTranscodeProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }
    protected $bitrates = [
        1080 => 5000,
        720 => 2800,
        480 => 1400,
        320 => 800,
    ];

    public function process()
    {
        $moduleId = (int)$this->getProperty('module_id');
        $lessonId = (int)$this->getProperty('lesson_id');
        if ($moduleId <= 0 && $lessonId <= 0) {
            return $this->failure('Не указан модуль или урок');
        }

        /** @var TrainingModuleLesson $lesson */
        $lesson = null;
        if ($lessonId > 0) {
            $lesson = $this->modx->getObject('TrainingModuleLesson', ['id' => $lessonId]);
            if (!$lesson) {
                return $this->failure('Урок не найден');
            }
            $moduleId = (int)$lesson->get('module_id');
        }

        /** @var TrainingModule $module */
        $module = $this->modx->getObject('TrainingModule', ['id' => $moduleId]);
        if (!$module) {
            return $this->failure('Модуль не найден');
        }

        $source = trim((string)$this->getProperty('source_video', ($lesson ? $lesson->get('source_video') : $module->get('source_video'))));
        if ($source === '') {
            return $this->failure('Укажи путь к исходному видеофайлу');
        }

        $sourceAbsolute = TrainingMediaHelper::resolveLocalPath($this->modx, $source);
        if ($sourceAbsolute === '' || !is_file($sourceAbsolute)) {
            return $this->failure('Исходный видеофайл не найден на сервере');
        }

        $dirs = $lesson ? TrainingMediaHelper::resolveLessonVideoDirs($this->modx, $lesson) : TrainingMediaHelper::resolveModuleVideoDirs($this->modx, $module);
        foreach (['base_absolute', 'source_absolute', 'video_absolute', 'preview_absolute'] as $dirKey) {
            if (!TrainingMediaHelper::ensureDir($dirs[$dirKey])) {
                return $this->failure('Не удалось создать папки для видео модуля');
            }
        }

        $sourceExtension = strtolower(pathinfo($sourceAbsolute, PATHINFO_EXTENSION));
        if ($sourceExtension === '') {
            $sourceExtension = 'mp4';
        }
        $storedSourceAbsolute = $dirs['source_absolute'] . 'source.' . $sourceExtension;
        if (!TrainingMediaHelper::copyInto($sourceAbsolute, $storedSourceAbsolute)) {
            return $this->failure('Не удалось сохранить исходный видеофайл в папку модуля');
        }

        if ($lesson) {
            $lesson->set('source_video', TrainingMediaHelper::fsPathToWeb($this->modx, $storedSourceAbsolute));
            $lesson->set('video_status', 'processing');
            $lesson->save();
        } else {
            $module->set('source_video', TrainingMediaHelper::fsPathToWeb($this->modx, $storedSourceAbsolute));
            $module->set('video_status', 'processing');
            $module->save();
        }

        $sourceMeta = TrainingMediaHelper::detectVideoMeta($this->modx, $storedSourceAbsolute);
        if ((int)$sourceMeta['height'] <= 0) {
            $module->set('video_status', 'error');
            $module->save();
            return $this->failure('ffprobe не смог определить параметры исходного видео');
        }

        $qualityString = trim((string)$this->getProperty('qualities', $this->modx->getOption('training_video_qualities', null, '1080,720,480,320', true)));
        $qualityParts = array_filter(array_map('trim', explode(',', $qualityString)));
        if (empty($qualityParts)) {
            $qualityParts = ['1080', '720', '480', '320'];
        }

        $allowUpscale = (int)$this->modx->getOption('training_upscale_variants', null, 0, true) === 1;
        $ffmpeg = TrainingMediaHelper::getCommand($this->modx, 'training_ffmpeg_command', 'ffmpeg');
        $createdQualities = [];
        $defaultQuality = '';

        foreach ($qualityParts as $qualityPart) {
            $targetHeight = (int)preg_replace('/\D+/', '', $qualityPart);
            if ($targetHeight <= 0) {
                continue;
            }

            if (!$allowUpscale && $targetHeight > (int)$sourceMeta['height']) {
                continue;
            }

            $qualityName = $targetHeight . 'p';
            $qualityDirAbsolute = $dirs['video_absolute'] . $qualityName . '/';
            if (!TrainingMediaHelper::ensureDir($qualityDirAbsolute)) {
                continue;
            }

            $outputAbsolute = $qualityDirAbsolute . 'video.mp4';
            $videoBitrate = isset($this->bitrates[$targetHeight]) ? (int)$this->bitrates[$targetHeight] : 1200;
            $audioBitrate = $targetHeight >= 720 ? '128k' : '96k';

            $command = escapeshellcmd($ffmpeg)
                . ' -y -i ' . escapeshellarg($storedSourceAbsolute)
                . ' -vf ' . escapeshellarg('scale=-2:' . $targetHeight)
                . ' -c:v libx264 -preset veryfast -crf 23 -pix_fmt yuv420p'
                . ' -b:v ' . escapeshellarg($videoBitrate . 'k')
                . ' -maxrate ' . escapeshellarg(($videoBitrate + 300) . 'k')
                . ' -bufsize ' . escapeshellarg(($videoBitrate * 2) . 'k')
                . ' -movflags +faststart -c:a aac -b:a ' . escapeshellarg($audioBitrate)
                . ' ' . escapeshellarg($outputAbsolute);

            $output = [];
            $code = 0;
            if (!TrainingMediaHelper::runCommand($this->modx, $command, $output, $code)) {
                $module->set('video_status', 'error');
                $module->save();
                return $this->failure("Ошибка FFmpeg на качестве {$qualityName}\n" . implode("\n", $output));
            }

            $meta = TrainingMediaHelper::detectVideoMeta($this->modx, $outputAbsolute);
            $isDefault = empty($defaultQuality) ? 1 : 0;
            if ($isDefault) {
                $defaultQuality = $qualityName;
            }

            if ($lesson) {
                TrainingMediaHelper::upsertLessonVideo($this->modx, $lessonId, [
                'quality' => $qualityName,
                'mime' => 'video/mp4',
                'file_path' => TrainingMediaHelper::fsPathToWeb($this->modx, $outputAbsolute),
                'width' => (int)$meta['width'],
                'height' => (int)$meta['height'],
                'bitrate' => (int)$meta['bitrate'],
                'filesize' => (int)$meta['filesize'],
                'is_default' => $isDefault,
                'is_active' => 1,
            ]);
            } else {
                TrainingMediaHelper::upsertModuleVideo($this->modx, $moduleId, [
                'quality' => $qualityName,
                'mime' => 'video/mp4',
                'file_path' => TrainingMediaHelper::fsPathToWeb($this->modx, $outputAbsolute),
                'width' => (int)$meta['width'],
                'height' => (int)$meta['height'],
                'bitrate' => (int)$meta['bitrate'],
                'filesize' => (int)$meta['filesize'],
                'is_default' => $isDefault,
                'is_active' => 1,
            ]);
            }
            $createdQualities[] = $qualityName;
        }

        if (empty($createdQualities)) {
            $module->set('video_status', 'error');
            $module->save();
            return $this->failure('Не удалось сгенерировать ни одного варианта качества');
        }

        if ($defaultQuality !== '') {
            if ($lesson) { TrainingMediaHelper::clearOtherDefaultLessonVideos($this->modx, $lessonId, $defaultQuality); } else { TrainingMediaHelper::clearOtherDefaultVideos($this->modx, $moduleId, $defaultQuality); }
        }

        $durationSeconds = (int)round((float)$sourceMeta['duration']);
        $timedSlides = 0;
        if ($lesson) {
            if ((int)$this->modx->getCount('TrainingModuleSlide', ['lesson_id' => $lessonId]) > 0 && $durationSeconds > 0) {
                $timedSlides = TrainingMediaHelper::applyEvenLessonSlideTimecodes($this->modx, $lessonId, $durationSeconds * 1000);
                if ($timedSlides > 0) {
                    $lesson->set('presentation_status', 'ready');
                }
            }
            $lesson->set('duration_seconds', $durationSeconds);
            $lesson->set('video_status', 'ready');
            $lesson->save();
        } else {
            if ((int)$this->modx->getCount('TrainingModuleSlide', ['module_id' => $moduleId]) > 0 && $durationSeconds > 0) {
                $timedSlides = TrainingMediaHelper::applyEvenSlideTimecodes($this->modx, $moduleId, $durationSeconds * 1000);
                if ($timedSlides > 0) {
                    $module->set('presentation_status', 'ready');
                }
            }

            $module->set('duration_seconds', $durationSeconds);
            $module->set('video_status', 'ready');
            $module->save();
        }

        return $this->success('Видео обработано', [
            'qualities' => $createdQualities,
            'duration_seconds' => $durationSeconds,
            'duration_human' => TrainingMediaHelper::formatSeconds($durationSeconds),
            'source_video' => $lesson ? $lesson->get('source_video') : $module->get('source_video'),
            'timed_slides' => $timedSlides,
            'video_output_dir' => $dirs['video_web'],
        ]);
    }
}

return 'TrainingModuleVideoTranscodeProcessor';
