<?php
class TrainingModuleVideoRemoveProcessor extends modProcessor
{
    public function checkPermissions(){return true;}
    public function process()
    {
        $ids = trim((string)$this->getProperty('ids'));
        if ($ids === '') return $this->failure('Не выбраны видео');
        foreach (array_filter(array_map('intval', explode(',', $ids))) as $id) {
            $obj = $this->modx->getObject('TrainingModuleVideo', ['id' => $id]);
            if ($obj) $obj->remove();
        }
        return $this->success();
    }
}
return 'TrainingModuleVideoRemoveProcessor';
