Пакет v2: уроки внутри модуля
Скопировать содержимое папки training поверх core/components/training/
Потом очистить core/cache/ и перезагрузить manager.
Важно: если section module.js не подключает module.lesson.grid.js, нужно добавить этот include вручную рядом с module.video.grid.js и module.slide.grid.js.
