Training.combo.CourseSlides = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;
    this.lessonId = config.lessonId || 0;

    Ext.applyIf(config, {
        hiddenName: config.name || 'image_selector',
        name: config.name || 'image_selector',
        fieldLabel: config.fieldLabel || 'Слайд из папки курса',
        valueField: 'path',
        displayField: 'path',
        editable: false,
        forceSelection: true,
        minChars: 1,
        pageSize: 20,
        triggerAction: 'all',
        mode: 'remote',
        anchor: '100%',
        emptyText: 'Выбрать слайд из папки курса',
        store: new Ext.data.JsonStore({
            url: Training.config.connector_url,
            root: 'results',
            totalProperty: 'total',
            idProperty: 'path',
            fields: ['path', 'name', 'filename', 'slide_no', 'dir'],
            baseParams: {
                action: 'mgr/module/slide/available',
                module_id: this.moduleId,
                lesson_id: this.lessonId
            }
        })
    });

    Training.combo.CourseSlides.superclass.constructor.call(this, config);
};

Ext.extend(Training.combo.CourseSlides, MODx.combo.ComboBox);
Ext.reg('training-combo-course-slides', Training.combo.CourseSlides);


Training.grid.ModuleSlides = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;
    this.lessonId = config.lessonId || 0;
    this.sm = new Ext.grid.CheckboxSelectionModel();

    Ext.applyIf(config, {
        id: 'training-grid-module-slides',
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/module/slides/getlist',
            module_id: this.moduleId,
            lesson_id: this.lessonId
        },
        sm: this.sm,
        fields: [
            'id',
            'module_id',
            'lesson_id',
            'slide_no',
            'image',
            'timecode_ms',
            'timecode_human',
            'is_active'
        ],
        paging: true,
        remoteSort: true,
        sortBy: 'slide_no',
        sortDir: 'ASC',
        autoHeight: true,
        anchor: '100%',
        multi_select: true,
        columns: [this.sm, {
            header: 'ID',
            dataIndex: 'id',
            width: 60
        }, {
            header: '№ слайда',
            dataIndex: 'slide_no',
            width: 90
        }, {
            header: 'Превью',
            dataIndex: 'image',
            width: 110,
            renderer: Training.utils.renderSlidePreview
        }, {
            header: 'Изображение',
            dataIndex: 'image',
            width: 380,
            renderer: Training.utils.renderFileLink
        }, {
            header: 'Таймкод',
            dataIndex: 'timecode_human',
            width: 100
        }, {
            header: 'Активен',
            dataIndex: 'is_active',
            width: 90,
            renderer: Training.utils.renderBoolean
        }],
        tbar: [{
            text: 'Добавить слайд',
            handler: this.createSlide,
            scope: this
        }, '-', {
            text: 'Изменить',
            handler: function(){ this.updateSlide(); },
            scope: this
        }, {
            text: 'Удалить',
            handler: function(){ this.removeSlide(); },
            scope: this
        }, '-', {
            text: 'Импортировать из папки курса',
            handler: this.importSlides,
            scope: this
        }, {
            text: 'Авторасставить таймкоды',
            handler: this.autoTimecodes,
            scope: this
        }, '->', {
            text: 'Обновить',
            handler: function() {
                this.refresh();
            },
            scope: this
        }],
        listeners: {
            rowdblclick: {
                fn: function(grid, rowIndex) {
                    var rec = grid.store.getAt(rowIndex);
                    if (rec) {
                        this.updateSlide(rec);
                    }
                },
                scope: this
            },
            rowcontextmenu: {
                fn: function(grid, rowIndex, e) {
                    var rec = grid.store.getAt(rowIndex);
                    if (!rec) { return; }
                    grid.getSelectionModel().selectRow(rowIndex);
                    this.menu.record = rec;
                    this.getMenu();
                    if (this.menu) {
                        this.menu.showAt(e.getXY());
                    }
                    e.stopEvent();
                },
                scope: this
            }
        }
    });

    Training.grid.ModuleSlides.superclass.constructor.call(this, config);
};

Ext.extend(Training.grid.ModuleSlides, MODx.grid.Grid, {
    setLessonContext: function(lessonId, silent) {
        this.lessonId = parseInt(lessonId, 10) || 0;
        this.baseParams.lesson_id = this.lessonId;
        if (this.getStore()) {
            this.getStore().baseParams.lesson_id = this.lessonId;
        }
        if (silent !== true) {
            this.refresh();
        }
    },

    ensureLessonSelected: function() {
        if (this.lessonId > 0) {
            return true;
        }
        MODx.msg.alert('Внимание', 'Сначала выбери видео в верхней таблице');
        return false;
    },

    getSelectedSlideIds: function() {
        var ids = [];

        if (typeof this._getSelectedIds === 'function') {
            var selected = this._getSelectedIds();
            if (Ext.isArray(selected) && selected.length) {
                return selected;
            }
            if (typeof selected === 'string' && selected.length) {
                return selected.split(',');
            }
        }

        var sm = this.getSelectionModel ? this.getSelectionModel() : this.sm;
        if (sm && sm.getSelections) {
            Ext.each(sm.getSelections(), function(rec) {
                var id = parseInt(rec.get ? rec.get('id') : rec.id, 10) || 0;
                if (id) {
                    ids.push(id);
                }
            });
        }

        if (!ids.length && this.menu && this.menu.record) {
            var menuId = parseInt(Training.utils.getRecordValue(this.menu.record, 'id'), 10) || 0;
            if (menuId) {
                ids.push(menuId);
            }
        }

        return ids;
    },

    getSingleSelectedSlide: function() {
        if (this.menu && this.menu.record) {
            return this.menu.record;
        }

        var ids = this.getSelectedSlideIds();
        if (!ids.length) {
            return null;
        }

        var id = parseInt(ids[0], 10) || 0;
        if (!id || !this.store) {
            return null;
        }

        var rec = this.store.getById ? this.store.getById(id) : null;
        if (!rec && this.store.each) {
            this.store.each(function(item) {
                if (!rec && parseInt(item.get('id'), 10) === id) {
                    rec = item;
                }
            });
        }

        return rec;
    },

    createSlide: function() {
        if (!this.ensureLessonSelected()) {
            return false;
        }

        var w = MODx.load({
            xtype: 'training-window-module-slide',
            title: 'Добавить слайд',
            baseParams: {
                action: 'mgr/module/slide/create'
            },
            moduleId: this.moduleId,
            lessonId: this.lessonId,
            listeners: {
                success: {
                    fn: function() {
                        this.refresh();
                        var lessonsGrid = Ext.getCmp('training-grid-module-lessons');
                        if (lessonsGrid) {
                            lessonsGrid.currentLessonId = this.lessonId;
                            lessonsGrid.refresh();
                        }
                    },
                    scope: this
                }
            }
        });

        w.setValues({
            module_id: this.moduleId,
            lesson_id: this.lessonId,
            slide_no: '',
            timecode_ms: 0,
            is_active: 1
        });
        w.show();
    },

    updateSlide: function(rec) {
        rec = rec || this.getSingleSelectedSlide();
        if (!rec) {
            MODx.msg.alert('Внимание', 'Выбери один слайд для редактирования');
            return false;
        }

        var recordData = rec.data || rec;
        var w = MODx.load({
            xtype: 'training-window-module-slide',
            title: 'Изменить слайд',
            baseParams: {
                action: 'mgr/module/slide/update'
            },
            moduleId: this.moduleId,
            lessonId: this.lessonId,
            listeners: {
                success: {
                    fn: function() {
                        this.refresh();
                    },
                    scope: this
                }
            }
        });

        w.show();
        w.setValues(recordData);
    },

    removeSlide: function(rec) {
        var ids = [];
        if (rec) {
            ids = [Training.utils.getRecordValue(rec, 'id')];
        } else {
            ids = this.getSelectedSlideIds();
        }

        var cleanIds = [];
        Ext.each(ids, function(item) {
            item = parseInt(item, 10) || 0;
            if (item) {
                cleanIds.push(item);
            }
        });
        ids = cleanIds;
        if (!ids.length) {
            MODx.msg.alert('Внимание', 'Выбери слайды для удаления');
            return false;
        }

        MODx.msg.confirm({
            title: 'Удаление',
            text: ids.length > 1 ? 'Удалить выбранные слайды?' : 'Удалить привязку слайда?',
            url: Training.config.connector_url,
            params: {
                action: 'mgr/module/slide/remove',
                ids: ids.join(',')
            },
            listeners: {
                success: {
                    fn: function() {
                        this.menu.record = null;
                        this.refresh();
                        var lessonsGrid = Ext.getCmp('training-grid-module-lessons');
                        if (lessonsGrid) {
                            lessonsGrid.currentLessonId = this.lessonId;
                            lessonsGrid.refresh();
                        }
                    },
                    scope: this
                }
            }
        });
    },

    importSlides: function() {
        if (!this.ensureLessonSelected()) {
            return false;
        }

        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/module/slide/import',
                module_id: this.moduleId,
                lesson_id: this.lessonId
            },
            listeners: {
                success: {
                    fn: function(r) {
                        this.refresh();
                        var lessonsGrid = Ext.getCmp('training-grid-module-lessons');
                        if (lessonsGrid) {
                            lessonsGrid.currentLessonId = this.lessonId;
                            lessonsGrid.refresh();
                        }
                        var message = 'Импорт завершён';
                        if (r && r.object && typeof r.object.created !== 'undefined') {
                            message += '. Добавлено: ' + r.object.created;
                        }
                        MODx.msg.alert('Готово', message);
                    },
                    scope: this
                },
                failure: {
                    fn: function(r) {
                        MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось импортировать слайды');
                    },
                    scope: this
                }
            }
        });
    },

    autoTimecodes: function() {
        if (!this.ensureLessonSelected()) {
            return false;
        }

        this.getEl().mask('Расставляем таймкоды...');

        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/module/slide/autotimecodes',
                module_id: this.moduleId,
                lesson_id: this.lessonId
            },
            listeners: {
                success: {
                    fn: function(r) {
                        this.getEl().unmask();
                        this.refresh();
                        var lessonsGrid = Ext.getCmp('training-grid-module-lessons');
                        if (lessonsGrid) {
                            lessonsGrid.currentLessonId = this.lessonId;
                            lessonsGrid.refresh();
                        }
                        var message = 'Таймкоды расставлены';
                        if (r && r.object && typeof r.object.updated !== 'undefined') {
                            message += '. Обновлено слайдов: ' + r.object.updated;
                        }
                        MODx.msg.alert('Готово', message);
                    },
                    scope: this
                },
                failure: {
                    fn: function(r) {
                        this.getEl().unmask();
                        MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось расставить таймкоды');
                    },
                    scope: this
                }
            }
        });
    },

    getMenu: function() {
        var rec = this.menu && this.menu.record ? this.menu.record : this.getSingleSelectedSlide();
        if (!rec) {
            return false;
        }

        this.addContextMenuItem([{
            text: 'Изменить',
            handler: function() {
                this.updateSlide(rec);
            },
            scope: this
        }, {
            text: 'Удалить',
            handler: function() {
                this.removeSlide(rec);
            },
            scope: this
        }, '-', {
            text: 'Открыть слайд',
            handler: function() {
                var image = Training.utils.getRecordValue(rec, 'image');
                if (image) {
                    window.open(Training.utils.normalizeLink(image), '_blank');
                }
            },
            scope: this
        }]);
        return true;
    }
});

Ext.reg('training-grid-module-slides', Training.grid.ModuleSlides);


Training.window.ModuleSlide = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;
    this.lessonId = config.lessonId || 0;

    Ext.applyIf(config, {
        width: 760,
        autoHeight: true,
        url: Training.config.connector_url,
        fields: [{
            xtype: 'hidden',
            name: 'id'
        }, {
            xtype: 'hidden',
            name: 'module_id',
            value: this.moduleId
        }, {
            xtype: 'hidden',
            name: 'lesson_id',
            value: this.lessonId
        }, {
            xtype: 'button',
            text: 'Выбрать файл с сервера',
            style: 'margin-bottom:10px;',
            handler: function(btn) {
                var win = btn.findParentByType('modx-window') || btn.findParentByType('window');
                var form = win && win.fp ? win.fp.getForm() : null;
                var field = form ? form.findField('image') : null;
                Training.utils.openPathBrowser(field, {
                    source: Training.config.media_source || 3,
                    allowedFileTypes: 'jpg,jpeg,png,webp,gif',
                    onSelect: function(path) {
                        if (!form) return;
                        var slideNoField = form.findField('slide_no');
                        if (slideNoField && (!slideNoField.getValue() || parseInt(slideNoField.getValue(), 10) <= 0)) {
                            var m = String(path || '').match(/(\d+)/);
                            if (m) {
                                slideNoField.setValue(parseInt(m[1],10) || '');
                            }
                        }
                    }
                });
            }
        }, {
            xtype: 'textfield',
            fieldLabel: 'Путь к изображению',
            name: 'image',
            anchor: '100%',
            allowBlank: false,
            emptyText: '/assets/training/courses/.../presentation/slides/001.jpg',
            triggerClass: 'x-form-search-trigger',
            onTriggerClick: function() {
                Training.utils.openPathBrowser(this);
            }
        }, {
            layout: 'column',
            border: false,
            defaults: {
                layout: 'form',
                border: false,
                labelAlign: 'top'
            },
            items: [{
                columnWidth: .5,
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: 'Номер слайда',
                    name: 'slide_no',
                    anchor: '95%',
                    emptyText: 'Если пусто — возьмётся из имени файла'
                }]
            }, {
                columnWidth: .5,
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: 'Таймкод, мс',
                    name: 'timecode_ms',
                    anchor: '95%'
                }]
            }]
        }, {
            xtype: 'xcheckbox',
            boxLabel: 'Слайд активен',
            hideLabel: true,
            name: 'is_active',
            inputValue: 1,
            checked: true
        }]
    });

    Training.window.ModuleSlide.superclass.constructor.call(this, config);
};

Ext.extend(Training.window.ModuleSlide, MODx.Window);
Ext.reg('training-window-module-slide', Training.window.ModuleSlide);
