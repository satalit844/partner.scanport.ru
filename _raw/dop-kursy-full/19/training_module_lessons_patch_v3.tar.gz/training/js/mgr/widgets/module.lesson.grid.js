Training.grid.ModuleLessons = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;
    this.currentLessonId = config.currentLessonId || 0;
    this.sm = new Ext.grid.CheckboxSelectionModel();

    Ext.applyIf(config, {
        id: 'training-grid-module-lessons',
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/module/lessons/getlist',
            module_id: this.moduleId
        },
        sm: this.sm,
        fields: [
            'id',
            'module_id',
            'title',
            'sort_order',
            'source_video',
            'video_status',
            'presentation_status',
            'duration_seconds',
            'videos_count',
            'slides_count',
            'is_default',
            'is_active'
        ],
        paging: true,
        remoteSort: true,
        sortBy: 'sort_order',
        sortDir: 'ASC',
        autoHeight: true,
        anchor: '100%',
        columns: [
            this.sm,
            {header: 'ID', dataIndex: 'id', width: 50},
            {header: 'Порядок', dataIndex: 'sort_order', width: 70},
            {header: 'Название', dataIndex: 'title', width: 220},
            {header: 'Исходник', dataIndex: 'source_video', width: 300, renderer: Training.utils.renderFileLink},
            {header: 'Видео', dataIndex: 'video_status', width: 80},
            {header: 'Слайды', dataIndex: 'presentation_status', width: 80},
            {header: 'Качества', dataIndex: 'videos_count', width: 70},
            {header: 'Слайдов', dataIndex: 'slides_count', width: 70},
            {header: 'По умолчанию', dataIndex: 'is_default', width: 90, renderer: Training.utils.renderBoolean},
            {header: 'Активен', dataIndex: 'is_active', width: 80, renderer: Training.utils.renderBoolean}
        ],
        tbar: [
            {
                text: 'Добавить видео',
                handler: this.createLesson,
                scope: this
            },
            {
                text: 'Изменить',
                handler: this.updateLesson,
                scope: this
            },
            {
                text: 'Удалить',
                handler: this.removeLesson,
                scope: this
            },
            '->',
            {
                text: 'Обновить',
                handler: function () {
                    this.refresh();
                },
                scope: this
            }
        ],
        listeners: {
            rowclick: {
                fn: function (grid, rowIndex) {
                    var rec = grid.store.getAt(rowIndex);
                    this.selectLesson(rec);
                },
                scope: this
            },
            rowdblclick: {
                fn: function (grid, rowIndex) {
                    var rec = grid.store.getAt(rowIndex);
                    if (rec) {
                        this.updateLesson(rec);
                    }
                },
                scope: this
            }
        }
    });

    Training.grid.ModuleLessons.superclass.constructor.call(this, config);

    this.getStore().on('load', function (store) {
        var rec = null;
        if (this.currentLessonId > 0) {
            rec = store.getById ? store.getById(this.currentLessonId) : null;
            if (!rec && store.each) {
                store.each(function (item) {
                    if (!rec && parseInt(item.get('id'), 10) === parseInt(this.currentLessonId, 10)) {
                        rec = item;
                    }
                }, this);
            }
        }

        if (!rec && store.getCount() > 0) {
            rec = store.getAt(0);
        }

        if (rec) {
            this.getSelectionModel().selectRecords([rec]);
            this.selectLesson(rec, true);
        } else {
            this.selectLesson(null, true);
        }
    }, this);
};

Ext.extend(Training.grid.ModuleLessons, MODx.grid.Grid, {
    getSelectedRecord: function () {
        if (this.menu && this.menu.record) {
            return this.menu.record;
        }
        var sm = this.getSelectionModel();
        var selected = sm && sm.getSelections ? sm.getSelections() : [];
        return selected && selected.length ? selected[0] : null;
    },

    selectLesson: function (rec, silent) {
        var lessonId = 0;
        var sourceVideo = '';

        if (rec) {
            lessonId = parseInt(rec.get('id'), 10) || 0;
            sourceVideo = rec.get('source_video') || '';
        }

        this.currentLessonId = lessonId;

        var videosGrid = Ext.getCmp('training-grid-module-videos');
        if (videosGrid && typeof videosGrid.setLessonContext === 'function') {
            videosGrid.setLessonContext(lessonId, sourceVideo, !!silent);
        }

        var slidesGrid = Ext.getCmp('training-grid-module-slides');
        if (slidesGrid && typeof slidesGrid.setLessonContext === 'function') {
            slidesGrid.setLessonContext(lessonId, !!silent);
        }
    },

    createLesson: function () {
        var w = MODx.load({
            xtype: 'training-window-module-lesson',
            title: 'Добавить видео',
            baseParams: {
                action: 'mgr/module/lesson/create'
            },
            moduleId: this.moduleId,
            listeners: {
                success: {
                    fn: function () {
                        this.refresh();
                    },
                    scope: this
                }
            }
        });

        w.setValues({
            module_id: this.moduleId,
            is_active: 1,
            is_default: 0
        });
        w.show();
    },

    updateLesson: function (rec) {
        rec = rec || this.getSelectedRecord();
        if (!rec) {
            MODx.msg.alert('Внимание', 'Выбери запись');
            return false;
        }

        var w = MODx.load({
            xtype: 'training-window-module-lesson',
            title: 'Изменить видео',
            baseParams: {
                action: 'mgr/module/lesson/update'
            },
            moduleId: this.moduleId,
            listeners: {
                success: {
                    fn: function () {
                        this.currentLessonId = parseInt((rec.data || rec).id, 10) || 0;
                        this.refresh();
                    },
                    scope: this
                }
            }
        });

        w.show();
        w.setValues(rec.data || rec);
    },

    removeLesson: function (rec) {
        rec = rec || this.getSelectedRecord();
        if (!rec) {
            MODx.msg.alert('Внимание', 'Выбери запись');
            return false;
        }

        var id = parseInt((rec.data || rec).id, 10) || 0;
        if (!id) {
            return false;
        }

        MODx.msg.confirm({
            title: 'Удаление',
            text: 'Удалить видео и все его качества/слайды?',
            url: Training.config.connector_url,
            params: {
                action: 'mgr/module/lesson/remove',
                ids: String(id)
            },
            listeners: {
                success: {
                    fn: function () {
                        if (this.currentLessonId === id) {
                            this.currentLessonId = 0;
                        }
                        this.refresh();
                    },
                    scope: this
                }
            }
        });
    }
});

Ext.reg('training-grid-module-lessons', Training.grid.ModuleLessons);


Training.window.ModuleLesson = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;

    Ext.applyIf(config, {
        width: 760,
        autoHeight: true,
        url: Training.config.connector_url,
        fields: [{
            xtype: 'hidden',
            name: 'id'
        }, {
            xtype: 'hidden',
            name: 'module_id',
            value: this.moduleId
        }, {
            xtype: 'textfield',
            fieldLabel: 'Название',
            name: 'title',
            anchor: '100%',
            allowBlank: false
        }, {
            xtype: 'numberfield',
            fieldLabel: 'Порядок',
            name: 'sort_order',
            anchor: '100%'
        }, {
            xtype: 'button',
            text: 'Выбрать исходное видео',
            style: 'margin-bottom:10px;',
            handler: function(btn) {
                var win = btn.findParentByType('modx-window') || btn.findParentByType('window');
                var form = win && win.fp ? win.fp.getForm() : null;
                var field = form ? form.findField('source_video') : null;
                Training.utils.openPathBrowser(field, {
                    source: Training.config.media_source || 3,
                    allowedFileTypes: 'mkv,mp4,mov,avi,webm,m3u8'
                });
            }
        }, {
            xtype: 'textfield',
            fieldLabel: 'Исходное видео',
            name: 'source_video',
            anchor: '100%'
        }, {
            xtype: 'textarea',
            fieldLabel: 'Описание',
            name: 'description',
            anchor: '100%'
        }, {
            xtype: 'xcheckbox',
            boxLabel: 'По умолчанию',
            hideLabel: true,
            name: 'is_default',
            inputValue: 1
        }, {
            xtype: 'xcheckbox',
            boxLabel: 'Активно',
            hideLabel: true,
            name: 'is_active',
            inputValue: 1,
            checked: true
        }]
    });

    Training.window.ModuleLesson.superclass.constructor.call(this, config);
};

Ext.extend(Training.window.ModuleLesson, MODx.Window);
Ext.reg('training-window-module-lesson', Training.window.ModuleLesson);
