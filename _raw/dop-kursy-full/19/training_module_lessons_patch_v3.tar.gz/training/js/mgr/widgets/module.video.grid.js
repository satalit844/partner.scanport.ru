Training.grid.ModuleVideos = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;
    this.lessonId = config.lessonId || 0;
    this.lessonSourceVideo = config.lessonSourceVideo || '';
    this.sm = new Ext.grid.CheckboxSelectionModel();

    Ext.applyIf(config, {
        id: 'training-grid-module-videos',
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/module/videos/getlist',
            module_id: this.moduleId,
            lesson_id: this.lessonId
        },
        sm: this.sm,
        fields: [
            'id',
            'module_id',
            'lesson_id',
            'quality',
            'mime',
            'file_path',
            'width',
            'height',
            'bitrate',
            'filesize',
            'is_default',
            'is_active'
        ],
        paging: true,
        remoteSort: true,
        sortBy: 'id',
        sortDir: 'ASC',
        autoHeight: true,
        anchor: '100%',
        multi_select: true,
        save_action: 'mgr/module/video/update',
        columns: [this.sm, {
            header: 'ID',
            dataIndex: 'id',
            width: 60
        }, {
            header: 'Качество',
            dataIndex: 'quality',
            width: 90
        }, {
            header: 'MIME',
            dataIndex: 'mime',
            width: 140
        }, {
            header: 'Файл',
            dataIndex: 'file_path',
            width: 360,
            renderer: Training.utils.renderFileLink
        }, {
            header: 'Размер',
            dataIndex: 'filesize',
            width: 100,
            renderer: Training.utils.renderBytes
        }, {
            header: 'Разрешение',
            dataIndex: 'width',
            width: 110,
            renderer: function(value, meta, rec) {
                return (rec.data.width || 0) + '×' + (rec.data.height || 0);
            }
        }, {
            header: 'Битрейт',
            dataIndex: 'bitrate',
            width: 80
        }, {
            header: 'По умолчанию',
            dataIndex: 'is_default',
            width: 110,
            renderer: Training.utils.renderBoolean
        }, {
            header: 'Активен',
            dataIndex: 'is_active',
            width: 90,
            renderer: Training.utils.renderBoolean
        }],
        tbar: [{
            text: 'Сгенерировать из исходника',
            handler: this.transcodeFromSource,
            scope: this
        }, '-', {
            text: 'Добавить видео',
            handler: this.createVideo,
            scope: this
        }, '-', {
            text: 'Изменить',
            handler: function(){ this.updateVideo(); },
            scope: this
        }, {
            text: 'Удалить',
            handler: function(){ this.removeVideo(); },
            scope: this
        }, '->', {
            text: 'Обновить',
            handler: function() {
                this.refresh();
            },
            scope: this
        }],
        listeners: {
            rowdblclick: {
                fn: function(grid, rowIndex) {
                    var rec = grid.store.getAt(rowIndex);
                    if (rec) {
                        this.updateVideo(rec);
                    }
                },
                scope: this
            },
            rowcontextmenu: {
                fn: function(grid, rowIndex, e) {
                    var rec = grid.store.getAt(rowIndex);
                    if (!rec) { return; }
                    grid.getSelectionModel().selectRow(rowIndex);
                    this.menu.record = rec;
                    this.getMenu();
                    if (this.menu) {
                        this.menu.showAt(e.getXY());
                    }
                    e.stopEvent();
                },
                scope: this
            }
        }
    });

    Training.grid.ModuleVideos.superclass.constructor.call(this, config);
};

Ext.extend(Training.grid.ModuleVideos, MODx.grid.Grid, {
    setLessonContext: function(lessonId, sourceVideo, silent) {
        this.lessonId = parseInt(lessonId, 10) || 0;
        this.lessonSourceVideo = sourceVideo || '';
        this.baseParams.lesson_id = this.lessonId;
        if (this.getStore()) {
            this.getStore().baseParams.lesson_id = this.lessonId;
        }
        if (silent !== true) {
            this.refresh();
        }
    },

    ensureLessonSelected: function() {
        if (this.lessonId > 0) {
            return true;
        }
        MODx.msg.alert('Внимание', 'Сначала выбери видео в верхней таблице');
        return false;
    },

    getSelectedVideoIds: function() {
        var ids = [];

        if (typeof this._getSelectedIds === 'function') {
            var selected = this._getSelectedIds();
            if (Ext.isArray(selected) && selected.length) {
                return selected;
            }
            if (typeof selected === 'string' && selected.length) {
                return selected.split(',');
            }
        }

        var sm = this.getSelectionModel ? this.getSelectionModel() : this.sm;
        if (sm && sm.getSelections) {
            Ext.each(sm.getSelections(), function(rec) {
                var id = parseInt(rec.get ? rec.get('id') : rec.id, 10) || 0;
                if (id) {
                    ids.push(id);
                }
            });
        }

        if (!ids.length && this.menu && this.menu.record) {
            var menuId = parseInt(Training.utils.getRecordValue(this.menu.record, 'id'), 10) || 0;
            if (menuId) {
                ids.push(menuId);
            }
        }

        return ids;
    },

    getSingleSelectedVideo: function() {
        if (this.menu && this.menu.record) {
            return this.menu.record;
        }

        var ids = this.getSelectedVideoIds();
        if (!ids.length) {
            return null;
        }

        var id = parseInt(ids[0], 10) || 0;
        if (!id || !this.store) {
            return null;
        }

        var rec = this.store.getById ? this.store.getById(id) : null;
        if (!rec && this.store.each) {
            this.store.each(function(item) {
                if (!rec && parseInt(item.get('id'), 10) === id) {
                    rec = item;
                }
            });
        }

        return rec;
    },

    transcodeFromSource: function() {
        if (!this.ensureLessonSelected()) {
            return false;
        }

        var sourceVideo = this.lessonSourceVideo || '';
        if (!sourceVideo) {
            var lessonsGrid = Ext.getCmp('training-grid-module-lessons');
            var lessonRec = lessonsGrid && lessonsGrid.getSelectedRecord ? lessonsGrid.getSelectedRecord() : null;
            if (lessonRec) {
                sourceVideo = lessonRec.get('source_video') || '';
            }
        }

        if (!sourceVideo) {
            MODx.msg.alert('Внимание', 'У выбранного видео не указан исходник');
            return false;
        }

        this.getEl().mask('Генерируем видео...');

        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/module/video/transcode',
                module_id: this.moduleId,
                lesson_id: this.lessonId,
                source_video: sourceVideo
            },
            listeners: {
                success: {
                    fn: function() {
                        this.getEl().unmask();
                        this.refresh();

                        var lessonsGrid = Ext.getCmp('training-grid-module-lessons');
                        if (lessonsGrid) {
                            lessonsGrid.currentLessonId = this.lessonId;
                            lessonsGrid.refresh();
                        }

                        var slidesGrid = Ext.getCmp('training-grid-module-slides');
                        if (slidesGrid) {
                            slidesGrid.refresh();
                        }

                        MODx.msg.alert('Готово', 'Варианты видео созданы для выбранного видео');
                    },
                    scope: this
                },
                failure: {
                    fn: function(r) {
                        this.getEl().unmask();
                        MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось обработать видео');
                    },
                    scope: this
                }
            }
        });
    },

    createVideo: function() {
        if (!this.ensureLessonSelected()) {
            return false;
        }

        var w = MODx.load({
            xtype: 'training-window-module-video',
            title: 'Добавить видео',
            baseParams: {
                action: 'mgr/module/video/create'
            },
            moduleId: this.moduleId,
            lessonId: this.lessonId,
            listeners: {
                success: {
                    fn: function() {
                        this.refresh();
                        var lessonsGrid = Ext.getCmp('training-grid-module-lessons');
                        if (lessonsGrid) {
                            lessonsGrid.currentLessonId = this.lessonId;
                            lessonsGrid.refresh();
                        }
                    },
                    scope: this
                }
            }
        });

        w.setValues({
            module_id: this.moduleId,
            lesson_id: this.lessonId,
            is_default: 0,
            is_active: 1,
            mime: 'video/mp4'
        });
        w.show();
    },

    updateVideo: function(rec) {
        rec = rec || this.getSingleSelectedVideo();
        if (!rec) {
            MODx.msg.alert('Внимание', 'Выбери одно видео для редактирования');
            return false;
        }

        var recordData = rec.data || rec;
        var w = MODx.load({
            xtype: 'training-window-module-video',
            title: 'Изменить видео',
            baseParams: {
                action: 'mgr/module/video/update'
            },
            moduleId: this.moduleId,
            lessonId: this.lessonId,
            listeners: {
                success: {
                    fn: function() {
                        this.refresh();
                        var lessonsGrid = Ext.getCmp('training-grid-module-lessons');
                        if (lessonsGrid) {
                            lessonsGrid.currentLessonId = this.lessonId;
                            lessonsGrid.refresh();
                        }
                    },
                    scope: this
                }
            }
        });

        w.show();
        w.setValues(recordData);
    },

    removeVideo: function(rec) {
        var ids = [];
        if (rec) {
            ids = [Training.utils.getRecordValue(rec, 'id')];
        } else {
            ids = this.getSelectedVideoIds();
        }

        var cleanIds = [];
        Ext.each(ids, function(item) {
            item = parseInt(item, 10) || 0;
            if (item) {
                cleanIds.push(item);
            }
        });
        ids = cleanIds;
        if (!ids.length) {
            MODx.msg.alert('Внимание', 'Выбери видео для удаления');
            return false;
        }

        MODx.msg.confirm({
            title: 'Удаление',
            text: ids.length > 1 ? 'Удалить выбранные видео?' : 'Удалить привязку видео?',
            url: Training.config.connector_url,
            params: {
                action: 'mgr/module/video/remove',
                ids: ids.join(',')
            },
            listeners: {
                success: {
                    fn: function() {
                        this.menu.record = null;
                        this.refresh();
                        var lessonsGrid = Ext.getCmp('training-grid-module-lessons');
                        if (lessonsGrid) {
                            lessonsGrid.currentLessonId = this.lessonId;
                            lessonsGrid.refresh();
                        }
                    },
                    scope: this
                }
            }
        });
    },

    getMenu: function() {
        var rec = this.menu && this.menu.record ? this.menu.record : this.getSingleSelectedVideo();
        if (!rec) {
            return false;
        }

        this.addContextMenuItem([{
            text: 'Изменить',
            handler: function() {
                this.updateVideo(rec);
            },
            scope: this
        }, {
            text: 'Удалить',
            handler: function() {
                this.removeVideo(rec);
            },
            scope: this
        }, '-', {
            text: 'Открыть видео',
            handler: function() {
                var path = Training.utils.getRecordValue(rec, 'file_path');
                if (path) {
                    window.open(Training.utils.normalizeLink(path), '_blank');
                }
            },
            scope: this
        }]);
        return true;
    }
});

Ext.reg('training-grid-module-videos', Training.grid.ModuleVideos);


Training.window.ModuleVideo = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;
    this.lessonId = config.lessonId || 0;

    Ext.applyIf(config, {
        width: 760,
        autoHeight: true,
        url: Training.config.connector_url,
        fields: [{
            xtype: 'hidden',
            name: 'id'
        }, {
            xtype: 'hidden',
            name: 'module_id',
            value: this.moduleId
        }, {
            xtype: 'hidden',
            name: 'lesson_id',
            value: this.lessonId
        }, {
            xtype: 'button',
            text: 'Выбрать файл с сервера',
            style: 'margin-bottom:10px;',
            handler: function(btn) {
                var win = btn.findParentByType('modx-window') || btn.findParentByType('window');
                var form = win && win.fp ? win.fp.getForm() : null;
                var field = form ? form.findField('file_path') : null;
                Training.utils.openPathBrowser(field, {
                    source: Training.config.media_source || 3,
                    allowedFileTypes: 'mkv,mp4,m3u8,mov,avi,webm',
                    onSelect: function(path) {
                        if (!form) return;
                        var mimeField = form.findField('mime');
                        if (mimeField && (!mimeField.getValue() || mimeField.getValue() === 'video/mp4')) {
                            mimeField.setValue((String(path).toLowerCase().indexOf('.m3u8') !== -1) ? 'application/vnd.apple.mpegurl' : 'video/mp4');
                        }
                        var qualityField = form.findField('quality');
                        if (qualityField && !qualityField.getValue()) {
                            var match = String(path || '').match(/(1080p|720p|480p|320p|hls)/i);
                            if (match) {
                                qualityField.setValue(match[1].toLowerCase());
                            }
                        }
                    }
                });
            }
        }, {
            xtype: 'textfield',
            fieldLabel: 'Качество',
            name: 'quality',
            anchor: '100%',
            allowBlank: false,
            emptyText: '1080p / 720p / 480p / 320p / hls'
        }, {
            xtype: 'trigger',
            fieldLabel: 'Путь к файлу',
            name: 'file_path',
            anchor: '100%',
            allowBlank: false,
            emptyText: '/assets/training/...',
            triggerClass: 'x-form-search-trigger',
            onTriggerClick: function() {
                Training.utils.openPathBrowser(this);
            }
        }, {
            xtype: 'textfield',
            fieldLabel: 'MIME',
            name: 'mime',
            anchor: '100%',
            emptyText: 'video/mp4'
        }, {
            layout: 'column',
            border: false,
            defaults: {
                layout: 'form',
                border: false,
                labelAlign: 'top'
            },
            items: [{
                columnWidth: .25,
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: 'Ширина',
                    name: 'width',
                    anchor: '95%'
                }]
            }, {
                columnWidth: .25,
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: 'Высота',
                    name: 'height',
                    anchor: '95%'
                }]
            }, {
                columnWidth: .25,
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: 'Битрейт',
                    name: 'bitrate',
                    anchor: '95%'
                }]
            }, {
                columnWidth: .25,
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: 'Размер файла',
                    name: 'filesize',
                    anchor: '95%'
                }]
            }]
        }, {
            xtype: 'xcheckbox',
            boxLabel: 'Видео по умолчанию',
            hideLabel: true,
            name: 'is_default',
            inputValue: 1
        }, {
            xtype: 'xcheckbox',
            boxLabel: 'Видео активно',
            hideLabel: true,
            name: 'is_active',
            inputValue: 1,
            checked: true
        }]
    });

    Training.window.ModuleVideo.superclass.constructor.call(this, config);
};

Ext.extend(Training.window.ModuleVideo, MODx.Window);
Ext.reg('training-window-module-video', Training.window.ModuleVideo);
