Training.panel.CourseTabs = function(config) {
    config = config || {};

    this.courseId = config.courseId || Training.config.course_id;

    Ext.apply(config, {
        id: 'training-course-tabs',
        border: true,
        deferredRender: false,
        defaults: {
            border: false,
            autoHeight: true
        },
        items: [{
            title: 'Общие',
            xtype: 'training-course-general-form',
            courseId: this.courseId
        }, {
            title: 'Модули',
            xtype: 'training-grid-course-modules',
            courseId: this.courseId
        }]
    });

    Training.panel.CourseTabs.superclass.constructor.call(this, config);
};

Ext.extend(Training.panel.CourseTabs, MODx.Tabs);
Ext.reg('training-course-tabs', Training.panel.CourseTabs);


Training.form.CourseGeneral = function(config) {
    config = config || {};
    this.courseId = config.courseId || Training.config.course_id;

    Ext.apply(config, {
        id: 'training-course-general-form',
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/course/update'
        },
        bodyCssClass: 'main-wrapper',
        cls: 'panel-desc',
        labelWidth: 180,
        autoHeight: true,
        defaults: {
            anchor: '100%'
        },
        items: [{
            html: '<div style="padding:10px 0 16px;color:#666;">На уровне курса храним исходную презентацию, PDF и разобранные слайды. Сначала указываем путь к ppt/pptx, затем запускаем разбор в PDF и JPG-слайды.</div>',
            border: false
        }, {
            xtype: 'hidden',
            name: 'id',
            value: this.courseId
        }, {
            xtype: 'displayfield',
            fieldLabel: 'ID курса',
            name: 'id_label'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Resource ID',
            name: 'resource_id'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Название',
            name: 'pagetitle'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Алиас',
            name: 'alias'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Контекст',
            name: 'context_key'
        }, {
            xtype: 'xcheckbox',
            boxLabel: 'Курс активен в training',
            hideLabel: true,
            name: 'is_active',
            inputValue: 1
        }, {
            xtype: 'textfield',
            fieldLabel: 'Исходный PPT/PPTX/PDF',
            name: 'source_presentation',
            anchor: '100%',
            emptyText: '/assets/uploads/training/course-1/source.pptx'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Статус презентации',
            name: 'presentation_status'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'PDF',
            name: 'presentation_pdf'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Папка слайдов',
            name: 'slides_dir'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Папка найдена',
            name: 'slides_dir_exists_label'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Слайдов в папке',
            name: 'available_slides_count'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Модулей',
            name: 'modules_count'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Опубликован',
            name: 'published_label'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'URI',
            name: 'uri'
        }],
        buttons: [{
            text: 'Сохранить',
            handler: this.submit,
            scope: this
        }, {
            text: 'Разобрать PPTX в слайды',
            handler: this.processPresentation,
            scope: this
        }, {
            text: 'Открыть ресурс',
            handler: function() {
                var form = this.getForm();
                var values = form.getValues();
                if (values.resource_id) {
                    MODx.loadPage('resource/update', 'id=' + values.resource_id);
                }
            },
            scope: this
        }, {
            text: 'Назад к списку',
            handler: function() {
                window.location.href = Training.utils.buildUrl({}, ['course_id', 'module_id']);
            }
        }]
    });

    Training.form.CourseGeneral.superclass.constructor.call(this, config);

    this.on('afterrender', this.loadCourse, this);
};

Ext.extend(Training.form.CourseGeneral, MODx.FormPanel, {
    loadCourse: function() {
        this.getForm().load({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/course/get',
                id: this.courseId
            }
        });
    },

    processPresentation: function() {
        var values = this.getForm().getValues();
        this.getEl().mask('Обрабатываем презентацию...');

        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/course/presentation/process',
                course_id: this.courseId,
                source_presentation: values.source_presentation || ''
            },
            listeners: {
                success: {
                    fn: function(r) {
                        this.getEl().unmask();
                        this.loadCourse();
                        var message = 'Презентация обработана';
                        if (r && r.object && typeof r.object.slides_count !== 'undefined') {
                            message += '. Слайдов: ' + r.object.slides_count;
                        }
                        MODx.msg.alert('Готово', message);
                    },
                    scope: this
                },
                failure: {
                    fn: function(r) {
                        this.getEl().unmask();
                        var msg = (r && r.message) ? r.message : 'Не удалось обработать презентацию';
                        if (r && r.responseText) { try { var rr = Ext.decode(r.responseText); if (rr && rr.message) { msg = rr.message; } } catch (e) {} }
                        MODx.msg.alert('Ошибка', msg);
                    },
                    scope: this
                }
            }
        });
    }
});

Ext.reg('training-course-general-form', Training.form.CourseGeneral);
