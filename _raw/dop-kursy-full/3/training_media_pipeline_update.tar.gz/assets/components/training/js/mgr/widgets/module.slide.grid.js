Training.combo.CourseSlides = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;

    Ext.applyIf(config, {
        hiddenName: config.name || 'image',
        name: config.name || 'image',
        fieldLabel: config.fieldLabel || 'Слайд из папки курса',
        valueField: 'path',
        displayField: 'name',
        editable: true,
        forceSelection: false,
        minChars: 1,
        pageSize: 20,
        triggerAction: 'all',
        mode: 'remote',
        anchor: '100%',
        store: new Ext.data.JsonStore({
            url: Training.config.connector_url,
            root: 'results',
            totalProperty: 'total',
            idProperty: 'path',
            fields: ['path', 'name', 'filename', 'slide_no', 'dir'],
            baseParams: {
                action: 'mgr/module/slide/available',
                module_id: this.moduleId
            }
        })
    });

    Training.combo.CourseSlides.superclass.constructor.call(this, config);
};

Ext.extend(Training.combo.CourseSlides, MODx.combo.ComboBox);
Ext.reg('training-combo-course-slides', Training.combo.CourseSlides);


Training.grid.ModuleSlides = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;

    Ext.applyIf(config, {
        id: 'training-grid-module-slides',
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/module/slides/getlist',
            module_id: this.moduleId
        },
        fields: [
            'id',
            'module_id',
            'slide_no',
            'image',
            'timecode_ms',
            'timecode_human',
            'is_active'
        ],
        paging: true,
        remoteSort: true,
        sortBy: 'slide_no',
        sortDir: 'ASC',
        autoHeight: true,
        anchor: '100%',
        columns: [{
            header: 'ID',
            dataIndex: 'id',
            width: 60
        }, {
            header: '№ слайда',
            dataIndex: 'slide_no',
            width: 90
        }, {
            header: 'Превью',
            dataIndex: 'image',
            width: 110,
            renderer: Training.utils.renderSlidePreview
        }, {
            header: 'Изображение',
            dataIndex: 'image',
            width: 300,
            renderer: Training.utils.renderFileLink
        }, {
            header: 'Таймкод',
            dataIndex: 'timecode_human',
            width: 100
        }, {
            header: 'Активен',
            dataIndex: 'is_active',
            width: 90,
            renderer: Training.utils.renderBoolean
        }],
        tbar: [{
            text: 'Добавить слайд',
            handler: this.createSlide,
            scope: this
        }, '-', {
            text: 'Изменить',
            handler: this.updateSlide,
            scope: this
        }, {
            text: 'Удалить',
            handler: this.removeSlide,
            scope: this
        }, '-', {
            text: 'Импортировать из папки курса',
            handler: this.importSlides,
            scope: this
        }, {
            text: 'Авторасставить таймкоды',
            handler: this.autoTimecodes,
            scope: this
        }, '->', {
            text: 'Обновить',
            handler: function() {
                this.refresh();
            },
            scope: this
        }],
        listeners: {
            rowdblclick: {
                fn: function(grid, rowIndex) {
                    var rec = grid.store.getAt(rowIndex);
                    if (rec) {
                        this.updateSlide(rec);
                    }
                },
                scope: this
            }
        }
    });

    Training.grid.ModuleSlides.superclass.constructor.call(this, config);
};

Ext.extend(Training.grid.ModuleSlides, MODx.grid.Grid, {
    createSlide: function() {
        var w = MODx.load({
            xtype: 'training-window-module-slide',
            title: 'Добавить слайд',
            baseParams: {
                action: 'mgr/module/slide/create'
            },
            moduleId: this.moduleId,
            listeners: {
                success: {
                    fn: function() {
                        this.refresh();
                    },
                    scope: this
                }
            }
        });

        w.setValues({
            module_id: this.moduleId,
            slide_no: '',
            timecode_ms: 0,
            is_active: 1
        });
        w.show();
    },

    updateSlide: function(rec) {
        rec = rec || this.menu.record || this.getSelectionModel().getSelected();
        if (!rec) {
            return false;
        }

        var w = MODx.load({
            xtype: 'training-window-module-slide',
            title: 'Изменить слайд',
            baseParams: {
                action: 'mgr/module/slide/update'
            },
            moduleId: this.moduleId,
            listeners: {
                success: {
                    fn: function() {
                        this.refresh();
                    },
                    scope: this
                }
            }
        });

        w.setValues(rec.data || rec);
        w.show();
    },

    removeSlide: function(rec) {
        rec = rec || this.menu.record || this.getSelectionModel().getSelected();
        if (!rec) {
            return false;
        }

        MODx.msg.confirm({
            title: 'Удаление',
            text: 'Удалить привязку слайда?',
            url: Training.config.connector_url,
            params: {
                action: 'mgr/module/slide/remove',
                id: Training.utils.getRecordValue(rec, 'id')
            },
            listeners: {
                success: {
                    fn: function() {
                        this.refresh();
                    },
                    scope: this
                }
            }
        });
    },

    importSlides: function() {
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/module/slide/import',
                module_id: this.moduleId
            },
            listeners: {
                success: {
                    fn: function(r) {
                        this.refresh();
                        var message = 'Импорт завершён';
                        if (r && r.object && typeof r.object.created !== 'undefined') {
                            message += '. Добавлено: ' + r.object.created;
                        }
                        MODx.msg.alert('Готово', message);
                    },
                    scope: this
                },
                failure: {
                    fn: function(r) {
                        MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось импортировать слайды');
                    },
                    scope: this
                }
            }
        });
    },


    autoTimecodes: function() {
        this.getEl().mask('Расставляем таймкоды...');

        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/module/slide/autotimecodes',
                module_id: this.moduleId
            },
            listeners: {
                success: {
                    fn: function(r) {
                        this.getEl().unmask();
                        this.refresh();
                        var form = Ext.getCmp('training-module-general-form');
                        if (form && form.loadModule) {
                            form.loadModule();
                        }
                        var message = 'Таймкоды расставлены';
                        if (r && r.object && typeof r.object.updated !== 'undefined') {
                            message += '. Обновлено слайдов: ' + r.object.updated;
                        }
                        MODx.msg.alert('Готово', message);
                    },
                    scope: this
                },
                failure: {
                    fn: function(r) {
                        this.getEl().unmask();
                        MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось расставить таймкоды');
                    },
                    scope: this
                }
            }
        });
    },

    getMenu: function() {
        var rec = this.menu && this.menu.record ? this.menu.record : null;
        if (!rec) {
            return false;
        }

        this.addContextMenuItem([{
            text: 'Изменить',
            handler: function() {
                this.updateSlide(rec);
            },
            scope: this
        }, {
            text: 'Удалить',
            handler: function() {
                this.removeSlide(rec);
            },
            scope: this
        }, '-', {
            text: 'Открыть слайд',
            handler: function() {
                var image = Training.utils.getRecordValue(rec, 'image');
                if (image) {
                    window.open(Training.utils.normalizeLink(image), '_blank');
                }
            },
            scope: this
        }]);
    }
});

Ext.reg('training-grid-module-slides', Training.grid.ModuleSlides);


Training.window.ModuleSlide = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;

    Ext.applyIf(config, {
        width: 760,
        autoHeight: true,
        url: Training.config.connector_url,
        fields: [{
            xtype: 'hidden',
            name: 'id'
        }, {
            xtype: 'hidden',
            name: 'module_id',
            value: this.moduleId
        }, {
            xtype: 'training-combo-course-slides',
            fieldLabel: 'Слайд из папки курса',
            moduleId: this.moduleId,
            name: 'image_selector',
            hiddenName: 'image_selector',
            anchor: '100%',
            listeners: {
                select: {
                    fn: function(combo, record) {
                        var win = combo.findParentByType('window');
                        if (!win || !record) {
                            return;
                        }

                        var form = win.fp.getForm();
                        var slideNoField = form.findField('slide_no');
                        var imageField = form.findField('image');
                        if (imageField) {
                            imageField.setValue(record.data.path || '');
                        }
                        if (slideNoField && !slideNoField.getValue() && record.data.slide_no) {
                            slideNoField.setValue(record.data.slide_no);
                        }
                    }
                }
            }
        }, {
            xtype: 'textfield',
            fieldLabel: 'Путь к изображению',
            name: 'image',
            anchor: '100%',
            allowBlank: false,
            emptyText: '/assets/training/courses/.../presentation/slides/001.jpg'
        }, {
            layout: 'column',
            border: false,
            defaults: {
                layout: 'form',
                border: false,
                labelAlign: 'top'
            },
            items: [{
                columnWidth: .5,
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: 'Номер слайда',
                    name: 'slide_no',
                    anchor: '95%',
                    emptyText: 'Если пусто — возьмётся из имени файла'
                }]
            }, {
                columnWidth: .5,
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: 'Таймкод, мс',
                    name: 'timecode_ms',
                    anchor: '95%'
                }]
            }]
        }, {
            xtype: 'xcheckbox',
            boxLabel: 'Слайд активен',
            hideLabel: true,
            name: 'is_active',
            inputValue: 1
        }]
    });

    Training.window.ModuleSlide.superclass.constructor.call(this, config);
};

Ext.extend(Training.window.ModuleSlide, MODx.Window);
Ext.reg('training-window-module-slide', Training.window.ModuleSlide);
