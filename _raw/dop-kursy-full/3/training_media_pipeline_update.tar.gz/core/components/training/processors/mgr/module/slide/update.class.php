<?php

require_once dirname(__FILE__) . '/_helpers.php';

class TrainingModuleSlideUpdateProcessor extends modObjectUpdateProcessor
{
    public $classKey = 'TrainingModuleSlide';
    public $objectType = 'training.module.slide';

    public function beforeSet()
    {
        $id = (int)$this->getProperty('id');
        $moduleId = (int)$this->getProperty('module_id');
        $image = trim((string)$this->getProperty('image'));
        $slideNo = (int)$this->getProperty('slide_no', 0);

        if ($id <= 0) {
            return 'Не указан ID слайда';
        }

        if ($moduleId <= 0) {
            return 'Не указан модуль';
        }

        if ($image === '') {
            return 'Выберите изображение слайда';
        }

        if ($slideNo <= 0) {
            return 'Укажите номер слайда';
        }

        $this->setProperty('module_id', $moduleId);
        $this->setProperty('image', TrainingModuleSlideHelper::normalizeWebPath($this->modx, $image));
        $this->setProperty('slide_no', $slideNo);
        $this->setProperty('timecode_ms', max(0, (int)$this->getProperty('timecode_ms', 0)));
        $this->setProperty('is_active', (int)$this->getProperty('is_active', 1));

        return parent::beforeSet();
    }
}

return 'TrainingModuleSlideUpdateProcessor';
