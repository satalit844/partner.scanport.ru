<?php

require_once dirname(__DIR__) . '/_media_helper.php';

class TrainingModuleGetProcessor extends modObjectGetProcessor
{
    public $classKey = 'TrainingModule';
    public $objectType = 'training.module';

    public function initialize()
    {
        if (!$this->getProperty('id')) {
            return $this->modx->lexicon('invalid_data');
        }

        return parent::initialize();
    }

    public function cleanup()
    {
        $array = $this->object->toArray();

        /** @var modResource $resource */
        $resource = $this->modx->getObject('modResource', [
            'id' => $array['resource_id'],
        ]);

        if ($resource) {
            $array['pagetitle'] = $resource->get('pagetitle');
            $array['alias'] = $resource->get('alias');
            $array['context_key'] = $resource->get('context_key');
            $array['uri'] = $resource->get('uri');
            $array['published'] = (int)$resource->get('published');
            $array['published_label'] = $array['published'] ? 'Да' : 'Нет';
        } else {
            $array['pagetitle'] = '—';
            $array['alias'] = '';
            $array['context_key'] = '';
            $array['uri'] = '—';
            $array['published'] = 0;
            $array['published_label'] = 'Нет';
        }

        /** @var TrainingCourse $course */
        $course = $this->modx->getObject('TrainingCourse', [
            'id' => $array['course_id'],
        ]);

        $array['course_title'] = '—';
        $array['course_resource_id'] = 0;
        if ($course) {
            $array['course_resource_id'] = (int)$course->get('resource_id');

            /** @var modResource $courseResource */
            $courseResource = $this->modx->getObject('modResource', [
                'id' => $course->get('resource_id'),
            ]);
            if ($courseResource) {
                $array['course_title'] = $courseResource->get('pagetitle');
            }
            $array['course_presentation_status'] = (string)$course->get('presentation_status');
            $array['course_source_presentation'] = (string)$course->get('source_presentation');
        }

        require_once dirname(__FILE__) . '/slide/_helpers.php';
        $scan = TrainingModuleSlideHelper::scanCourseSlides($this->modx, (int)$array['id']);
        $mediaDirs = TrainingMediaHelper::resolveModuleVideoDirs($this->modx, $this->object);

        $array['videos_count'] = (int)$this->modx->getCount('TrainingModuleVideo', [
            'module_id' => $array['id'],
        ]);
        $array['slides_count'] = (int)$this->modx->getCount('TrainingModuleSlide', [
            'module_id' => $array['id'],
        ]);
        $array['available_course_slides'] = count($scan['slides']);
        $array['course_slides_dir'] = !empty($scan['dir']['web']) ? $scan['dir']['web'] : '—';
        $array['course_slides_dir_exists_label'] = !empty($scan['dir']['exists']) ? 'Да' : 'Нет';
        $array['id_label'] = $array['id'];
        $array['course_id_label'] = $array['course_id'];
        $array['duration_human'] = TrainingMediaHelper::formatSeconds((int)$array['duration_seconds']);
        $array['createdon'] = !empty($array['createdon']) ? $array['createdon'] : '—';
        $array['updatedon'] = !empty($array['updatedon']) ? $array['updatedon'] : '—';
        $array['is_active'] = (int)!empty($array['is_active']);
        $array['is_required'] = (int)!empty($array['is_required']);
        $array['source_video'] = !empty($array['source_video']) ? $array['source_video'] : '';
        $array['video_output_dir'] = !empty($mediaDirs['video_web']) ? $mediaDirs['video_web'] : '—';

        return $this->success('', $array);
    }
}

return 'TrainingModuleGetProcessor';
