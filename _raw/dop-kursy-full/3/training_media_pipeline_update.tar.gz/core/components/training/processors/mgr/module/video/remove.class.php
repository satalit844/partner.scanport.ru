<?php

class TrainingModuleVideoRemoveProcessor extends modObjectRemoveProcessor
{
    public $classKey = 'TrainingModuleVideo';
    public $objectType = 'training.module.video';
}

return 'TrainingModuleVideoRemoveProcessor';
