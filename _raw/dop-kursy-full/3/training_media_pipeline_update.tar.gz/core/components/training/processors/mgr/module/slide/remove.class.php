<?php

class TrainingModuleSlideRemoveProcessor extends modObjectRemoveProcessor
{
    public $classKey = 'TrainingModuleSlide';
    public $objectType = 'training.module.slide';
}

return 'TrainingModuleSlideRemoveProcessor';
