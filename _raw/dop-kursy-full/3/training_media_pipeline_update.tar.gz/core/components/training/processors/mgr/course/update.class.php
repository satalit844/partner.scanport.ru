<?php

class TrainingCourseUpdateProcessor extends modObjectUpdateProcessor
{
    public $classKey = 'TrainingCourse';
    public $objectType = 'training.course';

    public function beforeSet()
    {
        $id = (int)$this->getProperty('id');
        if (!$id) {
            return 'Не указан ID курса';
        }

        $this->setProperty('is_active', (int)$this->getProperty('is_active', 0));
        $this->setProperty('source_presentation', trim((string)$this->getProperty('source_presentation', '')));
        $this->setProperty('presentation_pdf', trim((string)$this->getProperty('presentation_pdf', '')));
        $this->setProperty('slides_dir', trim((string)$this->getProperty('slides_dir', '')));

        $status = trim((string)$this->getProperty('presentation_status', ''));
        if ($status === '') {
            $status = 'none';
        }
        $this->setProperty('presentation_status', $status);

        return parent::beforeSet();
    }
}

return 'TrainingCourseUpdateProcessor';
