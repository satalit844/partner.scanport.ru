Training.grid.ModuleVideos = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;

    Ext.applyIf(config, {
        id: 'training-grid-module-videos',
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/module/videos/getlist',
            module_id: this.moduleId
        },
        fields: [
            'id',
            'module_id',
            'quality',
            'mime',
            'file_path',
            'width',
            'height',
            'bitrate',
            'filesize',
            'is_default',
            'is_active'
        ],
        paging: true,
        remoteSort: true,
        sortBy: 'id',
        sortDir: 'ASC',
        autoHeight: true,
        anchor: '100%',
        save_action: 'mgr/module/video/update',
        columns: [{
            header: 'ID',
            dataIndex: 'id',
            width: 60
        }, {
            header: 'Качество',
            dataIndex: 'quality',
            width: 90
        }, {
            header: 'MIME',
            dataIndex: 'mime',
            width: 140
        }, {
            header: 'Файл',
            dataIndex: 'file_path',
            width: 320,
            renderer: Training.utils.renderFileLink
        }, {
            header: 'Размер',
            dataIndex: 'filesize',
            width: 100,
            renderer: Training.utils.renderBytes
        }, {
            header: 'Разрешение',
            dataIndex: 'width',
            width: 100,
            renderer: function(value, meta, rec) {
                return (rec.data.width || 0) + '×' + (rec.data.height || 0);
            }
        }, {
            header: 'Битрейт',
            dataIndex: 'bitrate',
            width: 80
        }, {
            header: 'По умолчанию',
            dataIndex: 'is_default',
            width: 110,
            renderer: Training.utils.renderBoolean
        }, {
            header: 'Активен',
            dataIndex: 'is_active',
            width: 90,
            renderer: Training.utils.renderBoolean
        }],
        tbar: [{
            text: 'Добавить видео',
            handler: this.createVideo,
            scope: this
        }, '-', {
            text: 'Изменить',
            handler: this.updateVideo,
            scope: this
        }, {
            text: 'Удалить',
            handler: this.removeVideo,
            scope: this
        }, '->', {
            text: 'Обновить',
            handler: function() {
                this.refresh();
            },
            scope: this
        }],
        listeners: {
            rowdblclick: {
                fn: function(grid, rowIndex) {
                    var rec = grid.store.getAt(rowIndex);
                    if (rec) {
                        this.updateVideo(rec);
                    }
                },
                scope: this
            }
        }
    });

    Training.grid.ModuleVideos.superclass.constructor.call(this, config);
};

Ext.extend(Training.grid.ModuleVideos, MODx.grid.Grid, {
    createVideo: function() {
        var w = MODx.load({
            xtype: 'training-window-module-video',
            title: 'Добавить видео',
            baseParams: {
                action: 'mgr/module/video/create'
            },
            moduleId: this.moduleId,
            listeners: {
                success: {
                    fn: function() {
                        this.refresh();
                    },
                    scope: this
                }
            }
        });

        w.setValues({
            module_id: this.moduleId,
            is_default: 0,
            is_active: 1,
            mime: 'video/mp4'
        });
        w.show();
    },

    updateVideo: function(rec) {
        rec = rec || this.menu.record || this.getSelectionModel().getSelected();
        if (!rec) {
            return false;
        }

        var w = MODx.load({
            xtype: 'training-window-module-video',
            title: 'Изменить видео',
            baseParams: {
                action: 'mgr/module/video/update'
            },
            moduleId: this.moduleId,
            listeners: {
                success: {
                    fn: function() {
                        this.refresh();
                    },
                    scope: this
                }
            }
        });

        w.setValues(rec.data || rec);
        w.show();
    },

    removeVideo: function(rec) {
        rec = rec || this.menu.record || this.getSelectionModel().getSelected();
        if (!rec) {
            return false;
        }

        MODx.msg.confirm({
            title: 'Удаление',
            text: 'Удалить привязку видео?',
            url: Training.config.connector_url,
            params: {
                action: 'mgr/module/video/remove',
                id: Training.utils.getRecordValue(rec, 'id')
            },
            listeners: {
                success: {
                    fn: function() {
                        this.refresh();
                    },
                    scope: this
                }
            }
        });
    },

    getMenu: function() {
        var rec = this.menu && this.menu.record ? this.menu.record : null;
        if (!rec) {
            return false;
        }

        this.addContextMenuItem([{
            text: 'Изменить',
            handler: function() {
                this.updateVideo(rec);
            },
            scope: this
        }, {
            text: 'Удалить',
            handler: function() {
                this.removeVideo(rec);
            },
            scope: this
        }, '-', {
            text: 'Открыть видео',
            handler: function() {
                var path = Training.utils.getRecordValue(rec, 'file_path');
                if (path) {
                    window.open(Training.utils.normalizeLink(path), '_blank');
                }
            },
            scope: this
        }]);
    }
});

Ext.reg('training-grid-module-videos', Training.grid.ModuleVideos);


Training.window.ModuleVideo = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;

    Ext.applyIf(config, {
        width: 760,
        autoHeight: true,
        url: Training.config.connector_url,
        fields: [{
            xtype: 'hidden',
            name: 'id'
        }, {
            xtype: 'hidden',
            name: 'module_id',
            value: this.moduleId
        }, {
            xtype: 'textfield',
            fieldLabel: 'Качество',
            name: 'quality',
            anchor: '100%',
            allowBlank: false,
            emptyText: '1080p / 720p / 480p / 320p / hls'
        }, {
            xtype: 'textfield',
            fieldLabel: 'Путь к файлу',
            name: 'file_path',
            anchor: '100%',
            allowBlank: false,
            emptyText: '/assets/training/...'
        }, {
            xtype: 'textfield',
            fieldLabel: 'MIME',
            name: 'mime',
            anchor: '100%',
            emptyText: 'video/mp4'
        }, {
            layout: 'column',
            border: false,
            defaults: {
                layout: 'form',
                border: false,
                labelAlign: 'top'
            },
            items: [{
                columnWidth: .25,
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: 'Ширина',
                    name: 'width',
                    anchor: '95%'
                }]
            }, {
                columnWidth: .25,
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: 'Высота',
                    name: 'height',
                    anchor: '95%'
                }]
            }, {
                columnWidth: .25,
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: 'Битрейт',
                    name: 'bitrate',
                    anchor: '95%'
                }]
            }, {
                columnWidth: .25,
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: 'Размер файла',
                    name: 'filesize',
                    anchor: '95%'
                }]
            }]
        }, {
            xtype: 'xcheckbox',
            boxLabel: 'Видео по умолчанию',
            hideLabel: true,
            name: 'is_default',
            inputValue: 1
        }, {
            xtype: 'xcheckbox',
            boxLabel: 'Видео активно',
            hideLabel: true,
            name: 'is_active',
            inputValue: 1
        }]
    });

    Training.window.ModuleVideo.superclass.constructor.call(this, config);
};

Ext.extend(Training.window.ModuleVideo, MODx.Window);
Ext.reg('training-window-module-video', Training.window.ModuleVideo);
