Training.panel.ModuleTabs = function(config) {
    config = config || {};

    this.moduleId = config.moduleId || Training.config.module_id;
    this.courseId = config.courseId || Training.config.course_id;

    Ext.apply(config, {
        id: 'training-module-tabs',
        border: true,
        deferredRender: false,
        defaults: {
            border: false,
            autoHeight: true
        },
        items: [{
            title: 'Общие',
            xtype: 'training-module-general-form',
            moduleId: this.moduleId,
            courseId: this.courseId
        }, {
            title: 'Видео',
            xtype: 'training-grid-module-videos',
            moduleId: this.moduleId
        }, {
            title: 'Слайды',
            xtype: 'training-grid-module-slides',
            moduleId: this.moduleId
        }]
    });

    Training.panel.ModuleTabs.superclass.constructor.call(this, config);
};

Ext.extend(Training.panel.ModuleTabs, MODx.Tabs);
Ext.reg('training-module-tabs', Training.panel.ModuleTabs);


Training.form.ModuleGeneral = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;
    this.courseId = config.courseId || Training.config.course_id;

    Ext.apply(config, {
        id: 'training-module-general-form',
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/module/update'
        },
        bodyCssClass: 'main-wrapper',
        cls: 'panel-desc',
        labelWidth: 220,
        autoHeight: true,
        defaults: {
            anchor: '100%'
        },
        items: [{
            html: '<div style="padding:10px 0 16px;color:#666;">На этом этапе в модуле храним только базовые статусы. Видео привязываются во вкладке “Видео”, а слайды выбираются из папки курса во вкладке “Слайды”.</div>',
            border: false
        }, {
            xtype: 'hidden',
            name: 'id',
            value: this.moduleId
        }, {
            xtype: 'hidden',
            name: 'course_id',
            value: this.courseId
        }, {
            xtype: 'displayfield',
            fieldLabel: 'ID модуля',
            name: 'id_label'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'ID курса',
            name: 'course_id_label'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Курс',
            name: 'course_title'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Resource ID модуля',
            name: 'resource_id'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Название модуля',
            name: 'pagetitle'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'URI',
            name: 'uri'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Опубликован ресурс',
            name: 'published_label'
        }, {
            xtype: 'xcheckbox',
            boxLabel: 'Модуль активен',
            hideLabel: true,
            name: 'is_active',
            inputValue: 1
        }, {
            xtype: 'xcheckbox',
            boxLabel: 'Модуль обязателен для прохождения',
            hideLabel: true,
            name: 'is_required',
            inputValue: 1
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Длительность',
            name: 'duration_human'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Статус видео',
            name: 'video_status'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Статус презентации',
            name: 'presentation_status'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Папка слайдов курса',
            name: 'course_slides_dir'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Папка найдена',
            name: 'course_slides_dir_exists_label'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Слайдов в папке курса',
            name: 'available_course_slides'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Привязано видео',
            name: 'videos_count'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Привязано слайдов',
            name: 'slides_count'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Создан',
            name: 'createdon'
        }, {
            xtype: 'displayfield',
            fieldLabel: 'Обновлён',
            name: 'updatedon'
        }],
        buttons: [{
            text: 'Сохранить',
            handler: this.submit,
            scope: this
        }, {
            text: 'Открыть ресурс',
            handler: function() {
                var form = this.getForm();
                var values = form.getValues();
                if (values.resource_id) {
                    MODx.loadPage('resource/update', 'id=' + values.resource_id);
                }
            },
            scope: this
        }, {
            text: 'Назад к модулям курса',
            handler: function() {
                var form = this.getForm();
                var values = form.getValues();
                window.location.href = Training.utils.buildUrl({
                    course_id: values.course_id || this.courseId
                }, ['module_id']);
            },
            scope: this
        }, {
            text: 'Назад к курсам',
            handler: function() {
                window.location.href = Training.utils.buildUrl({}, ['course_id', 'module_id']);
            }
        }]
    });

    Training.form.ModuleGeneral.superclass.constructor.call(this, config);

    this.on('afterrender', this.loadModule, this);
};

Ext.extend(Training.form.ModuleGeneral, MODx.FormPanel, {
    loadModule: function() {
        this.getForm().load({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/module/get',
                id: this.moduleId
            }
        });
    }
});

Ext.reg('training-module-general-form', Training.form.ModuleGeneral);
