<?php

class TrainingModuleGetProcessor extends modObjectGetProcessor
{
    public $classKey = 'TrainingModule';
    public $objectType = 'training.module';

    public function initialize()
    {
        if (!$this->getProperty('id')) {
            return $this->modx->lexicon('invalid_data');
        }

        return parent::initialize();
    }

    public function cleanup()
    {
        $array = $this->object->toArray();

        /** @var modResource $resource */
        $resource = $this->modx->getObject('modResource', [
            'id' => $array['resource_id'],
        ]);

        if ($resource) {
            $array['pagetitle'] = $resource->get('pagetitle');
            $array['alias'] = $resource->get('alias');
            $array['context_key'] = $resource->get('context_key');
            $array['uri'] = $resource->get('uri');
            $array['published'] = (int)$resource->get('published');
            $array['published_label'] = $array['published'] ? 'Да' : 'Нет';
        } else {
            $array['pagetitle'] = '—';
            $array['alias'] = '';
            $array['context_key'] = '';
            $array['uri'] = '—';
            $array['published'] = 0;
            $array['published_label'] = 'Нет';
        }

        /** @var TrainingCourse $course */
        $course = $this->modx->getObject('TrainingCourse', [
            'id' => $array['course_id'],
        ]);

        $array['course_title'] = '—';
        $array['course_resource_id'] = 0;
        if ($course) {
            $array['course_resource_id'] = (int)$course->get('resource_id');

            /** @var modResource $courseResource */
            $courseResource = $this->modx->getObject('modResource', [
                'id' => $course->get('resource_id'),
            ]);
            if ($courseResource) {
                $array['course_title'] = $courseResource->get('pagetitle');
            }
        }

        require_once dirname(__FILE__) . '/slide/_helpers.php';
        $scan = TrainingModuleSlideHelper::scanCourseSlides($this->modx, (int)$array['id']);

        $array['videos_count'] = (int)$this->modx->getCount('TrainingModuleVideo', [
            'module_id' => $array['id'],
        ]);
        $array['slides_count'] = (int)$this->modx->getCount('TrainingModuleSlide', [
            'module_id' => $array['id'],
        ]);
        $array['available_course_slides'] = count($scan['slides']);
        $array['course_slides_dir'] = !empty($scan['dir']['web']) ? $scan['dir']['web'] : '—';
        $array['course_slides_dir_exists_label'] = !empty($scan['dir']['exists']) ? 'Да' : 'Нет';
        $array['id_label'] = $array['id'];
        $array['course_id_label'] = $array['course_id'];
        $array['duration_human'] = $this->formatSeconds((int)$array['duration_seconds']);
        $array['createdon'] = !empty($array['createdon']) ? $array['createdon'] : '—';
        $array['updatedon'] = !empty($array['updatedon']) ? $array['updatedon'] : '—';
        $array['is_active'] = (int)!empty($array['is_active']);
        $array['is_required'] = (int)!empty($array['is_required']);

        return $this->success('', $array);
    }

    protected function formatSeconds($seconds)
    {
        $seconds = (int)$seconds;
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        $seconds = $seconds % 60;

        if ($hours > 0) {
            return sprintf('%d:%02d:%02d', $hours, $minutes, $seconds);
        }

        return sprintf('%d:%02d', $minutes, $seconds);
    }
}

return 'TrainingModuleGetProcessor';
