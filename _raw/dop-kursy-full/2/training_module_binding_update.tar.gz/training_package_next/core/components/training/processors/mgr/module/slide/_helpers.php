<?php

class TrainingModuleSlideHelper
{
    /**
     * @param modX $modx
     * @param int $moduleId
     * @return array
     */
    public static function getModuleContext(modX $modx, $moduleId)
    {
        $moduleId = (int)$moduleId;
        if ($moduleId <= 0) {
            return [null, null, null];
        }

        /** @var TrainingModule $module */
        $module = $modx->getObject('TrainingModule', ['id' => $moduleId]);
        if (!$module) {
            return [null, null, null];
        }

        /** @var TrainingCourse $course */
        $course = $modx->getObject('TrainingCourse', ['id' => (int)$module->get('course_id')]);
        $courseResource = null;

        if ($course) {
            $courseResource = $modx->getObject('modResource', ['id' => (int)$course->get('resource_id')]);
        }

        return [$module, $course, $courseResource];
    }

    /**
     * @param modX $modx
     * @param int $moduleId
     * @return array
     */
    public static function resolveCourseSlidesDir(modX $modx, $moduleId)
    {
        list($module, $course, $courseResource) = self::getModuleContext($modx, $moduleId);
        if (!$module || !$course) {
            return [
                'absolute' => '',
                'web' => '',
                'exists' => false,
                'checked' => [],
            ];
        }

        $basePath = rtrim($modx->getOption('base_path'), '/\\') . '/';
        $assetsTrainingBase = $basePath . 'assets/training/';
        $courseDbId = (int)$course->get('id');
        $courseResourceId = (int)$course->get('resource_id');
        $courseAlias = $courseResource ? trim((string)$courseResource->get('alias')) : '';

        $candidates = [
            $assetsTrainingBase . 'courses/' . $courseDbId . '/presentation/slides/',
            $assetsTrainingBase . 'courses/' . $courseResourceId . '/presentation/slides/',
        ];

        if ($courseAlias !== '') {
            $candidates[] = $assetsTrainingBase . 'courses/' . $courseAlias . '/presentation/slides/';
        }

        foreach ($candidates as $candidate) {
            if (is_dir($candidate)) {
                return [
                    'absolute' => self::normalizeFsPath($candidate),
                    'web' => self::fsPathToWeb($modx, $candidate),
                    'exists' => true,
                    'checked' => array_map([__CLASS__, 'normalizeFsPath'], $candidates),
                ];
            }
        }

        return [
            'absolute' => self::normalizeFsPath($candidates[0]),
            'web' => self::fsPathToWeb($modx, $candidates[0]),
            'exists' => false,
            'checked' => array_map([__CLASS__, 'normalizeFsPath'], $candidates),
        ];
    }

    /**
     * @param modX $modx
     * @param int $moduleId
     * @return array
     */
    public static function scanCourseSlides(modX $modx, $moduleId)
    {
        $dirInfo = self::resolveCourseSlidesDir($modx, $moduleId);
        $results = [];

        if (empty($dirInfo['exists']) || empty($dirInfo['absolute']) || !is_dir($dirInfo['absolute'])) {
            return [
                'dir' => $dirInfo,
                'slides' => $results,
            ];
        }

        $allowedExt = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
        $items = scandir($dirInfo['absolute']);

        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }

            $filePath = $dirInfo['absolute'] . $item;
            if (!is_file($filePath)) {
                continue;
            }

            $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
            if (!in_array($extension, $allowedExt, true)) {
                continue;
            }

            $results[] = [
                'filename' => $item,
                'path' => self::fsPathToWeb($modx, $filePath),
                'absolute_path' => self::normalizeFsPath($filePath),
                'slide_no' => self::extractSlideNumber($item),
            ];
        }

        usort($results, function ($a, $b) {
            return strnatcasecmp($a['filename'], $b['filename']);
        });

        return [
            'dir' => $dirInfo,
            'slides' => $results,
        ];
    }

    /**
     * @param modX $modx
     * @param string $path
     * @return string
     */
    public static function normalizeWebPath(modX $modx, $path)
    {
        $path = trim((string)$path);
        if ($path === '') {
            return '';
        }

        $path = str_replace('\\', '/', $path);

        if (preg_match('#^(https?:)?//#i', $path)) {
            return $path;
        }

        $basePath = self::normalizeFsPath($modx->getOption('base_path'));
        if ($basePath !== '' && strpos(self::normalizeFsPath($path), $basePath) === 0) {
            return self::fsPathToWeb($modx, $path);
        }

        $path = '/' . ltrim($path, '/');
        return preg_replace('#/+#', '/', $path);
    }

    /**
     * @param modX $modx
     * @param string $path
     * @return int
     */
    public static function detectFileSize(modX $modx, $path)
    {
        $path = trim((string)$path);
        if ($path === '') {
            return 0;
        }

        $path = str_replace('\\', '/', $path);
        if (preg_match('#^(https?:)?//#i', $path)) {
            return 0;
        }

        $path = ltrim($path, '/');
        $absolute = rtrim($modx->getOption('base_path'), '/\\') . '/' . $path;
        if (is_file($absolute)) {
            return (int)filesize($absolute);
        }

        return 0;
    }

    /**
     * @param string $filename
     * @return int
     */
    public static function extractSlideNumber($filename)
    {
        if (preg_match('/(\d+)/', (string)$filename, $matches)) {
            return (int)$matches[1];
        }

        return 0;
    }

    /**
     * @param modX $modx
     * @param string $absolutePath
     * @return string
     */
    public static function fsPathToWeb(modX $modx, $absolutePath)
    {
        $absolutePath = self::normalizeFsPath($absolutePath);
        $basePath = self::normalizeFsPath($modx->getOption('base_path'));

        if ($absolutePath !== '' && $basePath !== '' && strpos($absolutePath, $basePath) === 0) {
            $relative = ltrim(substr($absolutePath, strlen($basePath)), '/');
            return '/' . $relative;
        }

        return $absolutePath;
    }

    /**
     * @param string $path
     * @return string
     */
    public static function normalizeFsPath($path)
    {
        $path = str_replace('\\', '/', (string)$path);
        $path = preg_replace('#/+#', '/', $path);

        if ($path !== '' && substr($path, -1) !== '/') {
            $path .= '/';
            if (preg_match('#\.[a-z0-9]+/$#i', $path)) {
                $path = rtrim($path, '/');
            }
        }

        return $path;
    }
}
