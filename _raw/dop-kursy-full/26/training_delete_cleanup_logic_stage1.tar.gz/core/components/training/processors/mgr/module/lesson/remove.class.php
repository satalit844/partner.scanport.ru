<?php

require_once dirname(dirname(__DIR__)) . '/_media_helper.php';

class TrainingModuleLessonRemoveProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    public function process()
    {
        $ids = $this->collectIds();
        if (empty($ids)) {
            return $this->failure('Не выбраны уроки');
        }

        $removed = 0;
        $affectedModules = [];

        foreach ($ids as $id) {
            /** @var TrainingModuleLesson $lesson */
            $lesson = $this->modx->getObject('TrainingModuleLesson', ['id' => $id]);
            if (!$lesson) {
                continue;
            }

            $result = TrainingMediaHelper::removeLessonCascade($this->modx, $lesson);
            if (!empty($result['removed'])) {
                $removed++;
                if (!empty($result['module_id'])) {
                    $affectedModules[(int)$result['module_id']] = (int)$result['module_id'];
                }
            }
        }

        foreach ($affectedModules as $moduleId) {
            TrainingMediaHelper::ensureModuleDefaultLesson($this->modx, $moduleId);
        }

        return $this->success('Уроки удалены', [
            'removed' => $removed,
            'module_ids' => array_values($affectedModules),
        ]);
    }

    protected function collectIds()
    {
        $raw = $this->getProperty('ids', $this->getProperty('id', ''));
        if (is_array($raw)) {
            return array_values(array_filter(array_map('intval', $raw)));
        }

        $raw = trim((string)$raw);
        if ($raw === '') {
            return [];
        }

        return array_values(array_filter(array_map('intval', array_map('trim', explode(',', $raw)))));
    }
}

return 'TrainingModuleLessonRemoveProcessor';
