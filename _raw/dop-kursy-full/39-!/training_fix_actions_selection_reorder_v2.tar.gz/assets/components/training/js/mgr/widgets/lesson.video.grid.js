Training.grid.LessonVideos = function(config) {
    config = config || {};
    this.lessonId = config.lessonId || Training.config.lesson_id;
    this.moduleId = config.moduleId || Training.config.module_id;
    this.sm = new Ext.grid.CheckboxSelectionModel();
    this.currentVideoId = 0;
    this.dragRecordId = 0;

    Ext.applyIf(config, {
        id: 'training-grid-lesson-videos',
        url: Training.config.connector_url,
        baseParams: {action: 'mgr/lesson/videos/getlist', lesson_id: this.lessonId},
        sm: this.sm,
        fields: ['id','lesson_id','title','description','sort_order','source_video','duration_seconds','video_status','is_default','is_active','qualities_count','slides_count'],
        paging: true,
        remoteSort: true,
        sortBy: 'sort_order',
        sortDir: 'ASC',
        autoHeight: true,
        anchor: '100%',
        columns: [
            this.sm,
            {header: 'ID', dataIndex: 'id', width: 50},
            {header: 'Видео урока', dataIndex: 'title', width: 260},
            {header: 'Порядок', dataIndex: 'sort_order', width: 70},
            {header: 'Исходное видео', dataIndex: 'source_video', width: 300, renderer: Training.utils.renderFileLink},
            {header: 'Статус', dataIndex: 'video_status', width: 80},
            {header: 'Длительность', dataIndex: 'duration_seconds', width: 90, renderer: Training.utils.renderSeconds},
            {header: 'Качества', dataIndex: 'qualities_count', width: 70},
            {header: 'Слайды', dataIndex: 'slides_count', width: 70},
            {header: 'По умолчанию', dataIndex: 'is_default', width: 90, renderer: Training.utils.renderBoolean},
            {header: 'Активен', dataIndex: 'is_active', width: 80, renderer: Training.utils.renderBoolean}
        ],
        tbar: [{
            text: 'Добавить видео',
            handler: this.createVideo,
            scope: this
        },{
            text: 'Открыть',
            handler: this.focusSelected,
            scope: this
        },{
            text: 'Изменить',
            handler: this.updateVideo,
            scope: this
        },{
            text: 'Удалить',
            handler: this.removeVideo,
            scope: this
        },'->',{
            text: 'Обновить',
            handler: function(){ this.refresh(); },
            scope: this
        }],
        listeners: {
            rowclick: {fn: function(grid, rowIndex, e){
                var target = e && e.getTarget ? e.getTarget() : null;
                if (target && String(target.className || '').indexOf('x-grid3-row-checker') !== -1) { return; }
                var rec = grid.store.getAt(rowIndex);
                grid.getSelectionModel().selectRow(rowIndex, !!(e && (e.ctrlKey || e.shiftKey)));
                this.selectVideo(rec);
            }, scope: this},
            rowdblclick: {fn: function(grid, rowIndex){
                var rec = grid.store.getAt(rowIndex);
                if (rec) {
                    grid.getSelectionModel().selectRow(rowIndex, false);
                    this.updateVideo(rec);
                }
            }, scope: this},
            rowcontextmenu: {fn: function(grid, rowIndex, e){
                var rec = grid.store.getAt(rowIndex);
                if (!rec) { return; }
                grid.getSelectionModel().selectRow(rowIndex, false);
                this.menu.record = rec;
                this.selectVideo(rec);
                this.getMenu();
                if (this.menu) { this.menu.showAt(e.getXY()); }
                e.stopEvent();
            }, scope: this},
            cellclick: {fn: function(grid, rowIndex, colIndex){
                var rec = grid.store.getAt(rowIndex);
                var dataIndex = grid.getColumnModel().getDataIndex(colIndex);
                if (!rec) { return; }
                grid.getSelectionModel().selectRow(rowIndex, false);
                if (dataIndex === 'is_active') {
                    this.quickUpdate(rec, {is_active: Training.utils.getRecordValue(rec, 'is_active') ? 0 : 1});
                } else if (dataIndex === 'is_default' && !Training.utils.getRecordValue(rec, 'is_default')) {
                    this.quickUpdate(rec, {is_default: 1});
                }
            }, scope: this},
            afterrender: {fn: this.initRowDragDrop, scope: this}
        }
    });
    Training.grid.LessonVideos.superclass.constructor.call(this, config);

    this.getStore().on('load', function(store){
        var selected = this.getSelectedRecord();
        var rec = null;
        if (selected) {
            rec = store.getById ? store.getById(parseInt(Training.utils.getRecordValue(selected, 'id'), 10)) : null;
        }
        if (!rec && store.getCount()) {
            rec = store.getAt(0);
        }
        if (rec) {
            this.getSelectionModel().selectRecords([rec]);
            this.selectVideo(rec);
        } else {
            this.selectVideo(null);
        }
        this.bindRowDragDrop();
    }, this);
};
Ext.extend(Training.grid.LessonVideos, MODx.grid.Grid, {
    getSelectedRecords: function() {
        var sm = this.getSelectionModel ? this.getSelectionModel() : this.sm;
        var records = [];
        if (sm && sm.getSelections) {
            records = sm.getSelections() || [];
        } else if (sm && sm.getSelected) {
            var one = sm.getSelected();
            records = one ? [one] : [];
        }
        if ((!records || !records.length) && this.menu && this.menu.record) {
            records = [this.menu.record];
        }
        return records && records.length ? records : [];
    },

    getSelectedRecord: function() {
        var records = this.getSelectedRecords();
        return records.length ? records[0] : null;
    },

    selectVideo: function(rec) {
        var id = rec ? (parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0) : 0;
        this.currentVideoId = id;
        var qualityGrid = Ext.getCmp('training-grid-lesson-qualities');
        if (qualityGrid && typeof qualityGrid.setVideoContext === 'function') {
            qualityGrid.setVideoContext(id, rec ? rec.data : null);
        }
        var slideGrid = Ext.getCmp('training-grid-lesson-slides');
        if (slideGrid && typeof slideGrid.setVideoContext === 'function') {
            slideGrid.setVideoContext(id, rec ? rec.data : null);
        }
    },

    focusSelected: function() {
        var rec = this.getSelectedRecord();
        if (!rec) {
            MODx.msg.alert('Внимание', 'Выбери видео урока');
            return false;
        }
        this.selectVideo(rec);
        return true;
    },

    quickUpdate: function(rec, patch) {
        rec = rec || this.getSelectedRecord();
        if (!rec) { return false; }
        var data = Ext.apply({}, rec.data || rec);
        data.action = 'mgr/lesson/video/update';
        data.id = parseInt(data.id, 10) || 0;
        data.lesson_id = this.lessonId;
        data.title = data.title || 'Видео';
        data.sort_order = parseInt(data.sort_order, 10) || 1;
        data.is_default = Training.utils.toBool(data.is_default) ? 1 : 0;
        data.is_active = Training.utils.toBool(data.is_active) ? 1 : 0;
        Ext.apply(data, patch || {});
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: data,
            listeners: {success: {fn: function(){ this.refresh(); }, scope: this}}
        });
        return true;
    },

    createVideo: function() {
        var w = MODx.load({
            xtype: 'training-window-lesson-video',
            title: 'Добавить видео урока',
            baseParams: {action: 'mgr/lesson/video/create'},
            lessonId: this.lessonId,
            listeners: {success: {fn: function(){ this.refresh(); }, scope: this}}
        });
        w.setValues({lesson_id: this.lessonId, is_active: 1, is_default: 0, sort_order: 1});
        w.show();
    },

    updateVideo: function(rec) {
        rec = rec || this.getSelectedRecord();
        if (!rec) {
            MODx.msg.alert('Внимание', 'Выбери видео урока');
            return false;
        }
        var w = MODx.load({
            xtype: 'training-window-lesson-video',
            title: 'Изменить видео урока',
            baseParams: {action: 'mgr/lesson/video/update'},
            lessonId: this.lessonId,
            listeners: {success: {fn: function(){ this.refresh(); }, scope: this}}
        });
        w.setValues(rec.data || rec);
        w.show();
        return true;
    },

    removeVideo: function() {
        var ids = [];
        Ext.each(this.getSelectedRecords(), function(rec){
            var id = parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0;
            if (id) { ids.push(id); }
        });
        if (!ids.length) {
            MODx.msg.alert('Внимание', 'Выбери видео урока');
            return false;
        }
        MODx.msg.confirm({
            title: 'Удаление',
            text: ids.length > 1 ? 'Удалить выбранные видео урока вместе с качествами и слайдами?' : 'Удалить видео урока вместе с качествами и слайдами?',
            url: Training.config.connector_url,
            params: {action: 'mgr/lesson/video/remove', ids: ids.join(',')},
            listeners: {success: {fn: function(){ this.refresh(); }, scope: this}}
        });
        return true;
    },

    getMenu: function() {
        var rec = this.menu && this.menu.record ? this.menu.record : this.getSelectedRecord();
        if (!rec) { return false; }
        this.addContextMenuItem([{
            text: 'Открыть',
            handler: function(){ this.selectVideo(rec); },
            scope: this
        },{
            text: 'Изменить',
            handler: function(){ this.updateVideo(rec); },
            scope: this
        },{
            text: 'Удалить',
            handler: function(){ var sm = this.getSelectionModel(); if (sm && sm.clearSelections) { sm.clearSelections(); } if (sm && sm.selectRecords) { sm.selectRecords([rec], false); } this.removeVideo(); },
            scope: this
        },'-',{
            text: Training.utils.getRecordValue(rec, 'is_active') ? 'Отключить' : 'Включить',
            handler: function(){ this.quickUpdate(rec, {is_active: Training.utils.getRecordValue(rec, 'is_active') ? 0 : 1}); },
            scope: this
        },{
            text: 'Сделать по умолчанию',
            handler: function(){ this.quickUpdate(rec, {is_default: 1}); },
            scope: this
        }]);
        return true;
    },

    initRowDragDrop: function() {
        var view = this.getView();
        if (!view) { return; }
        view.on('refresh', this.bindRowDragDrop, this);
        this.bindRowDragDrop();
    },

    bindRowDragDrop: function() {
        var view = this.getView();
        if (!view || !view.getRows) { return; }
        var rows = view.getRows();
        Ext.each(rows, function(row){
            if (!row || row._trainingVideoDnDBound) { return; }
            row._trainingVideoDnDBound = true;
            row.setAttribute('draggable', 'true');
            Ext.fly(row).on('dragstart', function(e){
                var rowIndex = view.findRowIndex(row);
                var rec = this.store.getAt(rowIndex);
                if (!rec) { return; }
                this.dragRecordId = parseInt(rec.get('id'), 10) || 0;
                if (e.browserEvent && e.browserEvent.dataTransfer) {
                    e.browserEvent.dataTransfer.effectAllowed = 'move';
                    e.browserEvent.dataTransfer.setData('text/plain', String(this.dragRecordId));
                }
            }, this);
            Ext.fly(row).on('dragover', function(e){
                if (e.browserEvent && e.browserEvent.preventDefault) {
                    e.browserEvent.preventDefault();
                }
                e.stopEvent();
            }, this);
            Ext.fly(row).on('drop', function(e){
                if (e.browserEvent && e.browserEvent.preventDefault) {
                    e.browserEvent.preventDefault();
                }
                e.stopEvent();
                var rowIndex = view.findRowIndex(row);
                var target = this.store.getAt(rowIndex);
                if (!target) { return; }
                var movedId = this.dragRecordId || 0;
                var targetId = parseInt(target.get('id'), 10) || 0;
                if (!movedId || !targetId || movedId === targetId) { return; }
                var box = Ext.fly(row).getBox();
                var pageY = e.getPageY ? e.getPageY() : (e.browserEvent ? e.browserEvent.pageY : 0);
                var position = (pageY - box.y) < (box.height / 2) ? 'before' : 'after';
                MODx.Ajax.request({
                    url: Training.config.connector_url,
                    params: {action: 'mgr/lesson/video/reorder', id: movedId, target_id: targetId, position: position},
                    listeners: {success: {fn: function(){ this.refresh(); }, scope: this}}
                });
            }, this);
        }, this);
    }
});
Ext.reg('training-grid-lesson-videos', Training.grid.LessonVideos);

Training.window.LessonVideo = function(config) {
    config = config || {};
    this.lessonId = config.lessonId || Training.config.lesson_id;
    Ext.applyIf(config, {
        width: 760,
        autoHeight: true,
        url: Training.config.connector_url,
        fields: [
            {xtype:'hidden',name:'id'},
            {xtype:'hidden',name:'lesson_id',value:this.lessonId},
            {xtype:'textfield',fieldLabel:'Название',name:'title',anchor:'100%',allowBlank:false},
            {xtype:'numberfield',fieldLabel:'Порядок',name:'sort_order',anchor:'100%'},
            {xtype:'button',text:'Выбрать исходное видео',style:'margin-bottom:10px;',handler:function(btn){var win=btn.findParentByType('modx-window')||btn.findParentByType('window');var form=win&&win.fp?win.fp.getForm():null;var field=form?form.findField('source_video'):null;Training.utils.openPathBrowser(field,{source:Training.config.media_source||3,allowedFileTypes:'mkv,mp4,mov,avi,webm,m3u8'});}},
            {xtype:'textfield',fieldLabel:'Исходное видео',name:'source_video',anchor:'100%'},
            {xtype:'textarea',fieldLabel:'Описание',name:'description',anchor:'100%'},
            {xtype:'xcheckbox',boxLabel:'По умолчанию',hideLabel:true,name:'is_default',inputValue:1},
            {xtype:'xcheckbox',boxLabel:'Активно',hideLabel:true,name:'is_active',inputValue:1,checked:true}
        ]
    });
    Training.window.LessonVideo.superclass.constructor.call(this, config);
};
Ext.extend(Training.window.LessonVideo, MODx.Window);
Ext.reg('training-window-lesson-video', Training.window.LessonVideo);
