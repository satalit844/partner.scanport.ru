Training.grid.LessonQualities = function(config) {
    config = config || {};
    this.lessonId = config.lessonId || Training.config.lesson_id;
    this.lessonVideoId = config.lessonVideoId || 0;
    this.sm = new Ext.grid.CheckboxSelectionModel({singleSelect: false});
    this.activeRecord = null;

    Ext.applyIf(config, {
        id: 'training-grid-lesson-qualities',
        url: Training.config.connector_url,
        baseParams: {action: 'mgr/lesson/qualities/getlist', lesson_video_id: this.lessonVideoId},
        sm: this.sm,
        fields: ['id','lesson_video_id','quality','mime','file_path','width','height','bitrate','filesize','is_default','is_active'],
        paging: true,
        remoteSort: false,
        autoHeight: true,
        anchor: '100%',
        columns: [
            this.sm,
            {header: 'ID', dataIndex: 'id', width: 50},
            {header: 'Качество', dataIndex: 'quality', width: 80},
            {header: 'MIME', dataIndex: 'mime', width: 120},
            {header: 'Файл', dataIndex: 'file_path', width: 320, renderer: Training.utils.renderFileLink},
            {header: 'Размер', dataIndex: 'filesize', width: 100, renderer: Training.utils.renderBytes},
            {header: 'Разрешение', dataIndex: 'width', width: 100, renderer: function(v,m,rec){ return (rec.data.width||0) + '×' + (rec.data.height||0); }},
            {header: 'Битрейт', dataIndex: 'bitrate', width: 80},
            {header: 'По умолчанию', dataIndex: 'is_default', width: 90, renderer: Training.utils.renderBoolean},
            {header: 'Активен', dataIndex: 'is_active', width: 80, renderer: Training.utils.renderBoolean}
        ],
        tbar: [{
            text: 'Добавить качество',
            handler: this.createQuality,
            scope: this
        },{
            text: 'Изменить',
            handler: this.updateQuality,
            scope: this
        },{
            text: 'Удалить',
            handler: this.removeQuality,
            scope: this
        },'->',{
            text: 'Обновить',
            handler: function(){ this.refresh(); },
            scope: this
        }],
        listeners: {
            rowclick: {fn: function(grid, rowIndex){
                var rec = grid.store.getAt(rowIndex);
                if (rec) { this.activeRecord = rec; }
            }, scope: this},
            rowdblclick: {fn: function(grid, rowIndex){
                var rec = grid.store.getAt(rowIndex);
                if (rec) { this.activeRecord = rec; this.updateQuality(rec); }
            }, scope: this},
            rowcontextmenu: {fn: function(grid, rowIndex, e){
                var rec = grid.store.getAt(rowIndex);
                if (!rec) { return; }
                this.activeRecord = rec;
                this.menu.record = rec;
                var sm = this.getSelectionModel();
                if (sm && sm.isSelected && !sm.isSelected(rowIndex) && sm.selectRow) {
                    sm.selectRow(rowIndex, true);
                }
                this.getMenu();
                if (this.menu) { this.menu.showAt(e.getXY()); }
                e.stopEvent();
            }, scope: this},
            cellclick: {fn: function(grid, rowIndex, colIndex, e){
                var rec = grid.store.getAt(rowIndex);
                var dataIndex = grid.getColumnModel().getDataIndex(colIndex);
                if (!rec) { return; }
                this.activeRecord = rec;
                if (this.isCheckerClick(e)) { return; }
                if (dataIndex === 'is_active') {
                    this.quickUpdate(rec, {is_active: Training.utils.getRecordValue(rec, 'is_active') ? 0 : 1});
                } else if (dataIndex === 'is_default' && !Training.utils.getRecordValue(rec, 'is_default')) {
                    this.quickUpdate(rec, {is_default: 1});
                }
            }, scope: this}
        }
    });

    Training.grid.LessonQualities.superclass.constructor.call(this, config);
    var sm = this.getSelectionModel();
    if (sm && sm.on) {
        sm.on('rowselect', function(selectionModel, rowIndex, rec){ this.activeRecord = rec || null; }, this);
        sm.on('rowdeselect', function(selectionModel){
            var selections = selectionModel.getSelections ? (selectionModel.getSelections() || []) : [];
            this.activeRecord = selections.length ? selections[0] : null;
        }, this);
    }
};
Ext.extend(Training.grid.LessonQualities, MODx.grid.Grid, {
    isCheckerClick: function(e) {
        return !!(e && e.getTarget && e.getTarget('.x-grid3-row-checker'));
    },

    setVideoContext: function(videoId) {
        this.lessonVideoId = parseInt(videoId, 10) || 0;
        this.baseParams.lesson_video_id = this.lessonVideoId;
        var store = this.getStore();
        store.baseParams.lesson_video_id = this.lessonVideoId;
        store.removeAll();
        this.activeRecord = null;
        if (this.lessonVideoId > 0) {
            store.load({params: {start: 0, limit: this.pageSize || 20}});
        }
    },

    ensureSelectedVideo: function() {
        var videos = Ext.getCmp('training-grid-lesson-videos');
        var rec = videos && videos.getSelectedRecord ? videos.getSelectedRecord() : null;
        if (!rec && videos && videos.activeRecord) {
            rec = videos.activeRecord;
        }
        if (rec && videos && videos.selectVideo) {
            videos.activeRecord = rec;
            videos.selectVideo(rec);
            this.lessonVideoId = parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0;
        }
        if (this.lessonVideoId > 0) { return true; }
        MODx.msg.alert('Внимание', 'Сначала выбери видео урока в верхней таблице');
        return false;
    },

    getSelectedQualityIds: function() {
        var ids = [];
        var sm = this.getSelectionModel ? this.getSelectionModel() : this.sm;
        if (sm && sm.getSelections) {
            Ext.each(sm.getSelections(), function(rec){
                var id = parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0;
                if (id) { ids.push(id); }
            });
        }
        if (!ids.length && this.menu && this.menu.record) {
            var menuId = parseInt(Training.utils.getRecordValue(this.menu.record, 'id'), 10) || 0;
            if (menuId) { ids.push(menuId); }
        }
        if (!ids.length && this.activeRecord) {
            var activeId = parseInt(Training.utils.getRecordValue(this.activeRecord, 'id'), 10) || 0;
            if (activeId) { ids.push(activeId); }
        }
        return ids;
    },

    getSelectedRecord: function() {
        var sm = this.getSelectionModel ? this.getSelectionModel() : this.sm;
        if (sm && sm.getSelections) {
            var selections = sm.getSelections();
            if (selections && selections.length) { return selections[0]; }
        }
        if (this.menu && this.menu.record) { return this.menu.record; }
        return this.activeRecord || null;
    },

    setWindowBaseParams: function(w, baseParams) {
        if (!w) { return; }
        w.baseParams = Ext.apply({}, baseParams || {});
        if (w.fp) {
            w.fp.baseParams = Ext.apply({}, baseParams || {});
            if (w.fp.form) { w.fp.form.baseParams = Ext.apply({}, baseParams || {}); }
            if (w.fp.getForm) { w.fp.getForm().baseParams = Ext.apply({}, baseParams || {}); }
        }
    },

    quickUpdate: function(rec, patch) {
        rec = rec || this.getSelectedRecord();
        if (!rec) { return false; }
        var data = Ext.apply({}, rec.data || rec);
        data.action = 'mgr/lesson/quality/update';
        data.id = parseInt(data.id, 10) || 0;
        data.lesson_video_id = this.lessonVideoId;
        data.quality = data.quality || '';
        data.file_path = data.file_path || '';
        data.is_default = Training.utils.toBool(data.is_default) ? 1 : 0;
        data.is_active = Training.utils.toBool(data.is_active) ? 1 : 0;
        Ext.apply(data, patch || {});
        MODx.Ajax.request({url: Training.config.connector_url, params: data, listeners: {success: {fn: function(){ this.refresh(); }, scope: this}}});
        return true;
    },

    createQuality: function() {
        if (!this.ensureSelectedVideo()) { return false; }
        var defaultValues = {lesson_video_id: this.lessonVideoId, mime: 'video/mp4', is_active: 1, is_default: 0};
        var w = MODx.load({
            xtype: 'training-window-lesson-quality',
            id: Ext.id(null, 'training-window-lesson-quality-create-'),
            title: 'Добавить качество',
            baseParams: {action: 'mgr/lesson/quality/create'},
            lessonVideoId: this.lessonVideoId,
            listeners: {success: {fn: function(){ this.refresh(); }, scope: this}}
        });
        this.setWindowBaseParams(w, {action: 'mgr/lesson/quality/create'});
        w.show();
        if (w.setValues) { w.setValues(defaultValues); }
        if (w.fp && w.fp.getForm) { w.fp.getForm().setValues(defaultValues); }
    },

    updateQuality: function(rec) {
        rec = rec || this.getSelectedRecord();
        if (!rec) { MODx.msg.alert('Внимание', 'Выбери качество'); return false; }
        var recordData = Ext.apply({}, rec.data || rec);
        recordData.id = parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0;
        recordData.lesson_video_id = this.lessonVideoId;
        var w = MODx.load({
            xtype: 'training-window-lesson-quality',
            id: Ext.id(null, 'training-window-lesson-quality-update-'),
            title: 'Изменить качество',
            baseParams: {action: 'mgr/lesson/quality/update', id: recordData.id},
            lessonVideoId: this.lessonVideoId,
            listeners: {success: {fn: function(){ this.refresh(); }, scope: this}}
        });
        this.setWindowBaseParams(w, {action: 'mgr/lesson/quality/update', id: recordData.id});
        w.show();
        if (w.setValues) { w.setValues(recordData); }
        if (w.fp && w.fp.getForm) { w.fp.getForm().setValues(recordData); }
        return true;
    },

    removeQuality: function() {
        var ids = this.getSelectedQualityIds();
        if (!ids.length) { MODx.msg.alert('Внимание', 'Выбери качество'); return false; }
        MODx.msg.confirm({
            title: 'Удаление',
            text: ids.length > 1 ? 'Удалить выбранные качества видео?' : 'Удалить качество видео?',
            url: Training.config.connector_url,
            params: {action: 'mgr/lesson/quality/remove', ids: ids.join(',')},
            listeners: {success: {fn: function(){ this.refresh(); var videos = Ext.getCmp('training-grid-lesson-videos'); if (videos) { videos.refresh(); } }, scope: this}}
        });
        return true;
    },

    getMenu: function() {
        var rec = this.menu && this.menu.record ? this.menu.record : this.getSelectedRecord();
        if (!rec) { return false; }
        this.addContextMenuItem([{
            text: 'Изменить',
            handler: function(){ this.activeRecord = rec; this.updateQuality(rec); },
            scope: this
        },{
            text: 'Удалить',
            handler: function(){ this.activeRecord = rec; this.removeQuality(); },
            scope: this
        },'-',{
            text: Training.utils.getRecordValue(rec, 'is_active') ? 'Отключить' : 'Включить',
            handler: function(){ this.quickUpdate(rec, {is_active: Training.utils.getRecordValue(rec, 'is_active') ? 0 : 1}); },
            scope: this
        },{
            text: 'Сделать по умолчанию',
            handler: function(){ this.quickUpdate(rec, {is_default: 1}); },
            scope: this
        }]);
        return true;
    }
});
Ext.reg('training-grid-lesson-qualities', Training.grid.LessonQualities);

Training.window.LessonQuality = function(config) {
    config = config || {};
    this.lessonVideoId = config.lessonVideoId || 0;
    Ext.applyIf(config, {
        width: 760,
        autoHeight: true,
        url: Training.config.connector_url,
        fields: [
            {xtype:'hidden',name:'id'},
            {xtype:'hidden',name:'lesson_video_id',value:this.lessonVideoId},
            {xtype:'textfield',fieldLabel:'Качество',name:'quality',anchor:'100%',allowBlank:false},
            {xtype:'textfield',fieldLabel:'MIME',name:'mime',anchor:'100%'},
            {xtype:'button',text:'Выбрать файл качества',style:'margin-bottom:10px;',handler:function(btn){var win=btn.findParentByType('modx-window')||btn.findParentByType('window');var form=win&&win.fp?win.fp.getForm():null;var field=form?form.findField('file_path'):null;Training.utils.openPathBrowser(field,{source:Training.config.media_source||3,allowedFileTypes:'mp4,m3u8,webm,mov'});}},
            {xtype:'textfield',fieldLabel:'Файл',name:'file_path',anchor:'100%',allowBlank:false},
            {xtype:'numberfield',fieldLabel:'Ширина',name:'width',anchor:'100%'},
            {xtype:'numberfield',fieldLabel:'Высота',name:'height',anchor:'100%'},
            {xtype:'numberfield',fieldLabel:'Битрейт',name:'bitrate',anchor:'100%'},
            {xtype:'numberfield',fieldLabel:'Размер файла',name:'filesize',anchor:'100%'},
            {xtype:'xcheckbox',boxLabel:'По умолчанию',hideLabel:true,name:'is_default',inputValue:1},
            {xtype:'xcheckbox',boxLabel:'Активно',hideLabel:true,name:'is_active',inputValue:1,checked:true}
        ]
    });
    Training.window.LessonQuality.superclass.constructor.call(this, config);
};
Ext.extend(Training.window.LessonQuality, MODx.Window);
Ext.reg('training-window-lesson-quality', Training.window.LessonQuality);
