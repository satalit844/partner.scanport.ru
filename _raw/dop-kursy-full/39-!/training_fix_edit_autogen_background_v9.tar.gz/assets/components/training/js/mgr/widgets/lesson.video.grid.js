Training.grid.LessonVideos = function(config) {
    config = config || {};
    this.lessonId = config.lessonId || Training.config.lesson_id;
    this.moduleId = config.moduleId || Training.config.module_id;
    this.sm = new Ext.grid.CheckboxSelectionModel({singleSelect: false});
    this.currentVideoId = 0;
    this.dragRecordId = 0;
    this.activeRecord = null;

    Ext.applyIf(config, {
        id: 'training-grid-lesson-videos',
        url: Training.config.connector_url,
        baseParams: {action: 'mgr/lesson/videos/getlist', lesson_id: this.lessonId},
        sm: this.sm,
        fields: ['id','lesson_id','title','description','sort_order','source_video','duration_seconds','video_status','is_default','is_active','qualities_count','slides_count'],
        paging: true,
        remoteSort: true,
        sortBy: 'sort_order',
        sortDir: 'ASC',
        autoHeight: true,
        anchor: '100%',
        columns: [
            this.sm,
            {header: 'ID', dataIndex: 'id', width: 50},
            {header: 'Видео урока', dataIndex: 'title', width: 260},
            {header: 'Порядок', dataIndex: 'sort_order', width: 70},
            {header: 'Исходное видео', dataIndex: 'source_video', width: 300, renderer: Training.utils.renderFileLink},
            {header: 'Статус', dataIndex: 'video_status', width: 80},
            {header: 'Длительность', dataIndex: 'duration_seconds', width: 90, renderer: Training.utils.renderSeconds},
            {header: 'Качества', dataIndex: 'qualities_count', width: 70},
            {header: 'Слайды', dataIndex: 'slides_count', width: 70},
            {header: 'По умолчанию', dataIndex: 'is_default', width: 90, renderer: Training.utils.renderBoolean},
            {header: 'Активен', dataIndex: 'is_active', width: 80, renderer: Training.utils.renderBoolean}
        ],
        tbar: [{
            text: 'Добавить видео',
            handler: this.createVideo,
            scope: this
        },{
            text: 'Открыть',
            handler: this.focusSelected,
            scope: this
        },{
            text: 'Изменить',
            handler: this.updateVideo,
            scope: this
        },{
            text: 'Удалить',
            handler: this.removeVideo,
            scope: this
        },'->',{
            text: 'Обновить',
            handler: function(){ this.refresh(); },
            scope: this
        }],
        listeners: {
            rowclick: {fn: function(grid, rowIndex, e){
                var rec = grid.store.getAt(rowIndex);
                if (!rec) { return; }
                this.activeRecord = rec;
                this.selectVideo(rec);
            }, scope: this},
            rowdblclick: {fn: function(grid, rowIndex){
                var rec = grid.store.getAt(rowIndex);
                if (rec) {
                    this.activeRecord = rec;
                    this.selectVideo(rec);
                    this.updateVideo(rec);
                }
            }, scope: this},
            rowcontextmenu: {fn: function(grid, rowIndex, e){
                var rec = grid.store.getAt(rowIndex);
                if (!rec) { return; }
                this.activeRecord = rec;
                this.menu.record = rec;
                this.selectVideo(rec);
                var sm = this.getSelectionModel();
                if (sm && sm.isSelected && !sm.isSelected(rowIndex) && sm.selectRow) {
                    sm.selectRow(rowIndex, true);
                }
                this.getMenu();
                if (this.menu) { this.menu.showAt(e.getXY()); }
                e.stopEvent();
            }, scope: this},
            cellclick: {fn: function(grid, rowIndex, colIndex, e){
                var rec = grid.store.getAt(rowIndex);
                var dataIndex = grid.getColumnModel().getDataIndex(colIndex);
                if (!rec) { return; }
                this.activeRecord = rec;
                this.selectVideo(rec);
                if (this.isCheckerClick(e)) { return; }
                if (dataIndex === 'is_active') {
                    this.quickUpdate(rec, {is_active: Training.utils.getRecordValue(rec, 'is_active') ? 0 : 1});
                } else if (dataIndex === 'is_default' && !Training.utils.getRecordValue(rec, 'is_default')) {
                    this.quickUpdate(rec, {is_default: 1});
                }
            }, scope: this},
            afterrender: {fn: this.initRowDragDrop, scope: this}
        }
    });

    Training.grid.LessonVideos.superclass.constructor.call(this, config);

    var sm = this.getSelectionModel();
    if (sm && sm.on) {
        sm.on('rowselect', function(selectionModel, rowIndex, rec){
            this.activeRecord = rec || null;
            this.selectVideo(this.activeRecord);
        }, this);
        sm.on('rowdeselect', function(selectionModel, rowIndex, rec){
            var selections = selectionModel.getSelections ? (selectionModel.getSelections() || []) : [];
            var activeId = this.activeRecord ? (parseInt(Training.utils.getRecordValue(this.activeRecord, 'id'), 10) || 0) : 0;
            var recId = rec ? (parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0) : 0;
            if (activeId > 0 && activeId === recId) {
                this.activeRecord = selections.length ? selections[0] : null;
                this.selectVideo(this.activeRecord);
            }
        }, this);
    }

    this.getStore().on('load', function(store){
        var rec = null;
        var preferredId = this.currentVideoId || (this.activeRecord ? (parseInt(Training.utils.getRecordValue(this.activeRecord, 'id'), 10) || 0) : 0);
        if (preferredId > 0) {
            store.each(function(item){
                if (!rec && (parseInt(Training.utils.getRecordValue(item, 'id'), 10) || 0) === preferredId) {
                    rec = item;
                }
            });
        }
        if (!rec && store.getCount()) {
            rec = store.getAt(0);
        }
        this.activeRecord = rec || null;
        this.selectVideo(this.activeRecord);
        this.bindRowDragDrop();
    }, this);
};
Ext.extend(Training.grid.LessonVideos, MODx.grid.Grid, {
    isCheckerClick: function(e) {
        return !!(e && e.getTarget && e.getTarget('.x-grid3-row-checker'));
    },

    getSelectedVideoIds: function() {
        var ids = [];
        var sm = this.getSelectionModel ? this.getSelectionModel() : this.sm;
        if (sm && sm.getSelections) {
            Ext.each(sm.getSelections(), function(rec) {
                var id = parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0;
                if (id) { ids.push(id); }
            });
        }
        if (!ids.length && this.menu && this.menu.record) {
            var menuId = parseInt(Training.utils.getRecordValue(this.menu.record, 'id'), 10) || 0;
            if (menuId) { ids.push(menuId); }
        }
        if (!ids.length && this.activeRecord) {
            var activeId = parseInt(Training.utils.getRecordValue(this.activeRecord, 'id'), 10) || 0;
            if (activeId) { ids.push(activeId); }
        }
        return ids;
    },

    getSelectedRecord: function() {
        var sm = this.getSelectionModel ? this.getSelectionModel() : this.sm;
        if (sm && sm.getSelections) {
            var selections = sm.getSelections();
            if (selections && selections.length) {
                return selections[0];
            }
        }
        if (this.menu && this.menu.record) {
            return this.menu.record;
        }
        return this.activeRecord || null;
    },

    selectVideo: function(rec) {
        var id = rec ? (parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0) : 0;
        this.currentVideoId = id;
        var qualityGrid = Ext.getCmp('training-grid-lesson-qualities');
        if (qualityGrid && typeof qualityGrid.setVideoContext === 'function') {
            qualityGrid.setVideoContext(id, rec ? rec.data : null);
        }
        var slideGrid = Ext.getCmp('training-grid-lesson-slides');
        if (slideGrid && typeof slideGrid.setVideoContext === 'function') {
            slideGrid.setVideoContext(id, rec ? rec.data : null);
        }
    },

    focusSelected: function() {
        var rec = this.getSelectedRecord();
        if (!rec) {
            MODx.msg.alert('Внимание', 'Выбери видео урока');
            return false;
        }
        this.activeRecord = rec;
        this.selectVideo(rec);
        return true;
    },

    setWindowBaseParams: function(w, baseParams) {
        if (!w) { return; }
        w.baseParams = Ext.apply({}, baseParams || {});
        if (w.fp) {
            w.fp.baseParams = Ext.apply({}, baseParams || {});
            if (w.fp.form) {
                w.fp.form.baseParams = Ext.apply({}, baseParams || {});
            }
            if (w.fp.getForm) {
                w.fp.getForm().baseParams = Ext.apply({}, baseParams || {});
            }
        }
    },

    getWindowValues: function(w) {
        if (w && w.fp && w.fp.getForm) {
            return w.fp.getForm().getValues();
        }
        return {};
    },

    autoTranscodeIfNeeded: function(videoId, sourceVideo) {
        videoId = parseInt(videoId, 10) || 0;
        sourceVideo = String(sourceVideo || '');
        if (!videoId || !sourceVideo) {
            return;
        }
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {action: 'mgr/lesson/video/transcode', lesson_video_id: videoId},
            listeners: {
                success: {fn: function(){
                    var qualityGrid = Ext.getCmp('training-grid-lesson-qualities');
                    var slideGrid = Ext.getCmp('training-grid-lesson-slides');
                    this.currentVideoId = videoId;
                    this.refresh();
                    if (qualityGrid) {
                        qualityGrid.lessonVideoId = videoId;
                        qualityGrid.refresh();
                    }
                    if (slideGrid) {
                        slideGrid.lessonVideoId = videoId;
                        slideGrid.refresh();
                    }
                }, scope: this},
                failure: {fn: function(){
                    this.currentVideoId = videoId;
                    this.refresh();
                }, scope: this}
            }
        });
    },

    quickUpdate: function(rec, patch) {
        rec = rec || this.getSelectedRecord();
        if (!rec) { return false; }
        var data = Ext.apply({}, rec.data || rec);
        data.action = 'mgr/lesson/video/update';
        data.id = parseInt(data.id, 10) || 0;
        data.lesson_id = this.lessonId;
        data.title = data.title || 'Видео';
        data.sort_order = parseInt(data.sort_order, 10) || 1;
        data.is_default = Training.utils.toBool(data.is_default) ? 1 : 0;
        data.is_active = Training.utils.toBool(data.is_active) ? 1 : 0;
        Ext.apply(data, patch || {});
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: data,
            listeners: {success: {fn: function(){ this.currentVideoId = parseInt(data.id, 10) || this.currentVideoId; this.refresh(); }, scope: this}}
        });
        return true;
    },

    getNextSortOrder: function() {
        var maxSort = 0;
        this.getStore().each(function(rec){
            var sort = parseInt(Training.utils.getRecordValue(rec, 'sort_order'), 10) || 0;
            if (sort > maxSort) { maxSort = sort; }
        });
        return maxSort + 1;
    },

    createVideo: function() {
        var grid = this;
        var defaultValues = {lesson_id: this.lessonId, is_active: 1, is_default: 0, sort_order: this.getNextSortOrder()};
        var w = MODx.load({
            xtype: 'training-window-lesson-video',
            id: Ext.id(null, 'training-window-lesson-video-create-'),
            title: 'Добавить видео урока',
            baseParams: {action: 'mgr/lesson/video/create'},
            lessonId: this.lessonId,
            listeners: {success: {fn: function(r){
                var result = Training.utils.getResultData ? Training.utils.getResultData(r) : null;
                var values = grid.getWindowValues(w);
                var newId = result && result.id ? (parseInt(result.id, 10) || 0) : 0;
                if (newId) {
                    grid.currentVideoId = newId;
                }
                grid.refresh();
                grid.autoTranscodeIfNeeded(newId, values.source_video || '');
            }, scope: this}}
        });
        this.setWindowBaseParams(w, {action: 'mgr/lesson/video/create'});
        w.show();
        if (w.setValues) { w.setValues(defaultValues); }
        if (w.fp && w.fp.getForm) { w.fp.getForm().setValues(defaultValues); }
    },

    updateVideo: function(rec) {
        var grid = this;
        rec = rec || this.getSelectedRecord();
        if (!rec) {
            MODx.msg.alert('Внимание', 'Выбери видео урока');
            return false;
        }
        var recordData = Ext.apply({}, rec.data || rec);
        recordData.id = parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0;
        recordData.lesson_id = this.lessonId;
        var oldSourceVideo = String(recordData.source_video || '');
        var w = MODx.load({
            xtype: 'training-window-lesson-video',
            id: Ext.id(null, 'training-window-lesson-video-update-'),
            title: 'Изменить видео урока',
            baseParams: {action: 'mgr/lesson/video/update', id: recordData.id},
            lessonId: this.lessonId,
            listeners: {success: {fn: function(){
                var values = grid.getWindowValues(w);
                grid.currentVideoId = recordData.id;
                grid.refresh();
                if (String(values.source_video || '') !== '' && String(values.source_video || '') !== oldSourceVideo) {
                    grid.autoTranscodeIfNeeded(recordData.id, values.source_video || '');
                }
            }, scope: this}}
        });
        this.setWindowBaseParams(w, {action: 'mgr/lesson/video/update', id: recordData.id});
        w.show();
        if (w.setValues) { w.setValues(recordData); }
        if (w.fp && w.fp.getForm) { w.fp.getForm().setValues(recordData); }
        return true;
    },

    removeVideo: function() {
        var ids = this.getSelectedVideoIds();
        if (!ids.length) {
            MODx.msg.alert('Внимание', 'Выбери видео урока');
            return false;
        }
        MODx.msg.confirm({
            title: 'Удаление',
            text: ids.length > 1 ? 'Удалить выбранные видео урока вместе с качествами и слайдами?' : 'Удалить видео урока вместе с качествами и слайдами?',
            url: Training.config.connector_url,
            params: {action: 'mgr/lesson/video/remove', ids: ids.join(',')},
            listeners: {success: {fn: function(){
                var currentId = parseInt(this.currentVideoId, 10) || 0;
                Ext.each(ids, function(id){ if ((parseInt(id, 10) || 0) === currentId) { this.currentVideoId = 0; } }, this);
                this.refresh();
            }, scope: this}}
        });
        return true;
    },

    getMenu: function() {
        var rec = this.menu && this.menu.record ? this.menu.record : this.getSelectedRecord();
        if (!rec) { return false; }
        this.addContextMenuItem([{
            text: 'Открыть',
            handler: function(){ this.activeRecord = rec; this.selectVideo(rec); },
            scope: this
        },{
            text: 'Изменить',
            handler: function(){ this.activeRecord = rec; this.updateVideo(rec); },
            scope: this
        },{
            text: 'Удалить',
            handler: function(){ this.activeRecord = rec; this.removeVideo(); },
            scope: this
        },'-',{
            text: Training.utils.getRecordValue(rec, 'is_active') ? 'Отключить' : 'Включить',
            handler: function(){ this.quickUpdate(rec, {is_active: Training.utils.getRecordValue(rec, 'is_active') ? 0 : 1}); },
            scope: this
        },{
            text: 'Сделать по умолчанию',
            handler: function(){ this.quickUpdate(rec, {is_default: 1}); },
            scope: this
        }]);
        return true;
    },

    initRowDragDrop: function() {
        var view = this.getView();
        if (!view) { return; }
        view.on('refresh', this.bindRowDragDrop, this);
        this.bindRowDragDrop();
    },

    bindRowDragDrop: function() {
        var view = this.getView();
        if (!view || !view.getRows) { return; }
        var rows = view.getRows();
        Ext.each(rows, function(row){
            if (!row || row._trainingVideoDnDBound) { return; }
            row._trainingVideoDnDBound = true;
            row.setAttribute('draggable', 'true');
            Ext.fly(row).on('dragstart', function(e){
                var rowIndex = view.findRowIndex(row);
                var rec = this.store.getAt(rowIndex);
                if (!rec) { return; }
                this.dragRecordId = parseInt(rec.get('id'), 10) || 0;
                if (e.browserEvent && e.browserEvent.dataTransfer) {
                    e.browserEvent.dataTransfer.effectAllowed = 'move';
                    e.browserEvent.dataTransfer.setData('text/plain', String(this.dragRecordId));
                }
            }, this);
            Ext.fly(row).on('dragover', function(e){
                if (e.browserEvent && e.browserEvent.preventDefault) { e.browserEvent.preventDefault(); }
                e.stopEvent();
            }, this);
            Ext.fly(row).on('drop', function(e){
                if (e.browserEvent && e.browserEvent.preventDefault) { e.browserEvent.preventDefault(); }
                e.stopEvent();
                var rowIndex = view.findRowIndex(row);
                var target = this.store.getAt(rowIndex);
                if (!target) { return; }
                var movedId = this.dragRecordId || 0;
                var targetId = parseInt(target.get('id'), 10) || 0;
                if (!movedId || !targetId || movedId === targetId) { return; }
                var box = Ext.fly(row).getBox();
                var pageY = e.getPageY ? e.getPageY() : (e.browserEvent ? e.browserEvent.pageY : 0);
                var position = (pageY - box.y) < (box.height / 2) ? 'before' : 'after';
                MODx.Ajax.request({
                    url: Training.config.connector_url,
                    params: {action: 'mgr/lesson/video/reorder', id: movedId, target_id: targetId, position: position},
                    listeners: {success: {fn: function(){ this.currentVideoId = movedId; this.refresh(); }, scope: this}}
                });
            }, this);
        }, this);
    }
});
Ext.reg('training-grid-lesson-videos', Training.grid.LessonVideos);

Training.window.LessonVideo = function(config) {
    config = config || {};
    this.lessonId = config.lessonId || Training.config.lesson_id;
    Ext.applyIf(config, {
        width: 760,
        autoHeight: true,
        url: Training.config.connector_url,
        fields: [
            {xtype:'hidden',name:'id'},
            {xtype:'hidden',name:'lesson_id',value:this.lessonId},
            {xtype:'textfield',fieldLabel:'Название',name:'title',anchor:'100%',allowBlank:false},
            {xtype:'numberfield',fieldLabel:'Порядок',name:'sort_order',anchor:'100%'},
            {xtype:'button',text:'Выбрать исходное видео',style:'margin-bottom:10px;',handler:function(btn){var win=btn.findParentByType('modx-window')||btn.findParentByType('window');var form=win&&win.fp?win.fp.getForm():null;var field=form?form.findField('source_video'):null;Training.utils.openPathBrowser(field,{source:Training.config.media_source||3,allowedFileTypes:'mkv,mp4,mov,avi,webm,m3u8'});}},
            {xtype:'textfield',fieldLabel:'Исходное видео',name:'source_video',anchor:'100%'},
            {xtype:'textarea',fieldLabel:'Описание',name:'description',anchor:'100%'},
            {xtype:'xcheckbox',boxLabel:'По умолчанию',hideLabel:true,name:'is_default',inputValue:1},
            {xtype:'xcheckbox',boxLabel:'Активно',hideLabel:true,name:'is_active',inputValue:1,checked:true}
        ]
    });
    Training.window.LessonVideo.superclass.constructor.call(this, config);
};
Ext.extend(Training.window.LessonVideo, MODx.Window);
Ext.reg('training-window-lesson-video', Training.window.LessonVideo);
