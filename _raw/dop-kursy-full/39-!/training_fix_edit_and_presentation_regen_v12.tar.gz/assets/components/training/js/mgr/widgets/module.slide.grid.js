Training.grid.LessonSlides = function(config) {
    config = config || {};
    this.lessonId = config.lessonId || Training.config.lesson_id;
    this.lessonVideoId = config.lessonVideoId || 0;
    this.sm = new Ext.grid.CheckboxSelectionModel({singleSelect: false});
    this.dragRecordId = 0;
    this.activeRecord = null;

    Ext.applyIf(config, {
        id: 'training-grid-lesson-slides',
        url: Training.config.connector_url,
        baseParams: {action: 'mgr/lesson/slides/getlist', lesson_video_id: this.lessonVideoId},
        sm: this.sm,
        fields: ['id','lesson_video_id','slide_no','image','timecode_ms','timecode_human','is_active'],
        paging: true,
        remoteSort: false,
        autoHeight: true,
        anchor: '100%',
        columns: [
            this.sm,
            {header: 'ID', dataIndex: 'id', width: 50},
            {header: 'Слайд', dataIndex: 'slide_no', width: 70},
            {header: 'Изображение', dataIndex: 'image', width: 300, renderer: Training.utils.renderFileLink},
            {header: 'Превью', dataIndex: 'image', width: 100, renderer: Training.utils.renderSlidePreview},
            {header: 'Таймкод', dataIndex: 'timecode_human', width: 80},
            {header: 'Активен', dataIndex: 'is_active', width: 80, renderer: Training.utils.renderBoolean}
        ],
        tbar: [{
            text: 'Импортировать из презентации',
            handler: this.importSlides,
            scope: this
        },{
            text: 'Расставить таймкоды',
            handler: this.autoTimecodes,
            scope: this
        },'-',{
            text: 'Добавить слайд',
            handler: this.createSlide,
            scope: this
        },{
            text: 'Изменить',
            handler: this.updateSlide,
            scope: this
        },{
            text: 'Удалить',
            handler: this.removeSlide,
            scope: this
        },'->',{
            text: 'Обновить',
            handler: function(){ this.refresh(); },
            scope: this
        }],
        listeners: {
            rowclick: {fn: function(grid, rowIndex){
                var rec = grid.store.getAt(rowIndex);
                if (rec) { this.activeRecord = rec; }
            }, scope: this},
            rowdblclick: {fn: function(grid, rowIndex){
                var rec = grid.store.getAt(rowIndex);
                if (rec) { this.activeRecord = rec; this.updateSlide(rec); }
            }, scope: this},
            rowcontextmenu: {fn: function(grid, rowIndex, e){
                var rec = grid.store.getAt(rowIndex);
                if (!rec) { return; }
                this.activeRecord = rec;
                this.menu.record = rec;
                var sm = this.getSelectionModel();
                if (sm && sm.isSelected && !sm.isSelected(rowIndex) && sm.selectRow) {
                    sm.selectRow(rowIndex, true);
                }
                this.getMenu();
                if (this.menu) { this.menu.showAt(e.getXY()); }
                e.stopEvent();
            }, scope: this},
            cellclick: {fn: function(grid, rowIndex, colIndex, e){
                var rec = grid.store.getAt(rowIndex);
                var dataIndex = grid.getColumnModel().getDataIndex(colIndex);
                if (!rec) { return; }
                this.activeRecord = rec;
                if (this.isCheckerClick(e)) { return; }
                if (dataIndex === 'is_active') {
                    this.quickUpdate(rec, {is_active: Training.utils.getRecordValue(rec, 'is_active') ? 0 : 1});
                }
            }, scope: this},
            afterrender: {fn: this.initRowDragDrop, scope: this}
        }
    });

    Training.grid.LessonSlides.superclass.constructor.call(this, config);
    var sm = this.getSelectionModel();
    if (sm && sm.on) {
        sm.on('rowselect', function(selectionModel, rowIndex, rec){ this.activeRecord = rec || null; }, this);
        sm.on('rowdeselect', function(selectionModel){
            var selections = selectionModel.getSelections ? (selectionModel.getSelections() || []) : [];
            this.activeRecord = selections.length ? selections[0] : null;
        }, this);
    }
    this.getStore().on('load', function(){ this.bindRowDragDrop(); }, this);
};
Ext.extend(Training.grid.LessonSlides, MODx.grid.Grid, {
    isCheckerClick: function(e) {
        return !!(e && e.getTarget && e.getTarget('.x-grid3-row-checker'));
    },

    setVideoContext: function(videoId) {
        this.lessonVideoId = parseInt(videoId, 10) || 0;
        this.baseParams.lesson_video_id = this.lessonVideoId;
        var store = this.getStore();
        store.baseParams.lesson_video_id = this.lessonVideoId;
        store.removeAll();
        this.activeRecord = null;
        if (this.lessonVideoId > 0) {
            store.load({params: {start: 0, limit: this.pageSize || 20}});
        }
    },

    ensureSelectedVideo: function() {
        var videos = Ext.getCmp('training-grid-lesson-videos');
        var rec = videos && videos.getSelectedRecord ? videos.getSelectedRecord() : null;
        if (!rec && videos && videos.activeRecord) {
            rec = videos.activeRecord;
        }
        if (rec && videos && videos.selectVideo) {
            videos.activeRecord = rec;
            videos.selectVideo(rec);
            this.lessonVideoId = parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0;
        }
        if (this.lessonVideoId > 0) { return true; }
        MODx.msg.alert('Внимание', 'Сначала выбери видео урока в верхней таблице');
        return false;
    },

    getSelectedSlideIds: function() {
        var ids = [];
        var sm = this.getSelectionModel ? this.getSelectionModel() : this.sm;
        if (sm && sm.getSelections) {
            Ext.each(sm.getSelections(), function(rec){
                var id = parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0;
                if (id) { ids.push(id); }
            });
        }
        if (!ids.length && this.menu && this.menu.record) {
            var menuId = parseInt(Training.utils.getRecordValue(this.menu.record, 'id'), 10) || 0;
            if (menuId) { ids.push(menuId); }
        }
        if (!ids.length && this.activeRecord) {
            var activeId = parseInt(Training.utils.getRecordValue(this.activeRecord, 'id'), 10) || 0;
            if (activeId) { ids.push(activeId); }
        }
        return ids;
    },

    getSelectedRecord: function() {
        var sm = this.getSelectionModel ? this.getSelectionModel() : this.sm;
        if (sm && sm.getSelections) {
            var selections = sm.getSelections();
            if (selections && selections.length) { return selections[0]; }
        }
        if (this.menu && this.menu.record) { return this.menu.record; }
        return this.activeRecord || null;
    },

    setWindowBaseParams: function(w, baseParams) {
        if (!w) { return; }
        w.baseParams = Ext.apply({}, baseParams || {});
        if (w.fp) {
            w.fp.baseParams = Ext.apply({}, baseParams || {});
            if (w.fp.form) { w.fp.form.baseParams = Ext.apply({}, baseParams || {}); }
            if (w.fp.getForm) { w.fp.getForm().baseParams = Ext.apply({}, baseParams || {}); }
        }
    },

    applyWindowValues: function(w, values) {
        if (!w) { return; }
        Ext.defer(function() {
            if (w.fp && w.fp.getForm) {
                var form = w.fp.getForm();
                if (form && form.reset) { form.reset(); }
                if (form && form.setValues) { form.setValues(values || {}); }
            }
            if (w.setValues) { w.setValues(values || {}); }
        }, 50);
    },

    quickUpdate: function(rec, patch) {
        rec = rec || this.getSelectedRecord();
        if (!rec) { return false; }
        var data = Ext.apply({}, rec.data || rec);
        data.action = 'mgr/lesson/slide/update';
        data.id = parseInt(data.id, 10) || 0;
        data.lesson_video_id = this.lessonVideoId;
        data.slide_no = parseInt(data.slide_no, 10) || 1;
        data.image = data.image || '';
        data.timecode_ms = parseInt(data.timecode_ms, 10) || 0;
        data.is_active = Training.utils.toBool(data.is_active) ? 1 : 0;
        Ext.apply(data, patch || {});
        MODx.Ajax.request({url: Training.config.connector_url, params: data, listeners: {success: {fn: function(){ this.refresh(); }, scope: this}}});
        return true;
    },

    importSlides: function() {
        if (!this.ensureSelectedVideo()) { return false; }
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {action: 'mgr/lesson/slide/import', lesson_id: this.lessonId, lesson_video_id: this.lessonVideoId},
            listeners: {success: {fn: function(){ this.refresh(); var videos = Ext.getCmp('training-grid-lesson-videos'); if (videos) { videos.refresh(); } }, scope: this}}
        });
    },

    autoTimecodes: function() {
        if (!this.ensureSelectedVideo()) { return false; }
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {action: 'mgr/lesson/slide/autotimecodes', lesson_video_id: this.lessonVideoId},
            listeners: {success: {fn: function(){ this.refresh(); }, scope: this}}
        });
    },

    createSlide: function() {
        if (!this.ensureSelectedVideo()) { return false; }
        var defaultValues = {lesson_video_id: this.lessonVideoId, is_active: 1};
        var w = MODx.load({
            xtype: 'training-window-lesson-slide',
            id: Ext.id(null, 'training-window-lesson-slide-create-'),
            title: 'Добавить слайд',
            baseParams: {action: 'mgr/lesson/slide/create'},
            lessonVideoId: this.lessonVideoId,
            listeners: {success: {fn: function(){ this.refresh(); var videos = Ext.getCmp('training-grid-lesson-videos'); if (videos) { videos.refresh(); } }, scope: this}}
        });
        this.setWindowBaseParams(w, {action: 'mgr/lesson/slide/create'});
        w.show();
        this.applyWindowValues(w, defaultValues);
    },

    updateSlide: function(rec) {
        rec = rec || this.getSelectedRecord();
        if (!rec) { MODx.msg.alert('Внимание', 'Выбери слайд'); return false; }
        var recordData = Ext.apply({}, rec.data || rec);
        recordData.id = parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0;
        recordData.lesson_video_id = this.lessonVideoId;
        var w = MODx.load({
            xtype: 'training-window-lesson-slide',
            id: Ext.id(null, 'training-window-lesson-slide-update-'),
            title: 'Изменить слайд',
            baseParams: {action: 'mgr/lesson/slide/update', id: recordData.id},
            lessonVideoId: this.lessonVideoId,
            listeners: {success: {fn: function(){ this.refresh(); }, scope: this}}
        });
        this.setWindowBaseParams(w, {action: 'mgr/lesson/slide/update', id: recordData.id});
        w.show();
        this.applyWindowValues(w, recordData);
        return true;
    },

    removeSlide: function() {
        var ids = this.getSelectedSlideIds();
        if (!ids.length) { MODx.msg.alert('Внимание', 'Выбери слайд'); return false; }
        MODx.msg.confirm({
            title: 'Удаление',
            text: ids.length > 1 ? 'Удалить выбранные слайды?' : 'Удалить слайд?',
            url: Training.config.connector_url,
            params: {action: 'mgr/lesson/slide/remove', ids: ids.join(',')},
            listeners: {success: {fn: function(){ this.refresh(); var videos = Ext.getCmp('training-grid-lesson-videos'); if (videos) { videos.refresh(); } }, scope: this}}
        });
        return true;
    },

    getMenu: function() {
        var rec = this.menu && this.menu.record ? this.menu.record : this.getSelectedRecord();
        if (!rec) { return false; }
        this.addContextMenuItem([{
            text: 'Изменить',
            handler: function(){ this.activeRecord = rec; this.updateSlide(rec); },
            scope: this
        },{
            text: 'Удалить',
            handler: function(){ this.activeRecord = rec; this.removeSlide(); },
            scope: this
        },'-',{
            text: Training.utils.getRecordValue(rec, 'is_active') ? 'Отключить' : 'Включить',
            handler: function(){ this.quickUpdate(rec, {is_active: Training.utils.getRecordValue(rec, 'is_active') ? 0 : 1}); },
            scope: this
        }]);
        return true;
    },

    initRowDragDrop: function() {
        var view = this.getView();
        if (!view) { return; }
        view.on('refresh', this.bindRowDragDrop, this);
        this.bindRowDragDrop();
    },

    bindRowDragDrop: function() {
        var view = this.getView();
        if (!view || !view.getRows) { return; }
        var rows = view.getRows();
        Ext.each(rows, function(row){
            if (!row || row._trainingSlideDnDBound) { return; }
            row._trainingSlideDnDBound = true;
            row.setAttribute('draggable', 'true');
            Ext.fly(row).on('dragstart', function(e){
                var rowIndex = view.findRowIndex(row);
                var rec = this.store.getAt(rowIndex);
                if (!rec) { return; }
                this.dragRecordId = parseInt(rec.get('id'), 10) || 0;
                if (e.browserEvent && e.browserEvent.dataTransfer) {
                    e.browserEvent.dataTransfer.effectAllowed = 'move';
                    e.browserEvent.dataTransfer.setData('text/plain', String(this.dragRecordId));
                }
            }, this);
            Ext.fly(row).on('dragover', function(e){
                if (e.browserEvent && e.browserEvent.preventDefault) { e.browserEvent.preventDefault(); }
                e.stopEvent();
            }, this);
            Ext.fly(row).on('drop', function(e){
                if (e.browserEvent && e.browserEvent.preventDefault) { e.browserEvent.preventDefault(); }
                e.stopEvent();
                var rowIndex = view.findRowIndex(row);
                var target = this.store.getAt(rowIndex);
                if (!target) { return; }
                var movedId = this.dragRecordId || 0;
                var targetId = parseInt(target.get('id'), 10) || 0;
                if (!movedId || !targetId || movedId === targetId) { return; }
                var box = Ext.fly(row).getBox();
                var pageY = e.getPageY ? e.getPageY() : (e.browserEvent ? e.browserEvent.pageY : 0);
                var position = (pageY - box.y) < (box.height / 2) ? 'before' : 'after';
                MODx.Ajax.request({
                    url: Training.config.connector_url,
                    params: {action: 'mgr/lesson/slide/reorder', id: movedId, target_id: targetId, position: position},
                    listeners: {success: {fn: function(){ this.refresh(); var videos = Ext.getCmp('training-grid-lesson-videos'); if (videos) { videos.refresh(); } }, scope: this}}
                });
            }, this);
        }, this);
    }
});
Ext.reg('training-grid-lesson-slides', Training.grid.LessonSlides);

Training.window.LessonSlide = function(config) {
    config = config || {};
    this.lessonVideoId = config.lessonVideoId || 0;
    Ext.applyIf(config, {
        width: 760,
        autoHeight: true,
        url: Training.config.connector_url,
        fields: [
            {xtype:'hidden',name:'id'},
            {xtype:'hidden',name:'lesson_video_id',value:this.lessonVideoId},
            {xtype:'numberfield',fieldLabel:'Номер слайда',name:'slide_no',anchor:'100%',allowBlank:false},
            {xtype:'button',text:'Выбрать изображение',style:'margin-bottom:10px;',handler:function(btn){var win=btn.findParentByType('modx-window')||btn.findParentByType('window');var form=win&&win.fp?win.fp.getForm():null;var field=form?form.findField('image'):null;Training.utils.openPathBrowser(field,{source:Training.config.media_source||3,allowedFileTypes:'jpg,jpeg,png,webp,gif'});}},
            {xtype:'textfield',fieldLabel:'Изображение',name:'image',anchor:'100%',allowBlank:false},
            {xtype:'numberfield',fieldLabel:'Таймкод (мс)',name:'timecode_ms',anchor:'100%'},
            {xtype:'xcheckbox',boxLabel:'Активен',hideLabel:true,name:'is_active',inputValue:1,checked:true}
        ]
    });
    Training.window.LessonSlide.superclass.constructor.call(this, config);
};
Ext.extend(Training.window.LessonSlide, MODx.Window);
Ext.reg('training-window-lesson-slide', Training.window.LessonSlide);
