Training.grid.LessonVideos = function(config) {
    config = config || {};
    this.lessonId = config.lessonId || Training.config.lesson_id;
    this.moduleId = config.moduleId || Training.config.module_id;
    this.sm = new Ext.grid.CheckboxSelectionModel({singleSelect: false});
    this.currentVideoId = 0;
    this.dragRecordId = 0;
    this.activeRecord = null;
    this.selectedRecordsCache = [];

    Ext.applyIf(config, {
        id: 'training-grid-lesson-videos',
        url: Training.config.connector_url,
        baseParams: {action: 'mgr/lesson/videos/getlist', lesson_id: this.lessonId},
        sm: this.sm,
        fields: ['id','lesson_id','title','description','sort_order','source_video','duration_seconds','video_status','is_default','is_active','qualities_count','slides_count'],
        paging: true,
        remoteSort: true,
        sortBy: 'sort_order',
        sortDir: 'ASC',
        autoHeight: true,
        anchor: '100%',
        columns: [
            this.sm,
            {header: 'ID', dataIndex: 'id', width: 50},
            {header: 'Видео урока', dataIndex: 'title', width: 260},
            {header: 'Порядок', dataIndex: 'sort_order', width: 70},
            {header: 'Исходное видео', dataIndex: 'source_video', width: 300, renderer: Training.utils.renderFileLink},
            {header: 'Статус', dataIndex: 'video_status', width: 80},
            {header: 'Длительность', dataIndex: 'duration_seconds', width: 90, renderer: Training.utils.renderSeconds},
            {header: 'Качества', dataIndex: 'qualities_count', width: 70},
            {header: 'Слайды', dataIndex: 'slides_count', width: 70},
            {header: 'По умолчанию', dataIndex: 'is_default', width: 90, renderer: Training.utils.renderBoolean},
            {header: 'Активен', dataIndex: 'is_active', width: 80, renderer: Training.utils.renderBoolean}
        ],
        tbar: [{
            text: 'Добавить видео',
            handler: this.createVideo,
            scope: this
        },{
            text: 'Открыть',
            handler: this.focusSelected,
            scope: this
        },{
            text: 'Изменить',
            handler: this.updateVideo,
            scope: this
        },{
            text: 'Удалить',
            handler: this.removeVideo,
            scope: this
        },'->',{
            text: 'Обновить',
            handler: function(){ this.refresh(); },
            scope: this
        }],
        listeners: {
            rowclick: {fn: function(grid, rowIndex, e){
                var rec = grid.store.getAt(rowIndex);
                if (!rec) { return; }
                this.activeRecord = rec;
                this.selectVideo(rec);
                if (this.isCheckerClick(e)) { return; }
                var sm = this.getSelectionModel();
                if (sm && sm.selectRow) {
                    sm.selectRow(rowIndex, !!(e && (e.ctrlKey || e.shiftKey)));
                }
            }, scope: this},
            rowdblclick: {fn: function(grid, rowIndex){
                var rec = grid.store.getAt(rowIndex);
                if (rec) {
                    this.activeRecord = rec;
                    this.selectVideo(rec);
                    this.updateVideo(rec);
                }
            }, scope: this},
            rowcontextmenu: {fn: function(grid, rowIndex, e){
                var rec = grid.store.getAt(rowIndex);
                if (!rec) { return; }
                this.activeRecord = rec;
                this.menu.record = rec;
                this.selectVideo(rec);
                var sm = this.getSelectionModel();
                if (sm && sm.isSelected && !sm.isSelected(rowIndex) && sm.selectRow) {
                    sm.selectRow(rowIndex, true);
                }
                this.getMenu();
                if (this.menu) { this.menu.showAt(e.getXY()); }
                e.stopEvent();
            }, scope: this},
            cellclick: {fn: function(grid, rowIndex, colIndex, e){
                var rec = grid.store.getAt(rowIndex);
                var dataIndex = grid.getColumnModel().getDataIndex(colIndex);
                if (!rec) { return; }
                if (this.isCheckerClick(e)) { return; }
                this.activeRecord = rec;
                this.selectVideo(rec);
                if (dataIndex === 'is_active') {
                    this.quickUpdate(rec, {is_active: Training.utils.getRecordValue(rec, 'is_active') ? 0 : 1});
                } else if (dataIndex === 'is_default' && !Training.utils.getRecordValue(rec, 'is_default')) {
                    this.quickUpdate(rec, {is_default: 1});
                }
            }, scope: this},
            afterrender: {fn: this.initRowDragDrop, scope: this}
        }
    });
    Training.grid.LessonVideos.superclass.constructor.call(this, config);

    var sm = this.getSelectionModel();
    if (sm && sm.on) {
        sm.on('rowselect', function(selectionModel, rowIndex, rec){
            this.selectedRecordsCache = selectionModel.getSelections ? (selectionModel.getSelections() || []) : [];
            this.activeRecord = rec || null;
            this.selectVideo(rec || null);
        }, this);
        sm.on('rowdeselect', function(selectionModel, rowIndex, rec){
            this.selectedRecordsCache = selectionModel.getSelections ? (selectionModel.getSelections() || []) : [];
            var activeId = this.activeRecord ? (parseInt(Training.utils.getRecordValue(this.activeRecord, 'id'), 10) || 0) : 0;
            var recId = rec ? (parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0) : 0;
            if (activeId > 0 && activeId === recId) {
                this.activeRecord = this.selectedRecordsCache.length ? this.selectedRecordsCache[this.selectedRecordsCache.length - 1] : null;
                this.selectVideo(this.activeRecord);
            }
        }, this);
        sm.on('selectionchange', function(selectionModel){
            this.selectedRecordsCache = selectionModel.getSelections ? (selectionModel.getSelections() || []) : [];
            if (!this.selectedRecordsCache.length && !this.activeRecord) {
                this.selectVideo(null);
            }
        }, this);
    }

    this.getStore().on('load', function(store){
        var rec = null;
        var preferredId = this.currentVideoId || (this.activeRecord ? (parseInt(Training.utils.getRecordValue(this.activeRecord, 'id'), 10) || 0) : 0);
        if (preferredId > 0) {
            store.each(function(item){
                if (!rec && (parseInt(Training.utils.getRecordValue(item, 'id'), 10) || 0) === preferredId) {
                    rec = item;
                }
            });
        }
        if (!rec && store.getCount()) {
            rec = store.getAt(0);
        }
        this.selectedRecordsCache = [];
        if (rec) {
            this.activeRecord = rec;
            this.selectVideo(rec);
        } else {
            this.activeRecord = null;
            this.selectVideo(null);
        }
        this.bindRowDragDrop();
    }, this);
};
Ext.extend(Training.grid.LessonVideos, MODx.grid.Grid, {
    isCheckerClick: function(e) {
        return !!(e && e.getTarget && e.getTarget('.x-grid3-row-checker'));
    },

    getSelectedRecords: function() {
        var sm = this.getSelectionModel();
        var records = sm && sm.getSelections ? (sm.getSelections() || []) : [];
        if (records.length) {
            return records;
        }
        if (this.menu && this.menu.record) {
            return [this.menu.record];
        }
        if (this.activeRecord) {
            return [this.activeRecord];
        }
        return [];
    },

    getSelectedRecord: function() {
        var records = this.getSelectedRecords();
        if (!records.length) {
            return null;
        }
        if (this.activeRecord) {
            var activeId = parseInt(Training.utils.getRecordValue(this.activeRecord, 'id'), 10) || 0;
            for (var i = 0; i < records.length; i++) {
                if ((parseInt(Training.utils.getRecordValue(records[i], 'id'), 10) || 0) === activeId) {
                    return records[i];
                }
            }
        }
        return records[0];
    },

    selectVideo: function(rec) {
        var id = rec ? (parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0) : 0;
        this.currentVideoId = id;
        var qualityGrid = Ext.getCmp('training-grid-lesson-qualities');
        if (qualityGrid && typeof qualityGrid.setVideoContext === 'function') {
            qualityGrid.setVideoContext(id, rec ? rec.data : null);
        }
        var slideGrid = Ext.getCmp('training-grid-lesson-slides');
        if (slideGrid && typeof slideGrid.setVideoContext === 'function') {
            slideGrid.setVideoContext(id, rec ? rec.data : null);
        }
    },

    focusSelected: function() {
        var rec = this.getSelectedRecord();
        if (!rec) {
            MODx.msg.alert('Внимание', 'Выбери видео урока');
            return false;
        }
        this.activeRecord = rec;
        this.selectVideo(rec);
        return true;
    },

    applyWindowValues: function(w, values, baseParams) {
        if (!w) { return; }
        if (w.fp && w.fp.getForm) {
            var form = w.fp.getForm();
            form.baseParams = Ext.apply(form.baseParams || {}, baseParams || {});
            form.setValues(values || {});
            Ext.iterate(values || {}, function(name, value) {
                var field = form.findField(name);
                if (field && field.setValue) {
                    field.setValue(value);
                }
            });
        }
        if (w.setValues) {
            w.setValues(values || {});
        }
    },

    quickUpdate: function(rec, patch) {
        rec = rec || this.getSelectedRecord();
        if (!rec) { return false; }
        var data = Ext.apply({}, rec.data || rec);
        data.action = 'mgr/lesson/video/update';
        data.id = parseInt(data.id, 10) || 0;
        data.lesson_id = this.lessonId;
        data.title = data.title || 'Видео';
        data.sort_order = parseInt(data.sort_order, 10) || 1;
        data.is_default = Training.utils.toBool(data.is_default) ? 1 : 0;
        data.is_active = Training.utils.toBool(data.is_active) ? 1 : 0;
        Ext.apply(data, patch || {});
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: data,
            listeners: {success: {fn: function(){ this.currentVideoId = parseInt(data.id, 10) || this.currentVideoId; this.refresh(); }, scope: this}}
        });
        return true;
    },

    getNextSortOrder: function() {
        var maxSort = 0;
        this.getStore().each(function(rec){
            var sort = parseInt(Training.utils.getRecordValue(rec, 'sort_order'), 10) || 0;
            if (sort > maxSort) { maxSort = sort; }
        });
        return maxSort + 1;
    },

    createVideo: function() {
        var values = {lesson_id: this.lessonId, is_active: 1, is_default: 0, sort_order: this.getNextSortOrder()};
        var w = MODx.load({
            xtype: 'training-window-lesson-video',
            id: Ext.id(null, 'training-window-lesson-video-create-'),
            title: 'Добавить видео урока',
            baseParams: {action: 'mgr/lesson/video/create'},
            lessonId: this.lessonId,
            listeners: {success: {fn: function(r){
                var data = Training.utils.getResultData ? Training.utils.getResultData(r) : null;
                this.currentVideoId = data && data.id ? (parseInt(data.id, 10) || 0) : this.currentVideoId;
                this.refresh();
            }, scope: this}}
        });
        this.applyWindowValues(w, values, {action: 'mgr/lesson/video/create'});
        w.show();
        this.applyWindowValues(w, values, {action: 'mgr/lesson/video/create'});
    },

    updateVideo: function(rec) {
        rec = rec || this.getSelectedRecord();
        if (!rec) {
            MODx.msg.alert('Внимание', 'Выбери видео урока');
            return false;
        }
        var values = Ext.apply({}, rec.data || rec);
        values.id = parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0;
        values.lesson_id = this.lessonId;
        var params = {action: 'mgr/lesson/video/update', id: values.id};
        var w = MODx.load({
            xtype: 'training-window-lesson-video',
            id: Ext.id(null, 'training-window-lesson-video-update-'),
            title: 'Изменить видео урока',
            baseParams: params,
            lessonId: this.lessonId,
            listeners: {success: {fn: function(){ this.currentVideoId = values.id; this.refresh(); }, scope: this}}
        });
        this.applyWindowValues(w, values, params);
        w.show();
        this.applyWindowValues(w, values, params);
        return true;
    },

    removeVideo: function() {
        var ids = [];
        Ext.each(this.getSelectedRecords(), function(rec){
            var id = parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0;
            if (id) { ids.push(id); }
        });
        if (!ids.length) {
            MODx.msg.alert('Внимание', 'Выбери видео урока');
            return false;
        }
        MODx.msg.confirm({
            title: 'Удаление',
            text: ids.length > 1 ? 'Удалить выбранные видео урока вместе с качествами и слайдами?' : 'Удалить видео урока вместе с качествами и слайдами?',
            url: Training.config.connector_url,
            params: {action: 'mgr/lesson/video/remove', ids: ids.join(',')},
            listeners: {success: {fn: function(){
                var currentId = parseInt(this.currentVideoId, 10) || 0;
                Ext.each(ids, function(id){ if ((parseInt(id, 10) || 0) === currentId) { this.currentVideoId = 0; } }, this);
                this.refresh();
            }, scope: this}}
        });
        return true;
    },

    getMenu: function() {
        var rec = this.menu && this.menu.record ? this.menu.record : this.getSelectedRecord();
        if (!rec) { return false; }
        this.addContextMenuItem([{
            text: 'Открыть',
            handler: function(){ this.activeRecord = rec; this.selectVideo(rec); },
            scope: this
        },{
            text: 'Изменить',
            handler: function(){ this.activeRecord = rec; this.updateVideo(rec); },
            scope: this
        },{
            text: 'Удалить',
            handler: function(){ this.activeRecord = rec; this.removeVideo(); },
            scope: this
        },'-',{
            text: Training.utils.getRecordValue(rec, 'is_active') ? 'Отключить' : 'Включить',
            handler: function(){ this.quickUpdate(rec, {is_active: Training.utils.getRecordValue(rec, 'is_active') ? 0 : 1}); },
            scope: this
        },{
            text: 'Сделать по умолчанию',
            handler: function(){ this.quickUpdate(rec, {is_default: 1}); },
            scope: this
        }]);
        return true;
    },

    initRowDragDrop: function() {
        var view = this.getView();
        if (!view) { return; }
        view.on('refresh', this.bindRowDragDrop, this);
        this.bindRowDragDrop();
    },

    bindRowDragDrop: function() {
        var view = this.getView();
        if (!view || !view.getRows) { return; }
        var rows = view.getRows();
        Ext.each(rows, function(row){
            if (!row || row._trainingVideoDnDBound) { return; }
            row._trainingVideoDnDBound = true;
            row.setAttribute('draggable', 'true');
            Ext.fly(row).on('dragstart', function(e){
                var rowIndex = view.findRowIndex(row);
                var rec = this.store.getAt(rowIndex);
                if (!rec) { return; }
                this.dragRecordId = parseInt(rec.get('id'), 10) || 0;
                if (e.browserEvent && e.browserEvent.dataTransfer) {
                    e.browserEvent.dataTransfer.effectAllowed = 'move';
                    e.browserEvent.dataTransfer.setData('text/plain', String(this.dragRecordId));
                }
            }, this);
            Ext.fly(row).on('dragover', function(e){
                if (e.browserEvent && e.browserEvent.preventDefault) { e.browserEvent.preventDefault(); }
                e.stopEvent();
            }, this);
            Ext.fly(row).on('drop', function(e){
                if (e.browserEvent && e.browserEvent.preventDefault) { e.browserEvent.preventDefault(); }
                e.stopEvent();
                var rowIndex = view.findRowIndex(row);
                var target = this.store.getAt(rowIndex);
                if (!target) { return; }
                var movedId = this.dragRecordId || 0;
                var targetId = parseInt(target.get('id'), 10) || 0;
                if (!movedId || !targetId || movedId === targetId) { return; }
                var box = Ext.fly(row).getBox();
                var pageY = e.getPageY ? e.getPageY() : (e.browserEvent ? e.browserEvent.pageY : 0);
                var position = (pageY - box.y) < (box.height / 2) ? 'before' : 'after';
                MODx.Ajax.request({
                    url: Training.config.connector_url,
                    params: {action: 'mgr/lesson/video/reorder', id: movedId, target_id: targetId, position: position},
                    listeners: {success: {fn: function(){ this.currentVideoId = movedId; this.refresh(); }, scope: this}}
                });
            }, this);
        }, this);
    }
});
Ext.reg('training-grid-lesson-videos', Training.grid.LessonVideos);

Training.window.LessonVideo = function(config) {
    config = config || {};
    this.lessonId = config.lessonId || Training.config.lesson_id;
    Ext.applyIf(config, {
        width: 760,
        autoHeight: true,
        url: Training.config.connector_url,
        fields: [
            {xtype:'hidden',name:'id'},
            {xtype:'hidden',name:'lesson_id',value:this.lessonId},
            {xtype:'textfield',fieldLabel:'Название',name:'title',anchor:'100%',allowBlank:false},
            {xtype:'numberfield',fieldLabel:'Порядок',name:'sort_order',anchor:'100%'},
            {xtype:'button',text:'Выбрать исходное видео',style:'margin-bottom:10px;',handler:function(btn){var win=btn.findParentByType('modx-window')||btn.findParentByType('window');var form=win&&win.fp?win.fp.getForm():null;var field=form?form.findField('source_video'):null;Training.utils.openPathBrowser(field,{source:Training.config.media_source||3,allowedFileTypes:'mkv,mp4,mov,avi,webm,m3u8'});}},
            {xtype:'textfield',fieldLabel:'Исходное видео',name:'source_video',anchor:'100%'},
            {xtype:'textarea',fieldLabel:'Описание',name:'description',anchor:'100%'},
            {xtype:'xcheckbox',boxLabel:'По умолчанию',hideLabel:true,name:'is_default',inputValue:1},
            {xtype:'xcheckbox',boxLabel:'Активно',hideLabel:true,name:'is_active',inputValue:1,checked:true}
        ]
    });
    Training.window.LessonVideo.superclass.constructor.call(this, config);
};
Ext.extend(Training.window.LessonVideo, MODx.Window);
Ext.reg('training-window-lesson-video', Training.window.LessonVideo);
