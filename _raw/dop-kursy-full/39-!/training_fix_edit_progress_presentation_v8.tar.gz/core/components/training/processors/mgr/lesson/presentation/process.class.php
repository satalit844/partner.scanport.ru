<?php

require_once dirname(dirname(__DIR__)) . '/_media_helper.php';
require_once dirname(dirname(__DIR__)) . '/lesson/_video_helper.php';

class TrainingLessonPresentationProcessProcessor extends modProcessor
{
    public function checkPermissions(){return true;}

    public function process()
    {
        $lessonId = (int)$this->getProperty('lesson_id');
        if ($lessonId <= 0) {
            return $this->failure('Не указан урок');
        }

        /** @var TrainingModuleLesson $lesson */
        $lesson = $this->modx->getObject('TrainingModuleLesson', ['id' => $lessonId]);
        if (!$lesson) {
            return $this->failure('Урок не найден');
        }

        $source = trim((string)$this->getProperty('source_presentation', $lesson->get('source_presentation')));
        if ($source === '') {
            return $this->failure('Укажи путь к PPT/PPTX/PDF файлу презентации');
        }

        $sourceAbsolute = TrainingMediaHelper::resolveLocalPath($this->modx, $source);
        if ($sourceAbsolute === '' || !is_file($sourceAbsolute)) {
            return $this->failure('Файл презентации не найден на сервере');
        }

        $extension = strtolower(pathinfo($sourceAbsolute, PATHINFO_EXTENSION));
        if (!in_array($extension, ['ppt', 'pptx', 'pdf'], true)) {
            return $this->failure('Поддерживаются только ppt, pptx и pdf');
        }

        $dirs = TrainingMediaHelper::resolveLessonPresentationDirs($this->modx, $lesson);
        if (!TrainingMediaHelper::ensureDir($dirs['base_absolute']) || !TrainingMediaHelper::ensureDir($dirs['slides_absolute'])) {
            return $this->failure('Не удалось создать папки урока для презентации');
        }

        $storedSourceAbsolute = $dirs['base_absolute'] . TrainingMediaHelper::buildLessonPresentationPdfFilename($lesson, $extension);
        if (!TrainingMediaHelper::copyInto($sourceAbsolute, $storedSourceAbsolute)) {
            return $this->failure('Не удалось сохранить исходный файл презентации');
        }

        $lesson->set('source_presentation', TrainingMediaHelper::fsPathToWeb($this->modx, $storedSourceAbsolute));
        $lesson->set('presentation_status', 'processing');
        $lesson->save();

        $pdfAbsolute = $dirs['pdf_absolute'];
        if ($extension === 'pdf') {
            if (!TrainingMediaHelper::copyInto($storedSourceAbsolute, $pdfAbsolute)) {
                return $this->failure('Не удалось сохранить PDF презентации');
            }
        } else {
            $soffice = TrainingMediaHelper::getCommand($this->modx, 'training_soffice_command', 'soffice');
            $output = [];
            $code = 0;
            $command = escapeshellcmd($soffice)
                . ' --headless --convert-to pdf --outdir '
                . escapeshellarg(rtrim($dirs['base_absolute'], '/'))
                . ' '
                . escapeshellarg($storedSourceAbsolute);

            if (!TrainingMediaHelper::runCommand($this->modx, $command, $output, $code)) {
                $lesson->set('presentation_status', 'error');
                $lesson->save();
                return $this->failure("LibreOffice не смог конвертировать презентацию в PDF\n" . implode("\n", $output));
            }

            $convertedPdf = $dirs['base_absolute'] . pathinfo($storedSourceAbsolute, PATHINFO_FILENAME) . '.pdf';
            if (!is_file($convertedPdf)) {
                $lesson->set('presentation_status', 'error');
                $lesson->save();
                return $this->failure('После конвертации не найден PDF файл');
            }

            if (realpath($convertedPdf) !== realpath($pdfAbsolute)) {
                @copy($convertedPdf, $pdfAbsolute);
            }
        }

        foreach ((array)@scandir($dirs['slides_absolute']) as $oldSlide) {
            if ($oldSlide === '.' || $oldSlide === '..') { continue; }
            $oldSlidePath = $dirs['slides_absolute'] . $oldSlide;
            if (is_file($oldSlidePath)) { @unlink($oldSlidePath); }
        }

        $pdftoppm = TrainingMediaHelper::getCommand($this->modx, 'training_pdftoppm_command', 'pdftoppm');
        $output = [];
        $code = 0;
        $prefixBase = 'course_' . TrainingLessonVideoHelper::getCourseIdByLesson($this->modx, $lesson)
            . '_module_' . (int)$lesson->get('module_id')
            . '_lesson_' . (int)$lesson->get('id') . '_slide';
        $prefix = $dirs['slides_absolute'] . $prefixBase;
        $command = escapeshellcmd($pdftoppm)
            . ' -jpeg -r 150 '
            . escapeshellarg($pdfAbsolute)
            . ' '
            . escapeshellarg($prefix);

        if (!TrainingMediaHelper::runCommand($this->modx, $command, $output, $code)) {
            $lesson->set('presentation_status', 'error');
            $lesson->save();
            return $this->failure("Не удалось разобрать PDF на слайды\n" . implode("\n", $output));
        }

        $slides = glob($dirs['slides_absolute'] . $prefixBase . '-*.jpg');
        natcasesort($slides);
        $index = 1;
        foreach ($slides as $slidePath) {
            $target = $dirs['slides_absolute'] . 'lesson_' . (int)$lesson->get('id') . '_slide_' . sprintf('%03d', $index) . '.jpg';
            if (realpath($slidePath) !== realpath($target)) {
                @rename($slidePath, $target);
            }
            $index++;
        }

        $slidesCount = count(glob($dirs['slides_absolute'] . '*.jpg'));
        $lesson->set('presentation_pdf', $dirs['pdf_web']);
        $lesson->set('slides_dir', $dirs['slides_web']);
        $lesson->set('presentation_status', $slidesCount > 0 ? 'ready' : 'none');
        $lesson->save();

        $assignedSlides = TrainingLessonVideoHelper::syncPresentationSlidesToVideos($this->modx, $lesson);
        TrainingLessonVideoHelper::recalcLesson($this->modx, $lesson);

        return $this->success('Презентация урока обработана', [
            'source_presentation' => $lesson->get('source_presentation'),
            'presentation_pdf' => $lesson->get('presentation_pdf'),
            'slides_dir' => $lesson->get('slides_dir'),
            'slides_count' => $slidesCount,
            'assigned_slides' => $assignedSlides,
        ]);
    }
}
return 'TrainingLessonPresentationProcessProcessor';
