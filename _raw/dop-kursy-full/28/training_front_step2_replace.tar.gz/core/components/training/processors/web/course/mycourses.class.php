<?php

require_once dirname(dirname(__FILE__)) . '/_helpers.php';

class TrainingWebCourseMyCoursesProcessor extends modProcessor
{
    public function checkPermissions()
    {
        return true;
    }

    protected function formatDateValue($value)
    {
        if ($value === null || $value === '' || $value === '0000-00-00 00:00:00') {
            return '—';
        }

        $ts = strtotime((string)$value);
        if (!$ts) {
            return '—';
        }

        return date('d.m.Y', $ts);
    }

    protected function buildState(array $row)
    {
        $progressPercent = isset($row['progress_percent']) ? (float)$row['progress_percent'] : 0;
        $completedUnits = isset($row['completed_units']) ? (int)$row['completed_units'] : 0;
        $totalUnits = isset($row['total_units']) ? (int)$row['total_units'] : 0;

        if ($totalUnits > 0 && $completedUnits >= $totalUnits) {
            return [
                'state' => 'done',
                'item_class' => 'is-done',
                'status_text' => 'Курс завершен',
                'status_class' => 'label-chip--green',
            ];
        }

        if ($completedUnits > 0 || $progressPercent > 0) {
            return [
                'state' => 'progress',
                'item_class' => 'is-progress',
                'status_text' => 'В процессе',
                'status_class' => 'label-chip--purple',
            ];
        }

        return [
            'state' => 'new',
            'item_class' => 'is-new',
            'status_text' => 'Не начат',
            'status_class' => 'label-chip--blue',
        ];
    }

    protected function getCourseStats($courseId, $userId)
    {
        $courseId = (int)$courseId;
        $userId = (int)$userId;

        $moduleIds = [];
        $c = $this->modx->newQuery('TrainingModule');
        $c->where([
            'course_id' => $courseId,
            'is_active' => 1,
        ]);
        $c->select(['id']);
        if ($c->prepare() && $c->stmt->execute()) {
            while ($row = $c->stmt->fetch(PDO::FETCH_ASSOC)) {
                $moduleId = (int)$row['id'];
                if ($moduleId > 0) {
                    $moduleIds[] = $moduleId;
                }
            }
        }

        $totalVideos = 0;
        $completedVideos = 0;

        if (!empty($moduleIds)) {
            $lessonIds = [];
            $c = $this->modx->newQuery('TrainingModuleLesson');
            $c->where([
                'module_id:IN' => $moduleIds,
                'is_active' => 1,
            ]);
            $c->select(['id']);
            $c->sortby('sort_order', 'ASC');
            if ($c->prepare() && $c->stmt->execute()) {
                while ($row = $c->stmt->fetch(PDO::FETCH_ASSOC)) {
                    $lessonId = (int)$row['id'];
                    if ($lessonId > 0) {
                        $lessonIds[] = $lessonId;
                    }
                }
            }

            if (!empty($lessonIds)) {
                $c = $this->modx->newQuery('TrainingModuleVideo');
                $c->where([
                    'lesson_id:IN' => $lessonIds,
                    'is_active' => 1,
                ]);
                $c->select(['DISTINCT lesson_id']);
                if ($c->prepare() && $c->stmt->execute()) {
                    $activeLessonIds = [];
                    while ($row = $c->stmt->fetch(PDO::FETCH_ASSOC)) {
                        $activeLessonIds[] = (int)$row['lesson_id'];
                    }
                    $lessonIds = array_values(array_unique(array_filter($activeLessonIds)));
                }
            }

            if (!empty($lessonIds)) {
                $totalVideos = count($lessonIds);
                $c = $this->modx->newQuery('TrainingUserLessonProgress');
                $c->where([
                    'course_id' => $courseId,
                    'user_id' => $userId,
                    'lesson_id:IN' => $lessonIds,
                    'completed' => 1,
                ]);
                $c->select(['COUNT(DISTINCT lesson_id) AS total']);
                if ($c->prepare() && $c->stmt->execute()) {
                    $completedVideos = (int)$c->stmt->fetchColumn();
                }
            }
        }

        $totalTests = (int)$this->modx->getCount('TrainingTestLink', [
            'course_id' => $courseId,
        ]);

        $passedTests = (int)$this->modx->getCount('TrainingUserTestStatus', [
            'course_id' => $courseId,
            'user_id' => $userId,
            'passed' => 1,
        ]);

        return [
            'total_videos' => $totalVideos,
            'completed_videos' => $completedVideos,
            'total_tests' => $totalTests,
            'passed_tests' => $passedTests,
        ];
    }

    public function process()
    {
        if ($failure = TrainingWebHelper::requireAuth($this)) {
            return $failure;
        }

        $userId = (int)$this->modx->user->get('id');
        $limit = max(0, (int)$this->getProperty('limit', 0));
        $start = max(0, (int)$this->getProperty('start', 0));
        $includeRevoked = (int)$this->getProperty('include_revoked', 0) === 1;
        $recalculate = (int)$this->getProperty('recalculate', 1) === 1;

        $service = TrainingWebHelper::getProgressService($this->modx);
        $rows = $service->getMyCourses($userId, [
            'limit' => $limit,
            'start' => $start,
            'include_revoked' => $includeRevoked,
            'recalculate' => $recalculate,
        ]);

        $results = [];

        foreach ($rows as $row) {
            $courseId = (int)$row['course_id'];
            $resourceId = (int)$row['resource_id'];

            if ($courseId <= 0 || $resourceId <= 0) {
                continue;
            }

            if (empty($row['course_is_active']) || empty($row['published'])) {
                continue;
            }

            /** @var modResource|null $resource */
            $resource = $this->modx->getObject('modResource', ['id' => $resourceId]);
            if (!$resource) {
                continue;
            }

            $image = trim((string)$resource->getTVValue('image_curse'));
            $descText = trim((string)$resource->getTVValue('desc'));
            $durationText = trim((string)$resource->getTVValue('time_curse'));

            $url = $this->modx->makeUrl(
                $resourceId,
                $resource->get('context_key'),
                '',
                'full'
            );

            $stats = $this->getCourseStats($courseId, $userId);

            $completedUnits = (int)$stats['completed_videos'] + (int)$stats['passed_tests'];
            $totalUnits = (int)$stats['total_videos'] + (int)$stats['total_tests'];
            $progressPercent = $totalUnits > 0 ? (int)round(($completedUnits / $totalUnits) * 100) : 0;

            $row['progress_percent'] = $progressPercent;
            $row['completed_units'] = $completedUnits;
            $row['total_units'] = $totalUnits;
            $state = $this->buildState($row);

            $completedModules = (int)$row['completed_modules'];
            $totalModules = max((int)$row['total_modules'], 0);

            $title = trim((string)($row['longtitle'] ?: $row['pagetitle']));
            if ($title === '') {
                $title = trim((string)$resource->get('pagetitle'));
            }

            $results[] = [
                'course_id' => $courseId,
                'resource_id' => $resourceId,

                'title' => $title,
                'pagetitle' => (string)$row['pagetitle'],
                'description' => $descText !== '' ? $descText : (string)$row['description'],
                'url' => $url,
                'image' => $image,
                'duration_text' => $durationText,

                'access_role' => (string)$row['access_role'],
                'status' => (string)$row['status'],
                'progress_percent' => $progressPercent,
                'progress_percent_text' => $progressPercent . '%',

                'completed_modules' => $completedModules,
                'total_modules' => $totalModules,

                'startedon' => $row['startedon'],
                'startedon_formatted' => $this->formatDateValue($row['startedon']),
                'completedon' => $row['completedon'],
                'completedon_formatted' => $this->formatDateValue($row['completedon']),
                'last_activity' => $row['last_activity'],
                'last_activity_formatted' => $this->formatDateValue($row['last_activity']),

                'videos_completed' => (int)$stats['completed_videos'],
                'videos_total' => (int)$stats['total_videos'],
                'modules_completed' => $completedModules,
                'modules_total' => $totalModules,
                'tests_passed' => (int)$stats['passed_tests'],
                'tests_total' => (int)$stats['total_tests'],

                'state' => $state['state'],
                'item_class' => $state['item_class'],
                'status_text' => $state['status_text'],
                'status_class' => $state['status_class'],

                'can_manage' => $service->canManageCourse($courseId, $userId) ? 1 : 0,
            ];
        }

        return $this->success('', [
            'total' => count($results),
            'results' => $results,
        ]);
    }
}

return 'TrainingWebCourseMyCoursesProcessor';