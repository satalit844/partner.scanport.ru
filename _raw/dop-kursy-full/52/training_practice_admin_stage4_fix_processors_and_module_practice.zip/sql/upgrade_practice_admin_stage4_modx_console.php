<?php
/**
 * Stage 4: практические задания в админке training.
 * Без удаления данных.
 * 1) Досоздает/дополняет таблицы практик.
 * 2) Ставит resource_id страницы практики = 176.
 * 3) Переносит старую практику из training_test_links link_type=practice в training_practices.
 * 4) Гарантирует тестовую практику для курса 1 / модуля 1 с id = id старой привязки, чтобы ссылка со страницы курса ?activity=2 открывала новую страницу практики.
 */

function tp4PlainTable(modX $modx, $name) {
    $prefix = (string)$modx->getOption('table_prefix');
    $candidates = array(
        $prefix . $name,
        $prefix . '_' . $name,
        'modx_' . $name,
    );
    foreach ($candidates as $table) {
        $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
        if ($table === '') { continue; }
        $stmt = $modx->query('SHOW TABLES LIKE ' . $modx->quote($table));
        if ($stmt && $stmt->fetchColumn()) {
            return $table;
        }
    }
    return preg_replace('/[^a-zA-Z0-9_]/', '', $prefix . $name);
}

function tp4ColumnExists(modX $modx, $table, $column) {
    $stmt = $modx->query('SHOW COLUMNS FROM `' . $table . '` LIKE ' . $modx->quote($column));
    return $stmt && $stmt->fetchColumn();
}

function tp4AddColumn(modX $modx, $table, $column, $definition) {
    if (tp4ColumnExists($modx, $table, $column)) {
        echo "OK column: {$table}.{$column}<br>";
        return;
    }
    $modx->exec('ALTER TABLE `' . $table . '` ADD COLUMN `' . $column . '` ' . $definition);
    echo "ADDED column: {$table}.{$column}<br>";
}

function tp4IndexExists(modX $modx, $table, $index) {
    $stmt = $modx->query('SHOW INDEX FROM `' . $table . '` WHERE `Key_name` = ' . $modx->quote($index));
    return $stmt && $stmt->fetchColumn();
}

function tp4AddIndex(modX $modx, $table, $index, $columns) {
    if (tp4IndexExists($modx, $table, $index)) {
        echo "OK index: {$table}.{$index}<br>";
        return;
    }
    $modx->exec('ALTER TABLE `' . $table . '` ADD INDEX `' . $index . '` (' . $columns . ')');
    echo "ADDED index: {$table}.{$index}<br>";
}

function tp4NormalizeDate($value) {
    $value = trim((string)$value);
    if ($value === '' || $value === '0000-00-00 00:00:00') { return null; }
    $time = strtotime(str_replace('T', ' ', $value));
    return $time ? date('Y-m-d H:i:s', $time) : null;
}

$practices = tp4PlainTable($modx, 'training_practices');
$attempts = tp4PlainTable($modx, 'training_practice_attempts');
$messages = tp4PlainTable($modx, 'training_practice_messages');
$files = tp4PlainTable($modx, 'training_practice_files');
$testLinks = tp4PlainTable($modx, 'training_test_links');
$userTests = tp4PlainTable($modx, 'usertest_tests');
$settings = tp4PlainTable($modx, 'system_settings');

$modx->exec("CREATE TABLE IF NOT EXISTS `{$practices}` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `module_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `title` VARCHAR(255) NOT NULL DEFAULT '',
  `description` MEDIUMTEXT NULL,
  `template_file` VARCHAR(500) NOT NULL DEFAULT '',
  `template_file_name` VARCHAR(255) NOT NULL DEFAULT '',
  `image` VARCHAR(500) NOT NULL DEFAULT '',
  `deadline_at` DATETIME NULL,
  `deadline_days` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `allowed_extensions` VARCHAR(255) NOT NULL DEFAULT 'pdf,doc,docx,xls,xlsx,png,jpg,jpeg,zip',
  `max_file_size` INT(10) UNSIGNED NOT NULL DEFAULT 52428800,
  `active` TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
  `rank` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `createdon` DATETIME NULL,
  `editedon` DATETIME NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

tp4AddColumn($modx, $practices, 'course_id', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `id`');
tp4AddColumn($modx, $practices, 'module_id', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `course_id`');
tp4AddColumn($modx, $practices, 'title', "VARCHAR(255) NOT NULL DEFAULT '' AFTER `module_id`");
tp4AddColumn($modx, $practices, 'description', 'MEDIUMTEXT NULL AFTER `title`');
tp4AddColumn($modx, $practices, 'template_file', "VARCHAR(500) NOT NULL DEFAULT '' AFTER `description`");
tp4AddColumn($modx, $practices, 'template_file_name', "VARCHAR(255) NOT NULL DEFAULT '' AFTER `template_file`");
tp4AddColumn($modx, $practices, 'image', "VARCHAR(500) NOT NULL DEFAULT '' AFTER `template_file_name`");
tp4AddColumn($modx, $practices, 'deadline_at', 'DATETIME NULL AFTER `image`');
tp4AddColumn($modx, $practices, 'deadline_days', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `deadline_at`');
tp4AddColumn($modx, $practices, 'allowed_extensions', "VARCHAR(255) NOT NULL DEFAULT 'pdf,doc,docx,xls,xlsx,png,jpg,jpeg,zip' AFTER `deadline_days`");
tp4AddColumn($modx, $practices, 'max_file_size', 'INT(10) UNSIGNED NOT NULL DEFAULT 52428800 AFTER `allowed_extensions`');
tp4AddColumn($modx, $practices, 'active', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 1 AFTER `max_file_size`');
tp4AddColumn($modx, $practices, 'rank', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `active`');
tp4AddColumn($modx, $practices, 'createdon', 'DATETIME NULL AFTER `rank`');
tp4AddColumn($modx, $practices, 'editedon', 'DATETIME NULL AFTER `createdon`');

$modx->exec("CREATE TABLE IF NOT EXISTS `{$attempts}` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `practice_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `course_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `module_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `attempt_num` INT(10) UNSIGNED NOT NULL DEFAULT 1,
  `status` VARCHAR(50) NOT NULL DEFAULT 'submitted',
  `deadline_at` DATETIME NULL,
  `createdon` DATETIME NULL,
  `submittedon` DATETIME NULL,
  `reviewedon` DATETIME NULL,
  `reviewedby` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_latest` TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

tp4AddColumn($modx, $attempts, 'practice_id', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `id`');
tp4AddColumn($modx, $attempts, 'attempt_num', 'INT(10) UNSIGNED NOT NULL DEFAULT 1 AFTER `user_id`');
tp4AddColumn($modx, $attempts, 'deadline_at', 'DATETIME NULL AFTER `status`');
tp4AddColumn($modx, $attempts, 'reviewedby', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `reviewedon`');
tp4AddColumn($modx, $attempts, 'is_latest', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 1 AFTER `reviewedby`');

if (tp4ColumnExists($modx, $attempts, 'attempt_no')) {
    $modx->exec("UPDATE `{$attempts}` SET `attempt_num` = `attempt_no` WHERE `attempt_num` = 1 AND `attempt_no` > 0");
}
if (tp4ColumnExists($modx, $attempts, 'reviewer_user_id')) {
    $modx->exec("UPDATE `{$attempts}` SET `reviewedby` = `reviewer_user_id` WHERE `reviewedby` = 0 AND `reviewer_user_id` > 0");
}

$modx->exec("CREATE TABLE IF NOT EXISTS `{$messages}` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `attempt_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `practice_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `author_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `author_type` VARCHAR(50) NOT NULL DEFAULT 'user',
  `message` MEDIUMTEXT NULL,
  `is_system` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
  `createdon` DATETIME NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

tp4AddColumn($modx, $messages, 'practice_id', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `attempt_id`');
tp4AddColumn($modx, $messages, 'author_id', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `practice_id`');
tp4AddColumn($modx, $messages, 'author_type', "VARCHAR(50) NOT NULL DEFAULT 'user' AFTER `author_id`");
tp4AddColumn($modx, $messages, 'message', 'MEDIUMTEXT NULL AFTER `author_type`');
tp4AddColumn($modx, $messages, 'is_system', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0 AFTER `message`');
tp4AddColumn($modx, $messages, 'createdon', 'DATETIME NULL AFTER `is_system`');

if (tp4ColumnExists($modx, $messages, 'user_id')) {
    $modx->exec("UPDATE `{$messages}` SET `author_id` = `user_id` WHERE `author_id` = 0 AND `user_id` > 0");
}
if (tp4ColumnExists($modx, $messages, 'sender_role')) {
    $modx->exec("UPDATE `{$messages}` SET `author_type` = CASE WHEN `sender_role` IN ('mentor','manager','admin') THEN 'mentor' ELSE 'user' END WHERE `author_type` = '' OR `author_type` = 'user'");
}

$modx->exec("CREATE TABLE IF NOT EXISTS `{$files}` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `attempt_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `message_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `practice_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `path` VARCHAR(500) NOT NULL DEFAULT '',
  `url` VARCHAR(500) NOT NULL DEFAULT '',
  `name` VARCHAR(255) NOT NULL DEFAULT '',
  `original_name` VARCHAR(255) NOT NULL DEFAULT '',
  `mime` VARCHAR(255) NOT NULL DEFAULT '',
  `extension` VARCHAR(50) NOT NULL DEFAULT '',
  `size` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `hash` VARCHAR(64) NOT NULL DEFAULT '',
  `createdon` DATETIME NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

tp4AddColumn($modx, $files, 'message_id', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `attempt_id`');
tp4AddColumn($modx, $files, 'practice_id', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `message_id`');
tp4AddColumn($modx, $files, 'user_id', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `practice_id`');
tp4AddColumn($modx, $files, 'url', "VARCHAR(500) NOT NULL DEFAULT '' AFTER `path`");
tp4AddColumn($modx, $files, 'name', "VARCHAR(255) NOT NULL DEFAULT '' AFTER `url`");
tp4AddColumn($modx, $files, 'original_name', "VARCHAR(255) NOT NULL DEFAULT '' AFTER `name`");
tp4AddColumn($modx, $files, 'mime', "VARCHAR(255) NOT NULL DEFAULT '' AFTER `original_name`");
tp4AddColumn($modx, $files, 'extension', "VARCHAR(50) NOT NULL DEFAULT '' AFTER `mime`");
tp4AddColumn($modx, $files, 'size', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `extension`');
tp4AddColumn($modx, $files, 'hash', "VARCHAR(64) NOT NULL DEFAULT '' AFTER `size`");
tp4AddColumn($modx, $files, 'createdon', 'DATETIME NULL AFTER `hash`');

// Системная настройка страницы практики.
$key = 'training.training_practice_resource_id';
$stmt = $modx->prepare("SELECT COUNT(*) FROM `{$settings}` WHERE `key` = :key");
$stmt->execute(array(':key' => $key));
if ((int)$stmt->fetchColumn() > 0) {
    $stmt = $modx->prepare("UPDATE `{$settings}` SET `value` = '176', `xtype` = 'numberfield', `namespace` = 'training', `area` = 'training' WHERE `key` = :key");
    $stmt->execute(array(':key' => $key));
} else {
    $stmt = $modx->prepare("INSERT INTO `{$settings}` (`key`, `value`, `xtype`, `namespace`, `area`) VALUES (:key, '176', 'numberfield', 'training', 'training')");
    $stmt->execute(array(':key' => $key));
}

// Миграция старых practical links. Важно: id новой практики = id старой привязки, чтобы /?activity=id открывался правильно со страницы курса.
$stmt = $modx->prepare("SELECT * FROM `{$testLinks}` WHERE `link_type` = 'practice' ORDER BY `id` ASC");
$stmt->execute();
$links = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($links as $link) {
    $linkId = (int)$link['id'];
    $courseId = (int)$link['course_id'];
    $moduleId = (int)$link['module_id'];
    $testId = (int)$link['usertest_test_id'];
    $rank = (int)$link['sort_order'];

    $title = 'Практическое задание #' . $linkId;
    $description = 'Загрузите выполненное задание PDF, DOCX или XLSX и отправьте сообщение ментору.';

    if ($testId > 0) {
        $testStmt = $modx->prepare("SELECT * FROM `{$userTests}` WHERE `id` = :id LIMIT 1");
        $testStmt->execute(array(':id' => $testId));
        $test = $testStmt->fetch(PDO::FETCH_ASSOC);
        if ($test) {
            $testName = trim((string)(isset($test['name']) ? $test['name'] : ''));
            if ($testName !== '') { $title = $testName; }
            $parts = array();
            foreach (array('description', 'instruction') as $field) {
                if (isset($test[$field]) && trim((string)$test[$field]) !== '') {
                    $parts[] = trim((string)$test[$field]);
                }
            }
            if ($parts) { $description = implode("\n\n", $parts); }
        }
    }

    $existsStmt = $modx->prepare("SELECT `id` FROM `{$practices}` WHERE `id` = :id LIMIT 1");
    $existsStmt->execute(array(':id' => $linkId));
    $exists = (int)$existsStmt->fetchColumn();

    if ($exists > 0) {
        $upd = $modx->prepare("UPDATE `{$practices}` SET `course_id` = :course_id, `module_id` = :module_id, `title` = :title, `description` = :description, `image` = :image, `active` = 1, `rank` = :rank, `editedon` = NOW() WHERE `id` = :id");
        $upd->execute(array(
            ':id' => $linkId,
            ':course_id' => $courseId,
            ':module_id' => $moduleId,
            ':title' => $title,
            ':description' => $description,
            ':image' => 'theme/images/training/tests/logo-scanport.svg',
            ':rank' => $rank,
        ));
        echo "UPDATED practice id={$linkId}: {$title}<br>";
    } else {
        $ins = $modx->prepare("INSERT INTO `{$practices}` (`id`, `course_id`, `module_id`, `title`, `description`, `template_file`, `template_file_name`, `image`, `deadline_at`, `deadline_days`, `allowed_extensions`, `max_file_size`, `active`, `rank`, `createdon`, `editedon`) VALUES (:id, :course_id, :module_id, :title, :description, '', '', :image, NULL, 0, 'pdf,doc,docx,xls,xlsx,png,jpg,jpeg,zip', 52428800, 1, :rank, NOW(), NOW())");
        $ins->execute(array(
            ':id' => $linkId,
            ':course_id' => $courseId,
            ':module_id' => $moduleId,
            ':title' => $title,
            ':description' => $description,
            ':image' => 'theme/images/training/tests/logo-scanport.svg',
            ':rank' => $rank,
        ));
        echo "INSERTED practice id={$linkId}: {$title}<br>";
    }
}

// Если по какой-то причине старой привязки нет, создаем одну рабочую практику для курса 1 / модуля 1.
$countStmt = $modx->query("SELECT COUNT(*) FROM `{$practices}` WHERE `course_id` = 1 AND `module_id` = 1 AND `active` = 1");
if ($countStmt && (int)$countStmt->fetchColumn() === 0) {
    $modx->exec("INSERT INTO `{$practices}` (`course_id`, `module_id`, `title`, `description`, `image`, `allowed_extensions`, `max_file_size`, `active`, `rank`, `createdon`, `editedon`) VALUES (1, 1, 'Практическое задание DataMobile', 'Загрузите выполненное задание PDF, DOCX или XLSX и отправьте сообщение ментору.', 'theme/images/training/tests/logo-scanport.svg', 'pdf,doc,docx,xls,xlsx,png,jpg,jpeg,zip', 52428800, 1, 1, NOW(), NOW())");
    echo "INSERTED fallback practice for course=1 module=1<br>";
}

// Перепривязка старых попыток к новой практике.
if (tp4ColumnExists($modx, $attempts, 'test_link_id')) {
    $modx->exec("UPDATE `{$attempts}` SET `practice_id` = `test_link_id` WHERE `practice_id` = 0 AND `test_link_id` > 0");
}
if (tp4ColumnExists($modx, $attempts, 'attempt_no')) {
    $modx->exec("UPDATE `{$attempts}` SET `attempt_num` = `attempt_no` WHERE `attempt_num` = 1 AND `attempt_no` > 0");
}
$modx->exec("UPDATE `{$messages}` m INNER JOIN `{$attempts}` a ON a.`id` = m.`attempt_id` SET m.`practice_id` = a.`practice_id` WHERE m.`practice_id` = 0 AND a.`practice_id` > 0");

tp4AddIndex($modx, $practices, 'course_id', '`course_id`');
tp4AddIndex($modx, $practices, 'module_id', '`module_id`');
tp4AddIndex($modx, $attempts, 'practice_user', '`practice_id`, `user_id`');
tp4AddIndex($modx, $messages, 'attempt_id', '`attempt_id`');
tp4AddIndex($modx, $files, 'attempt_id', '`attempt_id`');

$maxIdStmt = $modx->query("SELECT MAX(`id`) FROM `{$practices}`");
$maxId = $maxIdStmt ? (int)$maxIdStmt->fetchColumn() : 0;
if ($maxId > 0) {
    $modx->exec('ALTER TABLE `' . $practices . '` AUTO_INCREMENT = ' . ($maxId + 1));
}

$modx->cacheManager->refresh(array(
    'db' => array(),
    'system_settings' => array(),
    'scripts' => array(),
));

echo '<pre>';
echo "OK: training practice stage4 upgraded\n";
echo "practices table: {$practices}\n";
echo "practice page resource: 176\n";
echo "check admin: /manager/?a=6&namespace=training\n";
echo "check frontend activity from course: /obuchenie/obuchenie-glavnaya/stranitsa-prakticheskoe-zadanie/?activity=2\n";
echo '</pre>';
