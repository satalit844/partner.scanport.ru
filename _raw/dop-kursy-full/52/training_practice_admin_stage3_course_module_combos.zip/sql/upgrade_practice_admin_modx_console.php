<?php
/**
 * Безопасное обновление таблиц практических заданий.
 * Ничего не удаляет: только добавляет недостающие колонки и переносит старые практики из training_test_links link_type=practice.
 */

function tpTableName(modX $modx, $name) {
    $prefix = (string)$modx->getOption('table_prefix');
    $candidates = array(
        $prefix . $name,
        $prefix . '_' . $name,
        'modx_' . $name,
    );
    foreach ($candidates as $table) {
        $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
        $stmt = $modx->query('SHOW TABLES LIKE ' . $modx->quote($table));
        if ($stmt && $stmt->fetchColumn()) {
            return $table;
        }
    }
    return preg_replace('/[^a-zA-Z0-9_]/', '', $prefix . $name);
}

function tpColumnExists(modX $modx, $table, $column) {
    $stmt = $modx->query('SHOW COLUMNS FROM `' . $table . '` LIKE ' . $modx->quote($column));
    return $stmt && $stmt->fetchColumn();
}

function tpAddColumn(modX $modx, $table, $column, $definition) {
    if (tpColumnExists($modx, $table, $column)) {
        echo "OK column exists: {$table}.{$column}<br>";
        return;
    }
    $sql = 'ALTER TABLE `' . $table . '` ADD COLUMN `' . $column . '` ' . $definition;
    $modx->exec($sql);
    echo "ADDED column: {$table}.{$column}<br>";
}

function tpIndexExists(modX $modx, $table, $index) {
    $stmt = $modx->query('SHOW INDEX FROM `' . $table . '` WHERE `Key_name` = ' . $modx->quote($index));
    return $stmt && $stmt->fetchColumn();
}

function tpAddIndex(modX $modx, $table, $index, $columns) {
    if (tpIndexExists($modx, $table, $index)) {
        echo "OK index exists: {$table}.{$index}<br>";
        return;
    }
    $modx->exec('ALTER TABLE `' . $table . '` ADD INDEX `' . $index . '` (' . $columns . ')');
    echo "ADDED index: {$table}.{$index}<br>";
}

$practices = tpTableName($modx, 'training_practices');
$attempts = tpTableName($modx, 'training_practice_attempts');
$messages = tpTableName($modx, 'training_practice_messages');
$files = tpTableName($modx, 'training_practice_files');
$testLinks = tpTableName($modx, 'training_test_links');
$userTests = tpTableName($modx, 'usertest_tests');

$charset = 'utf8mb4';
$collation = 'utf8mb4_unicode_ci';

$modx->exec("\nCREATE TABLE IF NOT EXISTS `{$practices}` (\n  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,\n  `course_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,\n  `module_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,\n  `title` VARCHAR(255) NOT NULL DEFAULT '',\n  `description` MEDIUMTEXT NULL,\n  `template_file` VARCHAR(500) NOT NULL DEFAULT '',\n  `template_file_name` VARCHAR(255) NOT NULL DEFAULT '',\n  `image` VARCHAR(500) NOT NULL DEFAULT '',\n  `deadline_at` DATETIME NULL,\n  `deadline_days` INT(10) UNSIGNED NOT NULL DEFAULT 0,\n  `allowed_extensions` VARCHAR(255) NOT NULL DEFAULT 'pdf,doc,docx,xls,xlsx,png,jpg,jpeg,zip',\n  `max_file_size` INT(10) UNSIGNED NOT NULL DEFAULT 52428800,\n  `active` TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,\n  `rank` INT(10) UNSIGNED NOT NULL DEFAULT 0,\n  `createdon` DATETIME NULL,\n  `editedon` DATETIME NULL,\n  PRIMARY KEY (`id`)\n) ENGINE=InnoDB DEFAULT CHARSET={$charset} COLLATE={$collation}\n");

tpAddColumn($modx, $attempts, 'practice_id', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `id`');
tpAddColumn($modx, $attempts, 'attempt_num', 'INT(10) UNSIGNED NOT NULL DEFAULT 1 AFTER `user_id`');
tpAddColumn($modx, $attempts, 'deadline_at', 'DATETIME NULL AFTER `status`');
tpAddColumn($modx, $attempts, 'reviewedby', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `reviewedon`');
tpAddColumn($modx, $attempts, 'is_latest', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 1 AFTER `reviewedby`');

tpAddColumn($modx, $messages, 'practice_id', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `attempt_id`');
tpAddColumn($modx, $messages, 'author_id', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `practice_id`');
tpAddColumn($modx, $messages, 'author_type', "VARCHAR(50) NOT NULL DEFAULT 'user' AFTER `author_id`");

if (tpColumnExists($modx, $attempts, 'attempt_no')) {
    $modx->exec("UPDATE `{$attempts}` SET `attempt_num` = `attempt_no` WHERE `attempt_num` = 1 AND `attempt_no` > 0");
}
if (tpColumnExists($modx, $attempts, 'reviewer_user_id')) {
    $modx->exec("UPDATE `{$attempts}` SET `reviewedby` = `reviewer_user_id` WHERE `reviewedby` = 0 AND `reviewer_user_id` > 0");
}
if (tpColumnExists($modx, $messages, 'user_id')) {
    $modx->exec("UPDATE `{$messages}` SET `author_id` = `user_id` WHERE `author_id` = 0 AND `user_id` > 0");
}
if (tpColumnExists($modx, $messages, 'sender_role')) {
    $modx->exec("UPDATE `{$messages}` SET `author_type` = CASE WHEN `sender_role` IN ('mentor','manager','admin') THEN 'mentor' ELSE 'user' END WHERE `author_type` = '' OR `author_type` = 'user'");
}

// Перенос старых практик, которые раньше были привязаны через вкладку «Тесты и практики».
$modx->exec("\nINSERT INTO `{$practices}`\n(`course_id`, `module_id`, `title`, `description`, `template_file`, `template_file_name`, `image`, `deadline_at`, `deadline_days`, `allowed_extensions`, `max_file_size`, `active`, `rank`, `createdon`, `editedon`)\nSELECT\n    tl.`course_id`,\n    tl.`module_id`,\n    ut.`name`,\n    TRIM(CONCAT(IFNULL(ut.`description`, ''), CASE WHEN IFNULL(ut.`instruction`, '') <> '' THEN CONCAT('\\n\\n', ut.`instruction`) ELSE '' END)),\n    '',\n    '',\n    'theme/images/training/tests/logo-scanport.svg',\n    NULL,\n    0,\n    'pdf,doc,docx,xls,xlsx,png,jpg,jpeg,zip',\n    52428800,\n    IFNULL(ut.`active`, 1),\n    IFNULL(tl.`sort_order`, 0),\n    NOW(),\n    NOW()\nFROM `{$testLinks}` tl\nINNER JOIN `{$userTests}` ut ON ut.`id` = tl.`usertest_test_id`\nWHERE tl.`link_type` = 'practice'\n  AND NOT EXISTS (\n      SELECT 1\n      FROM `{$practices}` p\n      WHERE p.`course_id` = tl.`course_id`\n        AND p.`module_id` = tl.`module_id`\n        AND p.`title` = ut.`name`\n      LIMIT 1\n  )\n");

// Привязка старых попыток к новым practice_id, если они были от старой схемы через test_link_id.
if (tpColumnExists($modx, $attempts, 'test_link_id')) {
    $modx->exec("\n    UPDATE `{$attempts}` a\n    INNER JOIN `{$testLinks}` tl ON tl.`id` = a.`test_link_id` AND tl.`link_type` = 'practice'\n    INNER JOIN `{$userTests}` ut ON ut.`id` = tl.`usertest_test_id`\n    INNER JOIN `{$practices}` p ON p.`course_id` = tl.`course_id` AND p.`module_id` = tl.`module_id` AND p.`title` = ut.`name`\n    SET a.`practice_id` = p.`id`\n    WHERE a.`practice_id` = 0\n    ");
}

$modx->exec("\nUPDATE `{$messages}` m\nINNER JOIN `{$attempts}` a ON a.`id` = m.`attempt_id`\nSET m.`practice_id` = a.`practice_id`\nWHERE m.`practice_id` = 0 AND a.`practice_id` > 0\n");

tpAddIndex($modx, $practices, 'course_id', '`course_id`');
tpAddIndex($modx, $practices, 'module_id', '`module_id`');
tpAddIndex($modx, $attempts, 'practice_user', '`practice_id`, `user_id`');
tpAddIndex($modx, $messages, 'attempt_id', '`attempt_id`');
tpAddIndex($modx, $files, 'attempt_id', '`attempt_id`');

$modx->cacheManager->refresh(array(
    'db' => array(),
    'system_settings' => array(),
    'scripts' => array(),
));

echo '<pre>';
echo "OK: practice admin schema upgraded\n";
echo "practices: {$practices}\n";
echo "attempts: {$attempts}\n";
echo "messages: {$messages}\n";
echo "files: {$files}\n";
echo "old usertest table: {$userTests}\n";
echo '</pre>';
