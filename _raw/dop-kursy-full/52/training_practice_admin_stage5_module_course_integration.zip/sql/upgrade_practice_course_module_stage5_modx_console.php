<?php
/**
 * Stage 5: practical assignments inside course/module structure.
 * Safe: does not delete data.
 * - For link_type=practice in training_test_links, usertest_test_id is now treated as training_practices.id.
 * - Existing active practices are automatically linked to their module.
 * - Existing practice links are migrated to real rows in training_practices.
 */

function tp5PlainTable(modX $modx, $name) {
    $prefix = (string)$modx->getOption('table_prefix');
    $candidates = array($prefix . $name, $prefix . '_' . $name, 'modx_' . $name);
    foreach ($candidates as $table) {
        $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
        if ($table === '') { continue; }
        $stmt = $modx->query('SHOW TABLES LIKE ' . $modx->quote($table));
        if ($stmt && $stmt->fetchColumn()) { return $table; }
    }
    return preg_replace('/[^a-zA-Z0-9_]/', '', $prefix . $name);
}

function tp5ColumnExists(modX $modx, $table, $column) {
    $stmt = $modx->query('SHOW COLUMNS FROM `' . $table . '` LIKE ' . $modx->quote($column));
    return $stmt && $stmt->fetchColumn();
}

function tp5AddColumn(modX $modx, $table, $column, $definition) {
    if (tp5ColumnExists($modx, $table, $column)) {
        echo "OK column: {$table}.{$column}<br>";
        return;
    }
    $modx->exec('ALTER TABLE `' . $table . '` ADD COLUMN `' . $column . '` ' . $definition);
    echo "ADDED column: {$table}.{$column}<br>";
}

function tp5PracticeExists(modX $modx, $practices, $id) {
    $stmt = $modx->prepare("SELECT COUNT(*) FROM `{$practices}` WHERE `id` = :id");
    $stmt->execute(array(':id' => (int)$id));
    return (int)$stmt->fetchColumn() > 0;
}

function tp5GetUserTestTitle(modX $modx, $userTests, $id, $fallback) {
    $id = (int)$id;
    if ($id <= 0) { return $fallback; }
    $stmt = $modx->prepare("SELECT `name`, `description` FROM `{$userTests}` WHERE `id` = :id LIMIT 1");
    if (!$stmt || !$stmt->execute(array(':id' => $id))) { return $fallback; }
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) { return $fallback; }
    $name = trim((string)$row['name']);
    return $name !== '' ? $name : $fallback;
}

function tp5EnsurePracticeLink(modX $modx, $links, $courseId, $moduleId, $practiceId, $rank = 0) {
    $courseId = (int)$courseId;
    $moduleId = (int)$moduleId;
    $practiceId = (int)$practiceId;
    $rank = (int)$rank;
    if ($courseId <= 0 || $moduleId <= 0 || $practiceId <= 0) { return 0; }

    if ($rank <= 0) {
        $stmt = $modx->prepare("SELECT MAX(`sort_order`) FROM `{$links}` WHERE `course_id` = :course_id AND `module_id` = :module_id");
        $stmt->execute(array(':course_id' => $courseId, ':module_id' => $moduleId));
        $rank = ((int)$stmt->fetchColumn()) + 1;
    }

    $stmt = $modx->prepare("SELECT `id` FROM `{$links}` WHERE `link_type` = 'practice' AND `usertest_test_id` = :practice_id LIMIT 1");
    $stmt->execute(array(':practice_id' => $practiceId));
    $linkId = (int)$stmt->fetchColumn();

    if ($linkId > 0) {
        $stmt = $modx->prepare("UPDATE `{$links}` SET `course_id` = :course_id, `module_id` = :module_id, `sort_order` = :rank, `link_type` = 'practice' WHERE `id` = :id");
        $stmt->execute(array(':id' => $linkId, ':course_id' => $courseId, ':module_id' => $moduleId, ':rank' => $rank));
        return $linkId;
    }

    $stmt = $modx->prepare("\n        INSERT INTO `{$links}`\n        (`course_id`, `module_id`, `usertest_test_id`, `link_type`, `sort_order`, `is_required`, `max_attempts`, `min_pass_percent`, `block_next_module_until_passed`, `createdon`)\n        VALUES\n        (:course_id, :module_id, :practice_id, 'practice', :rank, 1, 5, 0, 0, NOW())\n    ");
    $stmt->execute(array(':course_id' => $courseId, ':module_id' => $moduleId, ':practice_id' => $practiceId, ':rank' => $rank));
    return (int)$modx->lastInsertId();
}

$practices = tp5PlainTable($modx, 'training_practices');
$attempts = tp5PlainTable($modx, 'training_practice_attempts');
$messages = tp5PlainTable($modx, 'training_practice_messages');
$files = tp5PlainTable($modx, 'training_practice_files');
$links = tp5PlainTable($modx, 'training_test_links');
$userTests = tp5PlainTable($modx, 'usertest_tests');
$settings = tp5PlainTable($modx, 'system_settings');

$modx->exec("CREATE TABLE IF NOT EXISTS `{$practices}` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `module_id` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `title` VARCHAR(255) NOT NULL DEFAULT '',
  `description` MEDIUMTEXT NULL,
  `template_file` VARCHAR(500) NOT NULL DEFAULT '',
  `template_file_name` VARCHAR(255) NOT NULL DEFAULT '',
  `image` VARCHAR(500) NOT NULL DEFAULT '',
  `deadline_at` DATETIME NULL,
  `deadline_days` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `allowed_extensions` VARCHAR(255) NOT NULL DEFAULT 'pdf,doc,docx,xls,xlsx,png,jpg,jpeg,zip',
  `max_file_size` INT(10) UNSIGNED NOT NULL DEFAULT 52428800,
  `active` TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
  `rank` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `createdon` DATETIME NULL,
  `editedon` DATETIME NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

tp5AddColumn($modx, $practices, 'course_id', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `id`');
tp5AddColumn($modx, $practices, 'module_id', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `course_id`');
tp5AddColumn($modx, $practices, 'title', "VARCHAR(255) NOT NULL DEFAULT '' AFTER `module_id`");
tp5AddColumn($modx, $practices, 'description', 'MEDIUMTEXT NULL AFTER `title`');
tp5AddColumn($modx, $practices, 'template_file', "VARCHAR(500) NOT NULL DEFAULT '' AFTER `description`");
tp5AddColumn($modx, $practices, 'template_file_name', "VARCHAR(255) NOT NULL DEFAULT '' AFTER `template_file`");
tp5AddColumn($modx, $practices, 'image', "VARCHAR(500) NOT NULL DEFAULT '' AFTER `template_file_name`");
tp5AddColumn($modx, $practices, 'deadline_at', 'DATETIME NULL AFTER `image`');
tp5AddColumn($modx, $practices, 'deadline_days', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `deadline_at`');
tp5AddColumn($modx, $practices, 'allowed_extensions', "VARCHAR(255) NOT NULL DEFAULT 'pdf,doc,docx,xls,xlsx,png,jpg,jpeg,zip' AFTER `deadline_days`");
tp5AddColumn($modx, $practices, 'max_file_size', 'INT(10) UNSIGNED NOT NULL DEFAULT 52428800 AFTER `allowed_extensions`');
tp5AddColumn($modx, $practices, 'active', 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 1 AFTER `max_file_size`');
tp5AddColumn($modx, $practices, 'rank', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `active`');
tp5AddColumn($modx, $practices, 'createdon', 'DATETIME NULL AFTER `rank`');
tp5AddColumn($modx, $practices, 'editedon', 'DATETIME NULL AFTER `createdon`');

tp5AddColumn($modx, $attempts, 'practice_id', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `id`');
tp5AddColumn($modx, $attempts, 'attempt_num', 'INT(10) UNSIGNED NOT NULL DEFAULT 1 AFTER `user_id`');
tp5AddColumn($modx, $messages, 'practice_id', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `attempt_id`');
tp5AddColumn($modx, $messages, 'author_id', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `practice_id`');
tp5AddColumn($modx, $messages, 'author_type', "VARCHAR(50) NOT NULL DEFAULT 'user' AFTER `author_id`");
tp5AddColumn($modx, $files, 'practice_id', 'INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `message_id`');

// Fix setting.
$key = 'training.training_practice_resource_id';
$stmt = $modx->prepare("SELECT COUNT(*) FROM `{$settings}` WHERE `key` = :key");
$stmt->execute(array(':key' => $key));
if ((int)$stmt->fetchColumn() > 0) {
    $stmt = $modx->prepare("UPDATE `{$settings}` SET `value` = '176', `xtype` = 'numberfield', `namespace` = 'training', `area` = 'training' WHERE `key` = :key");
    $stmt->execute(array(':key' => $key));
} else {
    $stmt = $modx->prepare("INSERT INTO `{$settings}` (`key`, `value`, `xtype`, `namespace`, `area`) VALUES (:key, '176', 'numberfield', 'training', 'training')");
    $stmt->execute(array(':key' => $key));
}

// 1) Existing practice links must point to real training_practices.id.
$stmt = $modx->query("SELECT * FROM `{$links}` WHERE `link_type` = 'practice' ORDER BY `id` ASC");
$linkRows = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : array();
foreach ($linkRows as $link) {
    $linkId = (int)$link['id'];
    $courseId = (int)$link['course_id'];
    $moduleId = (int)$link['module_id'];
    $practiceId = (int)$link['usertest_test_id'];
    $rank = (int)$link['sort_order'];

    if ($practiceId <= 0) {
        $title = 'Практическое задание #' . $linkId;
        $stmtIns = $modx->prepare("INSERT INTO `{$practices}` (`course_id`, `module_id`, `title`, `description`, `image`, `active`, `rank`, `createdon`, `editedon`) VALUES (:course_id, :module_id, :title, :description, :image, 1, :rank, NOW(), NOW())");
        $stmtIns->execute(array(':course_id' => $courseId, ':module_id' => $moduleId, ':title' => $title, ':description' => 'Загрузите выполненное задание и отправьте сообщение ментору.', ':image' => 'theme/images/training/tests/logo-scanport.svg', ':rank' => $rank));
        $practiceId = (int)$modx->lastInsertId();
        $modx->exec("UPDATE `{$links}` SET `usertest_test_id` = {$practiceId} WHERE `id` = {$linkId}");
        echo "CREATED practice {$practiceId} for link {$linkId}<br>";
    }

    if (!tp5PracticeExists($modx, $practices, $practiceId)) {
        $title = tp5GetUserTestTitle($modx, $userTests, $practiceId, 'Практическое задание DataMobile');
        $stmtIns = $modx->prepare("INSERT INTO `{$practices}` (`id`, `course_id`, `module_id`, `title`, `description`, `image`, `active`, `rank`, `createdon`, `editedon`) VALUES (:id, :course_id, :module_id, :title, :description, :image, 1, :rank, NOW(), NOW())");
        $stmtIns->execute(array(':id' => $practiceId, ':course_id' => $courseId, ':module_id' => $moduleId, ':title' => $title, ':description' => 'Загрузите выполненное задание PDF, DOCX или XLSX и отправьте сообщение ментору.', ':image' => 'theme/images/training/tests/logo-scanport.svg', ':rank' => $rank));
        echo "INSERTED practice id={$practiceId} for old link {$linkId}<br>";
    } else {
        $stmtUpd = $modx->prepare("UPDATE `{$practices}` SET `course_id` = :course_id, `module_id` = :module_id, `rank` = :rank, `active` = 1, `editedon` = NOW() WHERE `id` = :id");
        $stmtUpd->execute(array(':id' => $practiceId, ':course_id' => $courseId, ':module_id' => $moduleId, ':rank' => $rank));
        echo "OK linked practice id={$practiceId}<br>";
    }
}

// 2) Any active practice with course/module should be visible in course module.
$stmt = $modx->query("SELECT * FROM `{$practices}` WHERE `active` = 1 AND `course_id` > 0 AND `module_id` > 0 ORDER BY `course_id`, `module_id`, `rank`, `id`");
$practiceRows = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : array();
foreach ($practiceRows as $practice) {
    $linkId = tp5EnsurePracticeLink($modx, $links, (int)$practice['course_id'], (int)$practice['module_id'], (int)$practice['id'], (int)$practice['rank']);
    echo "practice #" . (int)$practice['id'] . " linked as test_link #{$linkId}<br>";
}

// 3) Guarantee one practice for course=1/module=1 for immediate test.
$stmt = $modx->query("SELECT `id` FROM `{$practices}` WHERE `course_id` = 1 AND `module_id` = 1 AND `active` = 1 ORDER BY `rank`, `id` LIMIT 1");
$demoPracticeId = $stmt ? (int)$stmt->fetchColumn() : 0;
if ($demoPracticeId <= 0) {
    $stmtIns = $modx->prepare("INSERT INTO `{$practices}` (`course_id`, `module_id`, `title`, `description`, `image`, `active`, `rank`, `createdon`, `editedon`) VALUES (1, 1, 'Практическое задание DataMobile', 'Загрузите выполненное задание PDF, DOCX или XLSX и отправьте сообщение ментору.', 'theme/images/training/tests/logo-scanport.svg', 1, 2, NOW(), NOW())");
    $stmtIns->execute();
    $demoPracticeId = (int)$modx->lastInsertId();
    echo "INSERTED demo practice #{$demoPracticeId}<br>";
}
$demoLinkId = tp5EnsurePracticeLink($modx, $links, 1, 1, $demoPracticeId, 2);
echo "DEMO practice #{$demoPracticeId} link #{$demoLinkId}<br>";

// 4) Move legacy attempt ids to current practice_id.
if (tp5ColumnExists($modx, $attempts, 'test_link_id') && tp5ColumnExists($modx, $attempts, 'practice_id')) {
    $modx->exec("UPDATE `{$attempts}` a INNER JOIN `{$links}` l ON l.`id` = a.`test_link_id` AND l.`link_type` = 'practice' SET a.`practice_id` = l.`usertest_test_id` WHERE a.`practice_id` = 0");
}
if (tp5ColumnExists($modx, $attempts, 'attempt_no') && tp5ColumnExists($modx, $attempts, 'attempt_num')) {
    $modx->exec("UPDATE `{$attempts}` SET `attempt_num` = `attempt_no` WHERE `attempt_num` = 1 AND `attempt_no` > 0");
}
if (tp5ColumnExists($modx, $messages, 'practice_id')) {
    $modx->exec("UPDATE `{$messages}` m INNER JOIN `{$attempts}` a ON a.`id` = m.`attempt_id` SET m.`practice_id` = a.`practice_id` WHERE m.`practice_id` = 0 AND a.`practice_id` > 0");
}

$maxIdStmt = $modx->query("SELECT MAX(`id`) FROM `{$practices}`");
$maxId = $maxIdStmt ? (int)$maxIdStmt->fetchColumn() : 0;
if ($maxId > 0) {
    $modx->exec('ALTER TABLE `' . $practices . '` AUTO_INCREMENT = ' . ($maxId + 1));
}

$modx->cacheManager->refresh(array('db' => array(), 'system_settings' => array(), 'scripts' => array()));

echo '<pre>';
echo "OK: stage5 practice module integration done\n";
echo "practices table: {$practices}\n";
echo "links table: {$links}\n";
echo "demo practice id: {$demoPracticeId}\n";
echo "practice page: /obuchenie/obuchenie-glavnaya/stranitsa-prakticheskoe-zadanie/?activity={$demoPracticeId}\n";
echo '</pre>';
