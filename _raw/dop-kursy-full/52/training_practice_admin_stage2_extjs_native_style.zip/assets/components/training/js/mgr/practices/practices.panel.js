(function () {
    'use strict';

    function bootTrainingPracticesExt() {
        if (!window.Ext || !window.MODx || !Ext.ns || !MODx.Panel || !MODx.grid || !MODx.Window) {
            window.setTimeout(bootTrainingPracticesExt, 50);
            return;
        }

        window.Training = window.Training || {};
        if (window.Training.panel && window.Training.panel.Practices) {
            return;
        }

Ext.ns('Training');
Ext.ns('Training.panel');
Ext.ns('Training.grid');
Ext.ns('Training.window');

Training.config = Training.config || {};
Training.config.connector_url = Training.config.connector_url || (MODx.config.assets_url + 'components/training/connector.php');

Training.panel.Practices = function(config) {
    config = config || {};
    Ext.applyIf(config, {
        id: 'training-panel-practices',
        cls: 'container',
        border: false,
        items: [{
            html: '<h2>Практические задания</h2>',
            border: false,
            cls: 'modx-page-header training-practices-page-title'
        }, {
            xtype: 'modx-tabs',
            id: 'training-practices-tabs',
            cls: 'main-wrapper',
            deferredRender: false,
            border: false,
            defaults: {
                border: false,
                autoHeight: true
            },
            items: [{
                title: 'Задания',
                layout: 'form',
                items: [{xtype: 'training-grid-practices'}]
            }, {
                title: 'Попытки и переписка',
                layout: 'form',
                items: [{xtype: 'training-panel-practice-review'}]
            }]
        }]
    });
    Training.panel.Practices.superclass.constructor.call(this, config);
};
Ext.extend(Training.panel.Practices, MODx.Panel);
Ext.reg('training-panel-practices', Training.panel.Practices);

Training.grid.Practices = function(config) {
    config = config || {};
    Ext.applyIf(config, {
        id: 'training-grid-practices',
        cls: 'modx-grid training-grid-practices',
        viewConfig: {forceFit: false, autoFill: false},
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/practice/practices/getlist'
        },
        save_action: 'mgr/practice/practices/update',
        autosave: false,
        fields: [
            'id','course_id','module_id','title','description','template_file','template_file_name','image',
            'deadline_at','deadline_at_formatted','deadline_days','allowed_extensions','max_file_size',
            'active','active_text','rank','createdon','createdon_formatted','editedon','editedon_formatted',
            'course_title','module_title','course_display','module_display'
        ],
        paging: true,
        remoteSort: true,
        anchor: '100%',
        autoHeight: true,
        columns: [{
            header: 'ID',
            dataIndex: 'id',
            width: 60,
            sortable: true
        }, {
            header: 'Курс',
            dataIndex: 'course_display',
            width: 180,
            sortable: true
        }, {
            header: 'Модуль',
            dataIndex: 'module_display',
            width: 180,
            sortable: true
        }, {
            header: 'Название',
            dataIndex: 'title',
            width: 300,
            sortable: true
        }, {
            header: 'Активно',
            dataIndex: 'active_text',
            width: 90,
            sortable: true
        }, {
            header: 'Срок',
            dataIndex: 'deadline_at_formatted',
            width: 150,
            sortable: true
        }, {
            header: 'Ранг',
            dataIndex: 'rank',
            width: 80,
            sortable: true
        }],
        tbar: [{
            text: 'Создать задание',
            cls: 'primary-button',
            handler: this.createPractice,
            scope: this
        }, '-', {
            xtype: 'textfield',
            id: 'training-practices-search',
            emptyText: 'Поиск...',
            width: 220,
            listeners: {
                render: {
                    fn: function(tf) {
                        tf.getEl().on('keyup', function(e) {
                            if (e.getKey() === Ext.EventObject.ENTER) {
                                this.search();
                            }
                        }, this);
                    },
                    scope: this
                }
            }
        }, {
            text: 'Найти',
            handler: this.search,
            scope: this
        }, {
            text: 'Сбросить',
            handler: this.resetSearch,
            scope: this
        }]
    });
    Training.grid.Practices.superclass.constructor.call(this, config);
};
Ext.extend(Training.grid.Practices, MODx.grid.Grid, {
    getMenu: function() {
        var m = [{
            text: 'Изменить',
            handler: this.updatePractice
        }, '-', {
            text: 'Удалить / отключить',
            handler: this.removePractice
        }];
        this.addContextMenuItem(m);
    },

    search: function() {
        this.getStore().baseParams.query = Ext.getCmp('training-practices-search').getValue();
        this.getBottomToolbar().changePage(1);
    },

    resetSearch: function() {
        Ext.getCmp('training-practices-search').setValue('');
        this.getStore().baseParams.query = '';
        this.getBottomToolbar().changePage(1);
    },

    createPractice: function(btn, e) {
        if (!this.createPracticeWindow) {
            this.createPracticeWindow = MODx.load({
                xtype: 'training-window-practice',
                title: 'Создать практическое задание',
                action: 'mgr/practice/practices/create',
                listeners: {
                    success: {
                        fn: this.refresh,
                        scope: this
                    }
                }
            });
        }
        this.createPracticeWindow.fp.getForm().reset();
        this.createPracticeWindow.show(e.target);
    },

    updatePractice: function(btn, e) {
        if (!this.menu.record) return;
        var record = this.menu.record;
        var win = MODx.load({
            xtype: 'training-window-practice',
            title: 'Изменить практическое задание',
            action: 'mgr/practice/practices/update',
            record: record,
            listeners: {
                success: {
                    fn: this.refresh,
                    scope: this
                }
            }
        });
        win.fp.getForm().setValues(record);
        win.show(e.target);
    },

    removePractice: function() {
        if (!this.menu.record) return;
        MODx.msg.confirm({
            title: 'Удалить задание',
            text: 'Если у задания уже есть попытки, оно будет отключено. Продолжить?',
            url: Training.config.connector_url,
            params: {
                action: 'mgr/practice/practices/remove',
                id: this.menu.record.id
            },
            listeners: {
                success: {
                    fn: this.refresh,
                    scope: this
                }
            }
        });
    }
});
Ext.reg('training-grid-practices', Training.grid.Practices);

Training.window.Practice = function(config) {
    config = config || {};
    Ext.applyIf(config, {
        width: 760,
        url: Training.config.connector_url,
        action: config.action || 'mgr/practice/practices/create',
        fields: [{
            xtype: 'hidden',
            name: 'id'
        }, {
            layout: 'column',
            border: false,
            defaults: {border: false, layout: 'form'},
            items: [{
                columnWidth: .5,
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: 'ID курса / ресурса курса',
                    name: 'course_id',
                    anchor: '100%',
                    allowBlank: false
                }]
            }, {
                columnWidth: .5,
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: 'ID модуля / ресурса модуля',
                    name: 'module_id',
                    anchor: '100%',
                    allowBlank: false
                }]
            }]
        }, {
            xtype: 'textfield',
            fieldLabel: 'Название',
            name: 'title',
            anchor: '100%',
            allowBlank: false
        }, {
            xtype: 'textarea',
            fieldLabel: 'Описание / инструкция',
            name: 'description',
            anchor: '100%',
            height: 120
        }, {
            layout: 'column',
            border: false,
            defaults: {border: false, layout: 'form'},
            items: [{
                columnWidth: .65,
                items: [{
                    xtype: 'textfield',
                    fieldLabel: 'Файл задания',
                    name: 'template_file',
                    anchor: '100%'
                }]
            }, {
                columnWidth: .35,
                items: [{
                    xtype: 'textfield',
                    fieldLabel: 'Название файла',
                    name: 'template_file_name',
                    anchor: '100%'
                }]
            }]
        }, {
            xtype: 'textfield',
            fieldLabel: 'Картинка',
            name: 'image',
            anchor: '100%'
        }, {
            layout: 'column',
            border: false,
            defaults: {border: false, layout: 'form'},
            items: [{
                columnWidth: .35,
                items: [{
                    xtype: 'textfield',
                    fieldLabel: 'Срок до даты',
                    name: 'deadline_at',
                    anchor: '100%',
                    emptyText: '2026-05-30 18:00:00'
                }]
            }, {
                columnWidth: .25,
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: 'Срок дней',
                    name: 'deadline_days',
                    anchor: '100%'
                }]
            }, {
                columnWidth: .2,
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: 'Ранг',
                    name: 'rank',
                    anchor: '100%'
                }]
            }, {
                columnWidth: .2,
                items: [{
                    xtype: 'combo',
                    fieldLabel: 'Активно',
                    name: 'active',
                    hiddenName: 'active',
                    anchor: '100%',
                    mode: 'local',
                    triggerAction: 'all',
                    editable: false,
                    value: 1,
                    store: [[1, 'Да'], [0, 'Нет']]
                }]
            }]
        }, {
            layout: 'column',
            border: false,
            defaults: {border: false, layout: 'form'},
            items: [{
                columnWidth: .65,
                items: [{
                    xtype: 'textfield',
                    fieldLabel: 'Разрешенные расширения',
                    name: 'allowed_extensions',
                    anchor: '100%',
                    value: 'pdf,doc,docx,xls,xlsx,png,jpg,jpeg,zip'
                }]
            }, {
                columnWidth: .35,
                items: [{
                    xtype: 'numberfield',
                    fieldLabel: 'Макс. размер файла, байт',
                    name: 'max_file_size',
                    anchor: '100%',
                    value: 52428800
                }]
            }]
        }]
    });
    Training.window.Practice.superclass.constructor.call(this, config);
};
Ext.extend(Training.window.Practice, MODx.Window);
Ext.reg('training-window-practice', Training.window.Practice);

Training.panel.PracticeReview = function(config) {
    config = config || {};
    Ext.applyIf(config, {
        id: 'training-panel-practice-review',
        cls: 'training-practice-review-panel',
        border: false,
        layout: 'form',
        items: [{
            xtype: 'training-grid-practice-attempts',
            listeners: {
                rowclick: function(grid, rowIndex) {
                    var rec = grid.getStore().getAt(rowIndex);
                    var messagesGrid = Ext.getCmp('training-grid-practice-messages');
                    if (messagesGrid && rec) {
                        messagesGrid.setAttempt(rec.data.id, rec.data);
                    }
                }
            }
        }, {
            xtype: 'training-grid-practice-messages'
        }]
    });
    Training.panel.PracticeReview.superclass.constructor.call(this, config);
};
Ext.extend(Training.panel.PracticeReview, MODx.Panel);
Ext.reg('training-panel-practice-review', Training.panel.PracticeReview);

Training.grid.PracticeAttempts = function(config) {
    config = config || {};
    Ext.applyIf(config, {
        id: 'training-grid-practice-attempts',
        cls: 'modx-grid training-grid-practice-attempts',
        viewConfig: {forceFit: false, autoFill: false},
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/practice/attempts/getlist'
        },
        fields: [
            'id','practice_id','practice_title','course_id','course_display','module_id','module_display',
            'user_id','user_display','email','attempt_num','status','status_text','deadline_at_formatted',
            'createdon_formatted','submittedon_formatted','reviewedon_formatted','is_latest'
        ],
        paging: true,
        remoteSort: true,
        anchor: '100%',
        autoHeight: true,
        columns: [{
            header: 'ID', dataIndex: 'id', width: 55, sortable: true
        }, {
            header: 'Задание', dataIndex: 'practice_title', width: 250, sortable: true
        }, {
            header: 'Пользователь', dataIndex: 'user_display', width: 180, sortable: true
        }, {
            header: 'Статус', dataIndex: 'status_text', width: 130, sortable: true
        }, {
            header: 'Попытка', dataIndex: 'attempt_num', width: 80, sortable: true
        }, {
            header: 'Отправлено', dataIndex: 'submittedon_formatted', width: 150, sortable: true
        }, {
            header: 'Курс', dataIndex: 'course_display', width: 160, sortable: true
        }, {
            header: 'Модуль', dataIndex: 'module_display', width: 160, sortable: true
        }],
        tbar: [{
            xtype: 'textfield',
            id: 'training-practice-attempts-search',
            emptyText: 'Поиск по пользователю или заданию...',
            width: 260,
            listeners: {
                render: {
                    fn: function(tf) {
                        tf.getEl().on('keyup', function(e) {
                            if (e.getKey() === Ext.EventObject.ENTER) this.search();
                        }, this);
                    },
                    scope: this
                }
            }
        }, {
            xtype: 'combo',
            id: 'training-practice-attempts-status',
            width: 170,
            mode: 'local',
            triggerAction: 'all',
            editable: false,
            emptyText: 'Все статусы',
            store: [
                ['', 'Все статусы'],
                ['submitted', 'Отправлено'],
                ['in_review', 'На проверке'],
                ['revision', 'На доработке'],
                ['approved', 'Принято'],
                ['rejected', 'Отклонено']
            ],
            listeners: {
                select: {fn: this.search, scope: this}
            }
        }, {
            text: 'Найти',
            handler: this.search,
            scope: this
        }, {
            text: 'Сбросить',
            handler: this.resetSearch,
            scope: this
        }]
    });
    Training.grid.PracticeAttempts.superclass.constructor.call(this, config);
};
Ext.extend(Training.grid.PracticeAttempts, MODx.grid.Grid, {
    getMenu: function() {
        this.addContextMenuItem([{
            text: 'На проверке',
            handler: function() { this.setStatus('in_review'); },
            scope: this
        }, {
            text: 'Принять',
            handler: function() { this.setStatus('approved'); },
            scope: this
        }, {
            text: 'На доработку',
            handler: function() { this.setStatus('revision'); },
            scope: this
        }, {
            text: 'Отклонить',
            handler: function() { this.setStatus('rejected'); },
            scope: this
        }]);
    },

    search: function() {
        this.getStore().baseParams.query = Ext.getCmp('training-practice-attempts-search').getValue();
        this.getStore().baseParams.status = Ext.getCmp('training-practice-attempts-status').getValue();
        this.getBottomToolbar().changePage(1);
    },

    resetSearch: function() {
        Ext.getCmp('training-practice-attempts-search').setValue('');
        Ext.getCmp('training-practice-attempts-status').setValue('');
        this.getStore().baseParams.query = '';
        this.getStore().baseParams.status = '';
        this.getBottomToolbar().changePage(1);
    },

    setStatus: function(status) {
        if (!this.menu.record) return;
        var text = 'Изменить статус попытки на «' + status + '»?';
        MODx.msg.confirm({
            title: 'Сменить статус',
            text: text,
            url: Training.config.connector_url,
            params: {
                action: 'mgr/practice/attempts/status',
                id: this.menu.record.id,
                status: status
            },
            listeners: {
                success: {
                    fn: function() {
                        this.refresh();
                        var messagesGrid = Ext.getCmp('training-grid-practice-messages');
                        if (messagesGrid) messagesGrid.refresh();
                    },
                    scope: this
                }
            }
        });
    }
});
Ext.reg('training-grid-practice-attempts', Training.grid.PracticeAttempts);

Training.grid.PracticeMessages = function(config) {
    config = config || {};
    Ext.applyIf(config, {
        id: 'training-grid-practice-messages',
        cls: 'modx-grid training-grid-practice-messages',
        viewConfig: {forceFit: false, autoFill: false},
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/practice/messages/getlist',
            attempt_id: 0
        },
        fields: ['id','attempt_id','practice_id','author_id','author_type','author_display','message','message_html','files_html','files_text','is_system','createdon_formatted'],
        paging: false,
        remoteSort: false,
        anchor: '100%',
        autoHeight: true,
        title: 'Переписка по выбранной попытке',
        columns: [{
            header: 'Дата',
            dataIndex: 'createdon_formatted',
            width: 140
        }, {
            header: 'Автор',
            dataIndex: 'author_display',
            width: 160
        }, {
            header: 'Тип',
            dataIndex: 'author_type',
            width: 90
        }, {
            header: 'Сообщение',
            dataIndex: 'message_html',
            width: 420,
            renderer: function(value) {
                return '<div class="training-practice-message-cell">' + (value || '') + '</div>';
            }
        }, {
            header: 'Файлы',
            dataIndex: 'files_html',
            width: 260,
            renderer: function(value) {
                return '<div class="training-practice-files-cell">' + (value || '') + '</div>';
            }
        }],
        tbar: [{
            xtype: 'displayfield',
            id: 'training-practice-selected-attempt',
            value: 'Выберите попытку выше'
        }],
        bbar: [{
            xtype: 'textarea',
            id: 'training-practice-message-text',
            emptyText: 'Ответ ментору/пользователю...',
            width: 520,
            height: 52
        }, {
            text: 'Отправить ответ',
            handler: this.sendMessage,
            scope: this
        }]
    });
    Training.grid.PracticeMessages.superclass.constructor.call(this, config);
    this.attemptId = 0;
};
Ext.extend(Training.grid.PracticeMessages, MODx.grid.Grid, {
    setAttempt: function(attemptId, record) {
        this.attemptId = parseInt(attemptId || 0, 10) || 0;
        this.getStore().baseParams.attempt_id = this.attemptId;
        var label = 'Попытка #' + this.attemptId;
        if (record) {
            label += ' — ' + (record.user_display || '') + ' / ' + (record.practice_title || '');
        }
        Ext.getCmp('training-practice-selected-attempt').setValue(label);
        this.refresh();
    },

    sendMessage: function() {
        var textField = Ext.getCmp('training-practice-message-text');
        var text = textField ? textField.getValue() : '';
        if (!this.attemptId) {
            MODx.msg.alert('Ошибка', 'Сначала выберите попытку');
            return;
        }
        if (!text) {
            MODx.msg.alert('Ошибка', 'Напишите сообщение');
            return;
        }
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/practice/messages/create',
                attempt_id: this.attemptId,
                message: text
            },
            listeners: {
                success: {
                    fn: function() {
                        textField.setValue('');
                        this.refresh();
                        var attemptsGrid = Ext.getCmp('training-grid-practice-attempts');
                        if (attemptsGrid) attemptsGrid.refresh();
                    },
                    scope: this
                }
            }
        });
    }
});
Ext.reg('training-grid-practice-messages', Training.grid.PracticeMessages);
    }

    bootTrainingPracticesExt();
})();
