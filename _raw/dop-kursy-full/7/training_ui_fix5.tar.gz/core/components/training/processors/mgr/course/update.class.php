<?php

class TrainingCourseUpdateProcessor extends modObjectUpdateProcessor
{
    public $classKey = 'TrainingCourse';
    public $objectType = 'training.course';

    public function checkPermissions()
    {
        return true;
    }

    protected function hasProperty($key)
    {
        return array_key_exists($key, $this->properties);
    }

    protected function boolValue($value)
    {
        return in_array((string)$value, ['1', 'true', 'yes', 'on'], true) || $value === true || $value === 1 ? 1 : 0;
    }

    public function beforeSet()
    {
        if (!(int)$this->getProperty('id')) {
            return 'Не указан ID курса';
        }

        $this->setProperty('is_active', $this->hasProperty('is_active') ? $this->boolValue($this->getProperty('is_active')) : (int)$this->object->get('is_active'));
        $this->setProperty('source_presentation', $this->hasProperty('source_presentation') ? trim((string)$this->getProperty('source_presentation')) : (string)$this->object->get('source_presentation'));
        $this->setProperty('presentation_pdf', $this->hasProperty('presentation_pdf') ? trim((string)$this->getProperty('presentation_pdf')) : (string)$this->object->get('presentation_pdf'));
        $this->setProperty('slides_dir', $this->hasProperty('slides_dir') ? trim((string)$this->getProperty('slides_dir')) : (string)$this->object->get('slides_dir'));
        $status = $this->hasProperty('presentation_status') ? trim((string)$this->getProperty('presentation_status')) : (string)$this->object->get('presentation_status');
        $this->setProperty('presentation_status', $status !== '' ? $status : 'none');
        return parent::beforeSet();
    }
}

return 'TrainingCourseUpdateProcessor';
