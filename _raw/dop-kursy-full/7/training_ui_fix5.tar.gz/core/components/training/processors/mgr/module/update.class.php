<?php

class TrainingModuleUpdateProcessor extends modObjectUpdateProcessor
{
    public $classKey = 'TrainingModule';
    public $objectType = 'training.module';

    public function checkPermissions()
    {
        return true;
    }

    protected function hasProperty($key)
    {
        return array_key_exists($key, $this->properties);
    }

    protected function boolValue($value)
    {
        return in_array((string)$value, ['1', 'true', 'yes', 'on'], true) || $value === true || $value === 1 ? 1 : 0;
    }

    public function beforeSet()
    {
        if (!(int)$this->getProperty('id')) {
            return 'Не указан ID модуля';
        }

        $this->setProperty('is_active', $this->hasProperty('is_active') ? $this->boolValue($this->getProperty('is_active')) : (int)$this->object->get('is_active'));
        $this->setProperty('is_required', $this->hasProperty('is_required') ? $this->boolValue($this->getProperty('is_required')) : (int)$this->object->get('is_required'));
        $this->setProperty('source_video', $this->hasProperty('source_video') ? trim((string)$this->getProperty('source_video')) : (string)$this->object->get('source_video'));
        $status = $this->hasProperty('video_status') ? trim((string)$this->getProperty('video_status')) : (string)$this->object->get('video_status');
        $this->setProperty('video_status', $status !== '' ? $status : 'none');
        $presentationStatus = $this->hasProperty('presentation_status') ? trim((string)$this->getProperty('presentation_status')) : (string)$this->object->get('presentation_status');
        $this->setProperty('presentation_status', $presentationStatus !== '' ? $presentationStatus : 'none');
        return parent::beforeSet();
    }
}

return 'TrainingModuleUpdateProcessor';
