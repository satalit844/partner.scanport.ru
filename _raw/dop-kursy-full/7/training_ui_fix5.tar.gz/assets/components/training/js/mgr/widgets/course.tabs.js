Training.panel.CourseTabs = function(config) {
    config = config || {};
    this.courseId = config.courseId || Training.config.course_id;
    Ext.apply(config, {
        id: 'training-course-tabs',
        border: true,
        deferredRender: false,
        defaults: {border: false, autoHeight: true},
        items: [{title: 'Общие', xtype: 'training-course-general-form', courseId: this.courseId}, {title: 'Модули', xtype: 'training-grid-course-modules', courseId: this.courseId}]
    });
    Training.panel.CourseTabs.superclass.constructor.call(this, config);
};
Ext.extend(Training.panel.CourseTabs, MODx.Tabs);
Ext.reg('training-course-tabs', Training.panel.CourseTabs);

Training.form.CourseGeneral = function(config) {
    config = config || {};
    this.courseId = config.courseId || Training.config.course_id;
    Ext.apply(config, {
        id: 'training-course-general-form',
        url: Training.config.connector_url,
        bodyCssClass: 'main-wrapper',
        cls: 'container',
        labelWidth: 190,
        autoHeight: true,
        border: false,
        bodyStyle: 'padding:16px;background:#fff;border:1px solid #e5e5e5;border-radius:6px;',
        defaults: {anchor: '100%'},
        items: [{html: '<div style="padding:0 0 16px;color:#666;line-height:1.6;">На уровне курса храним исходную презентацию, PDF и разобранные слайды. Сначала выбираем файл презентации, затем запускаем разбор в PDF и JPG-слайды.</div>', border: false}, {
            xtype: 'hidden', name: 'id', value: this.courseId
        }, {
            xtype: 'fieldset', title: 'Основное', autoHeight: true, defaults: {anchor: '100%'}, items: [
                {xtype: 'displayfield', fieldLabel: 'ID курса', name: 'id_label'},
                {xtype: 'displayfield', fieldLabel: 'Resource ID', name: 'resource_id'},
                {xtype: 'displayfield', fieldLabel: 'Название', name: 'pagetitle'},
                {xtype: 'displayfield', fieldLabel: 'Алиас', name: 'alias'},
                {xtype: 'displayfield', fieldLabel: 'Контекст', name: 'context_key'},
                {xtype: 'displayfield', fieldLabel: 'URI', name: 'uri'},
                {xtype: 'displayfield', fieldLabel: 'Опубликован ресурс', name: 'published_label'},
                {xtype: 'displayfield', fieldLabel: 'Модулей', name: 'modules_count'},
                {xtype: 'xcheckbox', boxLabel: 'Курс активен', hideLabel: true, name: 'is_active', inputValue: 1, checked: true}
            ]
        }, {
            xtype: 'fieldset', title: 'Презентация и слайды', autoHeight: true, defaults: {anchor: '100%'}, items: [
                {xtype: 'button', text: 'Выбрать файл с сервера', style: 'margin-bottom:8px;', handler: function() {
                    var field = this.getForm().findField('source_presentation');
                    Training.utils.openPathBrowser(field, {allowedFileTypes: 'ppt,pptx,pdf'});
                }, scope: this},
                {xtype: 'textfield', fieldLabel: 'Исходный PPT/PPTX/PDF', name: 'source_presentation', anchor: '100%', emptyText: '/assets/uploads/training/course-1/source.pptx'},
                {xtype: 'displayfield', fieldLabel: 'Статус презентации', name: 'presentation_status'},
                {xtype: 'displayfield', fieldLabel: 'PDF', name: 'presentation_pdf', renderer: Training.utils.renderFileLink},
                {xtype: 'displayfield', fieldLabel: 'Папка слайдов', name: 'slides_dir'},
                {xtype: 'displayfield', fieldLabel: 'Папка найдена', name: 'slides_dir_exists_label'},
                {xtype: 'displayfield', fieldLabel: 'Слайдов в папке', name: 'available_slides_count'}
            ]
        }],
        buttons: [{text: 'Сохранить', handler: this.saveForm, scope: this}, {text: 'Разобрать PPTX в слайды', handler: this.processPresentation, scope: this}, {text: 'Открыть ресурс', handler: function() {
            if (this.currentData && this.currentData.resource_id) {
                MODx.loadPage('resource/update', 'id=' + this.currentData.resource_id);
            }
        }, scope: this}, {text: 'Назад к списку', handler: function() { window.location.href = Training.utils.buildUrl({}, ['course_id', 'module_id']); }}]
    });
    Training.form.CourseGeneral.superclass.constructor.call(this, config);
    this.on('afterrender', this.loadCourse, this);
};
Ext.extend(Training.form.CourseGeneral, MODx.FormPanel, {
    applyLoadedData: function(obj) {
        this.currentData = obj || {};
        Training.utils.populateForm(this, obj, ['is_active']);
    },
    loadCourse: function() {
        this.getEl().mask('Загружаем курс...');
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {action: 'mgr/course/get', id: this.courseId},
            listeners: {
                success: {fn: function(r) { this.getEl().unmask(); this.applyLoadedData(Training.utils.getResultData(r)); }, scope: this},
                failure: {fn: function(r) { this.getEl().unmask(); MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось загрузить курс'); }, scope: this}
            }
        });
    },
    getSubmitValues: function() {
        var form = this.getForm();
        var values = form.getValues();
        values.id = this.courseId;
        var isActiveField = form.findField('is_active');
        values.is_active = isActiveField && Training.utils.toBool(isActiveField.getValue()) ? 1 : 0;
        return values;
    },
    saveForm: function() {
        var values = this.getSubmitValues();
        this.getEl().mask('Сохраняем курс...');
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: Ext.apply(values, {action: 'mgr/course/update'}),
            listeners: {
                success: {fn: function() { this.getEl().unmask(); this.loadCourse(); MODx.msg.alert('Готово', 'Курс сохранён'); }, scope: this},
                failure: {fn: function(r) { this.getEl().unmask(); MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось сохранить курс'); }, scope: this}
            }
        });
    },
    processPresentation: function() {
        var values = this.getSubmitValues();
        this.getEl().mask('Обрабатываем презентацию...');
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {action: 'mgr/course/presentation/process', course_id: this.courseId, source_presentation: values.source_presentation || ''},
            listeners: {
                success: {fn: function(r) { this.getEl().unmask(); this.loadCourse(); var message = 'Презентация обработана'; var obj = Training.utils.getResultData(r); if (typeof obj.slides_count !== 'undefined') { message += '. Слайдов: ' + obj.slides_count; } MODx.msg.alert('Готово', message); }, scope: this},
                failure: {fn: function(r) { this.getEl().unmask(); MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось обработать презентацию'); }, scope: this}
            }
        });
    }
});
Ext.reg('training-course-general-form', Training.form.CourseGeneral);
