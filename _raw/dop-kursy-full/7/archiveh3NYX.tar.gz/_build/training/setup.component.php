<?php
require_once __DIR__ . '/bootstrap.php';

$modx->setLogLevel(modX::LOG_LEVEL_ERROR);
$modx->setLogTarget('ECHO');

function saveNamespace(modX $modx, $name, $path, $assetsPath)
{
    $namespace = $modx->getObject('modNamespace', ['name' => $name]);
    if (!$namespace) {
        $namespace = $modx->newObject('modNamespace');
        $namespace->set('name', $name);
    }

    $namespace->set('path', $path);
    $namespace->set('assets_path', $assetsPath);

    return $namespace->save();
}

function saveSystemSetting(modX $modx, $key, $value, $xtype = 'textfield', $namespace = 'training', $area = 'Paths')
{
    $setting = $modx->getObject('modSystemSetting', ['key' => $key]);
    if (!$setting) {
        $setting = $modx->newObject('modSystemSetting');
        $setting->set('key', $key);
    }

    $setting->set('value', $value);
    $setting->set('xtype', $xtype);
    $setting->set('namespace', $namespace);
    $setting->set('area', $area);

    return $setting->save();
}

function saveAction(modX $modx, $namespace, $controller, $langTopics = 'training:default')
{
    $action = $modx->getObject('modAction', [
        'namespace'  => $namespace,
        'controller' => $controller,
    ]);

    if (!$action) {
        $action = $modx->newObject('modAction');
    }

    $action->set('namespace', $namespace);
    $action->set('controller', $controller);
    $action->set('haslayout', 1);
    $action->set('lang_topics', $langTopics);

    $action->save();

    return $action;
}

function saveMenu(modX $modx, $text, $description, $actionId, $namespace = 'training')
{
    $menu = $modx->getObject('modMenu', ['text' => $text]);

    if (!$menu) {
        $menu = $modx->newObject('modMenu');
        $menu->set('text', $text);
    }

    $menu->set('description', $description);
    $menu->set('parent', 'components');
    $menu->set('action', $actionId);
    $menu->set('namespace', $namespace);
    $menu->set('menuindex', 100);
    $menu->set('icon', '');
    $menu->set('params', '');
    $menu->set('handler', '');
    $menu->set('permissions', '');

    return $menu->save();
}

echo '<pre>';

$corePath   = $modx->getOption('core_path') . 'components/training/';
$assetsPath = $modx->getOption('assets_path') . 'components/training/';
$assetsUrl  = $modx->getOption('assets_url') . 'components/training/';

echo "1. Namespace...\n";
saveNamespace($modx, 'training', '{core_path}components/training/', '{assets_path}components/training/');
echo "   OK\n\n";

echo "2. System settings...\n";
saveSystemSetting($modx, 'training.core_path', $corePath, 'textfield', 'training', 'Paths');
saveSystemSetting($modx, 'training.assets_path', $assetsPath, 'textfield', 'training', 'Paths');
saveSystemSetting($modx, 'training.assets_url', $assetsUrl, 'textfield', 'training', 'Paths');
saveSystemSetting($modx, 'training.processors_path', $corePath . 'processors/', 'textfield', 'training', 'Paths');
saveSystemSetting($modx, 'training.connector_url', $assetsUrl . 'connector.php', 'textfield', 'training', 'Paths');
saveSystemSetting($modx, 'training.files_path', $modx->getOption('assets_path') . 'training/', 'textfield', 'training', 'Files');
saveSystemSetting($modx, 'training.files_url', $modx->getOption('assets_url') . 'training/', 'textfield', 'training', 'Files');
saveSystemSetting($modx, 'training.courses_parent_id', '150', 'textfield', 'training', 'Resources');
echo "   OK\n\n";

echo "3. Cleanup old menu/action...\n";

$menuTable = $modx->getTableName('modMenu');
$actionTable = $modx->getTableName('modAction');

/*
 * Сначала удаляем все menu этого namespace
 */
$sql = "DELETE FROM {$menuTable} WHERE namespace = 'training'";
$modx->exec($sql);
echo "   Menus deleted\n";

/*
 * Потом удаляем actions этого namespace
 */
$sql = "DELETE FROM {$actionTable} WHERE namespace = 'training'";
$modx->exec($sql);
echo "   Actions deleted\n\n";

echo "4. Create correct action...\n";
/*
 * ВАЖНО: controller = index
 */
$action = saveAction($modx, 'training', 'index');
echo "   Action ID: " . $action->get('id') . "\n\n";

echo "5. Create correct menu...\n";
/*
 * text = lexicon key
 */
saveMenu($modx, 'training.menu', 'training.menu_desc', $action->get('id'), 'training');
echo "   OK\n\n";

echo "6. Refresh cache...\n";
$modx->cacheManager->refresh();
echo "   OK\n\n";

echo "Done\n";
echo '</pre>';