<?php
define('MODX_API_MODE', true);

$siteRoot = dirname(dirname(__DIR__)) . '/';

require_once $siteRoot . 'config.core.php';
require_once MODX_CORE_PATH . 'config/' . MODX_CONFIG_KEY . '.inc.php';
require_once MODX_CORE_PATH . 'model/modx/modx.class.php';

$modx = new modX();
$modx->initialize('mgr');

$corePath = $modx->getOption(
    'training.core_path',
    null,
    MODX_CORE_PATH . 'components/training/'
);

$modelPath = $corePath . 'model/';
$schemaFile = $modelPath . 'schema/training.mysql.schema.xml';

if (!is_file($schemaFile)) {
    exit('Schema file not found: ' . $schemaFile);
}