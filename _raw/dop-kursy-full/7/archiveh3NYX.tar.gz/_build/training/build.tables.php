<?php
require_once __DIR__ . '/bootstrap.php';

$modx->setLogLevel(modX::LOG_LEVEL_ERROR);
$modx->setLogTarget('ECHO');

$modx->addPackage('training', $modelPath);

$manager = $modx->getManager();

$classes = [
    'TrainingCourse',
    'TrainingModule',
    'TrainingModuleVideo',
    'TrainingModuleSlide',
    'TrainingCourseAccess',
    'TrainingUserCourse',
    'TrainingUserModuleProgress',
    'TrainingTestLink',
    'TrainingUserTestStatus',
];

echo '<pre>';

foreach ($classes as $class) {
    echo "Checking class: {$class}\n";

    $result = $manager->createObjectContainer($class);
    echo "  -> createObjectContainer: " . ($result ? 'OK' : 'SKIPPED/EXISTS/ERROR') . "\n\n";
}

echo "Done";
echo '</pre>';