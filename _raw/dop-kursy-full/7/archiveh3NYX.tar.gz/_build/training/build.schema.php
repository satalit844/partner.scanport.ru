<?php
require_once __DIR__ . '/bootstrap.php';

$manager = $modx->getManager();
$generator = $manager->getGenerator();

$result = $generator->parseSchema(
    $schemaFile,
    $modelPath
);

if (!$result) {
    exit('Schema parse ERROR');
}

echo 'Schema parsed successfully';