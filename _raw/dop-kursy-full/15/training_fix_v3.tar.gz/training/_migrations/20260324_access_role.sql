ALTER TABLE `modx_training_course_access`
    ADD COLUMN `access_role` VARCHAR(16) NOT NULL DEFAULT 'employee' AFTER `principal_id`;

UPDATE `modx_training_course_access`
SET `access_role` = 'employee'
WHERE `access_role` IS NULL OR `access_role` = '';

ALTER TABLE `modx_training_user_courses`
    ADD COLUMN `access_role` VARCHAR(16) NOT NULL DEFAULT 'employee' AFTER `user_id`;

UPDATE `modx_training_user_courses`
SET `access_role` = 'employee'
WHERE `access_role` IS NULL OR `access_role` = '';
