Training.combo.AccessPrincipalType = function(config) {
    config = config || {};

    Ext.applyIf(config, {
        hiddenName: config.name || 'principal_type',
        name: config.name || 'principal_type',
        fieldLabel: config.fieldLabel || 'Тип доступа',
        mode: 'local',
        editable: false,
        forceSelection: true,
        triggerAction: 'all',
        valueField: 'value',
        displayField: 'label',
        fields: ['value', 'label'],
        store: new Ext.data.ArrayStore({
            fields: ['value', 'label'],
            data: [
                ['user', 'Пользователь'],
                ['group', 'Группа']
            ]
        }),
        value: config.value || 'user',
        anchor: '100%'
    });

    Training.combo.AccessPrincipalType.superclass.constructor.call(this, config);
};
Ext.extend(Training.combo.AccessPrincipalType, MODx.combo.ComboBox);
Ext.reg('training-combo-access-principal-type', Training.combo.AccessPrincipalType);

Training.combo.AccessRole = function(config) {
    config = config || {};

    Ext.applyIf(config, {
        hiddenName: config.name || 'access_role',
        name: config.name || 'access_role',
        fieldLabel: config.fieldLabel || 'Права',
        mode: 'local',
        editable: false,
        forceSelection: true,
        triggerAction: 'all',
        valueField: 'value',
        displayField: 'label',
        fields: ['value', 'label'],
        store: new Ext.data.ArrayStore({
            fields: ['value', 'label'],
            data: [
                ['employee', 'Сотрудник'],
                ['director', 'Директор']
            ]
        }),
        value: config.value || 'employee',
        anchor: '100%'
    });

    Training.combo.AccessRole.superclass.constructor.call(this, config);
};
Ext.extend(Training.combo.AccessRole, MODx.combo.ComboBox);
Ext.reg('training-combo-access-role', Training.combo.AccessRole);

Training.combo.AccessUsers = function(config) {
    config = config || {};

    Ext.applyIf(config, {
        hiddenName: config.name || 'principal_user_id',
        name: config.name || 'principal_user_id',
        fieldLabel: config.fieldLabel || 'Пользователь',
        valueField: 'id',
        displayField: 'display',
        editable: true,
        forceSelection: true,
        triggerAction: 'all',
        minChars: 1,
        pageSize: 20,
        mode: 'remote',
        anchor: '100%',
        listWidth: 520,
        minListWidth: 420,
        loadingText: 'Загрузка...',
        store: new Ext.data.JsonStore({
            url: Training.config.connector_url,
            root: 'results',
            totalProperty: 'total',
            idProperty: 'id',
            fields: ['id', 'name', 'username', 'fullname', 'email', 'display'],
            baseParams: {
                action: 'mgr/course/access/users'
            }
        }),
        tpl: new Ext.XTemplate(
            '<tpl for=".">',
                '<div class="x-combo-list-item" style="white-space:normal;line-height:1.35;padding:6px 8px;">{display}</div>',
            '</tpl>'
        ),
        itemSelector: 'div.x-combo-list-item'
    });

    Training.combo.AccessUsers.superclass.constructor.call(this, config);
};
Ext.extend(Training.combo.AccessUsers, MODx.combo.ComboBox);
Ext.reg('training-combo-access-users', Training.combo.AccessUsers);

Training.combo.AccessGroups = function(config) {
    config = config || {};

    Ext.applyIf(config, {
        hiddenName: config.name || 'principal_group_id',
        name: config.name || 'principal_group_id',
        fieldLabel: config.fieldLabel || 'Группа',
        valueField: 'id',
        displayField: 'display',
        editable: true,
        forceSelection: true,
        triggerAction: 'all',
        minChars: 0,
        pageSize: 20,
        mode: 'remote',
        anchor: '100%',
        listWidth: 420,
        minListWidth: 320,
        loadingText: 'Загрузка...',
        store: new Ext.data.JsonStore({
            url: Training.config.connector_url,
            root: 'results',
            totalProperty: 'total',
            idProperty: 'id',
            fields: ['id', 'name', 'display'],
            baseParams: {
                action: 'mgr/course/access/groups'
            }
        }),
        tpl: new Ext.XTemplate(
            '<tpl for=".">',
                '<div class="x-combo-list-item" style="white-space:normal;line-height:1.35;padding:6px 8px;">{display}</div>',
            '</tpl>'
        ),
        itemSelector: 'div.x-combo-list-item'
    });

    Training.combo.AccessGroups.superclass.constructor.call(this, config);
};
Ext.extend(Training.combo.AccessGroups, MODx.combo.ComboBox);
Ext.reg('training-combo-access-groups', Training.combo.AccessGroups);

Training.window.CourseAccess = function(config) {
    config = config || {};
    this.courseId = config.courseId || Training.config.course_id;
    this.record = Ext.isObject(config.record) ? config.record : {};
    this.isUpdate = !!parseInt(this.record.id, 10);
    this.ident = config.ident || Ext.id();

    if (!this.isUpdate && typeof config.record !== 'undefined') {
        delete config.record;
    }

    Ext.applyIf(config, {
        title: this.isUpdate ? 'Редактирование доступа' : 'Добавление доступа',
        width: 620,
        autoHeight: true,
        url: Training.config.connector_url,
        action: this.isUpdate ? 'mgr/course/access/update' : 'mgr/course/access/create',
        labelWidth: 130,
        fields: [{
            xtype: 'hidden',
            name: 'id',
            value: this.isUpdate ? (parseInt(this.record.id, 10) || '') : ''
        }, {
            xtype: 'hidden',
            name: 'course_id',
            value: this.courseId
        }, {
            xtype: 'training-combo-access-principal-type',
            name: 'principal_type',
            value: this.record.principal_type || 'user',
            listeners: {
                select: {
                    fn: this.togglePrincipalFields,
                    scope: this
                }
            }
        }, {
            xtype: 'training-combo-access-role',
            name: 'access_role',
            value: this.record.access_role || 'employee'
        }, {
            xtype: 'training-combo-access-users',
            name: 'principal_user_id',
            fieldLabel: 'Пользователь',
            id: this.ident + '-user-field'
        }, {
            xtype: 'training-combo-access-groups',
            name: 'principal_group_id',
            fieldLabel: 'Группа',
            hidden: true,
            id: this.ident + '-group-field'
        }, {
            xtype: 'hidden',
            name: 'principal_id',
            value: this.record.principal_id || 0
        }, {
            xtype: 'xdatetime',
            fieldLabel: 'Активно с',
            name: 'active_from',
            anchor: '100%'
        }, {
            xtype: 'xdatetime',
            fieldLabel: 'Активно до',
            name: 'active_to',
            anchor: '100%'
        }, {
            xtype: 'xcheckbox',
            boxLabel: 'Активно',
            hideLabel: true,
            name: 'is_active',
            checked: typeof this.record.is_active !== 'undefined' ? Training.utils.toBool(this.record.is_active) : true
        }],
        keys: [{
            key: Ext.EventObject.ENTER,
            shift: true,
            fn: function() {
                this.submit();
            },
            scope: this
        }],
        listeners: {
            success: {
                fn: function() {
                    var grid = Ext.getCmp('training-grid-course-access');
                    if (grid) {
                        grid.refresh();
                        grid.updateActionButtons();
                    }
                },
                scope: this
            }
        }
    });

    Training.window.CourseAccess.superclass.constructor.call(this, config);
    this.on('afterrender', this.applyRecord, this);
};
Ext.extend(Training.window.CourseAccess, MODx.Window, {
    getUserField: function() {
        return Ext.getCmp(this.ident + '-user-field');
    },

    getGroupField: function() {
        return Ext.getCmp(this.ident + '-group-field');
    },

    applyRecord: function() {
        var form = this.fp ? this.fp.getForm() : null;
        if (!form) {
            return;
        }

        form.findField('course_id').setValue(this.courseId);
        Training.utils.setCheckboxValue(form, 'is_active', typeof this.record.is_active !== 'undefined' ? this.record.is_active : 1);

        if (!this.isUpdate) {
            form.findField('principal_type').setValue('user');
            form.findField('access_role').setValue('employee');
            form.findField('principal_id').setValue(0);
            this.togglePrincipalFields();
            return;
        }

        form.setValues(this.record);
        this.togglePrincipalFields();

        if (String(this.record.principal_type) === 'group') {
            var groupField = this.getGroupField();
            if (groupField) {
                groupField.setValue(this.record.principal_id);
                groupField.setRawValue(this.record.principal_label || this.record.principal_name || '');
            }
            if (form.findField('principal_group_id')) {
                form.findField('principal_group_id').setValue(this.record.principal_id);
            }
        } else {
            var userField = this.getUserField();
            if (userField) {
                userField.setValue(this.record.principal_id);
                userField.setRawValue(this.record.principal_label || this.record.principal_name || '');
            }
            if (form.findField('principal_user_id')) {
                form.findField('principal_user_id').setValue(this.record.principal_id);
            }
        }

        form.findField('principal_id').setValue(this.record.principal_id || 0);
    },

    togglePrincipalFields: function() {
        var form = this.fp ? this.fp.getForm() : null;
        if (!form) {
            return;
        }

        var typeField = form.findField('principal_type');
        var type = typeField ? String(typeField.getValue() || 'user') : 'user';
        var userField = this.getUserField();
        var groupField = this.getGroupField();
        var userHidden = form.findField('principal_user_id');
        var groupHidden = form.findField('principal_group_id');

        if (type === 'group') {
            if (userField) {
                userField.hide();
                userField.clearValue();
            }
            if (userHidden) {
                userHidden.setValue('');
            }
            if (groupField) {
                groupField.show();
            }
        } else {
            if (groupField) {
                groupField.hide();
                groupField.clearValue();
            }
            if (groupHidden) {
                groupHidden.setValue('');
            }
            if (userField) {
                userField.show();
            }
        }

        this.doLayout();
    },

    submit: function(close) {
        var form = this.fp ? this.fp.getForm() : null;
        if (!form || !form.isValid()) {
            return false;
        }

        var type = String(form.findField('principal_type').getValue() || 'user');
        var principalId = 0;

        if (type === 'group') {
            principalId = parseInt(form.findField('principal_group_id').getValue(), 10) || 0;
        } else {
            principalId = parseInt(form.findField('principal_user_id').getValue(), 10) || 0;
        }

        if (!principalId) {
            MODx.msg.alert('Ошибка', type === 'group' ? 'Не выбрана группа' : 'Не выбран пользователь');
            return false;
        }

        form.findField('principal_id').setValue(principalId);
        form.findField('course_id').setValue(this.courseId);

        return Training.window.CourseAccess.superclass.submit.call(this, close);
    }
});
Ext.reg('training-window-course-access', Training.window.CourseAccess);

Training.grid.CourseAccess = function(config) {
    config = config || {};
    this.courseId = config.courseId || Training.config.course_id;
    this.selectionModel = new Ext.grid.RowSelectionModel({singleSelect: true});
    this.gridIdent = config.id || 'training-grid-course-access';

    Ext.applyIf(config, {
        id: this.gridIdent,
        sm: this.selectionModel,
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/course/access/getlist',
            course_id: this.courseId
        },
        paging: true,
        remoteSort: true,
        autoHeight: true,
        anchor: '100%',
        fields: [
            'id',
            'course_id',
            'principal_type',
            'principal_type_label',
            'principal_id',
            'principal_name',
            'principal_label',
            'access_role',
            'access_role_label',
            'assigned_by',
            'assigned_by_label',
            'active_from',
            'active_to',
            'is_active',
            'is_active_now',
            'createdon'
        ],
        columns: [{
            header: 'ID',
            dataIndex: 'id',
            width: 60
        }, {
            header: 'Тип',
            dataIndex: 'principal_type_label',
            width: 100
        }, {
            header: 'Кому',
            dataIndex: 'principal_label',
            width: 320
        }, {
            header: 'Права',
            dataIndex: 'access_role_label',
            width: 110
        }, {
            header: 'Активно',
            dataIndex: 'is_active',
            width: 80,
            renderer: Training.utils.renderBoolean
        }, {
            header: 'Действует сейчас',
            dataIndex: 'is_active_now',
            width: 120,
            renderer: Training.utils.renderBoolean
        }, {
            header: 'С',
            dataIndex: 'active_from',
            width: 140
        }, {
            header: 'По',
            dataIndex: 'active_to',
            width: 140
        }, {
            header: 'Назначил',
            dataIndex: 'assigned_by_label',
            width: 180
        }, {
            header: 'Создано',
            dataIndex: 'createdon',
            width: 140
        }],
        tbar: [{
            text: 'Добавить доступ',
            handler: this.createAccess,
            scope: this
        }, {
            text: 'Редактировать',
            itemId: 'btnUpdateAccess',
            disabled: true,
            handler: this.updateAccess,
            scope: this
        }, {
            text: 'Удалить',
            itemId: 'btnRemoveAccess',
            disabled: true,
            handler: this.removeAccess,
            scope: this
        }, '-', {
            text: 'Синхронизировать пользователей',
            handler: this.syncUsers,
            scope: this
        }, '->', {
            xtype: 'textfield',
            emptyText: 'Поиск',
            listeners: {
                render: {
                    fn: function(cmp) {
                        cmp.getEl().addKeyListener(Ext.EventObject.ENTER, function() {
                            this.getStore().baseParams.query = cmp.getValue();
                            this.getBottomToolbar().changePage(1);
                        }, this);
                    },
                    scope: this
                }
            }
        }, {
            text: 'Сброс',
            handler: function(btn) {
                var grid = this;
                var field = btn.ownerCt.items.get(btn.ownerCt.items.length - 2);
                if (field) {
                    field.setValue('');
                }
                grid.getStore().baseParams.query = '';
                grid.getBottomToolbar().changePage(1);
            },
            scope: this
        }],
        listeners: {
            rowclick: {
                fn: function() {
                    this.updateActionButtons();
                },
                scope: this
            },
            rowdblclick: {
                fn: function(grid, rowIndex) {
                    var rec = grid.store.getAt(rowIndex);
                    if (rec) {
                        this.updateAccess(rec);
                    }
                },
                scope: this
            },
            rowcontextmenu: {
                fn: function(grid, rowIndex, e) {
                    var rec = grid.store.getAt(rowIndex);
                    if (rec) {
                        grid.getSelectionModel().selectRow(rowIndex);
                        this.updateActionButtons();
                        this.menu.record = rec;
                        this.getMenu(e);
                    }
                },
                scope: this
            },
            cellclick: {
                fn: function(grid, rowIndex, columnIndex) {
                    var rec = grid.store.getAt(rowIndex);
                    var cm = grid.getColumnModel();
                    var dataIndex = cm.getDataIndex(columnIndex);
                    if (rec && dataIndex === 'is_active') {
                        this.toggleActive(rec);
                    }
                },
                scope: this
            }
        }
    });

    Training.grid.CourseAccess.superclass.constructor.call(this, config);
    this.getStore().on('load', this.updateActionButtons, this);

    var sm = this.getSelectionModel ? this.getSelectionModel() : this.selectionModel;
    if (sm && sm.on) {
        sm.on('selectionchange', this.updateActionButtons, this);
    }

    this.on('render', this.updateActionButtons, this);
};
Ext.extend(Training.grid.CourseAccess, MODx.grid.Grid, {
    getCurrentRecord: function(rec) {
        return rec || (this.menu && this.menu.record ? this.menu.record : this.getSelectionModel().getSelected());
    },

    updateActionButtons: function() {
        var hasSelection = !!this.getCurrentRecord();
        var toolbar = this.getTopToolbar ? this.getTopToolbar() : null;
        if (!toolbar || !toolbar.items) {
            return;
        }
        var btnUpdate = toolbar.getComponent('btnUpdateAccess');
        var btnRemove = toolbar.getComponent('btnRemoveAccess');
        if (btnUpdate) {
            btnUpdate.setDisabled(!hasSelection);
        }
        if (btnRemove) {
            btnRemove.setDisabled(!hasSelection);
        }
    },

    getMenu: function() {
        var m = [];
        var rec = this.getCurrentRecord();
        if (!rec) {
            return false;
        }

        m.push({
            text: 'Редактировать доступ',
            handler: function() {
                this.updateAccess(rec);
            },
            scope: this
        });

        m.push({
            text: Training.utils.toBool(rec.data.is_active) ? 'Выключить' : 'Включить',
            handler: function() {
                this.toggleActive(rec);
            },
            scope: this
        });

        m.push('-');
        m.push({
            text: 'Удалить',
            handler: function() {
                this.removeAccess(rec);
            },
            scope: this
        });

        this.addContextMenuItem(m);
        return true;
    },

    createAccess: function() {
        var w = MODx.load({
            xtype: 'training-window-course-access',
            courseId: this.courseId,
            ident: Ext.id()
        });
        w.show();
    },

    updateAccess: function(rec) {
        rec = this.getCurrentRecord(rec);
        if (!rec) {
            MODx.msg.alert('Внимание', 'Сначала выбери запись доступа');
            return false;
        }

        var w = MODx.load({
            xtype: 'training-window-course-access',
            courseId: this.courseId,
            ident: Ext.id(),
            record: rec.data || rec
        });
        w.show();
    },

    toggleActive: function(rec) {
        rec = this.getCurrentRecord(rec);
        if (!rec) {
            return false;
        }

        var values = Ext.apply({}, rec.data || rec);
        values.action = 'mgr/course/access/update';
        values.course_id = this.courseId;
        values.is_active = Training.utils.toBool(values.is_active) ? 0 : 1;

        this.getEl().mask('Сохраняем доступ...');
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: values,
            listeners: {
                success: {
                    fn: function() {
                        this.getEl().unmask();
                        this.refresh();
                    },
                    scope: this
                },
                failure: {
                    fn: function(r) {
                        this.getEl().unmask();
                        MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось сохранить доступ');
                    },
                    scope: this
                }
            }
        });
    },

    removeAccess: function(rec) {
        rec = this.getCurrentRecord(rec);
        var ids = [];
        if (rec) {
            ids = [Training.utils.getRecordValue(rec, 'id')];
        }
        if (!ids.length) {
            MODx.msg.alert('Внимание', 'Сначала выбери запись доступа');
            return false;
        }

        MODx.msg.confirm({
            title: 'Удаление',
            text: 'Удалить выбранный доступ?',
            url: Training.config.connector_url,
            params: {
                action: 'mgr/course/access/remove',
                ids: ids.join(',')
            },
            listeners: {
                success: {
                    fn: function() {
                        this.refresh();
                        this.updateActionButtons();
                    },
                    scope: this
                }
            }
        });
    },

    syncUsers: function() {
        this.getEl().mask('Синхронизируем пользователей...');
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/course/access/syncusers',
                course_id: this.courseId
            },
            listeners: {
                success: {
                    fn: function(r) {
                        this.getEl().unmask();
                        this.refresh();
                        this.updateActionButtons();
                        var data = Training.utils.getResultData(r) || {};
                        MODx.msg.alert(
                            'Готово',
                            'Синхронизация обновляет таблицу training_user_courses по текущим активным доступам.<br><br>' +
                            'Создано: ' + (data.created || 0) + '<br>Обновлено: ' + (data.updated || 0) + '<br>Отозвано: ' + (data.deactivated || 0)
                        );
                    },
                    scope: this
                },
                failure: {
                    fn: function(r) {
                        this.getEl().unmask();
                        MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось синхронизировать пользователей');
                    },
                    scope: this
                }
            }
        });
    }
});
Ext.reg('training-grid-course-access', Training.grid.CourseAccess);
