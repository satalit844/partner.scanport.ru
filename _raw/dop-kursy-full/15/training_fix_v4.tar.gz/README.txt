Заменить файл:
training/js/mgr/widgets/course.access.grid.js

После замены:
1. Очистить кэш MODX
2. Жестко обновить страницу менеджера

Исправление:
- ошибка this.sm.on / Cannot read properties of undefined (reading 'on')
- начальное обновление состояний кнопок после рендера грида
