$(document).ready(function () {
    $('body')
        .off('submit.UserTestAjax', '#UserTestForm')
        .on('submit.UserTestAjax', '#UserTestForm', function (e) {
            e.preventDefault();

            var form = $(this);
            if (form.data('ut-submitting')) {
                return false;
            }

            if (!validate_question() || !validate_ask()) {
                return false;
            }

            form.data('ut-submitting', 1);

            $.ajax({
                type: 'POST',
                url: typeof UserTestActionUrl !== 'undefined' ? UserTestActionUrl : form.attr('action'),
                dataType: 'json',
                data: form.serialize(),
                beforeSend: function () {
                    form.find('input[type="submit"], button[type="submit"]').prop('disabled', true);
                },
                success: function (data) {
                    if (!data || !data.success) {
                        alert(data && data.message ? data.message : 'Ошибка сохранения ответа');
                        return;
                    }

                    var parsed = $.parseHTML(data.html, document, true);
                    var $doc = $('<div>').append(parsed);
                    var $newMain = $doc.find('#testuser-main').first();

                    if ($newMain.length) {
                        $('#testuser-main').replaceWith($newMain);
                    } else {
                        $('#testuser-main').replaceWith(data.html);
                    }

                    var $newModal = $doc.find('#testListModal').first();
                    if ($newModal.length) {
                        var $modalInsideMain = $('#testuser-main #testListModal').first();
                        if ($modalInsideMain.length) {
                            $('#testListModal').not($modalInsideMain).remove();
                        } else {
                            $('#testListModal').remove();
                            $('body').append($newModal);
                        }
                    } else {
                        $('#testListModal').remove();
                    }

                    var $testMain = $('#testuser-main');
                    usertestSyncQuestionCounter($testMain.length ? $testMain : $doc);

                    if (window.AppTraining && typeof window.AppTraining.testListModal === 'function') {
                        window.AppTraining.testListModal();
                    }

                    if ($testMain.length && $testMain.offset()) {
                        $('html, body').animate({ scrollTop: $testMain.offset().top }, 300);
                    }

                    if (typeof window.CustomEvent === 'function') {
                        document.dispatchEvent(new CustomEvent('usertest:updated', {
                            detail: {
                                html: data.html
                            }
                        }));
                    }

                    var ctx = document.getElementById('chart-area');
                    if (ctx && typeof Chart !== 'undefined' && typeof config !== 'undefined') {
                        window.myPie = new Chart(ctx.getContext('2d'), config);
                    }
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    alert(xhr.status);
                    alert(thrownError);
                },
                complete: function () {
                    form.data('ut-submitting', 0);
                    form.find('input[type="submit"], button[type="submit"]').prop('disabled', false);
                }
            });

            return false;
        });

    usertestSyncQuestionCounter($('#testuser-main'));
});


function usertestSyncQuestionCounter($source) {
    var label = '';
    var number = 0;
    var count = 0;
    var $src = $source && $source.length ? $source : $(document);
    var $meta = $src.find('.js-ut-question-meta').first();
    var $form = $src.find('#UserTestForm').first();

    if ($meta.length) {
        label = $.trim($meta.attr('data-label') || '');
        number = parseInt($meta.attr('data-number') || 0, 10) || 0;
        count = parseInt($meta.attr('data-count') || 0, 10) || 0;
    }

    if (!label && $form.length) {
        label = $.trim($form.attr('data-question-label') || '');
        number = parseInt($form.attr('data-question-number') || 0, 10) || 0;
        count = parseInt($form.attr('data-question-count') || 0, 10) || 0;
    }

    if (!label && number > 0 && count > 0) {
        label = 'Вопрос ' + number + '/' + count;
    }

    if (!label) {
        return;
    }

    $('.js-ut-question-counter, .test-step-box').each(function () {
        $(this).text(label).attr('data-number', number).attr('data-count', count);
    });
}

function validate_question() {
    var validate = true;
    $('.error').remove();

    $('.question.validate').each(function () {
        var $question = $(this);
        var typeId = parseInt($question.data('type_id'), 10) || 0;
        var needError = false;

        switch (typeId) {
            case 1:
            case 12:
                needError = $question.find('input:radio:checked').length === 0;
                break;

            case 2:
                needError = $question.find('input:checkbox:checked').length === 0;
                break;

            case 3:
            case 4:
                needError = $.trim($question.find('input, textarea').first().val() || '') === '';
                break;

            case 9:
                $question.find('select').each(function () {
                    if ($(this).val() == 0) {
                        needError = true;
                    }
                });
                break;
        }

        if (needError) {
            validate = false;
            $question.append('<div class="w-100 m-0 p-0"></div><p class="error mt-2"><span class="text-danger py-2 px-3 badge rounded-pill text-bg-danger fw-normal">На этот вопрос требуется ответ!</span></p>');
        }
    });

    return validate;
}

function validate_ask() {
    var validate = true;
    $('.ask.validate').each(function () {
        var $ask = $(this);
        if ($.trim($ask.find('input').first().val() || '') === '') {
            validate = false;
            $ask.append('<span class="error text-danger py-2 px-3 badge rounded-pill text-bg-danger fw-normal">Это поле требуется!</span>');
        }
    });
    return validate;
}
