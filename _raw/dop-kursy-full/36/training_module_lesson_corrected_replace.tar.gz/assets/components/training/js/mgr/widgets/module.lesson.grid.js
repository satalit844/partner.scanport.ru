Training.grid.ModuleLessons = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;
    this.courseId = config.courseId || Training.config.course_id;
    this.currentLessonId = config.currentLessonId || 0;
    this.sm = new Ext.grid.CheckboxSelectionModel();

    Ext.applyIf(config, {
        id: 'training-grid-module-lessons',
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/module/lessons/getlist',
            module_id: this.moduleId
        },
        sm: this.sm,
        fields: [
            'id', 'module_id', 'title', 'sort_order', 'source_video', 'video_status', 'presentation_status',
            'duration_seconds', 'videos_count', 'slides_count', 'is_default', 'is_active'
        ],
        paging: true,
        remoteSort: true,
        sortBy: 'sort_order',
        sortDir: 'ASC',
        autoHeight: true,
        anchor: '100%',
        columns: [
            this.sm,
            {header: 'ID', dataIndex: 'id', width: 50},
            {header: 'Порядок', dataIndex: 'sort_order', width: 70},
            {header: 'Урок', dataIndex: 'title', width: 260},
            {header: 'Исходное видео', dataIndex: 'source_video', width: 320, renderer: Training.utils.renderFileLink},
            {header: 'Видео', dataIndex: 'video_status', width: 80},
            {header: 'Слайды', dataIndex: 'presentation_status', width: 80},
            {header: 'Качества', dataIndex: 'videos_count', width: 70},
            {header: 'Слайдов', dataIndex: 'slides_count', width: 70},
            {header: 'По умолчанию', dataIndex: 'is_default', width: 95, renderer: Training.utils.renderBoolean},
            {header: 'Активен', dataIndex: 'is_active', width: 80, renderer: Training.utils.renderBoolean}
        ],
        tbar: [{
            text: 'Добавить урок',
            handler: function() { this.createLesson(); },
            scope: this
        }, {
            text: 'Открыть урок',
            handler: function() { this.openLesson(); },
            scope: this
        }, {
            text: 'Изменить',
            handler: function() { this.updateLesson(); },
            scope: this
        }, {
            text: 'Удалить',
            handler: function() { this.removeLesson(); },
            scope: this
        }, '->', {
            text: 'Обновить',
            handler: function() { this.refresh(); },
            scope: this
        }],
        listeners: {
            rowclick: {
                fn: function(grid, rowIndex) {
                    var rec = grid.store.getAt(rowIndex);
                    this.selectLesson(rec);
                },
                scope: this
            },
            rowdblclick: {
                fn: function(grid, rowIndex) {
                    var rec = grid.store.getAt(rowIndex);
                    if (rec) {
                        this.openLesson(rec);
                    }
                },
                scope: this
            },
            rowcontextmenu: {
                fn: function(grid, rowIndex, e) {
                    var rec = grid.store.getAt(rowIndex);
                    if (!rec) {
                        return;
                    }
                    grid.getSelectionModel().selectRow(rowIndex);
                    this.menu.record = rec;
                    this.getMenu();
                    if (this.menu) {
                        this.menu.showAt(e.getXY());
                    }
                    e.stopEvent();
                },
                scope: this
            },
            cellclick: {
                fn: function(grid, rowIndex, colIndex) {
                    var rec = grid.store.getAt(rowIndex);
                    if (!rec) {
                        return;
                    }
                    var dataIndex = grid.getColumnModel().getDataIndex(colIndex);
                    if (dataIndex === 'is_active') {
                        this.quickUpdate(rec, {is_active: rec.get('is_active') ? 0 : 1});
                    } else if (dataIndex === 'is_default') {
                        if (!rec.get('is_default')) {
                            this.quickUpdate(rec, {is_default: 1});
                        }
                    }
                },
                scope: this
            }
        }
    });

    Training.grid.ModuleLessons.superclass.constructor.call(this, config);

    var sm = this.getSelectionModel();
    if (sm) {
        sm.on('rowselect', function(selectionModel, rowIndex, rec) {
            this.selectLesson(rec);
        }, this);
    }

    this.getStore().on('beforeload', function() {
        if (this.menu) {
            this.menu.record = null;
        }
    }, this);

    this.getStore().on('load', function(store) {
        var rec = null;
        if (this.currentLessonId > 0) {
            rec = store.getById ? store.getById(this.currentLessonId) : null;
            if (!rec && store.each) {
                store.each(function(item) {
                    if (!rec && parseInt(item.get('id'), 10) === parseInt(this.currentLessonId, 10)) {
                        rec = item;
                    }
                }, this);
            }
        }
        if (!rec && store.getCount() > 0) {
            rec = store.getAt(0);
        }
        if (rec) {
            this.getSelectionModel().selectRecords([rec]);
            this.selectLesson(rec);
        }
    }, this);
};

Ext.extend(Training.grid.ModuleLessons, MODx.grid.Grid, {
    getSelectedLessonIds: function() {
        var ids = [];
        if (typeof this._getSelectedIds === 'function') {
            var selected = this._getSelectedIds();
            if (Ext.isArray(selected) && selected.length) {
                return selected;
            }
            if (typeof selected === 'string' && selected.length) {
                return selected.split(',');
            }
        }
        var sm = this.getSelectionModel ? this.getSelectionModel() : this.sm;
        if (sm && sm.getSelections) {
            Ext.each(sm.getSelections(), function(rec) {
                var id = parseInt(rec.get ? rec.get('id') : rec.id, 10) || 0;
                if (id) {
                    ids.push(id);
                }
            });
        }
        if (!ids.length && this.menu && this.menu.record) {
            var menuId = parseInt(Training.utils.getRecordValue(this.menu.record, 'id'), 10) || 0;
            if (menuId) {
                ids.push(menuId);
            }
        }
        return ids;
    },

    getSelectedRecord: function() {
        var sm = this.getSelectionModel();
        var selected = sm && sm.getSelections ? sm.getSelections() : [];
        if (selected && selected.length) {
            return selected[0];
        }
        if (this.menu && this.menu.record) {
            return this.menu.record;
        }
        var ids = this.getSelectedLessonIds();
        if (!ids.length || !this.store) {
            return null;
        }
        var id = parseInt(ids[0], 10) || 0;
        var rec = this.store.getById ? this.store.getById(id) : null;
        if (!rec && this.store.each) {
            this.store.each(function(item) {
                if (!rec && parseInt(item.get('id'), 10) === id) {
                    rec = item;
                }
            });
        }
        return rec;
    },

    selectLesson: function(rec) {
        if (rec) {
            this.currentLessonId = parseInt(rec.get('id'), 10) || 0;
        }
        if (this.menu) {
            this.menu.record = null;
        }
    },

    openLesson: function(rec) {
        rec = rec || this.getSelectedRecord();
        if (!rec) {
            MODx.msg.alert('Внимание', 'Выбери урок');
            return false;
        }

        var lessonId = parseInt(Training.utils.getRecordValue(rec, 'id'), 10) || 0;
        if (!lessonId) {
            return false;
        }

        window.location.href = Training.utils.buildUrl({
            course_id: this.courseId,
            module_id: this.moduleId,
            lesson_id: lessonId
        });
        return true;
    },

    quickUpdate: function(rec, patch) {
        rec = rec || this.getSelectedRecord();
        if (!rec) {
            return false;
        }
        var data = Ext.apply({}, rec.data || rec);
        data.action = 'mgr/module/lesson/update';
        data.id = parseInt(data.id, 10) || 0;
        data.module_id = parseInt(data.module_id, 10) || this.moduleId;
        data.title = data.title || 'Урок';
        data.sort_order = parseInt(data.sort_order, 10) || 1;
        data.is_default = data.is_default ? 1 : 0;
        data.is_active = data.is_active ? 1 : 0;
        Ext.apply(data, patch || {});

        this.getEl().mask('Сохраняем...');
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: data,
            listeners: {
                success: {
                    fn: function() {
                        this.getEl().unmask();
                        this.currentLessonId = data.id;
                        this.refresh();
                    },
                    scope: this
                },
                failure: {
                    fn: function(r) {
                        this.getEl().unmask();
                        MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось сохранить урок');
                    },
                    scope: this
                }
            }
        });
        return true;
    },

    createLesson: function() {
        var w = MODx.load({
            xtype: 'training-window-module-lesson',
            title: 'Добавить урок',
            baseParams: {action: 'mgr/module/lesson/create'},
            moduleId: this.moduleId,
            listeners: {success: {fn: function() { this.refresh(); }, scope: this}}
        });
        w.setValues({module_id: this.moduleId, is_active: 1, is_default: 0});
        w.show();
    },

    updateLesson: function(rec) {
        rec = rec || this.getSelectedRecord();
        if (!rec) {
            MODx.msg.alert('Внимание', 'Выбери урок');
            return false;
        }
        var recordData = rec.data || rec;
        var w = MODx.load({
            xtype: 'training-window-module-lesson',
            title: 'Изменить урок',
            baseParams: {action: 'mgr/module/lesson/update'},
            moduleId: this.moduleId,
            listeners: {success: {fn: function() {
                this.currentLessonId = parseInt(recordData.id, 10) || 0;
                this.refresh();
            }, scope: this}}
        });
        w.show();
        w.setValues(recordData);
    },

    removeLesson: function(rec) {
        var ids = [];
        if (rec) {
            ids = [Training.utils.getRecordValue(rec, 'id')];
        } else {
            ids = this.getSelectedLessonIds();
        }
        var cleanIds = [];
        Ext.each(ids, function(item) {
            item = parseInt(item, 10) || 0;
            if (item) {
                cleanIds.push(item);
            }
        });
        ids = cleanIds;
        if (!ids.length) {
            MODx.msg.alert('Внимание', 'Выбери урок');
            return false;
        }
        MODx.msg.confirm({
            title: 'Удаление',
            text: ids.length > 1 ? 'Удалить выбранные уроки и все их видео/слайды?' : 'Удалить урок и все его видео/слайды?',
            url: Training.config.connector_url,
            params: {action: 'mgr/module/lesson/remove', ids: ids.join(',')},
            listeners: {success: {fn: function() {
                if (ids.length === 1 && this.currentLessonId === parseInt(ids[0], 10)) {
                    this.currentLessonId = 0;
                }
                this.refresh();
            }, scope: this}}
        });
    },

    getMenu: function() {
        var rec = this.menu && this.menu.record ? this.menu.record : this.getSelectedRecord();
        if (!rec) {
            return false;
        }
        this.addContextMenuItem([{
            text: 'Открыть урок',
            handler: function() { this.openLesson(rec); },
            scope: this
        }, {
            text: 'Изменить',
            handler: function() { this.updateLesson(rec); },
            scope: this
        }, {
            text: 'Удалить',
            handler: function() { this.removeLesson(rec); },
            scope: this
        }, '-', {
            text: Training.utils.getRecordValue(rec, 'is_active') ? 'Отключить' : 'Включить',
            handler: function() { this.quickUpdate(rec, {is_active: Training.utils.getRecordValue(rec, 'is_active') ? 0 : 1}); },
            scope: this
        }, {
            text: 'Сделать по умолчанию',
            handler: function() { this.quickUpdate(rec, {is_default: 1}); },
            scope: this
        }]);
        return true;
    }
});

Ext.reg('training-grid-module-lessons', Training.grid.ModuleLessons);

Training.window.ModuleLesson = function(config) {
    config = config || {};
    this.moduleId = config.moduleId || Training.config.module_id;

    Ext.applyIf(config, {
        width: 760,
        autoHeight: true,
        url: Training.config.connector_url,
        fields: [{
            xtype: 'hidden',
            name: 'id'
        }, {
            xtype: 'hidden',
            name: 'module_id',
            value: this.moduleId
        }, {
            xtype: 'textfield',
            fieldLabel: 'Название урока',
            name: 'title',
            anchor: '100%',
            allowBlank: false
        }, {
            xtype: 'numberfield',
            fieldLabel: 'Порядок',
            name: 'sort_order',
            anchor: '100%'
        }, {
            xtype: 'button',
            text: 'Выбрать исходное видео',
            style: 'margin-bottom:10px;',
            handler: function(btn) {
                var win = btn.findParentByType('modx-window') || btn.findParentByType('window');
                var form = win && win.fp ? win.fp.getForm() : null;
                var field = form ? form.findField('source_video') : null;
                Training.utils.openPathBrowser(field, {
                    source: Training.config.media_source || 3,
                    allowedFileTypes: 'mkv,mp4,mov,avi,webm,m3u8'
                });
            }
        }, {
            xtype: 'textfield',
            fieldLabel: 'Исходное видео',
            name: 'source_video',
            anchor: '100%'
        }, {
            xtype: 'textarea',
            fieldLabel: 'Описание',
            name: 'description',
            anchor: '100%'
        }, {
            xtype: 'xcheckbox',
            boxLabel: 'Урок по умолчанию',
            hideLabel: true,
            name: 'is_default',
            inputValue: 1
        }, {
            xtype: 'xcheckbox',
            boxLabel: 'Урок активен',
            hideLabel: true,
            name: 'is_active',
            inputValue: 1,
            checked: true
        }]
    });

    Training.window.ModuleLesson.superclass.constructor.call(this, config);
};

Ext.extend(Training.window.ModuleLesson, MODx.Window);
Ext.reg('training-window-module-lesson', Training.window.ModuleLesson);
