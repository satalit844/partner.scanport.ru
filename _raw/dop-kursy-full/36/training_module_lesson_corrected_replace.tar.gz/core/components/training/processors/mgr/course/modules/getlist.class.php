<?php

class TrainingCourseModulesGetListProcessor extends modObjectGetListProcessor
{
    public $classKey = 'TrainingModule';
    public $objectType = 'training.module';
    public $defaultSortField = 'Resource.menuindex';
    public $defaultSortDirection = 'ASC';

    public function prepareQueryBeforeCount(xPDOQuery $c)
    {
        $courseId = (int)$this->getProperty('course_id');
        if (!$courseId) {
            $c->where(['1 = 0']);
            return $c;
        }

        $query = trim((string)$this->getProperty('query', ''));

        $c->leftJoin('modResource', 'Resource', 'Resource.id = TrainingModule.resource_id');

        $c->select($this->modx->getSelectColumns('TrainingModule', 'TrainingModule'));
        $c->select([
            'Resource.pagetitle AS title',
            'Resource.menuindex AS menuindex',
            'Resource.published AS published',
        ]);

        $c->where([
            'TrainingModule.course_id' => $courseId,
        ]);

        if ($query !== '') {
            $c->where([
                'TrainingModule.id:=' => (int)$query,
                'OR:TrainingModule.resource_id:=' => (int)$query,
                'OR:Resource.pagetitle:LIKE' => '%' . $query . '%',
            ]);
        }

        return $c;
    }

    protected function countLessons($moduleId)
    {
        return (int)$this->modx->getCount('TrainingModuleLesson', [
            'module_id' => (int)$moduleId,
        ]);
    }

    protected function countLessonsWithVideo($moduleId)
    {
        $moduleId = (int)$moduleId;
        if ($moduleId <= 0) {
            return 0;
        }

        $c = $this->modx->newQuery('TrainingModuleLesson');
        $c->innerJoin('TrainingModuleVideo', 'Video', 'Video.lesson_id = TrainingModuleLesson.id AND Video.is_active = 1');
        $c->where([
            'TrainingModuleLesson.module_id' => $moduleId,
            'TrainingModuleLesson.is_active' => 1,
        ]);
        $c->select('COUNT(DISTINCT TrainingModuleLesson.id)');

        $count = 0;
        if ($c->prepare() && $c->stmt->execute()) {
            $count = (int)$c->stmt->fetchColumn();
        }

        return $count;
    }

    public function prepareRow(xPDOObject $object)
    {
        $array = $object->toArray();
        $moduleId = (int)$array['id'];

        $array['title'] = !empty($array['title']) ? $array['title'] : '—';
        $array['published'] = (int)!empty($array['published']);
        $array['is_active'] = (int)!empty($array['is_active']);
        $array['lessons_count'] = $this->countLessons($moduleId);
        $array['videos_count'] = $this->countLessonsWithVideo($moduleId);
        $array['slides_count'] = (int)$this->modx->getCount('TrainingModuleSlide', [
            'module_id' => $moduleId,
        ]);

        return $array;
    }
}

return 'TrainingCourseModulesGetListProcessor';
