<?php

class TrainingModuleLessonGetProcessor extends modObjectGetProcessor
{
    public $classKey = 'TrainingModuleLesson';
    public $objectType = 'training.module.lesson';

    public function checkPermissions()
    {
        return true;
    }

    public function initialize()
    {
        if (!(int)$this->getProperty('id')) {
            return $this->modx->lexicon('invalid_data');
        }
        return parent::initialize();
    }

    protected function fetchResourceData($id)
    {
        $id = (int)$id;
        if ($id <= 0) {
            return null;
        }

        $resource = $this->modx->getObject('modResource', ['id' => $id]);
        if ($resource) {
            return [
                'pagetitle' => $resource->get('pagetitle'),
                'alias' => $resource->get('alias'),
                'context_key' => $resource->get('context_key'),
                'uri' => $resource->get('uri'),
                'published' => (int)$resource->get('published'),
            ];
        }

        return null;
    }

    protected function formatSeconds($seconds)
    {
        $seconds = (int)$seconds;
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        $seconds = $seconds % 60;

        return $hours > 0
            ? sprintf('%d:%02d:%02d', $hours, $minutes, $seconds)
            : sprintf('%d:%02d', $minutes, $seconds);
    }

    public function cleanup()
    {
        $array = $this->object->toArray();
        $lessonId = (int)$array['id'];
        $moduleId = (int)$array['module_id'];

        /** @var TrainingModule $module */
        $module = $this->modx->getObject('TrainingModule', ['id' => $moduleId]);
        $courseId = $module ? (int)$module->get('course_id') : 0;

        $array['course_id'] = $courseId;
        $array['id_label'] = $lessonId;
        $array['module_id_label'] = $moduleId;
        $array['course_id_label'] = $courseId;
        $array['createdon'] = !empty($array['createdon']) ? $array['createdon'] : '—';
        $array['updatedon'] = !empty($array['updatedon']) ? $array['updatedon'] : '—';
        $array['video_status'] = !empty($array['video_status']) ? $array['video_status'] : 'none';
        $array['presentation_status'] = !empty($array['presentation_status']) ? $array['presentation_status'] : 'none';
        $array['duration_human'] = $this->formatSeconds((int)$array['duration_seconds']);
        $array['videos_count'] = (int)$this->modx->getCount('TrainingModuleVideo', ['lesson_id' => $lessonId]);
        $array['slides_count'] = (int)$this->modx->getCount('TrainingModuleSlide', ['lesson_id' => $lessonId]);
        $array['is_default'] = (int)!empty($array['is_default']);
        $array['is_active'] = (int)!empty($array['is_active']);

        $array['module_title'] = '—';
        $array['module_resource_id'] = $module ? (int)$module->get('resource_id') : 0;
        $array['course_title'] = '—';

        if ($module) {
            $moduleResource = $this->fetchResourceData((int)$module->get('resource_id'));
            if ($moduleResource && !empty($moduleResource['pagetitle'])) {
                $array['module_title'] = $moduleResource['pagetitle'];
            }

            /** @var TrainingCourse $course */
            $course = $this->modx->getObject('TrainingCourse', ['id' => $courseId]);
            if ($course) {
                $courseResource = $this->fetchResourceData((int)$course->get('resource_id'));
                if ($courseResource && !empty($courseResource['pagetitle'])) {
                    $array['course_title'] = $courseResource['pagetitle'];
                }
            }
        }

        return $this->success('', $array);
    }
}

return 'TrainingModuleLessonGetProcessor';
