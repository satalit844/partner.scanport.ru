Training.panel.LessonTabs = function(config) {
    config = config || {};

    this.lessonId = config.lessonId || Training.config.lesson_id;
    this.moduleId = config.moduleId || Training.config.module_id;
    this.courseId = config.courseId || Training.config.course_id;

    Ext.apply(config, {
        id: 'training-lesson-tabs',
        border: true,
        deferredRender: false,
        defaults: {
            border: false,
            autoHeight: true
        },
        items: [{
            title: 'Общие',
            xtype: 'training-lesson-general-form',
            lessonId: this.lessonId,
            moduleId: this.moduleId,
            courseId: this.courseId
        }, {
            title: 'Видео урока',
            xtype: 'training-grid-module-videos',
            moduleId: this.moduleId,
            lessonId: this.lessonId,
            anchor: '100%'
        }, {
            title: 'Слайды урока',
            xtype: 'training-grid-module-slides',
            moduleId: this.moduleId,
            lessonId: this.lessonId,
            anchor: '100%'
        }]
    });

    Training.panel.LessonTabs.superclass.constructor.call(this, config);
};

Ext.extend(Training.panel.LessonTabs, MODx.Tabs);
Ext.reg('training-lesson-tabs', Training.panel.LessonTabs);


Training.form.LessonGeneral = function(config) {
    config = config || {};
    this.lessonId = config.lessonId || Training.config.lesson_id;
    this.moduleId = config.moduleId || Training.config.module_id;
    this.courseId = config.courseId || Training.config.course_id;

    Ext.apply(config, {
        id: 'training-lesson-general-form',
        url: Training.config.connector_url,
        baseParams: {
            action: 'mgr/module/lesson/update'
        },
        bodyCssClass: 'main-wrapper',
        cls: 'container',
        labelWidth: 220,
        autoHeight: true,
        border: false,
        bodyStyle: 'padding:16px;background:#fff;border:1px solid #e5e5e5;border-radius:6px;',
        defaults: {
            anchor: '100%'
        },
        items: [{
            html: '<div style="padding:0 0 16px;color:#666;line-height:1.6;">На карточке урока редактируются урок и его медиа: исходное видео, качества и слайды. Тесты и практики остаются на уровне модуля.</div>',
            border: false
        }, {
            xtype: 'hidden',
            name: 'id',
            value: this.lessonId
        }, {
            xtype: 'hidden',
            name: 'module_id',
            value: this.moduleId
        }, {
            xtype: 'hidden',
            name: 'course_id',
            value: this.courseId
        }, {
            xtype: 'fieldset',
            title: 'Основное',
            autoHeight: true,
            defaults: {anchor: '100%'},
            items: [{
                xtype: 'displayfield',
                fieldLabel: 'ID урока',
                name: 'id_label'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'ID модуля',
                name: 'module_id_label'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'ID курса',
                name: 'course_id_label'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Курс',
                name: 'course_title'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Модуль',
                name: 'module_title'
            }, {
                xtype: 'textfield',
                fieldLabel: 'Название урока',
                name: 'title',
                allowBlank: false,
                anchor: '100%'
            }, {
                xtype: 'numberfield',
                fieldLabel: 'Порядок',
                name: 'sort_order',
                allowDecimals: false,
                allowNegative: false,
                anchor: '100%'
            }, {
                xtype: 'textarea',
                fieldLabel: 'Описание',
                name: 'description',
                anchor: '100%'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Длительность',
                name: 'duration_human'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Качеств видео',
                name: 'videos_count'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Слайдов',
                name: 'slides_count'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Статус видео',
                name: 'video_status'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Статус слайдов',
                name: 'presentation_status'
            }, {
                xtype: 'xcheckbox',
                boxLabel: 'Урок по умолчанию в модуле',
                hideLabel: true,
                name: 'is_default',
                inputValue: 1
            }, {
                xtype: 'xcheckbox',
                boxLabel: 'Урок активен',
                hideLabel: true,
                name: 'is_active',
                inputValue: 1,
                checked: true
            }]
        }, {
            xtype: 'fieldset',
            title: 'Исходное видео урока',
            autoHeight: true,
            defaults: {anchor: '100%'},
            items: [{
                xtype: 'button',
                text: 'Выбрать файл с сервера',
                style: 'margin-bottom:10px;',
                handler: function() {
                    var field = this.getForm().findField('source_video');
                    if (field) {
                        Training.utils.openPathBrowser(field, {
                            source: Training.config.media_source || 3,
                            allowedFileTypes: 'mkv,mp4,mov,avi,webm,m3u8'
                        });
                    }
                },
                scope: this
            }, {
                xtype: 'textfield',
                fieldLabel: 'Исходное видео',
                name: 'source_video',
                anchor: '100%'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Создан',
                name: 'createdon'
            }, {
                xtype: 'displayfield',
                fieldLabel: 'Обновлён',
                name: 'updatedon'
            }]
        }],
        buttons: [{
            text: 'Сохранить',
            handler: this.saveForm,
            scope: this
        }, {
            text: 'Открыть ресурс модуля',
            handler: function() {
                var form = this.getForm();
                var values = form.getValues();
                if (values.module_resource_id) {
                    MODx.loadPage('resource/update', 'id=' + values.module_resource_id);
                }
            },
            scope: this
        }, {
            text: 'Назад к модулю',
            handler: function() {
                window.location.href = Training.utils.buildUrl({
                    course_id: this.courseId,
                    module_id: this.moduleId
                }, ['lesson_id']);
            },
            scope: this
        }, {
            text: 'Назад к курсу',
            handler: function() {
                window.location.href = Training.utils.buildUrl({
                    course_id: this.courseId
                }, ['module_id', 'lesson_id']);
            },
            scope: this
        }]
    });

    Training.form.LessonGeneral.superclass.constructor.call(this, config);
    this.on('afterrender', this.loadLesson, this);
};

Ext.extend(Training.form.LessonGeneral, MODx.FormPanel, {
    loadLesson: function() {
        var form = this.getForm();
        this.getEl().mask('Загружаем урок...');
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: {
                action: 'mgr/module/lesson/get',
                id: this.lessonId
            },
            listeners: {
                success: {
                    fn: function(r) {
                        this.getEl().unmask();
                        var obj = Training.utils.getResultData(r);
                        form.setValues(obj);
                        Training.utils.setCheckboxValue(form, 'is_active', obj.is_active);
                        Training.utils.setCheckboxValue(form, 'is_default', obj.is_default);
                    },
                    scope: this
                },
                failure: {
                    fn: function(r) {
                        this.getEl().unmask();
                        MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось загрузить урок');
                    },
                    scope: this
                }
            }
        });
    },

    saveForm: function() {
        var form = this.getForm();
        if (!form.isValid()) {
            return false;
        }

        var sourceField = form.findField('source_video');
        var descriptionField = form.findField('description');
        var params = {
            action: 'mgr/module/lesson/update',
            id: this.lessonId,
            module_id: this.moduleId,
            title: form.findField('title') ? String(form.findField('title').getValue() || '').replace(/^\s+|\s+$/g, '') : '',
            description: descriptionField ? String(descriptionField.getValue() || '') : '',
            sort_order: form.findField('sort_order') ? (parseInt(form.findField('sort_order').getValue(), 10) || 1) : 1,
            source_video: sourceField ? String(sourceField.getValue() || '').replace(/^\s+|\s+$/g, '') : '',
            is_default: Training.utils.toBool(form.findField('is_default').getValue()) ? 1 : 0,
            is_active: Training.utils.toBool(form.findField('is_active').getValue()) ? 1 : 0
        };

        this.getEl().mask('Сохраняем урок...');
        MODx.Ajax.request({
            url: Training.config.connector_url,
            params: params,
            listeners: {
                success: {
                    fn: function() {
                        this.getEl().unmask();
                        this.loadLesson();
                        var videosGrid = Ext.getCmp('training-grid-module-videos');
                        if (videosGrid) {
                            videosGrid.lessonSourceVideo = params.source_video || '';
                        }
                        MODx.msg.alert('Готово', 'Урок сохранён');
                    },
                    scope: this
                },
                failure: {
                    fn: function(r) {
                        this.getEl().unmask();
                        MODx.msg.alert('Ошибка', (r && r.message) ? r.message : 'Не удалось сохранить урок');
                    },
                    scope: this
                }
            }
        });
    }
});

Ext.reg('training-lesson-general-form', Training.form.LessonGeneral);
