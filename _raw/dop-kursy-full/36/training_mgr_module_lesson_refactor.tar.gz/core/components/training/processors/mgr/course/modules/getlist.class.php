<?php

class TrainingCourseModulesGetListProcessor extends modObjectGetListProcessor
{
    public $classKey = 'TrainingModule';
    public $objectType = 'training.module';
    public $defaultSortField = 'Resource.menuindex';
    public $defaultSortDirection = 'ASC';

    public function prepareQueryBeforeCount(xPDOQuery $c)
    {
        $courseId = (int)$this->getProperty('course_id');
        if (!$courseId) {
            $c->where(['1 = 0']);
            return $c;
        }

        $query = trim((string)$this->getProperty('query', ''));

        $c->leftJoin('modResource', 'Resource', 'Resource.id = TrainingModule.resource_id');

        $c->select($this->modx->getSelectColumns('TrainingModule', 'TrainingModule'));
        $c->select([
            'Resource.pagetitle AS title',
            'Resource.menuindex AS menuindex',
            'Resource.published AS published',
        ]);

        $c->where([
            'TrainingModule.course_id' => $courseId,
        ]);

        if ($query !== '') {
            $c->where([
                'TrainingModule.id:=' => (int)$query,
                'OR:TrainingModule.resource_id:=' => (int)$query,
                'OR:Resource.pagetitle:LIKE' => '%' . $query . '%',
            ]);
        }

        return $c;
    }

    protected function countLessons($moduleId)
    {
        $moduleId = (int)$moduleId;
        if ($moduleId <= 0) {
            return 0;
        }

        return (int)$this->modx->getCount('TrainingModuleLesson', [
            'module_id' => $moduleId,
            'is_active' => 1,
        ]);
    }

    protected function countActivities($moduleId, $courseId)
    {
        $moduleId = (int)$moduleId;
        $courseId = (int)$courseId;
        if ($moduleId <= 0 || $courseId <= 0) {
            return 0;
        }

        return (int)$this->modx->getCount('TrainingTestLink', [
            'module_id' => $moduleId,
            'course_id' => $courseId,
        ]);
    }

    public function prepareRow(xPDOObject $object)
    {
        $array = $object->toArray();

        $array['title'] = !empty($array['title']) ? $array['title'] : '—';
        $array['published'] = (int)!empty($array['published']);
        $array['is_active'] = (int)!empty($array['is_active']);
        $array['lessons_count'] = $this->countLessons((int)$array['id']);
        $array['activities_count'] = $this->countActivities((int)$array['id'], (int)$array['course_id']);

        return $array;
    }
}

return 'TrainingCourseModulesGetListProcessor';
