<?php

class TrainingModuleLessonGetProcessor extends modProcessor
{
    public $objectType = 'training.module.lesson';

    public function checkPermissions()
    {
        return true;
    }

    protected function fetchResourceRow($resourceId)
    {
        $resourceId = (int)$resourceId;
        if ($resourceId <= 0) {
            return null;
        }

        /** @var modResource|null $resource */
        $resource = $this->modx->getObject('modResource', ['id' => $resourceId]);
        if ($resource) {
            return [
                'resource_id' => $resourceId,
                'pagetitle' => (string)$resource->get('pagetitle'),
                'alias' => (string)$resource->get('alias'),
                'context_key' => (string)$resource->get('context_key'),
                'uri' => (string)$resource->get('uri'),
                'published' => (int)$resource->get('published'),
            ];
        }

        return null;
    }

    protected function formatSeconds($seconds)
    {
        $seconds = (int)$seconds;
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        $seconds = $seconds % 60;

        if ($hours > 0) {
            return sprintf('%d:%02d:%02d', $hours, $minutes, $seconds);
        }

        return sprintf('%d:%02d', $minutes, $seconds);
    }

    public function process()
    {
        $id = (int)$this->getProperty('id');
        if ($id <= 0) {
            return $this->failure('Не указан урок');
        }

        /** @var TrainingModuleLesson|null $lesson */
        $lesson = $this->modx->getObject('TrainingModuleLesson', ['id' => $id]);
        if (!$lesson) {
            return $this->failure('Урок не найден');
        }

        $array = $lesson->toArray();
        $moduleId = (int)$lesson->get('module_id');
        $courseId = 0;

        /** @var TrainingModule|null $module */
        $module = $this->modx->getObject('TrainingModule', ['id' => $moduleId]);
        $moduleResourceRow = null;
        if ($module) {
            $courseId = (int)$module->get('course_id');
            $moduleResourceRow = $this->fetchResourceRow((int)$module->get('resource_id'));
        }

        /** @var TrainingCourse|null $course */
        $course = $courseId > 0 ? $this->modx->getObject('TrainingCourse', ['id' => $courseId]) : null;
        $courseResourceRow = null;
        if ($course) {
            $courseResourceRow = $this->fetchResourceRow((int)$course->get('resource_id'));
        }

        $array['course_id'] = $courseId;
        $array['id_label'] = (int)$array['id'];
        $array['module_id_label'] = $moduleId;
        $array['course_id_label'] = $courseId;
        $array['is_default'] = (int)!empty($array['is_default']);
        $array['is_active'] = (int)!empty($array['is_active']);
        $array['video_status'] = trim((string)$array['video_status']) !== '' ? (string)$array['video_status'] : 'none';
        $array['presentation_status'] = trim((string)$array['presentation_status']) !== '' ? (string)$array['presentation_status'] : 'none';
        $array['duration_human'] = $this->formatSeconds((int)$array['duration_seconds']);
        $array['videos_count'] = (int)$this->modx->getCount('TrainingModuleVideo', ['lesson_id' => (int)$array['id']]);
        $array['slides_count'] = (int)$this->modx->getCount('TrainingModuleSlide', ['lesson_id' => (int)$array['id']]);
        $array['createdon'] = !empty($array['createdon']) ? $array['createdon'] : '—';
        $array['updatedon'] = !empty($array['updatedon']) ? $array['updatedon'] : '—';

        $array['module_title'] = $moduleResourceRow && !empty($moduleResourceRow['pagetitle'])
            ? $moduleResourceRow['pagetitle']
            : ('Модуль #' . $moduleId);
        $array['module_resource_id'] = $moduleResourceRow ? (int)$moduleResourceRow['resource_id'] : 0;
        $array['module_uri'] = $moduleResourceRow ? (string)$moduleResourceRow['uri'] : '—';
        $array['module_published_label'] = ($moduleResourceRow && !empty($moduleResourceRow['published'])) ? 'Да' : 'Нет';

        $array['course_title'] = $courseResourceRow && !empty($courseResourceRow['pagetitle'])
            ? $courseResourceRow['pagetitle']
            : ($courseId > 0 ? ('Курс #' . $courseId) : '—');

        return $this->success('', $array);
    }
}

return 'TrainingModuleLessonGetProcessor';
